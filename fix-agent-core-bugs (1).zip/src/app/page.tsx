import { redirect } from "next/navigation";

// The Learn-with-Leo app (leo/) is a local-first Vite single-file build. Its output is published
// as public/leo.html (rebuild with `cd leo && npm run build` and copy dist/ into public/).
export default function HomePage() {
  redirect("/leo.html");
}
