import path from "path";
import { defineConfig } from "vitest/config";

// Kept separate from vite.config.ts so the single-file production build is unchanged.
export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
  },
});
