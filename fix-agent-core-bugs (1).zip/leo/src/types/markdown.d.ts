/** Markdown files are bundled as their raw text via Vite's `?raw` suffix. */
declare module "*.md?raw" {
  const content: string;
  export default content;
}
