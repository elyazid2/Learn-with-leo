import { db, NOTE_VERSION_LIMIT, type Note, type NoteVersion } from "./db";

/** The note's saved versions, oldest first. A legacy `previousContent` counts as one version. */
export function listVersions(note: Pick<Note, "versions" | "previousContent" | "title" | "updatedAt">): NoteVersion[] {
  if (note.versions) return note.versions;
  if (note.previousContent !== undefined) return [{ title: note.title, content: note.previousContent, at: note.updatedAt, replacedBy: "ai" }];
  return [];
}

/** The version list after the current content is pushed (before an edit replaces it), capped at NOTE_VERSION_LIMIT. */
export function versionsWithCurrent(note: Note, replacedBy: NoteVersion["replacedBy"], now = Date.now()): NoteVersion[] {
  return [...listVersions(note), { title: note.title, content: note.content, at: now, replacedBy }].slice(-NOTE_VERSION_LIMIT);
}

/**
 * Put the most recent saved version back as the note's content (undo of Leo's last edit). The
 * version is removed from the stack, so pressing it again walks further back. Title is kept so
 * wikilinks pointing at the note stay valid. Returns false when there is nothing to restore.
 */
export async function restorePreviousVersion(noteId: string): Promise<boolean> {
  const note = await db.notes.get(noteId);
  if (!note) return false;
  const versions = listVersions(note);
  const prev = versions[versions.length - 1];
  if (!prev) return false;
  const now = Date.now();
  await db.notes.update(noteId, {
    content: prev.content,
    versions: versions.slice(0, -1),
    previousContent: undefined,
    lastEditedBy: "user",
    updatedAt: now,
  });
  await db.projects.update(note.projectId, { updatedAt: now });
  const fresh = await db.notes.get(noteId);
  if (fresh) {
    const { indexNote } = await import("./retrieval");
    await indexNote(fresh);
  }
  return true;
}
