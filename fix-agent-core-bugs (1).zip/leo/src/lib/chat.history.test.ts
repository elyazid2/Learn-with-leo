import { describe, expect, it } from "vitest";
import type { Message } from "./db";
import { buildHistory, collapseActionResults } from "./chat";

let t = 0;
const msg = (m: Partial<Message> & Pick<Message, "role" | "content">): Message => ({
  id: `m${++t}`,
  threadId: "th",
  projectId: "p",
  createdAt: t,
  ...m,
});

const CONTEXT = `<workspace_context>\n## PDF "bio.pdf" — page 4 of 9 (extracted text)\nMitochondria are the powerhouse…\n## Current note: "Cells" (id=n1)\nCell notes\n</workspace_context>\n\nExplain page 4 and add it to my note`;

/** A learner turn followed by two agent-loop steps (read → results → read → results). */
function loopThread(): Message[] {
  return [
    msg({ role: "user", content: "Hi" }),
    msg({ role: "assistant", content: "Hello!" }),
    msg({ role: "user", content: "Explain page 4 and add it to my note", apiContent: CONTEXT }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"note","id":"n2"}\n```' }),
    msg({ role: "user", hidden: true, content: '<action_results>\n## Note "Old" (id=n2)\nFIRST READ BODY\n</action_results>' }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"guide","id":"excalidraw"}\n```' }),
    msg({ role: "user", hidden: true, content: '<action_results>\n## Guide "excalidraw"\nGUIDE TEXT\n</action_results>' }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"sketch","id":"s1"}\n```' }),
    msg({ role: "user", hidden: true, content: "<action_results>\n## Sketch \"Flow\" (id=s1)\ns1 rectangle 0 0 10 10\n- FAILED note: x\n</action_results>" }),
  ];
}

describe("buildHistory (regression #2)", () => {
  it("keeps the learner's context on steps ≥ 2 instead of collapsing it to a placeholder", () => {
    const h = buildHistory(loopThread());
    const learner = h.find((m) => m.content.includes("Explain page 4"))!;
    expect(learner.content).toBe(CONTEXT);
    expect(learner.content).not.toContain("[workspace context was attached");
  });

  it("collapses older <action_results> bodies and keeps only the latest in full", () => {
    const h = buildHistory(loopThread());
    const results = h.filter((m) => m.content.startsWith("<action_results>"));
    expect(results).toHaveLength(3);
    expect(results[0].content).toContain('## Note "Old" (id=n2)');
    expect(results[0].content).not.toContain("FIRST READ BODY");
    // The guide is read once per chat, so it is never collapsed.
    expect(results[1].content).toContain("GUIDE TEXT");
    // Latest one in full.
    expect(results[2].content).toContain("s1 rectangle 0 0 10 10");
    expect(results[2].content).toContain("- FAILED note: x");
  });

  it("collapses older turns' apiContent and uses visible text for the first step", () => {
    const thread = loopThread().slice(0, 3);
    thread[0] = { ...thread[0], apiContent: "<workspace_context>\nold\n</workspace_context>\n\nHi" };
    const h = buildHistory(thread);
    expect(h[0].content).toBe("Hi\n[workspace context was attached to this message when it was sent]");
    expect(h[2].content).toBe(CONTEXT);
  });

  it("attaches invalid-action feedback to the newest user-role message", () => {
    const thread = [
      msg({ role: "user", content: "Make a note", apiContent: "CTX\n\nMake a note" }),
      msg({ role: "assistant", hidden: true, content: '```action\n{"type":"note"}\n```' }),
      msg({ role: "user", hidden: true, content: "<action_results>\n- FAILED note: bad\n</action_results>" }),
    ];
    const h = buildHistory(thread);
    expect(h[0].content).toBe("CTX\n\nMake a note");
    expect(h[2].content).toContain("could not be executed");
  });

  it("collapseActionResults keeps headings and FAILED lines", () => {
    const out = collapseActionResults('<action_results>\n## Note "A" (id=1)\nbody\nmore\n- FAILED read: nope\n</action_results>');
    expect(out).toContain('## Note "A" (id=1)');
    expect(out).not.toContain("body");
    expect(out.startsWith("<action_results>\n")).toBe(true);
    expect(out.endsWith("\n</action_results>")).toBe(true);
  });
});
