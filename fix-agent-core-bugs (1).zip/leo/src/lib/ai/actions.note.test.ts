import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});
vi.mock("@/lib/retrieval", () => ({ indexNote: vi.fn(async () => {}) }));

import { db, NOTE_VERSION_LIMIT, type Message, type Note } from "@/lib/db";
import { restorePreviousVersion } from "@/lib/noteVersions";
import { applyApprovedAction, applyPatches, executeActions, noteViewIn, planNoteEdit, type Action } from "./actions";

const fake = db as unknown as ReturnType<typeof import("../../test/fakeDb").createFakeDb>;
const P = "proj";
const T = "thread";
let clock = 1000;

const note = (over: Partial<Note> = {}): Note => ({ id: "n1", projectId: P, title: "Cells", content: "Cells have a membrane.", author: "user", createdAt: 1, updatedAt: 1, ...over });

async function addMsg(m: Partial<Message> & Pick<Message, "role" | "content">) {
  await db.messages.add({ id: `m${++clock}`, threadId: T, projectId: P, createdAt: ++clock, ...m });
}
/** Leo read the note in this thread (a `read` result). */
const readNote = (n: Note, body = n.content) => addMsg({ role: "user", hidden: true, content: `<action_results>\n## Note "${n.title}" (id=${n.id})\n${body}\n</action_results>` });
const run = (a: Action) => executeActions(P, T, [a]);

beforeEach(() => {
  fake.reset();
});

describe("note edits (regression #4)", () => {
  it("refuses to edit a note that was never read or attached in this thread", async () => {
    await db.notes.add(note());
    const r = await run({ type: "note", id: "n1", title: "", content: "More." });
    expect(r.results[0].ok).toBe(false);
    expect(r.results[0].label).toMatch(/read it first/);
    expect((await db.notes.get("n1"))!.content).toBe("Cells have a membrane.");
  });

  it("a read in the same reply does not count (its contents have not reached the model yet)", async () => {
    await db.notes.add(note());
    const r = await executeActions(P, T, [
      { type: "read", kind: "note", id: "n1" },
      { type: "note", id: "n1", title: "", content: "More." },
    ]);
    expect(r.read).toHaveLength(1);
    expect(r.results[1]).toMatchObject({ ok: false });
  });

  it("defaults to append, keeps the author, sets lastEditedBy and saves a version", async () => {
    const n = note();
    await db.notes.add(n);
    await readNote(n);
    const r = await run({ type: "note", id: "n1", title: "", content: "They also have ribosomes." });
    expect(r.results[0]).toMatchObject({ ok: true, label: "Appended to note · Cells" });
    const after = (await db.notes.get("n1"))!;
    expect(after.content).toBe("Cells have a membrane.\n\nThey also have ribosomes.");
    expect(after.author).toBe("user");
    expect(after.lastEditedBy).toBe("ai");
    expect(after.versions?.map((v) => v.content)).toEqual(["Cells have a membrane."]);
  });

  it("counts an attached / @mentioned note as seen", async () => {
    await db.notes.add(note());
    await addMsg({ role: "user", content: "fix it", apiContent: `<workspace_context>\n## Current note: "Cells" (id=n1)\nCells have a membrane.\n</workspace_context>\n\nfix it` });
    const r = await run({ type: "note", id: "n1", title: "", mode: "patch", content: "", patches: [{ find: "membrane", replace: "cell membrane" }] });
    expect(r.results[0]).toMatchObject({ ok: true });
    expect((await db.notes.get("n1"))!.content).toBe("Cells have a cell membrane.");
  });

  it("patch needs an exact, unique match", async () => {
    const n = note({ content: "a b a" });
    await db.notes.add(n);
    await readNote(n);
    const dup = await run({ type: "note", id: "n1", title: "", mode: "patch", content: "", patches: [{ find: "a", replace: "x" }] });
    expect(dup.results[0].ok).toBe(false);
    expect(dup.results[0].label).toMatch(/more than once/);
    const missing = await run({ type: "note", id: "n1", title: "", mode: "patch", content: "", patches: [{ find: "zzz", replace: "x" }] });
    expect(missing.results[0].label).toMatch(/not found/);
    expect((await db.notes.get("n1"))!.content).toBe("a b a");
    expect(applyPatches("a b a", [{ find: "a b", replace: "c" }, { find: "c a", replace: "done" }])).toEqual({ content: "done" });
  });

  it("replace on Leo's own note runs directly", async () => {
    const n = note({ author: "ai" });
    await db.notes.add(n);
    await readNote(n);
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "New text" });
    expect(r.results[0]).toMatchObject({ ok: true });
    expect(r.pending).toEqual([]);
    expect((await db.notes.get("n1"))!.content).toBe("New text");
  });

  it("replace on a learner's note waits for Apply, then applies", async () => {
    const n = note();
    await db.notes.add(n);
    await readNote(n);
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "Rewritten" });
    expect(r.pending).toHaveLength(1);
    expect(r.pending[0]).toMatchObject({ status: "pending", label: "Replace the learner's note “Cells”" });
    expect((await db.notes.get("n1"))!.content).toBe("Cells have a membrane.");
    const applied = await applyApprovedAction(P, r.pending[0].action as unknown as Action);
    expect(applied.ok).toBe(true);
    const after = (await db.notes.get("n1"))!;
    expect(after.content).toBe("Rewritten");
    expect(after.author).toBe("user");
  });

  it("after a clipped read only append/patch are allowed", async () => {
    const n = note({ author: "ai" });
    await db.notes.add(n);
    await readNote(n, "Cells have a mem\n…[truncated]");
    const replace = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "x" });
    expect(replace.results[0].ok).toBe(false);
    expect(replace.results[0].label).toMatch(/clipped/);
    const append = await run({ type: "note", id: "n1", title: "", content: "x" });
    expect(append.results[0].ok).toBe(true);
  });

  it("keeps the last 10 versions and can restore the previous one", async () => {
    const n = note({ content: "v0" });
    await db.notes.add(n);
    await readNote(n);
    for (let i = 1; i <= 12; i++) await run({ type: "note", id: "n1", title: "", mode: "patch", content: "", patches: [{ find: `v${i - 1}`, replace: `v${i}` }] });
    const after = (await db.notes.get("n1"))!;
    expect(after.content).toBe("v12");
    expect(after.versions).toHaveLength(NOTE_VERSION_LIMIT);
    expect(after.versions!.map((v) => v.content)).toEqual(["v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11"]);
    expect(await restorePreviousVersion("n1")).toBe(true);
    const restored = (await db.notes.get("n1"))!;
    expect(restored.content).toBe("v11");
    expect(restored.versions).toHaveLength(NOTE_VERSION_LIMIT - 1);
  });

  it("creating a note marks it as Leo's", async () => {
    const r = await run({ type: "note", title: "Summary", content: "x" });
    expect(r.results[0]).toMatchObject({ ok: true, label: "Created note · Summary" });
    const created = (await db.notes.toArray())[0];
    expect(created).toMatchObject({ author: "ai", lastEditedBy: "ai" });
  });

  it("planNoteEdit / noteViewIn are pure and agree with the rules", () => {
    const view = noteViewIn([{ role: "user", content: '## Referenced note: "Cells" (id=n1)\nbody' }], "n1");
    expect(view).toEqual({ seen: true, clipped: false });
    expect(noteViewIn([{ role: "assistant", content: '## Note "Cells" (id=n1)\nbody' }], "n1").seen).toBe(false);
    expect(noteViewIn([{ role: "user", content: '## Note "Other" (id=n10)\nbody' }], "n1").seen).toBe(false);
    expect(planNoteEdit(note(), { type: "note", id: "n1", title: "", content: "x", mode: "replace" }, view).kind).toBe("confirm");
  });
});

describe("memory scope (#5)", () => {
  it("update keeps the existing scope unless one is given; save defaults by kind", async () => {
    await db.memories.add({ id: "m1", projectId: P, kind: "goal", text: "Pass the exam", createdAt: 1, updatedAt: 1 });
    await run({ type: "memory", op: "update", id: "m1", text: "Pass the exam in June" });
    expect((await db.memories.get("m1"))!.projectId).toBe(P);
    await run({ type: "memory", op: "update", id: "m1", text: "Pass", scope: "global" });
    expect((await db.memories.get("m1"))!.projectId).toBe("*");

    await run({ type: "memory", op: "save", kind: "preference", text: "Likes diagrams" });
    await run({ type: "memory", op: "save", kind: "weakness", text: "Mixes up mitosis and meiosis" });
    const all = await db.memories.toArray();
    expect(all.find((m) => m.text === "Likes diagrams")!.projectId).toBe("*");
    expect(all.find((m) => m.text.startsWith("Mixes"))!.projectId).toBe(P);
  });

  it("delete waits for Apply", async () => {
    await db.memories.add({ id: "m1", projectId: P, kind: "fact", text: "x", createdAt: 1, updatedAt: 1 });
    const r = await run({ type: "memory", op: "delete", id: "m1" });
    expect(r.pending).toHaveLength(1);
    expect(await db.memories.get("m1")).toBeDefined();
    await applyApprovedAction(P, r.pending[0].action as unknown as Action);
    expect(await db.memories.get("m1")).toBeUndefined();
  });
});
