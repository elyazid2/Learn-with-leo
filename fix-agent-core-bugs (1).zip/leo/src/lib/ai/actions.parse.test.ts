import { describe, expect, it } from "vitest";
import { extractActions, invalidActionFeedback, parseSegments, progressHint, stripActions } from "./actions";

const fence = "```";

/** A note whose markdown contains a fenced code block (escaped newlines, as valid JSON requires). */
const noteWithCode = JSON.stringify({
  type: "note",
  title: "Loops",
  content: `# For loops\n\n${fence}python\nfor i in range(3):\n    print(i)\n${fence}\n\nThat prints 0, 1, 2.`,
});

describe("parseSegments — action blocks whose JSON contains code fences (regression #1)", () => {
  it("keeps a valid note whose markdown contains triple backticks", () => {
    const reply = `Here is your note.\n\n${fence}action\n${noteWithCode}\n${fence}\n\nWant a quiz?`;
    const segs = parseSegments(reply);
    expect(segs.filter((s) => s.kind === "invalid")).toEqual([]);
    const actions = extractActions(reply);
    expect(actions).toHaveLength(1);
    expect(actions[0]).toMatchObject({ type: "note", title: "Loops" });
    expect((actions[0] as { content: string }).content).toContain(`${fence}python\nfor i in range(3)`);
    expect(segs[0]).toEqual({ kind: "text", text: "Here is your note.\n\n" });
    expect(segs[segs.length - 1]).toMatchObject({ kind: "text", text: "\n\nWant a quiz?" });
    expect(invalidActionFeedback(reply)).toBeNull();
  });

  it("handles several blocks, each closed by its own fence line", () => {
    const reply = `${fence}action\n${noteWithCode}\n${fence}\nmiddle\n${fence}action\n{"type":"map","concept":"Loops","status":"learning"}\n${fence}`;
    const actions = extractActions(reply);
    expect(actions.map((a) => a.type)).toEqual(["note", "map"]);
    expect(stripActions(reply)).toBe("middle");
  });

  it("handles a pretty-printed multi-line note containing a code fence", () => {
    const pretty = JSON.stringify(JSON.parse(noteWithCode), null, 2);
    const reply = `${fence}action\n${pretty}\n${fence}\nafter`;
    expect(extractActions(reply)).toHaveLength(1);
    expect(stripActions(reply)).toBe("after");
  });

  it("closes at the first fence line that yields valid JSON", () => {
    const valid = `{"type":"point","kind":"next","text":"Practice loops"}`;
    const reply = `${fence}action\n${valid}\n${fence}\n${fence}\nafter`;
    expect(extractActions(reply)).toEqual([{ type: "point", kind: "next", text: "Practice loops" }]);
  });

  it("does not swallow a following block when an earlier body is broken", () => {
    const reply = `${fence}action\n{"type":"map","concept":}\n${fence}\nmid\n${fence}action\n{"type":"map","concept":"B"}\n${fence}`;
    const segs = parseSegments(reply);
    expect(segs.map((s) => s.kind)).toEqual(["invalid", "text", "action"]);
  });

  it("still accepts a closer glued to the JSON (legacy)", () => {
    const reply = `ok\n${fence}action\n{"type":"map","concept":"Sets"}${fence}\nbye`;
    expect(extractActions(reply)).toEqual([{ type: "map", concept: "Sets" }]);
  });

  it("reports a genuinely broken block once, and a block without a closer as cut off", () => {
    const broken = `${fence}action\n{"type":"map","concept":}\n${fence}`;
    const segs = parseSegments(broken);
    expect(segs).toHaveLength(1);
    expect(segs[0]).toMatchObject({ kind: "invalid" });
    expect(parseSegments(`${fence}action\n{"type":"map"`)).toEqual([expect.objectContaining({ kind: "invalid", reason: "action block was cut off" })]);
  });

  it("shows a streaming note with a code fence as pending, not as an error", () => {
    const partial = `Writing it.\n${fence}action\n{"type":"note","title":"Loops","content":"${fence}python\\nfor`;
    const segs = parseSegments(partial, true);
    expect(segs.map((s) => s.kind)).toEqual(["text", "pending"]);
    expect(progressHint(partial)).toBe("Writing a note\u2026");
  });
});
