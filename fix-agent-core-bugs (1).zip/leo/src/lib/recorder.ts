import { create } from "zustand";
import { addFile } from "./media";
import { useApp } from "./store";

/**
 * Global voice recorder. The MediaRecorder, mic stream and analyser live at module level and the
 * UI state lives in this store, so a recording keeps going while you navigate: no screen owns it,
 * and nothing is cancelled when a screen unmounts. The floating RecorderPill (mounted once in App)
 * is the only UI.
 */

export type RecorderPhase = "idle" | "starting" | "recording" | "paused" | "done";
export const BAR_COUNT = 24;
const quiet = () => Array<number>(BAR_COUNT).fill(0.06);

interface RecorderState {
  phase: RecorderPhase;
  projectId: string | null;
  elapsed: number;
  levels: number[];
  name: string;
  saving: boolean;
  previewUrl: string;
}

export const useRecorder = create<RecorderState>(() => ({
  phase: "idle",
  projectId: null,
  elapsed: 0,
  levels: quiet(),
  name: "",
  saving: false,
  previewUrl: "",
}));

let rec: MediaRecorder | null = null;
let stream: MediaStream | null = null;
let ctx: AudioContext | null = null;
let raf = 0;
let chunks: Blob[] = [];
let blob: Blob | null = null;
let startedAt = 0;
let accumulated = 0;
/** Bumped on reset so a late `onstop` from a discarded recorder can't resurrect a "done" state. */
let generation = 0;

const set = useRecorder.setState;
const get = useRecorder.getState;

const pickMime = () => {
  const opts = ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"];
  return opts.find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported?.(m)) ?? "";
};
const extFor = (type: string) => (type.includes("mp4") ? "m4a" : type.includes("ogg") ? "ogg" : "webm");
const seconds = () => accumulated + (rec?.state === "recording" ? (Date.now() - startedAt) / 1000 : 0);

/** Leo's orb shows "listening" while the mic is live. */
function setListening(on: boolean) {
  const app = useApp.getState();
  const projectId = get().projectId;
  if (on) app.setAgentActivity("listening", projectId);
  else if (app.agent.phase === "listening" && app.agent.projectId === projectId) app.setAgentActivity("idle", projectId);
}

function releaseMic() {
  cancelAnimationFrame(raf);
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  ctx?.close().catch(() => {});
  ctx = null;
}

function reset() {
  generation++;
  releaseMic();
  setListening(false);
  if (rec && rec.state !== "inactive") {
    rec.onstop = null;
    try {
      rec.stop();
    } catch {
      /* already stopped */
    }
  }
  rec = null;
  chunks = [];
  blob = null;
  accumulated = 0;
  const url = get().previewUrl;
  if (url) URL.revokeObjectURL(url);
  set({ phase: "idle", projectId: null, elapsed: 0, levels: quiet(), name: "", saving: false, previewUrl: "" });
}

export async function startRecording(projectId: string) {
  const phase = get().phase;
  if (phase !== "idle") {
    useApp.getState().showToast(phase === "done" ? "Save or discard the last recording first" : "Already recording");
    return;
  }
  set({ phase: "starting", projectId, elapsed: 0, levels: quiet() });
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    if (get().phase !== "starting") {
      s.getTracks().forEach((t) => t.stop());
      return;
    }
    stream = s;
    const mime = pickMime();
    const r = new MediaRecorder(s, mime ? { mimeType: mime } : undefined);
    chunks = [];
    const gen = ++generation;
    r.ondataavailable = (e) => {
      if (e.data.size) chunks.push(e.data);
    };
    r.onstop = () => {
      if (gen !== generation) return;
      blob = new Blob(chunks, { type: r.mimeType || mime || "audio/webm" });
      releaseMic();
      setListening(false);
      set({ phase: "done", elapsed: accumulated, previewUrl: URL.createObjectURL(blob) });
    };
    r.start(250);
    rec = r;

    const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = new AC();
    ctx = ac;
    const an = ac.createAnalyser();
    an.fftSize = 512;
    ac.createMediaStreamSource(s).connect(an);
    const buf = new Uint8Array(an.fftSize);
    let lastPush = 0;
    const tick = (now: number) => {
      if (now - lastPush > 90 && rec?.state === "recording") {
        lastPush = now;
        an.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) {
          const v = (buf[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.min(1, Math.sqrt(sum / buf.length) * 3.4);
        set((st) => ({ levels: [...st.levels.slice(1), Math.max(0.06, rms)], elapsed: seconds() }));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    startedAt = Date.now();
    accumulated = 0;
    set({
      phase: "recording",
      name: `Recording ${new Date().toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}`,
    });
    setListening(true);
  } catch (e) {
    reset();
    const err = e as Error;
    useApp.getState().showToast(err.name === "NotAllowedError" ? "Microphone permission was denied" : `Can't record: ${err.message}`);
  }
}

export function togglePause() {
  if (!rec) return;
  if (rec.state === "recording") {
    rec.pause();
    accumulated += (Date.now() - startedAt) / 1000;
    set({ phase: "paused", elapsed: accumulated });
    setListening(false);
  } else if (rec.state === "paused") {
    rec.resume();
    startedAt = Date.now();
    set({ phase: "recording" });
    setListening(true);
  }
}

export function stopRecording() {
  if (!rec || rec.state === "inactive") return;
  if (rec.state === "recording") accumulated += (Date.now() - startedAt) / 1000;
  set({ elapsed: accumulated });
  rec.stop();
}

export function discardRecording() {
  reset();
}

export const setRecordingName = (name: string) => set({ name });

export async function saveRecording() {
  const { projectId, name, elapsed } = get();
  if (!blob || !projectId) return;
  set({ saving: true });
  try {
    await addFile(projectId, blob, `${name.trim() || "Recording"}.${extFor(blob.type)}`, { recorded: true, duration: elapsed, kind: "audio" });
    useApp.getState().showToast("Recording saved to library");
    reset();
  } catch (e) {
    set({ saving: false });
    useApp.getState().showToast(`Couldn't save: ${(e as Error).message}`);
  }
}

// If the page is hidden mid-recording (screen lock, app switch) the OS may cut the mic.
// Save what we have straight to the library so nothing is lost.
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    const r = rec;
    if (!r || r.state === "inactive" || document.visibilityState !== "hidden") return;
    const gen = generation;
    const projectId = get().projectId;
    const duration = seconds();
    r.onstop = () => {
      const b = new Blob(chunks, { type: r.mimeType || "audio/webm" });
      if (gen !== generation || b.size === 0 || !projectId) return reset();
      addFile(projectId, b, `Recording (interrupted ${new Date().toLocaleTimeString()}).${extFor(b.type)}`, { recorded: true, duration, kind: "audio" })
        .then(() => useApp.getState().showToast("Recording was interrupted — saved to library"))
        .catch((e) => useApp.getState().showToast(`Couldn't save interrupted recording: ${e.message}`));
      reset();
    };
    r.stop();
  });
}
