import { useEffect, useState } from "react";
import { Download, HardDrive, Trash2, Upload } from "lucide-react";
import { db } from "@/lib/db";
import { download, exportBackup, importBackup } from "@/lib/backup";
import { formatBytes } from "@/lib/media";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui";
import { cn } from "@/utils/cn";
import ChatLogsRow from "./ChatLogs";

/** Settings → "Backup & export": storage meter, full backup, chat logs, and a separate danger row. */
export default function BackupExportSection() {
  const showToast = useApp((s) => s.showToast);
  const [usage, setUsage] = useState<{ used: number; quota: number } | null>(null);
  const [persisted, setPersisted] = useState<boolean | null>(null);
  const [withKeys, setWithKeys] = useState(false);
  const [busy, setBusy] = useState(false);

  const refresh = () => {
    navigator.storage?.estimate?.().then((e) => setUsage({ used: e.usage ?? 0, quota: e.quota ?? 0 }));
    navigator.storage?.persisted?.().then(setPersisted);
  };
  useEffect(refresh, []);

  const doExport = async () => {
    setBusy(true);
    try {
      const blob = await exportBackup(withKeys);
      download(blob, `harness-backup-${new Date().toISOString().slice(0, 10)}.json`);
    } finally {
      setBusy(false);
    }
  };
  const doImport = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try {
      const r = await importBackup(f);
      showToast(`Restored ${r.files} file(s), ${r.tables} table(s)${r.keysKept ? `, kept ${r.keysKept} existing API key(s)` : ""}`);
      refresh();
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const wipe = async () => {
    if (!confirm("Delete ALL projects, files, notes, chats and providers from this device? This cannot be undone.")) return;
    await db.delete();
    localStorage.removeItem("harness.activeThread");
    location.hash = "";
    location.reload();
  };

  const pct = usage && usage.quota ? Math.min(100, (usage.used / usage.quota) * 100) : 0;

  return (
    <section className="mt-10">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">Backup & export</h2>
      <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-line">
        {/* Storage meter */}
        <div className="flex items-center gap-3 p-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05]">
            <HardDrive size={17} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex justify-between text-sm">
              <span className="font-semibold">{usage ? formatBytes(usage.used) : "…"} used</span>
              <span className="text-muted">{usage?.quota ? `of ${formatBytes(usage.quota)}` : ""}</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink/[0.06]">
              <div className="h-full rounded-full bg-ink" style={{ width: `${Math.max(pct, 1)}%` }} />
            </div>
            <p className="mt-1 text-[11px] text-muted">{persisted ? "Persistent storage — the browser won't clear it." : "The browser may clear this under pressure. Back up often."}</p>
          </div>
        </div>

        {/* Full backup */}
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-line p-4">
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold">Full backup</div>
            <label className="mt-1 flex w-fit cursor-pointer items-center gap-2 text-[12px] text-muted">
              <input type="checkbox" className="accent-black" checked={withKeys} onChange={(e) => setWithKeys(e.target.checked)} />
              Include API keys
            </label>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="soft" size="sm" onClick={() => void doExport()} disabled={busy}>
              <Download size={14} /> Export
            </Button>
            <label
              className={cn(
                "inline-flex h-8 cursor-pointer select-none items-center justify-center gap-2 rounded-full bg-black/[0.05] px-3 text-[13px] font-medium text-ink transition hover:bg-black/[0.08] focus-within:ring-2 focus-within:ring-ink/30",
                busy && "pointer-events-none opacity-40"
              )}
            >
              <Upload size={14} /> Import
              <input
                type="file"
                accept="application/json,.json"
                className="sr-only"
                onChange={(e) => {
                  void doImport(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
          </div>
        </div>

        {/* Chat logs */}
        <div className="border-t border-line p-4">
          <ChatLogsRow />
        </div>

        {/* Danger zone */}
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-danger-line bg-danger-bg/40 p-4">
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold text-danger-fg">Erase all</div>
            <p className="mt-0.5 text-[12px] leading-snug text-muted">Delete everything on this device. Can't be undone.</p>
          </div>
          <Button variant="danger" size="sm" onClick={() => void wipe()}>
            <Trash2 size={14} /> Erase all
          </Button>
        </div>
      </div>
    </section>
  );
}
