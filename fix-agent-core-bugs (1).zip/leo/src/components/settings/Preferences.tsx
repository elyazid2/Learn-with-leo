import type { ReactNode } from "react";
import AgentAvatar from "@/components/AgentAvatar";
import { Segmented, Toggle } from "@/components/ui";
import { AVATAR_COLORS, AVATAR_EXPRESSIONS, AVATAR_SHAPES, type AvatarColor, type AvatarExpression, type AvatarShape } from "@/lib/avatar";
import { useSettings, type ThemePreference } from "@/lib/settings";
import { cn } from "@/utils/cn";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-8 first:mt-6">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">{title}</h2>
      <div className="rounded-2xl bg-card p-4 ring-1 ring-line">{children}</div>
    </section>
  );
}

function ToggleRow({ title, text, checked, onChange }: { title: string; text: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <div className="flex items-center gap-4 border-b border-line py-3 first:pt-0 last:border-0 last:pb-0">
      <div className="flex-1">
        <div className="text-sm font-semibold">{title}</div>
        <p className="mt-0.5 text-[13px] leading-relaxed text-muted">{text}</p>
      </div>
      <Toggle checked={checked} onChange={onChange} label={title} />
    </div>
  );
}

export default function PreferenceSections() {
  const theme = useSettings((s) => s.theme);
  const reduceMotion = useSettings((s) => s.reduceMotion);
  const avatar = useSettings((s) => s.avatar);
  const enterToSend = useSettings((s) => s.enterToSend);
  const shareMediaByDefault = useSettings((s) => s.shareMediaByDefault);
  const confirmDeletes = useSettings((s) => s.confirmDeletes);
  const showDictation = useSettings((s) => s.showDictation);
  const setSettings = useSettings((s) => s.setSettings);

  return (
    <>
      <Section title="Appearance">
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm font-semibold">Theme</span>
          <Segmented<ThemePreference>
            value={theme}
            onChange={(theme) => setSettings({ theme })}
            options={[{ value: "light", label: "Light" }, { value: "dark", label: "Dark" }, { value: "system", label: "System" }]}
          />
        </div>
        <div className="mt-3 border-t border-line pt-3">
          <ToggleRow
            title="Reduce motion"
            text="Freeze Leo and minimize interface transitions. Your system's reduced-motion preference is always respected."
            checked={reduceMotion}
            onChange={(reduceMotion) => setSettings({ reduceMotion })}
          />
        </div>
      </Section>

      <Section title="Leo">
        <div className="flex items-center gap-4 rounded-3xl bg-ink/[0.035] p-4">
          <AgentAvatar look={avatar} size={74} />
          <div>
            <div className="text-sm font-semibold">{AVATAR_SHAPES[avatar.shape].label} · {AVATAR_EXPRESSIONS[avatar.expression].label}</div>
            <p className="mt-1 max-w-xs text-[13px] leading-relaxed text-muted">How Leo looks across your projects. Ask Leo in a project chat and it can change its look there.</p>
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-2 text-[12px] font-medium text-muted">Shape</div>
          <div className="grid grid-cols-3 gap-1.5">
            {(Object.keys(AVATAR_SHAPES) as AvatarShape[]).map((shape) => (
              <button
                key={shape}
                onClick={() => setSettings({ avatar: { ...avatar, shape } })}
                className={cn("flex flex-col items-center gap-0.5 rounded-2xl px-1 py-2 ring-1 transition", avatar.shape === shape ? "bg-ink/[0.08] ring-ink" : "ring-line hover:bg-ink/[0.03]")}
                aria-pressed={avatar.shape === shape}
              >
                <AgentAvatar look={{ ...avatar, shape }} size={31} frozenAt={0} />
                <span className="text-[11px] text-muted">{AVATAR_SHAPES[shape].label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-2 text-[12px] font-medium text-muted">Color</div>
          <div className="flex flex-wrap gap-2">
            {(Object.keys(AVATAR_COLORS) as AvatarColor[]).map((color) => (
              <button
                key={color}
                onClick={() => setSettings({ avatar: { ...avatar, color } })}
                className={cn("h-8 w-8 rounded-full transition-transform", avatar.color === color ? "ring-2 ring-ink ring-offset-2 ring-offset-card" : "hover:scale-110")}
                style={{ background: AVATAR_COLORS[color].hex }}
                aria-label={AVATAR_COLORS[color].label}
                aria-pressed={avatar.color === color}
              />
            ))}
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-2 text-[12px] font-medium text-muted">Rest expression</div>
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
            {(Object.keys(AVATAR_EXPRESSIONS) as AvatarExpression[]).map((expression) => (
              <button
                key={expression}
                onClick={() => setSettings({ avatar: { ...avatar, expression } })}
                className={cn("flex flex-col items-center gap-0.5 rounded-2xl px-1 py-2 ring-1 transition", avatar.expression === expression ? "bg-ink/[0.08] ring-ink" : "ring-line hover:bg-ink/[0.03]")}
                aria-pressed={avatar.expression === expression}
              >
                <AgentAvatar look={{ ...avatar, expression }} size={28} frozenAt={0} />
                <span className="text-[11px] text-muted">{AVATAR_EXPRESSIONS[expression].label}</span>
              </button>
            ))}
          </div>
        </div>
      </Section>

      <Section title="Workspace">
        <ToggleRow title="Enter to send" text="On desktop, Enter sends and Shift+Enter adds a new line. Turn off to always add a new line." checked={enterToSend} onChange={(enterToSend) => setSettings({ enterToSend })} />
        <ToggleRow title="Share media by default" text="Include an open library image or sketch in chat automatically. You can still toggle it per message." checked={shareMediaByDefault} onChange={(shareMediaByDefault) => setSettings({ shareMediaByDefault })} />
        <ToggleRow title="Show dictation button" text="Add a microphone button to the chat composer so you can speak your message." checked={showDictation} onChange={(showDictation) => setSettings({ showDictation })} />
        <ToggleRow title="Confirm before deleting" text="Ask before removing projects, notes, files, sketches, chats, and providers." checked={confirmDeletes} onChange={(confirmDeletes) => setSettings({ confirmDeletes })} />
      </Section>
    </>
  );
}
