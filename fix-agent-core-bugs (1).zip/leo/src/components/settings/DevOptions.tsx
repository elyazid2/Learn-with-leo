import { useState } from "react";
import { RotateCcw, Save } from "lucide-react";
import { useSettings } from "@/lib/settings";
import { DEFAULT_LEO_CORE } from "@/lib/ai/prompt";
import { Button, Field } from "@/components/ui";

/**
 * "Leo prompt (advanced)": editable Leo system prompt and retrieval depth.
 * Always available and independent of Developer mode — it never switches the provider.
 * Changes apply to the next message.
 */
export default function LeoPromptSection() {
  const saved = useSettings((s) => s.leoSystemPrompt);
  const topK = useSettings((s) => s.retrievalTopK);
  const setSettings = useSettings((s) => s.setSettings);
  const [draft, setDraft] = useState(saved || DEFAULT_LEO_CORE);
  const [notice, setNotice] = useState("");
  const dirty = draft !== (saved || DEFAULT_LEO_CORE);
  const isDefault = !saved;

  const say = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2400);
  };

  const save = () => {
    const value = draft.trim() === DEFAULT_LEO_CORE.trim() ? "" : draft;
    setSettings({ leoSystemPrompt: value });
    setDraft(value || DEFAULT_LEO_CORE);
    say("Saved. Applies to your next message.");
  };

  const reset = () => {
    setSettings({ leoSystemPrompt: "" });
    setDraft(DEFAULT_LEO_CORE);
    say("Reset to the built-in prompt.");
  };

  return (
    <section className="mt-10">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">Leo prompt (advanced)</h2>
      <div className="rounded-2xl bg-card p-4 ring-1 ring-line">
      <p className="mb-4 text-[13px] leading-relaxed text-muted">Change Leo's core instructions and how much of your library it reads. Works with any provider and is saved on this device.</p>

      <div className="space-y-4">
        <Field label="Leo agent system prompt" hint={isDefault ? "Using the built-in prompt." : "Custom prompt active. Reset to return to the default."}>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={14}
            spellCheck={false}
            aria-label="Leo agent system prompt"
            className="w-full resize-y rounded-2xl bg-paper p-3 font-mono text-[12.5px] leading-relaxed ring-1 ring-line outline-none focus:ring-ink/30"
          />
        </Field>
        <div className="flex flex-wrap items-center gap-2">
          <Button size="md" onClick={save} disabled={!dirty}>
            <Save size={15} /> Save and apply
          </Button>
          <Button variant="soft" onClick={reset} disabled={isDefault && !dirty}>
            <RotateCcw size={15} /> Reset to default
          </Button>
          <span className="text-[12px] text-muted" aria-live="polite">
            {notice || (dirty ? "Unsaved changes" : "")}
          </span>
        </div>

        <Field label={`Passages retrieved per message · ${topK}`} hint="How many passages from your PDFs and notes Leo sees for each message.">
          <input type="range" min={1} max={12} step={1} value={topK} onChange={(e) => setSettings({ retrievalTopK: Number(e.target.value) })} className="w-full accent-black" />
        </Field>
      </div>
      </div>
    </section>
  );
}
