import { useEffect, useRef, useState } from "react";
import { Copy, Download, FileText, MoreHorizontal } from "lucide-react";
import { shareOrDownload } from "@/lib/backup";
import { buildChatLogs, chatLogsFilename } from "@/lib/chatLogs";
import { useApp } from "@/lib/store";
import { Button, Segmented } from "@/components/ui";

/**
 * Chat logs for debugging Leo: exactly what the model saw and did, including hidden action
 * results and guide text. Images/audio become placeholders; API keys and provider settings
 * are never part of this export.
 *
 * Getting the file out is the hard part: <a download> is silent in sandboxed iframes and many
 * phone browsers, so the export tries the share sheet first, then a download link, and keeps
 * Copy and Show text available under "More".
 */

/** Clipboard with a fallback for browsers that don't allow navigator.clipboard (iframes, http). */
async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}

type Busy = null | "export" | "copy" | "text";

/** One row of the "Backup & export" card. Rendered by BackupExport. */
export default function ChatLogsRow() {
  const showToast = useApp((s) => s.showToast);
  const [scope, setScope] = useState<"last" | "all">("last");
  const [busy, setBusy] = useState<Busy>(null);
  const [text, setText] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const close = (e: PointerEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setMenuOpen(false);
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("pointerdown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [menuOpen]);

  const makeJson = async () => {
    const data = await buildChatLogs(scope);
    if (!data.threads.length) throw new Error("No chats to export yet");
    return { data, json: JSON.stringify(data, null, 2) };
  };

  const run = async (kind: Exclude<Busy, null>, fn: () => Promise<void>) => {
    setMenuOpen(false);
    setBusy(kind);
    try {
      await fn();
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const doExport = () =>
    run("export", async () => {
      const { data, json } = await makeJson();
      const result = await shareOrDownload(new Blob([json], { type: "application/json" }), chatLogsFilename());
      const n = data.threads.length;
      if (result.how === "shared") showToast(`Shared ${n} chat${n === 1 ? "" : "s"}`);
      else if (result.how === "cancelled") showToast("Share cancelled — nothing was exported");
      else if (result.how === "failed") showToast(`Could not export: ${result.error}. Try More → Copy.`);
      else showToast("Download started — if nothing appeared, try More → Copy");
    });

  const doCopy = () =>
    run("copy", async () => {
      const { json } = await makeJson();
      showToast((await copyText(json)) ? "Copied the chat log JSON" : "Copy was blocked — use Show text instead");
    });

  const doShow = () => {
    if (text !== null) {
      setMenuOpen(false);
      setText(null);
      return;
    }
    void run("text", async () => {
      const { json } = await makeJson();
      setText(json);
    });
  };

  return (
    <div>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">Chat logs</div>
          <p className="mt-0.5 text-[12px] leading-snug text-muted">Every message and action result, for debugging. No keys or media.</p>
        </div>
        <div className="flex items-center gap-2">
          <Segmented<"last" | "all">
            className="h-8 items-center [&>button]:h-7 [&>button]:py-0"
            value={scope}
            onChange={(v) => {
              setScope(v);
              setText(null);
            }}
            options={[
              { value: "last", label: "Last" },
              { value: "all", label: "All" },
            ]}
          />
          <Button variant="soft" size="sm" onClick={() => void doExport()} disabled={busy !== null}>
            <Download size={14} /> {busy === "export" ? "Exporting…" : "Export"}
          </Button>
          <div ref={menuRef} className="relative">
            <Button
              variant="soft"
              size="sm"
              className="w-8 px-0"
              onClick={() => setMenuOpen((o) => !o)}
              disabled={busy !== null}
              aria-label="More chat log options"
              aria-haspopup="menu"
              aria-expanded={menuOpen}
            >
              <MoreHorizontal size={15} />
            </Button>
            {menuOpen && (
              <div role="menu" className="absolute right-0 top-full z-20 mt-1.5 w-40 overflow-hidden rounded-2xl bg-elevated p-1 shadow-[0_12px_32px_rgba(0,0,0,0.16)] ring-1 ring-line">
                <button role="menuitem" onClick={() => void doCopy()} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-[13px] font-medium hover:bg-ink/[0.05]">
                  <Copy size={14} /> Copy
                </button>
                <button role="menuitem" onClick={doShow} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-[13px] font-medium hover:bg-ink/[0.05]">
                  <FileText size={14} /> {text === null ? "Show text" : "Hide text"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      {text !== null && (
        <textarea
          readOnly
          value={text}
          dir="ltr"
          spellCheck={false}
          onFocus={(e) => e.currentTarget.select()}
          onClick={(e) => e.currentTarget.select()}
          className="mt-3 h-56 w-full resize-y rounded-2xl bg-paper p-3 font-mono text-[11px] leading-snug text-ink ring-1 ring-line outline-none focus:ring-2 focus:ring-ink/30"
          aria-label="Chat log JSON"
        />
      )}
    </div>
  );
}
