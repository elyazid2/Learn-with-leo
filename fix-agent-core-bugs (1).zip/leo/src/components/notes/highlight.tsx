import { memo, type ReactNode } from "react";

/**
 * Live markdown styling for the note editor. Renders the exact same characters as the textarea
 * (which sits on top with transparent text), so only colour / weight / style may change — never
 * size or spacing. The editor uses a monospace face, where bold and italic keep the same width.
 */

const INLINE =
  /(`[^`\n]+`)|(\*\*[^*\n]+?\*\*|__[^_\n]+?__)|(~~[^~\n]+?~~)|(\*[^*\s\n][^*\n]*?\*|(?<![\w])_[^_\s\n][^_\n]*?_(?![\w]))|(\[\[[^\]\n]+\]\])|(!?\[[^\]\n]*\]\([^)\n]*\))|(\$[^$\n]+\$)|((?<=^|\s)#[\p{L}\p{N}_/-]*[\p{L}_/-][\p{L}\p{N}_/-]*)/gu;

const mk = (s: string, key: string) => (
  <span key={key} className="hl-mk">
    {s}
  </span>
);

function wrapped(token: string, open: number, close: number, cls: string, key: string) {
  return (
    <span key={key} className={cls}>
      {mk(token.slice(0, open), "o")}
      {token.slice(open, token.length - close)}
      {mk(token.slice(token.length - close), "c")}
    </span>
  );
}

function inline(text: string, keyBase: string): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0;
  let i = 0;
  for (const m of text.matchAll(INLINE)) {
    const at = m.index ?? 0;
    if (at > last) out.push(text.slice(last, at));
    const t = m[0];
    const key = `${keyBase}-${i++}`;
    if (m[1]) out.push(wrapped(t, 1, 1, "hl-code", key));
    else if (m[2]) out.push(wrapped(t, 2, 2, "hl-b", key));
    else if (m[3]) out.push(wrapped(t, 2, 2, "hl-s", key));
    else if (m[4]) out.push(wrapped(t, 1, 1, "hl-i", key));
    else if (m[5]) out.push(wrapped(t, 2, 2, "hl-wiki", key));
    else if (m[6]) {
      const mid = t.indexOf("](");
      out.push(
        <span key={key} className="hl-link">
          {mk(t.slice(0, t.startsWith("!") ? 2 : 1), "o")}
          {t.slice(t.startsWith("!") ? 2 : 1, mid)}
          <span className="hl-mk">{t.slice(mid)}</span>
        </span>
      );
    } else if (m[7]) out.push(wrapped(t, 1, 1, "hl-math", key));
    else if (m[8]) out.push(<span key={key} className="hl-tag">{t}</span>);
    else out.push(t);
    last = at + t.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function line(raw: string, n: number): ReactNode {
  const k = `l${n}`;
  let m: RegExpExecArray | null;
  if ((m = /^(#{1,6})(\s+)(.*)$/.exec(raw))) {
    return (
      <span key={k} className={`hl-h hl-h${m[1].length}`}>
        {mk(m[1] + m[2], "m")}
        {inline(m[3], k)}
      </span>
    );
  }
  if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(raw)) return mk(raw, k);
  if ((m = /^(\s*>+\s?)(.*)$/.exec(raw))) {
    return (
      <span key={k} className="hl-quote">
        {mk(m[1], "m")}
        {inline(m[2], k)}
      </span>
    );
  }
  if ((m = /^(\s*)([-*+]|\d+[.)])(\s+)(\[[ xX]\]\s+)?(.*)$/.exec(raw))) {
    const done = !!m[4] && /x/i.test(m[4]);
    return (
      <span key={k}>
        {m[1]}
        <span className="hl-list">{m[2]}</span>
        {m[3]}
        {m[4] && <span className="hl-task">{m[4]}</span>}
        <span className={done ? "hl-done" : undefined}>{inline(m[5], k)}</span>
      </span>
    );
  }
  return <span key={k}>{inline(raw, k)}</span>;
}

/** Highlighted mirror of the note source. */
export const MarkdownMirror = memo(function MarkdownMirror({ source }: { source: string }) {
  const lines = source.split("\n");
  const out: ReactNode[] = [];
  let fence = false;
  let mathBlock = false;
  lines.forEach((raw, n) => {
    if (n > 0) out.push("\n");
    const trimmed = raw.trim();
    if (/^(```|~~~)/.test(trimmed)) {
      fence = !fence;
      out.push(<span key={`f${n}`} className="hl-fence">{raw}</span>);
      return;
    }
    if (!fence && trimmed === "$$") {
      mathBlock = !mathBlock;
      out.push(<span key={`f${n}`} className="hl-math">{raw}</span>);
      return;
    }
    if (fence) return void out.push(<span key={`c${n}`} className="hl-codeblock">{raw}</span>);
    if (mathBlock) return void out.push(<span key={`m${n}`} className="hl-math">{raw}</span>);
    out.push(line(raw, n));
  });
  // A trailing newline needs a character after it to occupy a line, like the textarea does.
  out.push("\u200b");
  return <>{out}</>;
});
