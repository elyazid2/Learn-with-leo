import { useMemo } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { FileText, Plus } from "lucide-react";
import { db, type Note, type Project } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { confirmDeletion } from "@/lib/settings";
import { removeChunks } from "@/lib/retrieval";
import { createNote, leafOf, parentOf, resolveLink } from "@/lib/notes";
import { timeAgo } from "@/lib/media";
import NoteEditor from "@/components/notes/NoteEditor";
import "@/components/notes/notes.css";

/**
 * Obsidian-minimal notes: a title header and a live-styled markdown editor with a read/edit toggle.
 *
 * The richer workspace (tabs, file tree, graph view, quick switcher, backlinks panel and
 * formatting toolbars) still lives in components/notes/* and the data model is unchanged
 * (folders, wikilinks, tags) — it just isn't rendered here.
 */
export default function Notes({ project, noteId }: { project: Project; noteId?: string }) {
  const notesQ = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]);
  const list = useMemo(() => notesQ ?? [], [notesQ]);
  const active = noteId ? list.find((n) => n.id === noteId) : undefined;

  const open = (id: string) => navigate(projectPath(project.id, "notes", id));

  const newNote = async () => open(await createNote(project.id, { folder: "" }));

  const openLink = async (target: string) => {
    const hit = resolveLink(target, list);
    if (hit) return open(hit.id);
    // Like Obsidian: following a link to a note that does not exist creates it.
    open(await createNote(project.id, { title: leafOf(target), folder: target.includes("/") ? parentOf(target) : "" }));
  };

  const removeNote = async (n: Note) => {
    if (!confirmDeletion(`Delete "${n.title}"? This cannot be undone.`)) return;
    navigate(projectPath(project.id));
    await db.notes.delete(n.id);
    await removeChunks(n.id);
  };

  return (
    <div className="obs absolute inset-0 flex flex-col">
      {noteId ? (
        <NoteEditor
          key={noteId}
          noteId={noteId}
          notes={list}
          onOpenLink={(t) => void openLink(t)}
          onDelete={() => {
            if (active) void removeNote(active);
          }}
        />
      ) : (
        <Welcome notes={list} onNew={() => void newNote()} onOpen={open} />
      )}
    </div>
  );
}

function Welcome({ notes, onNew, onOpen }: { notes: Note[]; onNew: () => void; onOpen: (id: string) => void }) {
  const recent = [...notes].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 8);
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto w-full max-w-[760px] px-5 pb-40 pt-8 md:px-10">
        <div className="flex items-center gap-3">
          <h1 className="obs-title min-w-0 flex-1">Notes</h1>
          <button type="button" onClick={onNew} className="flex h-9 items-center gap-1.5 rounded-lg bg-white/[0.07] px-3 text-[13px] font-medium text-[#dcddde] transition-colors hover:bg-white/[0.12]">
            <Plus size={15} /> New note
          </button>
        </div>
        {recent.length ? (
          <ul className="mt-6 divide-y divide-white/[0.06]">
            {recent.map((n) => (
              <li key={n.id}>
                <button type="button" onClick={() => onOpen(n.id)} className="flex w-full items-center gap-3 py-3 text-left text-[15px] text-[#dcddde] transition-colors hover:text-white">
                  <FileText size={15} className="shrink-0 text-[#6f6f76]" />
                  <span className="min-w-0 flex-1 truncate">{n.title || "Untitled"}</span>
                  <span className="shrink-0 text-[12px] text-[#6f6f76]">{timeAgo(n.updatedAt)}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-4 text-[15px] leading-relaxed text-[#8e8e93]">No notes yet. Write in Markdown — [[links]], #tags and $math$ all work.</p>
        )}
      </div>
    </div>
  );
}
