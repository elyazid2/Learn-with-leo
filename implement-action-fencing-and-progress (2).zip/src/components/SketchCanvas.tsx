// Must load before Excalidraw so its fonts come from the bundle, not the (blocked) CDN.
import "@/lib/excalidrawFonts";
import { useEffect, useMemo, useRef } from "react";
import { Excalidraw, MainMenu, exportToBlob, serializeAsJSON } from "@excalidraw/excalidraw";
import "@excalidraw/excalidraw/index.css";
import type { ExcalidrawImperativeAPI } from "@excalidraw/excalidraw/types";
import { db, type Sketch } from "@/lib/db";
import { blobToDataUrl } from "@/lib/media";
import { useApp } from "@/lib/store";
import { useResolvedTheme } from "@/lib/settings";

type Scene = { elements: readonly { version: number; isDeleted?: boolean }[]; appState: Record<string, unknown>; files: Record<string, unknown> };

export default function SketchCanvas({ sketch, title, onSaving }: { sketch: Sketch; title: string; onSaving: (s: boolean) => void }) {
  const api = useRef<ExcalidrawImperativeAPI | null>(null);
  const lastSig = useRef<string>("");
  const timer = useRef<number | undefined>(undefined);
  const pending = useRef<Scene | null>(null);
  const setSketch = useApp((s) => s.setSketch);
  const setSketchApi = useApp((s) => s.setSketchApi);
  const theme = useResolvedTheme();

  const initialData = useMemo(() => {
    try {
      const j = JSON.parse(sketch.scene || "{}");
      return {
        elements: j.elements ?? [],
        appState: { ...(j.appState ?? {}), collaborators: new Map() },
        files: j.files ?? {},
        scrollToContent: true,
      };
    } catch {
      return { elements: [], appState: {}, scrollToContent: true };
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sketch.id]);

  const exportImage = async (max: number, mime: string) => {
    const a = api.current;
    if (!a) return null;
    const elements = a.getSceneElements();
    if (!elements.length) return null;
    const blob = await exportToBlob({
      elements,
      appState: { ...a.getAppState(), exportBackground: true, viewBackgroundColor: "#ffffff" },
      files: a.getFiles(),
      maxWidthOrHeight: max,
      mimeType: mime,
      quality: 0.8,
    });
    return blobToDataUrl(blob);
  };

  const flush = async () => {
    const s = pending.current;
    if (!s) return;
    pending.current = null;
    const scene = serializeAsJSON(s.elements as never, s.appState as never, s.files as never, "local");
    let thumb: string | undefined;
    try {
      thumb = (await exportImage(420, "image/jpeg")) ?? undefined;
    } catch {
      /* ignore thumbnail failure */
    }
    await db.sketches.update(sketch.id, { scene, thumb: thumb ?? "", updatedAt: Date.now() });
    onSaving(false);
  };

  useEffect(() => {
    setSketch({ id: sketch.id, title, getDataUrl: () => exportImage(1280, "image/png") });
  }, [sketch.id, title]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(
    () => () => {
      window.clearTimeout(timer.current);
      void flush();
      setSketch(null);
      setSketchApi(null);
    },
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  return (
    <div className="excalidraw-wrap absolute inset-0">
      <Excalidraw
        theme={theme}
        excalidrawAPI={(a) => {
          api.current = a;
          // Published so Leo's edit_sketch action can update a sketch the learner is looking at.
          useApp.getState().setSketchApi(
            a ? { sketchId: sketch.id, updateScene: (scene) => a.updateScene(scene as never) } : null
          );
        }}
        initialData={initialData as never}
        UIOptions={{ canvasActions: { loadScene: false, saveToActiveFile: false, toggleTheme: false } }}
        onChange={(elements, appState, files) => {
          const sig = elements.length + ":" + elements.reduce((n, e) => n + e.version, 0) + ":" + Object.keys(files).length + ":" + appState.viewBackgroundColor;
          if (!lastSig.current) {
            lastSig.current = sig;
            return;
          }
          if (sig === lastSig.current) return;
          lastSig.current = sig;
          pending.current = { elements, appState: appState as never, files: files as never };
          onSaving(true);
          window.clearTimeout(timer.current);
          timer.current = window.setTimeout(() => void flush(), 900);
        }}
      >
        {/* Only what belongs in a study sketch — no file dialogs or third-party links. */}
        <MainMenu>
          <MainMenu.DefaultItems.SaveAsImage />
          <MainMenu.DefaultItems.Help />
          <MainMenu.DefaultItems.ClearCanvas />
          <MainMenu.Separator />
          <MainMenu.DefaultItems.ChangeCanvasBackground />
        </MainMenu>
      </Excalidraw>
    </div>
  );
}
