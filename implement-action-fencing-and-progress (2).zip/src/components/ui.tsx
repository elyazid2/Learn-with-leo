import { useEffect, useRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "@/utils/cn";
import { STATUS_META, type Concept, type ConceptStatus } from "@/lib/db";
import { useApp } from "@/lib/store";

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "soft" | "ghost" | "danger" | "outline";
  size?: "sm" | "md" | "lg";
};

export function Button({ variant = "primary", size = "md", className, ...rest }: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full font-medium transition active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none select-none",
        size === "sm" && "h-8 px-3 text-[13px]",
        size === "md" && "h-10 px-4 text-sm",
        size === "lg" && "h-12 px-6 text-[15px]",
        variant === "primary" && "bg-ink text-white hover:bg-ink/90",
        variant === "soft" && "bg-black/[0.05] text-ink hover:bg-black/[0.08]",
        variant === "ghost" && "text-ink hover:bg-black/[0.05]",
        variant === "outline" && "border border-line bg-white text-ink hover:bg-black/[0.03]",
        variant === "danger" && "bg-danger-bg text-danger-fg hover:bg-danger-line",
        className
      )}
    />
  );
}

export function IconBtn({ className, ...rest }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-ink/80 transition hover:bg-black/[0.06] active:scale-95 disabled:opacity-30",
        className
      )}
    />
  );
}

let sheetSeq = 0;
const sheetStack: number[] = [];

export function Sheet({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  wide?: boolean;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const idRef = useRef(0);
  if (!idRef.current) idRef.current = ++sheetSeq;
  useEffect(() => {
    if (!open) return;
    const me = idRef.current;
    sheetStack.push(me);
    const previous = document.activeElement as HTMLElement | null;
    const focusable = () =>
      Array.from(
        panel.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])') ?? []
      ).filter((el) => el.offsetParent !== null);
    const raf = requestAnimationFrame(() => {
      if (panel.current?.contains(document.activeElement)) return;
      const first = focusable().find((el) => el.tagName !== "BUTTON");
      (first ?? panel.current)?.focus({ preventScroll: true });
    });
    const on = (e: KeyboardEvent) => {
      if (sheetStack[sheetStack.length - 1] !== me) return;
      if (e.key === "Escape") {
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== "Tab") return;
      const els = focusable();
      if (!els.length) return;
      const i = els.indexOf(document.activeElement as HTMLElement);
      if (e.shiftKey && i <= 0) {
        e.preventDefault();
        els[els.length - 1].focus();
      } else if (!e.shiftKey && (i === els.length - 1 || i === -1)) {
        e.preventDefault();
        els[0].focus();
      }
    };
    window.addEventListener("keydown", on);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", on);
      const idx = sheetStack.lastIndexOf(me);
      if (idx >= 0) sheetStack.splice(idx, 1);
      document.body.style.overflow = prevOverflow;
      if (!sheetStack.length) previous?.focus?.({ preventScroll: true });
    };
  }, [open]);
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-[#000]/30 backdrop-blur-[2px]" onClick={() => onCloseRef.current()} />
      <div
        ref={panel}
        tabIndex={-1}
        className={cn(
          "rise relative max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl bg-card p-5 pb-[max(2rem,env(safe-area-inset-bottom))] shadow-2xl outline-none sm:rounded-2xl sm:pb-5",
          wide ? "sm:max-w-2xl" : "sm:max-w-md"
        )}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-black/10 sm:hidden" />
        {title && (
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="display text-[22px] leading-none">{title}</h2>
            <IconBtn onClick={() => onCloseRef.current()} aria-label="Close">
              <X size={18} />
            </IconBtn>
          </div>
        )}
        {children}
      </div>
    </div>,
    document.body
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-medium text-muted">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-2xl border border-line bg-white px-4 py-3 text-[16px] outline-none transition-[border-color,box-shadow] placeholder:text-muted/70 focus:border-ink/40 focus:ring-4 focus:ring-black/[0.04]";

export function StatusBar({ concepts, className }: { concepts: Concept[]; className?: string }) {
  const total = concepts.length;
  const order: ConceptStatus[] = ["solid", "learning", "shaky", "new"];
  return (
    <div className={cn("flex h-1.5 w-full gap-[2px] overflow-hidden rounded-full bg-black/[0.06]", className)}>
      {total > 0 &&
        order.map((s) => {
          const n = concepts.filter((c) => c.status === s).length;
          if (!n) return null;
          return (
            <div
              key={s}
              className="h-full rounded-full transition-[width]"
              style={{ width: `${(n / total) * 100}%`, background: STATUS_META[s].color }}
            />
          );
        })}
    </div>
  );
}

export function Ring({ value, size = 44, stroke = 4, color = "#17171a", children }: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - Math.max(0, Math.min(1, value)))}
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-[11px] font-semibold">{children}</div>
    </div>
  );
}

export function Empty({ icon, title, text, children }: { icon: ReactNode; title: string; text?: string; children?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-ink/70 shadow-sm ring-1 ring-line">
        {icon}
      </div>
      <h3 className="display text-2xl">{title}</h3>
      {text && <p className="mt-1.5 max-w-xs text-sm text-muted">{text}</p>}
      {children && <div className="mt-5 flex flex-wrap justify-center gap-2">{children}</div>}
    </div>
  );
}

export function Toast() {
  const toast = useApp((s) => s.toast);
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[100] flex justify-center px-4">
      <div key={toast.id} className="rise rounded-full bg-ink px-4 py-2 text-sm text-white shadow-lg">
        {toast.text}
      </div>
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", checked ? "bg-ink" : "bg-ink/15")}
    >
      <span className={cn("absolute left-0 top-1 h-5 w-5 rounded-full shadow-sm transition-transform", checked ? "translate-x-6 bg-on-ink" : "translate-x-1 bg-[#fff]")} />
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("inline-flex rounded-full bg-black/[0.05] p-0.5", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "rounded-full px-3 py-1 text-[13px] font-medium transition",
            value === o.value ? "bg-white text-ink shadow-sm" : "text-muted hover:text-ink"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
