import { colorOf, type Project } from "@/lib/db";
import { readableOn } from "@/lib/color";
import { emojiRenders, iconOf } from "@/lib/projectIcon";
import { cn } from "@/utils/cn";

type Iconish = Pick<Project, "icon" | "tag" | "color" | "name">;

/** Project badge: the chosen emoji on a soft tint of the project color, or an uploaded image/logo. */
export default function ProjectAvatar({ project, size = 36, className }: { project: Iconish; size?: number; animate?: boolean; className?: string }) {
  const col = colorOf(project.color);
  const icon = iconOf(project);
  const radius = size >= 40 ? "rounded-2xl" : "rounded-xl";
  const showEmoji = icon.kind === "emoji" && emojiRenders(icon.emoji);
  const letter = (project.name.trim().charAt(0) || "?").toUpperCase();
  if (icon.kind === "image")
    return (
      <img
        src={icon.src}
        alt=""
        aria-hidden
        draggable={false}
        className={cn("shrink-0 select-none bg-card object-cover ring-1 ring-line", radius, className)}
        style={{ width: size, height: size }}
      />
    );
  return (
    <div
      aria-hidden
      className={cn("flex shrink-0 select-none items-center justify-center", radius, className)}
      style={
        showEmoji
          ? {
              width: size,
              height: size,
              background: `color-mix(in srgb, ${col.hex} 16%, var(--card))`,
              boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${col.hex} 24%, transparent)`,
            }
          : { width: size, height: size, background: col.hex, color: readableOn(col.hex) }
      }
    >
      {showEmoji ? (
        <span className="emoji leading-none" style={{ fontSize: Math.round(size * 0.55) }}>
          {icon.emoji}
        </span>
      ) : (
        <span className="font-semibold leading-none" style={{ fontSize: Math.round(size * 0.44) }}>
          {letter}
        </span>
      )}
    </div>
  );
}
