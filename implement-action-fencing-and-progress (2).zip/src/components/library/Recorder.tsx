import { useEffect, useRef, useState } from "react";
import { Mic, Pause, Play, Square, Trash2 } from "lucide-react";
import { addFile, formatDuration } from "@/lib/media";
import { useApp } from "@/lib/store";
import { Button, Sheet, inputCls } from "../ui";

type Phase = "idle" | "recording" | "paused" | "done";

const pickMime = () => {
  const opts = ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"];
  return opts.find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported?.(m)) ?? "";
};

export default function Recorder({ projectId, open, onClose }: { projectId: string; open: boolean; onClose: () => void }) {
  const showToast = useApp((s) => s.showToast);
  const [phase, setPhase] = useState<Phase>("idle");
  const [elapsed, setElapsed] = useState(0);
  const [levels, setLevels] = useState<number[]>(() => Array(40).fill(0.05));
  const [blob, setBlob] = useState<Blob | null>(null);
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const rec = useRef<MediaRecorder | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const chunks = useRef<Blob[]>([]);
  const raf = useRef(0);
  const ctx = useRef<AudioContext | null>(null);
  const startedAt = useRef(0);
  const accumulated = useRef(0);
  const previewUrl = useRef<string>("");
  /** Bumped on reset so a late `onstop` from a discarded recorder can't resurrect a "done" state. */
  const generation = useRef(0);
  const projectRef = useRef(projectId);
  projectRef.current = projectId;

  const cleanup = () => {
    cancelAnimationFrame(raf.current);
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    ctx.current?.close().catch(() => {});
    ctx.current = null;
  };

  useEffect(() => () => cleanup(), []);

  const reset = () => {
    generation.current++;
    cleanup();
    if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
    previewUrl.current = "";
    setPhase("idle");
    setElapsed(0);
    setBlob(null);
    setLevels(Array(40).fill(0.05));
    setError("");
    accumulated.current = 0;
  };

  const close = () => {
    const r = rec.current;
    if (r && r.state !== "inactive") {
      // Closing mid-recording: finish and show the preview instead of silently discarding audio.
      stop();
      return;
    }
    if (phase === "done" && blob && !confirmDiscard()) return;
    reset();
    onClose();
  };
  const confirmDiscard = () => window.confirm("Discard this recording?");

  // If the page is hidden mid-recording (screen lock, app switch) the OS will cut the mic.
  // Save what we have straight to the library so nothing is lost.
  useEffect(() => {
    const onHide = () => {
      const r = rec.current;
      if (!r || r.state === "inactive" || document.visibilityState !== "hidden") return;
      const gen = generation.current;
      const seconds = accumulated.current + (r.state === "recording" ? (Date.now() - startedAt.current) / 1000 : 0);
      r.onstop = () => {
        const b = new Blob(chunks.current, { type: r.mimeType || "audio/webm" });
        cleanup();
        if (gen !== generation.current || b.size === 0) return;
        const ext = b.type.includes("mp4") ? "m4a" : b.type.includes("ogg") ? "ogg" : "webm";
        addFile(projectRef.current, b, `Recording (interrupted ${new Date().toLocaleTimeString()}).${ext}`, { recorded: true, duration: seconds, kind: "audio" })
          .then(() => useApp.getState().showToast("Recording was interrupted — saved to library"))
          .catch((e) => useApp.getState().showToast(`Couldn't save interrupted recording: ${e.message}`));
        generation.current++;
        setPhase("idle");
        setElapsed(0);
      };
      r.stop();
    };
    document.addEventListener("visibilitychange", onHide);
    return () => document.removeEventListener("visibilitychange", onHide);
  }, []);

  const start = async () => {
    setError("");
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      stream.current = s;
      const mime = pickMime();
      const r = new MediaRecorder(s, mime ? { mimeType: mime } : undefined);
      chunks.current = [];
      const gen = ++generation.current;
      r.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      r.onstop = () => {
        if (gen !== generation.current) return;
        const b = new Blob(chunks.current, { type: r.mimeType || mime || "audio/webm" });
        setBlob(b);
        if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
        previewUrl.current = URL.createObjectURL(b);
        setPhase("done");
        cleanup();
      };
      r.start(250);
      rec.current = r;

      const AC: typeof AudioContext =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ac = new AC();
      ctx.current = ac;
      const src = ac.createMediaStreamSource(s);
      const an = ac.createAnalyser();
      an.fftSize = 512;
      src.connect(an);
      const buf = new Uint8Array(an.fftSize);
      let lastPush = 0;
      const tick = (now: number) => {
        an.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) {
          const v = (buf[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.min(1, Math.sqrt(sum / buf.length) * 3.2);
        if (now - lastPush > 70) {
          lastPush = now;
          if (rec.current?.state === "recording") {
            setLevels((l) => [...l.slice(1), Math.max(0.05, rms)]);
            setElapsed(accumulated.current + (Date.now() - startedAt.current) / 1000);
          }
        }
        raf.current = requestAnimationFrame(tick);
      };
      raf.current = requestAnimationFrame(tick);
      startedAt.current = Date.now();
      accumulated.current = 0;
      setName(`Recording ${new Date().toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}`);
      setPhase("recording");
    } catch (e) {
      setError((e as Error).name === "NotAllowedError" ? "Microphone permission was denied." : `Can't record: ${(e as Error).message}`);
    }
  };

  const pause = () => {
    const r = rec.current;
    if (!r) return;
    if (r.state === "recording") {
      r.pause();
      accumulated.current += (Date.now() - startedAt.current) / 1000;
      setPhase("paused");
    } else if (r.state === "paused") {
      r.resume();
      startedAt.current = Date.now();
      setPhase("recording");
    }
  };

  const stop = () => {
    const r = rec.current;
    if (!r) return;
    if (r.state === "recording") accumulated.current += (Date.now() - startedAt.current) / 1000;
    setElapsed(accumulated.current);
    r.stop();
  };

  const save = async () => {
    if (!blob) return;
    setSaving(true);
    try {
      const ext = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
      await addFile(projectId, blob, `${name.trim() || "Recording"}.${ext}`, { recorded: true, duration: elapsed, kind: "audio" });
      showToast("Recording saved to library");
      reset();
      onClose();
    } catch (e) {
      setError(`Couldn't save: ${(e as Error).message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet open={open} onClose={close} title="Record">
      <div className="flex flex-col items-center">
        <div className="flex h-28 w-full items-center justify-center gap-[3px] rounded-3xl bg-black/[0.03] px-4">
          {levels.map((l, i) => (
            <div
              key={i}
              className="w-1.5 rounded-full transition-[height] duration-75"
              style={{ height: `${Math.max(6, l * 96)}%`, background: phase === "recording" ? "#e5485e" : "var(--ink)", opacity: 0.35 + l * 0.65 }}
            />
          ))}
        </div>
        <div className="mt-4 display text-[40px] tabular-nums leading-none">{formatDuration(elapsed)}</div>
        <div className="mt-1 h-4 text-[12px] text-muted">
          {phase === "recording" ? "Recording…" : phase === "paused" ? "Paused" : phase === "done" ? "Preview before saving" : ""}
        </div>
        {error && <p className="mt-2 text-center text-[13px] text-rose-600">{error}</p>}

        {phase === "idle" && (
          <button onClick={start} className="mt-5 flex h-20 w-20 items-center justify-center rounded-full bg-[#e5485e] text-[#fff] shadow-[0_8px_24px_rgba(0,0,0,0.16)] transition active:scale-95" aria-label="Start recording">
            <Mic size={30} />
          </button>
        )}
        {(phase === "recording" || phase === "paused") && (
          <div className="mt-5 flex items-center gap-5">
            <button onClick={pause} className="flex h-14 w-14 items-center justify-center rounded-full bg-black/[0.06]" aria-label={phase === "paused" ? "Resume" : "Pause"}>
              {phase === "paused" ? <Play size={22} /> : <Pause size={22} />}
            </button>
            <button onClick={stop} className="pulse-ring flex h-20 w-20 items-center justify-center rounded-full bg-ink text-white" aria-label="Stop">
              <Square size={26} fill="currentColor" />
            </button>
          </div>
        )}
        {phase === "done" && blob && (
          <div className="mt-4 w-full space-y-3">
            <audio controls src={previewUrl.current} className="w-full" />
            <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
            <div className="flex gap-2">
              <Button size="lg" className="flex-1" onClick={save} disabled={saving}>
                Save to library
              </Button>
              <Button size="lg" variant="danger" onClick={() => confirmDiscard() && reset()} aria-label="Discard">
                <Trash2 size={16} />
              </Button>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
}
