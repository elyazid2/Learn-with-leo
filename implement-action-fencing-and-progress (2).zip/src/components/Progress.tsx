import type { ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowRight, ChevronRight, Clock, Compass, GraduationCap, MessageCircle, RotateCcw, Target } from "lucide-react";
import { colorOf, db, type Concept, type Project } from "@/lib/db";
import { askLeo, startPlacement } from "@/lib/chat";
import { navigate, projectPath } from "@/lib/router";
import { useSettings } from "@/lib/settings";
import { normalizeAvatarLook } from "@/lib/avatar";
import { accentText } from "@/lib/color";
import AgentAvatar from "./AgentAvatar";
import KnowledgeMap from "./KnowledgeMap";
import PointsCard from "./PointsCard";
import { Button, Ring, Sheet, StatusBar } from "./ui";
import { cn } from "@/utils/cn";

const LEVELS = ["Beginner", "Novice", "Intermediate", "Advanced", "Expert"];
const DUE_COLOR = "#e5940c";

export const TEACH_PROMPT = "Teach me the next thing I should learn.";
export const QUIZ_PROMPT = "Quiz me on what I've been learning — one question at a time.";
const FOCUS_PROMPT = "Look at my points card and knowledge map. What should I focus on right now, and why?";
const reviewPrompt = (due: Concept[]) =>
  `Quiz me on what's due for review, starting with ${due
    .slice(0, 4)
    .map((c) => `"${c.name}"`)
    .join(", ")}.`;

function useLearning(project: Project) {
  const concepts = useLiveQuery(() => db.concepts.where("projectId").equals(project.id).toArray(), [project.id]) ?? [];
  const openPoints = useLiveQuery(() => db.points.where("projectId").equals(project.id).filter((p) => !p.done).count(), [project.id]) ?? 0;
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const developerMode = useSettings((s) => s.developerMode);
  // Mastery counts leaves: parents are containers the AI auto-creates and would cap the score.
  const parentIds = new Set(concepts.map((c) => c.parentId).filter(Boolean) as string[]);
  const leaves = concepts.filter((c) => !parentIds.has(c.id));
  const solid = leaves.filter((c) => c.status === "solid").length;
  const mastery = leaves.length ? solid / leaves.length : 0;
  const recent = concepts.flatMap((c) => c.recent ?? []);
  const correct = recent.reduce((s, r) => s + r, 0);
  const accuracy = recent.length ? correct / recent.length : 0;
  const now = Date.now();
  const due = concepts.filter((c) => c.nextReview && c.nextReview <= now).sort((a, b) => (a.nextReview ?? 0) - (b.nextReview ?? 0));
  const needProvider = providerCount === 0 && !developerMode;
  const go = (fn: () => void) => (needProvider ? navigate("settings") : fn());
  return { concepts, leaves, solid, mastery, recent, correct, accuracy, due, openPoints, needProvider, go };
}

/** The library only shows a learning summary once there is something to summarize. */
export function useHasLearning(project: Project) {
  const n = useLiveQuery(() => db.concepts.where("projectId").equals(project.id).count(), [project.id]);
  return project.placement.status === "done" || (n ?? 0) > 0;
}

/** Neutral placement prompt (lives in the Progress sheet — no colored banner on the library). */
function PlacementCard({ project }: { project: Project }) {
  const L = useLearning(project);
  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);
  const status = project.placement.status;
  return (
    <section className="rounded-2xl bg-card p-4 ring-1 ring-line">
      <div className="flex items-center gap-3">
        <AgentAvatar state="waiting" look={look} size={44} />
        <div className="min-w-0">
          <h3 className="text-[15px] font-semibold">{status === "in_progress" ? "Placement in progress" : "Find your starting point"}</h3>
          <p className="mt-0.5 text-[13px] leading-snug text-muted">Leo asks a few adaptive questions to set your level and build your map.</p>
        </div>
      </div>
      <Button className="mt-3 w-full" onClick={() => L.go(() => void startPlacement(project.id))}>
        <Compass size={16} /> {L.needProvider ? "Add an AI provider for Leo" : status === "in_progress" ? "Continue placement" : "Start placement"}
      </Button>
    </section>
  );
}

/** Compact learning summary at the top of the library. Tapping it opens the Progress sheet. */
export function LearningCard({ project }: { project: Project }) {
  const L = useLearning(project);
  const pl = project.placement;
  return (
    <section className="rounded-2xl bg-card p-4 ring-1 ring-line sm:p-5">
      <button
        onClick={() => navigate(projectPath(project.id, "progress"))}
        className="-m-1.5 flex w-[calc(100%+12px)] items-center gap-3 rounded-xl p-1.5 text-left transition-colors hover:bg-ink/[0.03]"
        aria-label="Open progress, knowledge map and points"
      >
        <div className="min-w-0 flex-1">
          <div className="text-[12px] font-medium text-muted">Level</div>
          <div className="display truncate text-[22px] leading-tight">{pl.status === "done" ? pl.level : "Not set yet"}</div>
        </div>
        <div className="text-right">
          <div className="display text-[22px] leading-tight tabular-nums">{Math.round(L.mastery * 100)}%</div>
          <div className="text-[12px] text-muted">mastered</div>
        </div>
        <ChevronRight size={18} className="shrink-0 text-muted" />
      </button>
      <StatusBar concepts={L.leaves} className="mt-3" />
      <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12.5px] text-muted">
        {L.due.length > 0 && (
          <span className="inline-flex items-center gap-1 font-semibold" style={{ color: accentText(DUE_COLOR) }}>
            <Clock size={13} /> {L.due.length} due for review
          </span>
        )}
        <span>{L.leaves.length} concepts</span>
        <span>
          {L.openPoints} open {L.openPoints === 1 ? "point" : "points"}
        </span>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button onClick={() => L.go(() => void askLeo(project.id, TEACH_PROMPT))}>
          <GraduationCap size={16} /> Teach me
        </Button>
        <Button variant="soft" onClick={() => L.go(() => void askLeo(project.id, L.due.length ? reviewPrompt(L.due) : QUIZ_PROMPT))}>
          <Target size={16} /> {L.due.length ? `Review ${L.due.length}` : "Quiz me"}
        </Button>
      </div>
    </section>
  );
}

function StatTile({ children, label, sub }: { children: ReactNode; label: string; sub: string }) {
  return (
    <div className="flex min-w-0 flex-col items-start gap-2 rounded-2xl bg-card p-3 ring-1 ring-line">
      {children}
      <div className="min-w-0">
        <div className="text-[13px] font-semibold">{label}</div>
        <div className="truncate text-[12px] text-muted">{sub}</div>
      </div>
    </div>
  );
}

function LevelScale({ level, color }: { level?: string; color: string }) {
  const idx = LEVELS.findIndex((l) => l.toLowerCase() === (level ?? "").toLowerCase());
  return (
    <div className="mt-3 flex gap-1">
      {LEVELS.map((l, i) => (
        <div key={l} className="flex-1">
          <div className="h-1.5 rounded-full" style={{ background: idx >= 0 && i <= idx ? color : "var(--line)" }} />
          <div className={cn("mt-1 hidden text-[11px] sm:block", i === idx ? "font-semibold text-ink" : "text-muted")}>{l}</div>
        </div>
      ))}
    </div>
  );
}

/** Everything about learning in one place: level, stats, reviews, knowledge map, points. */
export function ProgressSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const L = useLearning(project);
  const pl = project.placement;
  const col = colorOf(project.color);

  const retake = () =>
    L.go(() => {
      if (!window.confirm("Retake placement? Your level and starting point will be replaced; the map and points stay.")) return;
      void startPlacement(project.id, { restart: true });
    });

  return (
    <Sheet open={open} onClose={onClose} title="Progress" wide>
      <div className="space-y-4">
        {pl.status === "done" ? (
          <section className="rounded-2xl bg-ink/[0.035] p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[12px] font-medium text-muted">Your level</div>
                <div className="display text-[26px] leading-tight">{pl.level}</div>
              </div>
              <Button size="sm" variant="ghost" onClick={retake}>
                <RotateCcw size={14} /> Retake
              </Button>
            </div>
            <LevelScale level={pl.level} color={col.hex} />
            {pl.startingPoint && (
              <p className="mt-3 text-[14px] leading-relaxed">
                <span className="font-semibold">Starting point · </span>
                {pl.startingPoint}
              </p>
            )}
            {pl.summary && <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{pl.summary}</p>}
          </section>
        ) : (
          <PlacementCard project={project} />
        )}

        <div className="grid grid-cols-3 gap-2">
          <StatTile label="Mastery" sub={`${L.solid}/${L.leaves.length} solid`}>
            <Ring value={L.mastery} size={44} color="#16a372">
              {Math.round(L.mastery * 100)}%
            </Ring>
          </StatTile>
          <StatTile label="Accuracy" sub={L.recent.length ? `${L.correct}/${L.recent.length} recent` : "No quizzes yet"}>
            <Ring value={L.accuracy} size={44} color="#3b82f6">
              {L.recent.length ? `${Math.round(L.accuracy * 100)}%` : "–"}
            </Ring>
          </StatTile>
          <StatTile label="Due" sub="for review">
            <span className="display flex h-11 items-center text-[26px] tabular-nums">{L.due.length}</span>
          </StatTile>
        </div>

        {L.due.length > 0 && (
          <button
            onClick={() => L.go(() => void askLeo(project.id, reviewPrompt(L.due)))}
            className="flex w-full items-center gap-3 rounded-2xl bg-card p-4 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.03]"
          >
            <span
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full"
              style={{ background: `color-mix(in srgb, ${DUE_COLOR} 15%, transparent)`, color: accentText(DUE_COLOR) }}
            >
              <Clock size={16} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[14px] font-semibold">
                Review {L.due.length} due concept{L.due.length === 1 ? "" : "s"}
              </span>
              <span className="block truncate text-[12px] text-muted">{L.due.map((c) => c.name).join(" · ")}</span>
            </span>
            <ArrowRight size={16} className="shrink-0 text-muted" />
          </button>
        )}

        <KnowledgeMap project={project} />
        <PointsCard projectId={project.id} />

        <button
          onClick={() => L.go(() => void askLeo(project.id, FOCUS_PROMPT))}
          className="flex w-full items-center gap-3 rounded-2xl bg-card p-4 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.03]"
        >
          <MessageCircle size={18} className="text-muted" />
          <span className="flex-1 text-[14px]">Ask Leo what to focus on next</span>
          <ArrowRight size={16} className="text-muted" />
        </button>
      </div>
    </Sheet>
  );
}
