import { useMemo, useState, type KeyboardEvent as RKeyboardEvent } from "react";
import { FileText, Plus, X } from "lucide-react";
import type { Note } from "@/lib/db";
import { extractLinks, rankNotes, resolveLink } from "@/lib/notes";
import { cn } from "@/utils/cn";

type Item = { note?: Note; create?: string };

/** Ctrl/⌘+O: find a note by name or text, or create one. */
export function QuickSwitcher({ notes, onPick, onCreate, onClose }: { notes: Note[]; onPick: (id: string) => void; onCreate: (title: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [index, setIndex] = useState(0);
  const items = useMemo<Item[]>(() => {
    const list: Item[] = rankNotes(notes, q, 30).map((note) => ({ note }));
    const t = q.trim();
    if (t && !notes.some((n) => n.title.toLowerCase() === t.toLowerCase())) list.push({ create: t });
    return list;
  }, [notes, q]);

  const run = (it: Item | undefined) => {
    if (!it) return;
    if (it.note) onPick(it.note.id);
    else if (it.create) onCreate(it.create);
  };

  const onKey = (e: RKeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setIndex((i) => Math.min(items.length - 1, i + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setIndex((i) => Math.max(0, i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      run(items[index] ?? items[0]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center bg-black/55 px-3 pt-[10vh]" onMouseDown={onClose}>
      <div role="dialog" aria-label="Quick switcher" onMouseDown={(e) => e.stopPropagation()} className="w-full max-w-[560px] overflow-hidden rounded-2xl bg-[#262626] shadow-2xl ring-1 ring-white/10">
        <input
          autoFocus
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setIndex(0);
          }}
          onKeyDown={onKey}
          placeholder="Find or create a note…"
          aria-label="Find or create a note"
          className="h-14 w-full bg-transparent px-4 text-[16px] text-white outline-none placeholder:text-[#6f6f76]"
        />
        <div className="max-h-[55vh] overflow-y-auto border-t border-white/[0.06] p-1.5">
          {items.length === 0 && <p className="px-3 py-6 text-center text-[14px] text-[#8e8e93]">No notes yet. Type a name to create one.</p>}
          {items.map((it, i) => (
            <button
              key={(it.note?.id ?? "new") + i}
              type="button"
              onMouseEnter={() => setIndex(i)}
              onClick={() => run(it)}
              className={cn("flex min-h-12 w-full items-center gap-3 rounded-xl px-3 py-2 text-left", i === index ? "bg-[#7c6af0]/25 text-white" : "text-[#dcddde] hover:bg-white/[0.05]")}
            >
              {it.note ? <FileText size={16} className="shrink-0 text-[#8e8e93]" /> : <Plus size={16} className="shrink-0 text-[#a68bff]" />}
              <span className="min-w-0 flex-1 truncate text-[15px]">{it.note ? it.note.title : `Create “${it.create}”`}</span>
              {it.note && (
                <span className="max-w-[40%] truncate text-[12px] text-[#8e8e93]">
                  {it.note.folder ? `${it.note.folder}/` : ""}
                  {it.note.content.trim().slice(0, 40).replace(/\s+/g, " ")}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

type GNode = { id: string; title: string; x: number; y: number; r: number; deg: number };

/** A small force-directed layout: nodes repel, links pull, everything drifts toward the centre. */
function layoutGraph(notes: Note[]) {
  const n = notes.length;
  if (!n) return { nodes: [] as GNode[], edges: [] as [number, number][], viewBox: "0 0 100 100", unit: 1 };
  const index = new Map<string, number>();
  notes.forEach((note, i) => index.set(note.id, i));
  const seen = new Set<string>();
  const edges: [number, number][] = [];
  for (const note of notes) {
    for (const t of extractLinks(note.content)) {
      const to = resolveLink(t, notes);
      if (!to || to.id === note.id) continue;
      const a = index.get(note.id) as number;
      const b = index.get(to.id) as number;
      const key = a < b ? `${a}-${b}` : `${b}-${a}`;
      if (seen.has(key)) continue;
      seen.add(key);
      edges.push([a, b]);
    }
  }
  const deg = notes.map(() => 0);
  for (const [a, b] of edges) {
    deg[a]++;
    deg[b]++;
  }
  const x = notes.map((_, i) => Math.cos((i / n) * Math.PI * 2) * (90 + (i % 5) * 14));
  const y = notes.map((_, i) => Math.sin((i / n) * Math.PI * 2) * (90 + (i % 5) * 14));
  const iters = n > 250 ? 80 : 240;
  for (let it = 0; it < iters; it++) {
    const cool = 1 - it / iters;
    const fx = notes.map(() => 0);
    const fy = notes.map(() => 0);
    if (n <= 400) {
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          const dx = x[i] - x[j];
          const dy = y[i] - y[j];
          const d2 = dx * dx + dy * dy + 1;
          const d = Math.sqrt(d2);
          const f = 1200 / d2;
          fx[i] += (dx / d) * f;
          fy[i] += (dy / d) * f;
          fx[j] -= (dx / d) * f;
          fy[j] -= (dy / d) * f;
        }
      }
    }
    for (const [a, b] of edges) {
      const dx = x[b] - x[a];
      const dy = y[b] - y[a];
      const d = Math.sqrt(dx * dx + dy * dy) + 0.01;
      const f = (d - 80) * 0.035;
      fx[a] += (dx / d) * f;
      fy[a] += (dy / d) * f;
      fx[b] -= (dx / d) * f;
      fy[b] -= (dy / d) * f;
    }
    for (let i = 0; i < n; i++) {
      fx[i] -= x[i] * 0.01;
      fy[i] -= y[i] * 0.01;
      const mag = Math.hypot(fx[i], fy[i]) || 1;
      const step = Math.min(mag, 14 * cool + 0.6);
      x[i] += (fx[i] / mag) * step;
      y[i] += (fy[i] / mag) * step;
    }
  }
  const minX = Math.min(...x);
  const maxX = Math.max(...x);
  const minY = Math.min(...y);
  const maxY = Math.max(...y);
  const pad = 70;
  const w = maxX - minX + pad * 2;
  const h = maxY - minY + pad * 2;
  const unit = Math.max(w, h) / 100;
  const nodes: GNode[] = notes.map((note, i) => ({
    id: note.id,
    title: note.title,
    x: x[i],
    y: y[i],
    r: unit * (1.1 + Math.min(1.6, deg[i] * 0.25)),
    deg: deg[i],
  }));
  return { nodes, edges, viewBox: `${minX - pad} ${minY - pad} ${w} ${h}`, unit };
}

/** Graph view of linked notes. Orphans are shown too, so you can see what is not connected yet. */
export function GraphOverlay({ notes, activeId, onOpen, onClose }: { notes: Note[]; activeId?: string; onOpen: (id: string) => void; onClose: () => void }) {
  const graph = useMemo(() => layoutGraph(notes), [notes]);
  return (
    <div role="dialog" aria-modal="true" aria-label="Graph view" className="fixed inset-0 z-[90] flex flex-col bg-[#1a1a1a]">
      <div className="flex h-12 shrink-0 items-center justify-between border-b border-white/[0.06] px-4">
        <span className="text-[13px] text-[#8e8e93]">
          Graph view · {graph.nodes.length} {graph.nodes.length === 1 ? "note" : "notes"} · {graph.edges.length} {graph.edges.length === 1 ? "link" : "links"}
        </span>
        <button type="button" onClick={onClose} className="flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-[13px] text-[#c4c4c8] hover:bg-white/[0.06]">
          <X size={15} /> Close
        </button>
      </div>
      <div className="min-h-0 flex-1">
        {graph.nodes.length === 0 ? (
          <p className="p-8 text-center text-[14px] text-[#8e8e93]">Create a few notes and link them with [[wikilinks]] to see your graph.</p>
        ) : (
          <svg viewBox={graph.viewBox} className="h-full w-full" role="img" aria-label="Note graph">
            {graph.edges.map(([a, b], i) => (
              <line key={i} x1={graph.nodes[a].x} y1={graph.nodes[a].y} x2={graph.nodes[b].x} y2={graph.nodes[b].y} stroke="#4a4a52" strokeWidth={graph.unit * 0.22} />
            ))}
            {graph.nodes.map((node) => {
              const fill = node.id === activeId ? "#a68bff" : node.deg ? "#8e8e96" : "#4a4a52";
              return (
                <g key={node.id} onClick={() => onOpen(node.id)} className="cursor-pointer">
                  <circle cx={node.x} cy={node.y} r={node.r} fill={fill} />
                  <text x={node.x} y={node.y + node.r + graph.unit * 3} textAnchor="middle" fontSize={graph.unit * 2.6} fill={node.id === activeId ? "#e4dcff" : "#a1a1aa"}>
                    {node.title}
                  </text>
                </g>
              );
            })}
          </svg>
        )}
      </div>
    </div>
  );
}
