import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, FileText, FilePlus, Folder as FolderIcon, FolderInput, FolderPlus, Link2, MoreHorizontal, Pencil, Search, Trash2, X } from "lucide-react";
import type { Folder, Note } from "@/lib/db";
import { allFolders, backlinksOf, createFolder, extractLinks, extractTags, leafOf, moveNote, parentOf, pathOf, renameNote, resolveLink, tagCounts } from "@/lib/notes";
import { cn } from "@/utils/cn";

function readJSON<T>(key: string, fallback: T): T {
  try {
    const v = JSON.parse(localStorage.getItem(key) || "null");
    return v ?? fallback;
  } catch {
    return fallback;
  }
}

const byTitle = (a: Note, b: Note) => a.title.localeCompare(b.title);

interface TreeProps {
  projectId: string;
  notes: Note[];
  folders: Folder[];
  activeId?: string;
  selectedFolder: string;
  onSelectFolder: (folder: string) => void;
  onOpen: (id: string) => void;
  onNewNote: (folder: string) => void;
  onDelete: (note: Note) => void;
  tagFilter: string | null;
  onTagFilter: (tag: string | null) => void;
  onClose?: () => void;
}

/** Obsidian-style file tree: folders and notes, filter, tags, rename / move / delete. */
export function FileTree(p: TreeProps) {
  const storeKey = `harness.notes.open.${p.projectId}`;
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(readJSON<string[]>(storeKey, [])));
  const [query, setQuery] = useState("");
  const [renaming, setRenaming] = useState<string | null>(null);
  const [menu, setMenu] = useState<Note | null>(null);
  const [newFolder, setNewFolder] = useState<string | null>(null);
  const folderPaths = useMemo(() => allFolders(p.notes, p.folders), [p.notes, p.folders]);
  const tags = useMemo(() => tagCounts(p.notes), [p.notes]);

  useEffect(() => {
    localStorage.setItem(storeKey, JSON.stringify([...expanded]));
  }, [expanded, storeKey]);

  const toggle = (path: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });

  const q = query.trim().toLowerCase();
  const flat = q
    ? p.notes.filter((n) => n.title.toLowerCase().includes(q) || pathOf(n).toLowerCase().includes(q))
    : p.tagFilter
      ? p.notes.filter((n) => extractTags(n.content).includes(p.tagFilter as string))
      : null;

  const noteRow = (n: Note, depth: number) => (
    <div key={`n:${n.id}`} className="group flex items-center pr-1" style={{ paddingLeft: depth * 14 + 6 }}>
      {renaming === n.id ? (
        <LineInput
          initial={n.title}
          onDone={async (v) => {
            setRenaming(null);
            if (v) await renameNote(p.notes, n, v);
          }}
        />
      ) : (
        <button
          type="button"
          onClick={() => p.onOpen(n.id)}
          aria-current={n.id === p.activeId ? "page" : undefined}
          className={cn(
            "flex min-h-10 min-w-0 flex-1 items-center gap-2 rounded-md px-2 text-left text-[14px] transition-colors",
            n.id === p.activeId ? "bg-white/[0.09] text-white" : "text-[#b4b4b8] hover:bg-white/[0.05] hover:text-white"
          )}
        >
          <FileText size={15} className="shrink-0 text-[#8e8e93]" />
          <span className="truncate">{n.title}</span>
        </button>
      )}
      {renaming !== n.id && (
        <button
          type="button"
          aria-label={`Actions for ${n.title}`}
          onClick={() => setMenu(n)}
          className="ml-0.5 flex h-10 w-9 shrink-0 items-center justify-center rounded-md text-[#8e8e93] hover:bg-white/[0.07] hover:text-white md:opacity-0 md:group-hover:opacity-100 md:focus:opacity-100"
        >
          <MoreHorizontal size={16} />
        </button>
      )}
    </div>
  );

  const folderRow = (path: string, depth: number) => {
    const leaf = leafOf(path);
    const isOpen = expanded.has(path);
    return (
      <div key={`f:${path}`} className="group flex items-center pr-1" style={{ paddingLeft: depth * 14 }}>
        <button type="button" aria-label={`${isOpen ? "Collapse" : "Expand"} ${leaf}`} onClick={() => toggle(path)} className="flex h-10 w-7 shrink-0 items-center justify-center text-[#8e8e93]">
          <ChevronRight size={15} className={cn("transition-transform", isOpen && "rotate-90")} />
        </button>
        <button
          type="button"
          onClick={() => {
            p.onSelectFolder(path);
            if (!isOpen) toggle(path);
          }}
          className={cn("flex min-h-10 min-w-0 flex-1 items-center gap-2 rounded-md px-1.5 text-left text-[14px]", p.selectedFolder === path ? "text-white" : "text-[#c4c4c8] hover:text-white")}
        >
          <FolderIcon size={15} className="shrink-0 text-[#8e8e93]" />
          <span className="truncate">{leaf}</span>
        </button>
        <button
          type="button"
          aria-label={`New note in ${leaf}`}
          onClick={() => p.onNewNote(path)}
          className="flex h-10 w-9 shrink-0 items-center justify-center rounded-md text-[#8e8e93] hover:bg-white/[0.07] hover:text-white md:opacity-0 md:group-hover:opacity-100"
        >
          <FilePlus size={15} />
        </button>
      </div>
    );
  };

  const renderLevel = (parent: string, depth: number): ReactNode[] => {
    const out: ReactNode[] = [];
    for (const f of folderPaths.filter((f) => parentOf(f) === parent)) {
      out.push(folderRow(f, depth));
      if (expanded.has(f)) out.push(...renderLevel(f, depth + 1));
    }
    for (const n of p.notes.filter((n) => (n.folder ?? "") === parent).sort(byTitle)) out.push(noteRow(n, depth));
    return out;
  };

  const createFolderFrom = async (name: string | null) => {
    const parent = newFolder ?? "";
    setNewFolder(null);
    if (!name) return;
    const path = await createFolder(p.projectId, parent ? `${parent}/${name}` : name);
    if (parent) setExpanded((prev) => new Set(prev).add(parent));
    if (path) p.onSelectFolder(path);
  };

  const empty = p.notes.length === 0 && newFolder === null && folderPaths.length === 0;

  return (
    <>
      <div className="flex shrink-0 items-center gap-0.5 px-3 pb-1 pt-3">
        <span className="flex-1 pl-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-[#8e8e93]">Files</span>
        <button type="button" aria-label="New note" title="New note" onClick={() => p.onNewNote(p.selectedFolder)} className="flex h-10 w-10 items-center justify-center rounded-lg text-[#9a9aa0] hover:bg-white/[0.07] hover:text-white">
          <FilePlus size={17} />
        </button>
        <button type="button" aria-label="New folder" title="New folder" onClick={() => setNewFolder(p.selectedFolder)} className="flex h-10 w-10 items-center justify-center rounded-lg text-[#9a9aa0] hover:bg-white/[0.07] hover:text-white">
          <FolderPlus size={17} />
        </button>
        {p.onClose && (
          <button type="button" aria-label="Close file list" onClick={p.onClose} className="flex h-10 w-10 items-center justify-center rounded-lg text-[#9a9aa0] hover:bg-white/[0.07] hover:text-white">
            <X size={17} />
          </button>
        )}
      </div>
      <div className="px-3 pb-2">
        <div className="flex h-10 items-center gap-2 rounded-lg bg-white/[0.05] px-2.5 text-[#8e8e93] ring-1 ring-white/[0.04] focus-within:ring-[#7c6af0]/60">
          <Search size={14} className="shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter notes"
            aria-label="Filter notes"
            className="min-w-0 flex-1 bg-transparent text-[14px] text-[#e5e5e7] outline-none placeholder:text-[#6f6f76]"
          />
        </div>
        <div className="mt-1.5 min-h-4 px-1 text-[12px] text-[#6f6f76]">{p.selectedFolder ? `New notes go to ${p.selectedFolder}` : "New notes go to the root"}</div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-1.5 pb-4">
        {p.tagFilter && (
          <div className="mx-1 mb-1 flex items-center justify-between rounded-md bg-[#7c6af0]/15 px-2.5 py-1.5 text-[13px] text-[#c9bfff]">
            <span>#{p.tagFilter}</span>
            <button type="button" onClick={() => p.onTagFilter(null)} className="rounded px-1.5 py-0.5 hover:bg-white/10">
              Clear
            </button>
          </div>
        )}
        {newFolder !== null && (
          <div className="px-1 pb-1" style={{ paddingLeft: (newFolder ? newFolder.split("/").length * 14 : 0) + 6 }}>
            <LineInput initial="" placeholder="Folder name" onDone={(v) => void createFolderFrom(v)} />
          </div>
        )}
        {flat ? (
          [...flat].sort(byTitle).map((n) => noteRow(n, 0))
        ) : empty ? (
          <p className="px-3 py-8 text-center text-[13px] leading-relaxed text-[#8e8e93]">No notes yet. Tap + to create your first note.</p>
        ) : (
          renderLevel("", 0)
        )}
      </div>

      {tags.length > 0 && (
        <div className="shrink-0 border-t border-white/[0.06] px-3 py-3">
          <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.08em] text-[#8e8e93]">Tags</div>
          <div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">
            {tags.map(([t, c]) => (
              <button
                key={t}
                type="button"
                onClick={() => p.onTagFilter(p.tagFilter === t ? null : t)}
                className={cn("rounded-md px-2 py-1 text-[12.5px] transition-colors", p.tagFilter === t ? "bg-emerald-400/25 text-emerald-200" : "bg-emerald-400/10 text-emerald-300 hover:bg-emerald-400/20")}
              >
                #{t} <span className="opacity-60">{c}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {menu && (
        <ActionMenu
          note={menu}
          folders={folderPaths}
          onClose={() => setMenu(null)}
          onRename={() => {
            setRenaming(menu.id);
            setMenu(null);
          }}
          onMove={async (folder) => {
            await moveNote(menu, folder);
            if (folder) setExpanded((prev) => new Set(prev).add(folder));
            setMenu(null);
          }}
          onDelete={() => {
            const n = menu;
            setMenu(null);
            p.onDelete(n);
          }}
        />
      )}
    </>
  );
}

/** Inline text field used for renaming and creating folders. Commits once, on Enter or blur. */
function LineInput({ initial, placeholder, onDone }: { initial: string; placeholder?: string; onDone: (value: string | null) => void }) {
  const done = useRef(false);
  const finish = (v: string | null) => {
    if (done.current) return;
    done.current = true;
    onDone(v && v.trim() ? v.trim() : null);
  };
  return (
    <input
      autoFocus
      defaultValue={initial}
      placeholder={placeholder}
      aria-label={placeholder ?? "Rename note"}
      onFocus={(e) => e.currentTarget.select()}
      onBlur={(e) => finish(e.currentTarget.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") finish(e.currentTarget.value);
        if (e.key === "Escape") finish(null);
      }}
      className="my-0.5 h-10 min-w-0 w-full rounded-md bg-white/[0.08] px-2.5 text-[14px] text-white outline-none ring-1 ring-[#7c6af0]"
    />
  );
}

function ActionMenu({
  note,
  folders,
  onClose,
  onRename,
  onMove,
  onDelete,
}: {
  note: Note;
  folders: string[];
  onClose: () => void;
  onRename: () => void;
  onMove: (folder: string) => void;
  onDelete: () => void;
}) {
  const [moving, setMoving] = useState(false);
  return (
    <div className="fixed inset-0 z-[95] flex items-end justify-center bg-black/50 p-3 md:items-center" onMouseDown={onClose}>
      <div role="menu" onMouseDown={(e) => e.stopPropagation()} className="w-full max-w-sm overflow-hidden rounded-2xl bg-[#262626] p-1.5 shadow-2xl ring-1 ring-white/10">
        <div className="truncate px-3 py-2 text-[13px] text-[#8e8e93]">{note.title}</div>
        {!moving ? (
          <>
            <MenuItem icon={<Pencil size={17} />} label="Rename" onClick={onRename} />
            <MenuItem icon={<FolderInput size={17} />} label="Move to folder…" onClick={() => setMoving(true)} />
            <MenuItem icon={<Link2 size={17} />} label={`Folder: ${note.folder || "root"}`} onClick={() => undefined} muted />
            <MenuItem icon={<Trash2 size={17} />} label="Delete note" danger onClick={onDelete} />
          </>
        ) : (
          <div className="max-h-[60vh] overflow-y-auto">
            <MenuItem icon={<ChevronLeft size={17} />} label="Back" onClick={() => setMoving(false)} />
            <MenuItem icon={<FolderIcon size={17} />} label="Root (no folder)" onClick={() => onMove("")} />
            {folders.map((f) => (
              <MenuItem key={f} icon={<FolderIcon size={17} />} label={f} onClick={() => onMove(f)} />
            ))}
          </div>
        )}
        <button type="button" onClick={onClose} className="mt-1 flex min-h-12 w-full items-center justify-center rounded-xl text-[15px] font-medium text-[#c4c4c8] hover:bg-white/[0.06]">
          Cancel
        </button>
      </div>
    </div>
  );
}

function MenuItem({ icon, label, onClick, danger, muted }: { icon: ReactNode; label: string; onClick: () => void; danger?: boolean; muted?: boolean }) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      className={cn(
        "flex min-h-12 w-full items-center gap-3 rounded-xl px-3 text-left text-[15px] transition-colors hover:bg-white/[0.07]",
        danger ? "text-red-400" : muted ? "text-[#8e8e93]" : "text-[#e5e5e7]"
      )}
    >
      <span className="shrink-0">{icon}</span>
      <span className="min-w-0 truncate">{label}</span>
    </button>
  );
}

/** Right panel: backlinks, outgoing links, tags and details for the open note. */
export function InfoPanel({
  note,
  notes,
  onOpen,
  onOpenLink,
  onTag,
}: {
  note: Note;
  notes: Note[];
  onOpen: (id: string) => void;
  onOpenLink: (target: string) => void;
  onTag: (tag: string) => void;
}) {
  const backlinks = useMemo(() => backlinksOf(note, notes), [note, notes]);
  const outgoing = useMemo(() => {
    const seen = new Set<string>();
    const out: { target: string; hit?: Note }[] = [];
    for (const t of extractLinks(note.content)) {
      const k = t.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push({ target: t, hit: resolveLink(t, notes) });
    }
    return out;
  }, [note, notes]);
  const tags = useMemo(() => extractTags(note.content), [note.content]);
  const words = note.content.trim() ? note.content.trim().split(/\s+/).length : 0;

  return (
    <div className="flex h-full flex-col overflow-y-auto px-4 py-4 text-[14px]">
      <Section title={`Backlinks · ${backlinks.length}`}>
        {backlinks.length === 0 && <p className="px-2 text-[13px] text-[#6f6f76]">No notes link here yet.</p>}
        {backlinks.map((b) => (
          <button key={b.note.id} type="button" onClick={() => onOpen(b.note.id)} className="block w-full rounded-lg px-2 py-2 text-left hover:bg-white/[0.05]">
            <div className="truncate text-[14px] text-[#dcddde]">{b.note.title}</div>
            <div className="line-clamp-2 text-[12.5px] leading-snug text-[#8e8e93]">{b.line}</div>
          </button>
        ))}
      </Section>
      <Section title={`Outgoing links · ${outgoing.length}`}>
        {outgoing.length === 0 && <p className="px-2 text-[13px] text-[#6f6f76]">Type [[ to link another note.</p>}
        {outgoing.map((o) => (
          <button key={o.target} type="button" onClick={() => onOpenLink(o.target)} className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-[14px] hover:bg-white/[0.05]">
            <Link2 size={14} className="shrink-0 text-[#8e8e93]" />
            <span className={cn("min-w-0 flex-1 truncate", !o.hit && "text-[#f0a0a8]")}>{o.target}</span>
            {!o.hit && <span className="shrink-0 text-[11px] text-[#8e8e93]">create</span>}
          </button>
        ))}
      </Section>
      <Section title="Tags">
        {tags.length === 0 && <p className="px-2 text-[13px] text-[#6f6f76]">Add #tags anywhere in the note.</p>}
        <div className="flex flex-wrap gap-1.5 px-1">
          {tags.map((t) => (
            <button key={t} type="button" onClick={() => onTag(t)} className="rounded-md bg-emerald-400/10 px-2 py-1 text-[13px] text-emerald-300 hover:bg-emerald-400/20">
              #{t}
            </button>
          ))}
        </div>
      </Section>
      <Section title="Details">
        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 px-2 text-[13px] text-[#8e8e93]">
          <dt>Path</dt>
          <dd className="truncate text-[#c4c4c8]">{pathOf(note)}.md</dd>
          <dt>Words</dt>
          <dd className="text-[#c4c4c8]">{words}</dd>
          <dt>Created</dt>
          <dd className="text-[#c4c4c8]">{new Date(note.createdAt).toLocaleDateString()}</dd>
        </dl>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-6">
      <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.08em] text-[#8e8e93]">{title}</h3>
      {children}
    </section>
  );
}
