import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type KeyboardEvent as RKeyboardEvent } from "react";
import ReactMarkdown, { defaultUrlTransform } from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { useLiveQuery } from "dexie-react-hooks";
import { BookOpen, Bold, Check, Code, Hash, Heading, Italic, Link2, List, ListChecks, ListOrdered, Pencil, Quote, Sigma, Trash2, type LucideIcon } from "lucide-react";
import { db, type Note } from "@/lib/db";
import { useApp } from "@/lib/store";
import { indexNote } from "@/lib/retrieval";
import { normalizeMath } from "@/components/Markdown";
import { LIST_RE, nextMarker, toggleTask } from "@/lib/blocks";
import { pathOf, rankNotes, renameNote, renderableMarkdown, resolveLink, softTitle } from "@/lib/notes";
import { timeAgo } from "@/lib/media";
import { cn } from "@/utils/cn";

const TOUCH = typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches;

type Mode = "edit" | "read";
interface Draft {
  title: string;
  content: string;
}
type Item = { note?: Note; create?: string };
interface Suggest {
  start: number;
  query: string;
  index: number;
}

const readMode = (): Mode => (typeof localStorage !== "undefined" && localStorage.getItem("harness.notes.mode") === "read" ? "read" : "edit");

/** True on phones and tablets with a touch screen. */
export function useIsWide() {
  const [wide, setWide] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const on = () => setWide(mq.matches);
    on();
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return wide;
}

/** Pixels covered by the on-screen keyboard (0 when there is none). */
export function useKeyboardInset() {
  const [inset, setInset] = useState(0);
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    const on = () => setInset(Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop)));
    on();
    vv.addEventListener("resize", on);
    vv.addEventListener("scroll", on);
    return () => {
      vv.removeEventListener("resize", on);
      vv.removeEventListener("scroll", on);
    };
  }, []);
  return inset;
}

interface Props {
  noteId: string;
  notes: Note[];
  onOpenLink: (target: string) => void;
  onTag: (tag: string) => void;
  onDelete: () => void;
}

/** One note: title (the file name), edit / reading modes, autosave, [[ autocomplete and a compact keyboard toolbar. */
export default function NoteEditor({ noteId, notes, onOpenLink, onTag, onDelete }: Props) {
  const live = useLiveQuery(async () => (await db.notes.get(noteId)) ?? null, [noteId]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [mode, setMode] = useState<Mode>(readMode);
  const [saved, setSaved] = useState(true);
  const [focused, setFocused] = useState(false);
  const [suggest, setSuggest] = useState<Suggest | null>(null);
  const ta = useRef<HTMLTextAreaElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);
  const latest = useRef<Draft>({ title: "", content: "" });
  const dirty = useRef(false);
  const base = useRef<{ title: string; updatedAt: number } | null>(null);
  const timer = useRef<number | undefined>(undefined);
  const pendingSel = useRef<[number, number] | null>(null);
  const autoFocused = useRef(false);
  const notesRef = useRef(notes);
  notesRef.current = notes;
  const setNoteCtx = useApp((s) => s.setNote);
  const inset = useKeyboardInset();

  // Pull outside changes (renames from the file tree, other tabs) without clobbering what is being typed.
  useEffect(() => {
    if (!live) return;
    if (base.current && (dirty.current || live.updatedAt === base.current.updatedAt)) return;
    base.current = { title: live.title, updatedAt: live.updatedAt };
    latest.current = { title: live.title, content: live.content };
    setDraft(latest.current);
  }, [live]);

  const persist = useCallback(async () => {
    window.clearTimeout(timer.current);
    if (!dirty.current || !base.current) return;
    dirty.current = false;
    const { title, content } = latest.current;
    const current = await db.notes.get(noteId);
    if (!current) return;
    const now = Date.now();
    let nextTitle = current.title;
    if (title !== current.title) nextTitle = await renameNote(notesRef.current, current, title);
    await db.notes.update(noteId, { title: nextTitle, content, updatedAt: now });
    await db.projects.update(current.projectId, { updatedAt: now });
    const fresh = await db.notes.get(noteId);
    if (fresh) await indexNote(fresh);
    base.current = { title: nextTitle, updatedAt: now };
    if (nextTitle !== title && latest.current.title === title) {
      latest.current = { ...latest.current, title: nextTitle };
      setDraft(latest.current);
    }
    if (!dirty.current) setSaved(true);
  }, [noteId]);

  const schedule = () => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void persist(), 450);
  };

  const update = (patch: Partial<Draft>) => {
    const next = { ...latest.current, ...patch };
    latest.current = next;
    dirty.current = true;
    setSaved(false);
    setDraft(next);
    schedule();
  };

  // Flush on leave so a quick back-navigation never drops typing.
  useEffect(() => {
    const flush = () => void persist();
    window.addEventListener("pagehide", flush);
    return () => {
      window.removeEventListener("pagehide", flush);
      void persist();
    };
  }, [persist]);

  // Share the open note with Leo.
  useEffect(() => {
    if (draft) setNoteCtx({ id: noteId, title: draft.title || "Untitled", content: draft.content });
  }, [draft, noteId, setNoteCtx]);
  useEffect(() => () => setNoteCtx(null), [setNoteCtx]);

  useEffect(() => {
    if (draft && !autoFocused.current) {
      autoFocused.current = true;
      if (!draft.content && draft.title === "Untitled") titleRef.current?.focus();
    }
  }, [draft]);

  const content = draft?.content ?? "";
  useLayoutEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
    if (pendingSel.current) {
      const [a, b] = pendingSel.current;
      pendingSel.current = null;
      el.focus({ preventScroll: true });
      el.setSelectionRange(a, b);
    }
  }, [content, mode]);

  /* ------------------------------------------------------------ editing helpers */

  const withSel = (fn: (v: string, s: number, e: number) => { value: string; start: number; end: number }) => {
    const el = ta.current;
    const v = latest.current.content;
    const s = el?.selectionStart ?? v.length;
    const e = el?.selectionEnd ?? s;
    const r = fn(v, s, e);
    pendingSel.current = [r.start, r.end];
    update({ content: r.value });
    el?.focus({ preventScroll: true });
  };

  const wrap = (before: string, after = before, placeholder = "text") =>
    withSel((v, s, e) => {
      const sel = v.slice(s, e) || placeholder;
      return { value: v.slice(0, s) + before + sel + after + v.slice(e), start: s + before.length, end: s + before.length + sel.length };
    });

  const prefix = (p: string) =>
    withSel((v, s, e) => {
      const lineStart = v.lastIndexOf("\n", s - 1) + 1;
      const lines = v.slice(lineStart, e).split("\n");
      const allHave = lines.every((l) => l.startsWith(p));
      const replaced = lines.map((l) => (allHave ? l.slice(p.length) : p + l.replace(LIST_RE, "").replace(/^#{1,6}\s+/, ""))).join("\n");
      const caret = lineStart + replaced.length;
      return { value: v.slice(0, lineStart) + replaced + v.slice(e), start: caret, end: caret };
    });

  const insertWikilink = () => {
    const el = ta.current;
    const v = latest.current.content;
    const s = el?.selectionStart ?? v.length;
    const e = el?.selectionEnd ?? s;
    pendingSel.current = [s + 2, s + 2];
    setSuggest({ start: s, query: "", index: 0 });
    update({ content: v.slice(0, s) + "[[" + v.slice(e) });
    el?.focus({ preventScroll: true });
  };

  const onText = (value: string, caret: number) => {
    update({ content: value });
    const m = /\[\[([^[\]\n|#]*)$/.exec(value.slice(0, caret));
    setSuggest(m ? { start: caret - m[0].length, query: m[1], index: 0 } : null);
  };

  const items = useMemo<Item[]>(() => {
    if (!suggest) return [];
    const q = suggest.query.trim();
    const list: Item[] = rankNotes(
      notes.filter((n) => n.id !== noteId),
      q,
      7
    ).map((note) => ({ note }));
    if (q && !notes.some((n) => n.title.toLowerCase() === q.toLowerCase())) list.push({ create: q });
    return list;
  }, [suggest, notes, noteId]);

  const pick = (item: Item) => {
    if (!suggest) return;
    const v = latest.current.content;
    const caret = ta.current?.selectionStart ?? v.length;
    const note = item.note;
    const duplicate = !!note && notes.filter((n) => n.title === note.title).length > 1;
    const target = note ? (duplicate ? pathOf(note) : note.title) : item.create ?? "";
    const link = `[[${target}]]`;
    pendingSel.current = [suggest.start + link.length, suggest.start + link.length];
    setSuggest(null);
    update({ content: v.slice(0, suggest.start) + link + v.slice(caret) });
  };

  const onKeyDown = (e: RKeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && !e.altKey) {
      const k = e.key.toLowerCase();
      if (k === "b") return (e.preventDefault(), wrap("**"));
      if (k === "i") return (e.preventDefault(), wrap("*"));
      if (k === "k") return (e.preventDefault(), insertWikilink());
    }
    if (suggest && items.length) {
      if (e.key === "ArrowDown") return (e.preventDefault(), setSuggest({ ...suggest, index: (suggest.index + 1) % items.length }));
      if (e.key === "ArrowUp") return (e.preventDefault(), setSuggest({ ...suggest, index: (suggest.index - 1 + items.length) % items.length }));
      if (e.key === "Enter" || e.key === "Tab") return (e.preventDefault(), pick(items[suggest.index] ?? items[0]));
    }
    if (suggest && e.key === "Escape") return (e.preventDefault(), setSuggest(null));
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      const el = e.currentTarget;
      const v = el.value;
      const s = el.selectionStart;
      if (s !== el.selectionEnd) return;
      const lineStart = v.lastIndexOf("\n", s - 1) + 1;
      const line = v.slice(lineStart, s);
      const m = LIST_RE.exec(line);
      if (!m) return;
      e.preventDefault();
      const marker = m[0];
      const rest = v.slice(s).split("\n")[0];
      if (line.trim() === marker.trim() && rest.trim() === "") {
        // Enter on an empty item ends the list.
        pendingSel.current = [lineStart, lineStart];
        update({ content: v.slice(0, lineStart) + v.slice(s) });
      } else {
        const next = nextMarker(marker);
        const caret = s + 1 + next.length;
        pendingSel.current = [caret, caret];
        update({ content: v.slice(0, s) + "\n" + next + v.slice(s) });
      }
    }
  };

  const switchMode = (m: Mode) => {
    setMode(m);
    localStorage.setItem("harness.notes.mode", m);
    if (m === "read") ta.current?.blur();
  };

  /* ------------------------------------------------------------ render */

  if (live === undefined) return <div className="h-full" />;
  if (live === null) return <div className="flex h-full items-center justify-center text-[14px] text-[#8e8e93]">This note no longer exists.</div>;
  if (!draft) return <div className="h-full" />;

  const words = draft.content.trim() ? draft.content.trim().split(/\s+/).length : 0;

  const actions: { label: string; icon: LucideIcon; run: () => void }[] = [
    { label: "Link to a note [[ ]]", icon: Link2, run: insertWikilink },
    { label: "Tag", icon: Hash, run: () => wrap("#", "", "tag") },
    { label: "Bold", icon: Bold, run: () => wrap("**") },
    { label: "Italic", icon: Italic, run: () => wrap("*") },
    { label: "Heading", icon: Heading, run: () => prefix("## ") },
    { label: "Bulleted list", icon: List, run: () => prefix("- ") },
    { label: "Numbered list", icon: ListOrdered, run: () => prefix("1. ") },
    { label: "Checklist", icon: ListChecks, run: () => prefix("- [ ] ") },
    { label: "Quote", icon: Quote, run: () => prefix("> ") },
    { label: "Code", icon: Code, run: () => wrap("`") },
    { label: "Math", icon: Sigma, run: () => wrap("$", "$", "x^2") },
  ];
  const actionButton = (a: (typeof actions)[number], big: boolean) => {
    const Icon = a.icon;
    return (
      <button
        key={a.label}
        type="button"
        aria-label={a.label}
        title={a.label}
        onMouseDown={(e) => e.preventDefault()}
        onClick={a.run}
        className={cn(
          "flex shrink-0 items-center justify-center text-[#b4b4b8] transition-colors hover:bg-white/[0.07] hover:text-white active:scale-95",
          big ? "h-11 w-11 rounded-xl" : "h-8 w-8 rounded-md"
        )}
      >
        <Icon size={big ? 19 : 16} strokeWidth={2} />
      </button>
    );
  };

  const showMobileBar = TOUCH && focused && mode === "edit";

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      <div className="flex shrink-0 items-center gap-1.5 border-b border-white/[0.06] px-2 py-1 md:px-4">
        <div role="toolbar" aria-label="Formatting" className="hidden min-w-0 flex-1 items-center gap-0.5 overflow-x-auto md:flex">
          {mode === "edit" && actions.map((a) => actionButton(a, false))}
        </div>
        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <div role="group" aria-label="Mode" className="flex shrink-0 rounded-lg bg-white/[0.05] p-0.5">
            {(["edit", "read"] as const).map((m) => (
              <button
                key={m}
                type="button"
                aria-pressed={mode === m}
                onClick={() => switchMode(m)}
                className={cn(
                  "flex h-9 items-center gap-1.5 rounded-md px-2.5 text-[13px] font-medium transition-colors md:h-7",
                  mode === m ? "bg-white/[0.12] text-white" : "text-[#8e8e93] hover:text-white"
                )}
              >
                {m === "edit" ? <Pencil size={14} /> : <BookOpen size={14} />}
                <span className="hidden sm:inline">{m === "edit" ? "Editing" : "Reading"}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={onDelete}
            aria-label="Delete note"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-[#8e8e93] transition-colors hover:bg-red-500/10 hover:text-red-400 md:h-8 md:w-8"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-[880px] px-5 pb-52 pt-6 md:px-12 md:pt-10" data-ctx-source={`note "${draft.title || "Untitled"}"`}>
          <input
            ref={titleRef}
            value={draft.title}
            onChange={(e) => update({ title: softTitle(e.target.value) })}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                ta.current?.focus();
              }
            }}
            placeholder="Untitled"
            aria-label="Note title"
            className="obs-title block w-full bg-transparent outline-none placeholder:text-[#5c5c63]"
          />
          <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12.5px] text-[#8e8e93] tabular-nums">
            <span className="truncate">{pathOf({ title: draft.title, folder: live.folder })}</span>
            <span aria-hidden>·</span>
            <span>
              {words} {words === 1 ? "word" : "words"}
            </span>
            <span aria-hidden>·</span>
            <span>Edited {timeAgo(live.updatedAt)}</span>
            <span className="inline-flex items-center gap-1.5" aria-live="polite">
              <span className={cn("h-1.5 w-1.5 rounded-full", saved ? "bg-emerald-400" : "bg-amber-400")} />
              {saved ? "Saved" : "Saving…"}
            </span>
          </div>

          <div className={cn("mt-6", mode === "edit" && "md:grid md:grid-cols-2 md:gap-10")}>
            <div className={cn(mode === "read" && "hidden")}>
              <textarea
                ref={ta}
                value={draft.content}
                onChange={(e) => onText(e.target.value, e.target.selectionStart)}
                onKeyDown={onKeyDown}
                onFocus={() => setFocused(true)}
                onBlur={() => {
                  setFocused(false);
                  setSuggest(null);
                }}
                rows={12}
                dir="auto"
                spellCheck
                aria-label="Note content"
                placeholder="Start writing… use [[links]] to connect notes, #tags, Markdown and $math$ work"
                className="obs-source block w-full resize-none overflow-hidden bg-transparent outline-none placeholder:text-[#5c5c63]"
              />
            </div>
            <div className={cn(mode === "edit" ? "hidden md:block md:border-l md:border-white/[0.06] md:pl-10" : "")}>
              {mode === "edit" && <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.08em] text-[#6f6f76]">Live preview</div>}
              <NoteMarkdown source={draft.content} notes={notes} onOpenLink={onOpenLink} onTag={onTag} onToggleTask={(nth, checked) => update({ content: toggleTask(latest.current.content, nth, checked) })} />
            </div>
          </div>
        </div>
      </div>

      {suggest && items.length > 0 && (
        <div
          role="listbox"
          aria-label="Link to a note"
          className="fixed inset-x-2 z-[85] overflow-hidden rounded-xl border border-white/10 bg-[#2a2a2c] p-1 shadow-2xl md:absolute md:inset-x-auto md:right-6 md:top-14 md:w-80"
          style={TOUCH ? { bottom: inset + 56 } : undefined}
        >
          <div className="px-2.5 pb-1 pt-1.5 text-[11px] font-semibold uppercase tracking-[0.08em] text-[#8e8e93]">Link to note</div>
          {items.map((it, i) => (
            <button
              key={(it.note?.id ?? "new") + i}
              type="button"
              role="option"
              aria-selected={i === suggest.index}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => pick(it)}
              className={cn(
                "flex min-h-11 w-full items-center gap-2.5 rounded-lg px-2.5 text-left text-[14px] md:min-h-0 md:py-1.5",
                i === suggest.index ? "bg-[#7c6af0]/25 text-white" : "text-[#dcddde] hover:bg-white/[0.06]"
              )}
            >
              {it.note ? <span className="min-w-0 flex-1 truncate">{it.note.title}</span> : <span className="min-w-0 flex-1 truncate">Create “{it.create}”</span>}
              {it.note?.folder && <span className="max-w-[40%] truncate text-[12px] text-[#8e8e93]">{it.note.folder}</span>}
            </button>
          ))}
        </div>
      )}

      {showMobileBar && (
        <div
          role="toolbar"
          aria-label="Formatting"
          className="fixed inset-x-0 z-[80] flex items-center gap-0.5 overflow-x-auto border-t border-white/10 bg-[#252527] px-2 py-1 md:hidden"
          style={{ bottom: inset, paddingBottom: inset ? 4 : "max(4px, env(safe-area-inset-bottom))" }}
        >
          {actions.map((a) => actionButton(a, true))}
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => ta.current?.blur()}
            aria-label="Done editing"
            className="ml-auto flex h-11 shrink-0 items-center gap-1 rounded-xl bg-[#7c6af0] px-3.5 text-[14px] font-semibold text-white"
          >
            <Check size={16} /> Done
          </button>
        </div>
      )}
    </div>
  );
}

/** Reading view. Wikilinks open notes (or create missing ones), tags filter the file list, task boxes toggle in place. */
const NoteMarkdown = memo(function NoteMarkdown({
  source,
  notes,
  onOpenLink,
  onTag,
  onToggleTask,
}: {
  source: string;
  notes: Note[];
  onOpenLink: (target: string) => void;
  onTag: (tag: string) => void;
  onToggleTask: (nth: number, checked: boolean) => void;
}) {
  const prepared = useMemo(() => normalizeMath(renderableMarkdown(source)), [source]);
  let taskIndex = -1;
  return (
    <div className="obs-md" dir="auto">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
        urlTransform={(url) => (url.startsWith("wikilink:") || url.startsWith("tag:") ? url : defaultUrlTransform(url))}
        components={{
          a: ({ node: _node, href = "", children }) => {
            if (href.startsWith("wikilink:")) {
              const target = decodeURIComponent(href.slice("wikilink:".length));
              const missing = !resolveLink(target, notes);
              return (
                <button type="button" onClick={() => onOpenLink(target)} className={cn("obs-wiki", missing && "is-missing")} title={missing ? "Create this note" : target}>
                  {children}
                </button>
              );
            }
            if (href.startsWith("tag:")) {
              return (
                <button type="button" onClick={() => onTag(decodeURIComponent(href.slice("tag:".length)))} className="obs-tag">
                  {children}
                </button>
              );
            }
            return (
              <a href={href} target="_blank" rel="noreferrer">
                {children}
              </a>
            );
          },
          table: ({ node: _node, ...props }) => (
            <div className="overflow-x-auto">
              <table {...props} />
            </div>
          ),
          input: ({ node: _node, ...props }) => {
            if (props.type !== "checkbox") return <input {...props} />;
            const nth = ++taskIndex;
            return <input type="checkbox" checked={!!props.checked} onChange={(e) => onToggleTask(nth, e.target.checked)} className="obs-check" aria-label="Toggle task" />;
          },
        }}
      >
        {prepared}
      </ReactMarkdown>
    </div>
  );
});
