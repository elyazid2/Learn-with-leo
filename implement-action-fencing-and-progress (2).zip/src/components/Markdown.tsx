import { memo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { cn } from "@/utils/cn";

/**
 * Normalise LaTeX delimiters (\\( \\) and \\[ \\] → $ / $$) and escape currency-looking
 * dollars ("$5 and $10") so they don't open math. Code spans and fences are left untouched.
 */
export function normalizeMath(src: string) {
  const parts = src.split(/(```[\s\S]*?```|`[^`\n]*`)/g);
  return parts
    .map((part, i) => {
      if (i % 2 === 1) return part; // code
      let out = part.replace(/\\\[([\s\S]+?)\\\]/g, (_, m) => `$$${m}$$`).replace(/\\\(([\s\S]+?)\\\)/g, (_, m) => `$${m}$`);
      // A "$12.50"-style amount followed by space/punctuation on a line with no other "$" is money, not math.
      out = out
        .split("\n")
        .map((line) => {
          const dollars = (line.match(/\$/g) ?? []).length;
          if (dollars === 0) return line;
          if (dollars === 1 || /(^|[\s(])\$\d[\d,]*(\.\d+)?(?=[\s.,;:!?)]|$)/.test(line) && !/\$[^$\d][^$]*\$/.test(line))
            return line.replace(/(^|[\s(])\$(?=\d)/g, "$1\\$");
          return line;
        })
        .join("\n");
      return out;
    })
    .join("");
}

export const Markdown = memo(function Markdown({
  children,
  className,
  onToggleTask,
}: {
  children: string;
  className?: string;
  /** When provided, task-list checkboxes become interactive (nth checkbox in source order). */
  onToggleTask?: (nth: number, checked: boolean) => void;
}) {
  let taskIndex = -1;
  return (
    <div className={cn("md", className)} dir="auto">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
        components={{
          a: ({ node: _n, ...props }) => <a {...props} target="_blank" rel="noreferrer" />,
          table: ({ node: _n, ...props }) => (
            <div className="md-table">
              <table {...props} />
            </div>
          ),
          input: ({ node: _n, ...props }) => {
            if (props.type !== "checkbox") return <input {...props} />;
            const nth = ++taskIndex;
            if (!onToggleTask) return <input {...props} disabled readOnly />;
            return (
              <input
                type="checkbox"
                checked={!!props.checked}
                onChange={(e) => onToggleTask(nth, e.target.checked)}
                className="mr-1.5 h-4 w-4 cursor-pointer accent-black align-middle"
                aria-label="Toggle task"
              />
            );
          },
        }}
      >
        {normalizeMath(children)}
      </ReactMarkdown>
    </div>
  );
});
