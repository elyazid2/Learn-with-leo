import { useState } from "react";
import { Copy, Download, FileText } from "lucide-react";
import { shareOrDownload } from "@/lib/backup";
import { buildChatLogs, chatLogsFilename } from "@/lib/chatLogs";
import { useApp } from "@/lib/store";
import { Button, Field, Segmented } from "@/components/ui";

/**
 * Chat logs for debugging Leo: exactly what the model saw and did, including hidden action
 * results and guide text. Images/audio become placeholders; API keys and provider settings
 * are never part of this export.
 *
 * Getting the file out is the hard part: <a download> is silent in sandboxed iframes and many
 * phone browsers, so the export tries the share sheet first, then a download link, and always
 * keeps Copy and Show text available.
 */

/** Clipboard with a fallback for browsers that don't allow navigator.clipboard (iframes, http). */
async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}

type Busy = null | "export" | "copy" | "text";

export default function ChatLogsSection() {
  const showToast = useApp((s) => s.showToast);
  const [scope, setScope] = useState<"last" | "all">("last");
  const [busy, setBusy] = useState<Busy>(null);
  const [text, setText] = useState<string | null>(null);

  const makeJson = async () => {
    const data = await buildChatLogs(scope);
    if (!data.threads.length) throw new Error("No chats to export yet");
    return { data, json: JSON.stringify(data, null, 2) };
  };

  const doExport = async () => {
    setBusy("export");
    try {
      const { data, json } = await makeJson();
      const result = await shareOrDownload(new Blob([json], { type: "application/json" }), chatLogsFilename());
      const n = data.threads.length;
      if (result.how === "shared") showToast(`Shared ${n} chat${n === 1 ? "" : "s"}`);
      else if (result.how === "cancelled") showToast("Share cancelled — nothing was exported");
      else if (result.how === "failed") showToast(`Could not export: ${result.error}. Use Copy or Show text.`);
      else showToast("Download started — if no file appeared, use Copy or Show text");
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const doCopy = async () => {
    setBusy("copy");
    try {
      const { json } = await makeJson();
      showToast((await copyText(json)) ? "Copied the chat log JSON" : "Copy was blocked — use Show text instead");
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const doShow = async () => {
    if (text !== null) {
      setText(null);
      return;
    }
    setBusy("text");
    try {
      const { json } = await makeJson();
      setText(json);
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="mt-10">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">Chat logs</h2>
      <div className="space-y-3 rounded-2xl bg-card p-4 ring-1 ring-line">
        <p className="text-[13px] leading-relaxed text-muted">
          Every message in order, including hidden action results and guide text — exactly what the model saw and did, plus what the provider returned
          (model, max tokens, finish reason, duration). Images and audio are replaced with a placeholder; API keys and provider settings are never included.
        </p>
        <Field label="Which chats">
          <Segmented<"last" | "all">
            className="flex w-full [&>button]:flex-1 [&>button]:py-2"
            value={scope}
            onChange={(v) => {
              setScope(v);
              setText(null);
            }}
            options={[
              { value: "last", label: "Last chat" },
              { value: "all", label: "All chats" },
            ]}
          />
        </Field>
        <div className="flex flex-wrap gap-2">
          <Button variant="soft" onClick={() => void doExport()} disabled={busy !== null}>
            <Download size={15} /> {busy === "export" ? "Exporting…" : "Export chat logs"}
          </Button>
          <Button variant="soft" onClick={() => void doCopy()} disabled={busy !== null}>
            <Copy size={15} /> {busy === "copy" ? "Copying…" : "Copy"}
          </Button>
          <Button variant="soft" onClick={() => void doShow()} disabled={busy !== null}>
            <FileText size={15} /> {busy === "text" ? "Building…" : text === null ? "Show text" : "Hide text"}
          </Button>
        </div>
        {text !== null && (
          <textarea
            readOnly
            value={text}
            dir="ltr"
            spellCheck={false}
            onFocus={(e) => e.currentTarget.select()}
            onClick={(e) => e.currentTarget.select()}
            className="h-64 w-full resize-y rounded-2xl bg-white p-3 font-mono text-[11px] leading-snug text-ink ring-1 ring-line outline-none focus:ring-2 focus:ring-ink/30"
            aria-label="Chat log JSON"
          />
        )}
      </div>
    </section>
  );
}
