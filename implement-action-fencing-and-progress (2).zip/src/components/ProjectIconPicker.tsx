import { useRef, useState } from "react";
import { ImagePlus, Loader2, Smile } from "lucide-react";
import type { ProjectIcon } from "@/lib/db";
import { EMOJI_CHOICES, defaultEmojiFor, pickIconChar } from "@/lib/projectIcon";
import { iconFromImage } from "@/lib/media";
import ProjectAvatar from "./ProjectAvatar";
import { Button, Segmented, inputCls } from "./ui";
import { cn } from "@/utils/cn";

type Tab = "emoji" | "image";

/** Choose a project icon: an emoji (curated grid or any typed emoji) or an uploaded image/logo. */
export default function ProjectIconPicker({ value, onChange, color, tag }: { value?: ProjectIcon; onChange: (icon: ProjectIcon) => void; color: string; tag: string }) {
  const current: ProjectIcon = value ?? { kind: "emoji", emoji: defaultEmojiFor(tag) };
  const [tab, setTab] = useState<Tab>(current.kind);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const lastEmoji = useRef(current.kind === "emoji" ? current.emoji : defaultEmojiFor(tag));
  const lastImage = useRef(current.kind === "image" ? current.src : "");

  const chooseEmoji = (emoji: string) => {
    lastEmoji.current = emoji;
    onChange({ kind: "emoji", emoji });
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setError("");
    if (t === "emoji" && current.kind !== "emoji") onChange({ kind: "emoji", emoji: lastEmoji.current });
    if (t === "image" && current.kind !== "image" && lastImage.current) onChange({ kind: "image", src: lastImage.current });
  };

  const onFile = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    setError("");
    const src = await iconFromImage(file);
    setBusy(false);
    if (!src) {
      setError("That image couldn't be read. Try a PNG, JPG, SVG or WebP.");
      return;
    }
    lastImage.current = src;
    onChange({ kind: "image", src });
  };

  return (
    <div>
      <div className="flex items-center gap-4">
        <ProjectAvatar project={{ icon: current, tag, color, name: "Preview" }} size={60} />
        <Segmented<Tab>
          value={tab}
          onChange={switchTab}
          options={[
            { value: "emoji", label: "Emoji" },
            { value: "image", label: "Image or logo" },
          ]}
        />
      </div>

      {tab === "emoji" ? (
        <>
          <div className="mt-3 grid grid-cols-8 gap-1" role="listbox" aria-label="Emoji">
            {EMOJI_CHOICES.map((e) => {
              const selected = current.kind === "emoji" && current.emoji === e;
              return (
                <button
                  key={e}
                  type="button"
                  role="option"
                  aria-selected={selected}
                  aria-label={e}
                  onClick={() => chooseEmoji(e)}
                  className={cn(
                    "flex aspect-square items-center justify-center rounded-xl text-[22px] transition-colors",
                    selected ? "bg-ink/[0.08] ring-2 ring-ink" : "hover:bg-ink/[0.05]"
                  )}
                >
                  <span className="emoji leading-none">{e}</span>
                </button>
              );
            })}
          </div>
          <div className="relative mt-3">
            <Smile size={17} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input
              className={cn(inputCls, "pl-10")}
              value=""
              placeholder="Or type any emoji"
              aria-label="Type an emoji"
              enterKeyHint="done"
              onChange={(e) => {
                const ch = pickIconChar(e.target.value);
                if (ch) chooseEmoji(ch);
              }}
            />
          </div>
        </>
      ) : (
        <div className="mt-3 rounded-2xl bg-ink/[0.035] p-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <Button type="button" variant="soft" onClick={() => fileRef.current?.click()} disabled={busy}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} />}
              {current.kind === "image" ? "Change image" : "Choose image"}
            </Button>
            {current.kind === "image" && (
              <Button type="button" variant="ghost" onClick={() => switchTab("emoji")}>
                Use an emoji instead
              </Button>
            )}
          </div>
          <p className="mt-2 text-[12px] leading-relaxed text-muted">Photos are cropped to a square. Logos with a transparent background are kept whole.</p>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              void onFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </div>
      )}
      {error && <p className="mt-2 text-[12px] text-danger-fg">{error}</p>}
    </div>
  );
}
