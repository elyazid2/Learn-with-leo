import { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { GraduationCap, Plus, Target, Trash2, Clock } from "lucide-react";
import { STATUS_META, colorOf, db, type Concept, type ConceptStatus, type Project } from "@/lib/db";
import { upsertConcept } from "@/lib/ai/actions";
import { askLeo } from "@/lib/chat";
import { iconOf } from "@/lib/projectIcon";
import { Button, Field, Segmented, Sheet, inputCls } from "./ui";
import { confirmDeletion } from "@/lib/settings";
import { cn } from "@/utils/cn";

interface Pos {
  x: number;
  y: number;
  angle: number;
  depth: number;
  leaf: boolean;
  parent?: string;
}

function layout(concepts: Concept[]) {
  const ids = new Set(concepts.map((c) => c.id));
  const kids = new Map<string, Concept[]>();
  const push = (k: string, c: Concept) => kids.set(k, [...(kids.get(k) ?? []), c]);
  for (const c of concepts) push(c.parentId && ids.has(c.parentId) && c.parentId !== c.id ? c.parentId : "root", c);

  // cycle guard: anything unreachable from root gets attached to root
  const reach = new Set<string>();
  const visit = (k: string) => {
    for (const c of kids.get(k) ?? []) {
      if (reach.has(c.id)) continue;
      reach.add(c.id);
      visit(c.id);
    }
  };
  visit("root");
  for (const c of concepts) if (!reach.has(c.id)) push("root", c);

  const wCache = new Map<string, number>();
  const seen = new Set<string>();
  const weight = (k: string): number => {
    if (wCache.has(k)) return wCache.get(k)!;
    if (seen.has(k)) return 1;
    seen.add(k);
    const ch = kids.get(k) ?? [];
    const w = ch.length ? ch.reduce((s, c) => s + weight(c.id), 0) : 1;
    wCache.set(k, w);
    return w;
  };
  const leaves = weight("root");

  let maxDepth = 1;
  const depthOf = (k: string, d: number, guard = new Set<string>()) => {
    for (const c of kids.get(k) ?? []) {
      if (guard.has(c.id)) continue;
      guard.add(c.id);
      maxDepth = Math.max(maxDepth, d);
      depthOf(c.id, d + 1, guard);
    }
  };
  depthOf("root", 1);

  const baseOuter = 90 + (maxDepth - 1) * 80;
  const needed = (leaves * 30) / (2 * Math.PI);
  const scale = Math.max(1, needed / baseOuter);
  const radius = (d: number) => (d === 0 ? 0 : (90 + (d - 1) * 80) * scale);

  const pos = new Map<string, Pos>();
  const place = (k: string, a0: number, a1: number, depth: number, placed = new Set<string>()) => {
    const ch = (kids.get(k) ?? []).filter((c) => !placed.has(c.id));
    const total = ch.reduce((s, c) => s + weight(c.id), 0) || 1;
    let a = a0;
    for (const c of ch) {
      placed.add(c.id);
      const span = ((a1 - a0) * weight(c.id)) / total;
      const angle = a + span / 2;
      const r = radius(depth);
      pos.set(c.id, {
        x: Math.cos(angle) * r,
        y: Math.sin(angle) * r,
        angle,
        depth,
        leaf: !(kids.get(c.id) ?? []).length,
        parent: k === "root" ? undefined : k,
      });
      place(c.id, a, a + span, depth + 1, placed);
      a += span;
    }
  };
  place("root", -Math.PI / 2, (3 * Math.PI) / 2, 1);
  return { pos, outer: radius(maxDepth), radius };
}

const truncate = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

/** Ids of a concept and everything under it (cycle-safe). */
export function descendantIds(id: string, concepts: Concept[]) {
  const out = new Set<string>([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of concepts) if (c.parentId && out.has(c.parentId) && !out.has(c.id)) { out.add(c.id); grew = true; }
  }
  return out;
}

export default function KnowledgeMap({ project }: { project: Project }) {
  const concepts = useLiveQuery(() => db.concepts.where("projectId").equals(project.id).toArray(), [project.id]) ?? [];
  const [selected, setSelected] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [view, setView] = useState<"map" | "list">(() => (typeof window !== "undefined" && window.innerWidth < 640 ? "list" : "map"));
  const col = colorOf(project.color);
  const center = iconOf(project);
  const { pos, outer, radius } = useMemo(() => layout(concepts), [concepts]);
  const sel = concepts.find((c) => c.id === selected) ?? null;
  const pad = 120;
  const size = outer + pad;

  const counts = (Object.keys(STATUS_META) as ConceptStatus[]).map((s) => ({
    s,
    n: concepts.filter((c) => c.status === s).length,
  }));

  return (
    <div className="rounded-2xl bg-card p-4 ring-1 ring-line sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-[11rem] flex-1">
          <h3 className="display text-[20px] leading-tight">Knowledge map</h3>
          <p className="mt-1 text-[12px] text-muted">Tap a concept to inspect, edit, or study it.</p>
        </div>
        <div className="flex items-center gap-2">
          {concepts.length > 0 && (
            <Segmented<"map" | "list"> value={view} onChange={setView} options={[{ value: "map", label: "Map" }, { value: "list", label: "List" }]} />
          )}
          <Button size="sm" variant="soft" onClick={() => setAdding(true)}>
            <Plus size={14} /> Concept
          </Button>
        </div>
      </div>

      {concepts.length === 0 ? (
        <div className="relative mt-4 flex aspect-[4/3] items-center justify-center overflow-hidden rounded-3xl bg-black/[0.02]">
          <svg viewBox="-150 -110 300 220" className="absolute inset-0 h-full w-full opacity-60">
            {[50, 95].map((r) => (
              <circle key={r} r={r} fill="none" stroke="var(--line)" strokeDasharray="3 5" />
            ))}
            {Array.from({ length: 7 }).map((_, i) => {
              const a = (i / 7) * Math.PI * 2;
              return <circle key={i} cx={Math.cos(a) * 95} cy={Math.sin(a) * 95} r={5} fill="var(--line)" />;
            })}
          </svg>
          <p className="relative max-w-[220px] text-center text-[13px] text-muted">
            Concepts appear here as you take placement, learn and get tested.
          </p>
        </div>
      ) : view === "list" ? (
        <ConceptList concepts={concepts} onSelect={setSelected} />
      ) : (
        <svg viewBox={`${-size} ${-size} ${size * 2} ${size * 2}`} className="mt-2 w-full select-none" style={{ maxHeight: 560 }}>
          {[1, 2, 3, 4].map((d) =>
            radius(d) <= outer + 1 ? <circle key={d} r={radius(d)} fill="none" stroke="var(--line)" strokeOpacity={0.65} strokeDasharray="2 6" /> : null
          )}
          {/* edges */}
          {concepts.map((c) => {
            const p = pos.get(c.id);
            if (!p) return null;
            const parent = p.parent ? pos.get(p.parent) : undefined;
            const px = parent?.x ?? 0;
            const py = parent?.y ?? 0;
            let d: string;
            if (!parent) d = `M0 0 L${p.x} ${p.y}`;
            else {
              const rp = Math.hypot(px, py);
              const rc = Math.hypot(p.x, p.y);
              const rm = (rp + rc) / 2;
              d = `M${px} ${py} C${Math.cos(parent.angle) * rm} ${Math.sin(parent.angle) * rm} ${Math.cos(p.angle) * rm} ${
                Math.sin(p.angle) * rm
              } ${p.x} ${p.y}`;
            }
            return (
              <path
                key={"e" + c.id}
                d={d}
                fill="none"
                stroke={STATUS_META[c.status].color}
                strokeOpacity={0.35}
                strokeWidth={parent ? 1.4 : 2}
              />
            );
          })}
          {/* center */}
          <circle r={27} style={{ fill: `color-mix(in srgb, ${col.hex} 16%, var(--card))` }} stroke={col.hex} strokeOpacity={0.4} strokeWidth={1.5} />
          {center.kind === "image" ? (
            <>
              <clipPath id={`km-${project.id}`}>
                <circle r={25} />
              </clipPath>
              <image href={center.src} x={-25} y={-25} width={50} height={50} clipPath={`url(#km-${project.id})`} preserveAspectRatio="xMidYMid slice" />
            </>
          ) : (
            <text textAnchor="middle" dy="0.36em" fontSize={26} className="emoji">
              {center.emoji}
            </text>
          )}
          {/* nodes */}
          {concepts.map((c) => {
            const p = pos.get(c.id);
            if (!p) return null;
            const r = p.depth === 1 ? 9 : 6.5;
            const isSel = selected === c.id;
            const deg = (p.angle * 180) / Math.PI;
            const flip = Math.cos(p.angle) < 0;
            const color = STATUS_META[c.status].color;
            const acc = c.attempts ? c.correct / c.attempts : null;
            return (
              <g key={c.id} className="cursor-pointer" onClick={() => setSelected(c.id)}>
                <circle cx={p.x} cy={p.y} r={18} fill="transparent" />
                {isSel && <circle cx={p.x} cy={p.y} r={r + 6} fill="none" stroke="#17171a" strokeWidth={1.5} />}
                <circle cx={p.x} cy={p.y} r={r} fill={c.status === "new" ? "var(--card)" : color} stroke={color} strokeWidth={2} />
                {acc !== null && (
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={r + 3}
                    fill="none"
                    stroke={color}
                    strokeWidth={1.5}
                    strokeDasharray={`${acc * 2 * Math.PI * (r + 3)} 999`}
                    transform={`rotate(-90 ${p.x} ${p.y})`}
                    opacity={0.6}
                  />
                )}
                {p.leaf && p.depth > 1 ? (
                  <text
                    transform={`translate(${p.x} ${p.y}) rotate(${flip ? deg + 180 : deg})`}
                    x={flip ? -(r + 7) : r + 7}
                    dy="0.35em"
                    textAnchor={flip ? "end" : "start"}
                    fontSize={11.5}
                    fill="var(--ink)"
                    fontWeight={isSel ? 650 : 450}
                  >
                    {truncate(c.name, 22)}
                  </text>
                ) : (
                  <text
                    x={p.x}
                    y={p.y + r + 15}
                    textAnchor="middle"
                    fontSize={12.5}
                    fontWeight={600}
                    fill="var(--ink)"
                    stroke="var(--card)"
                    strokeWidth={4}
                    paintOrder="stroke"
                  >
                    {truncate(c.name, 20)}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      )}

      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
        {counts.map(({ s, n }) => (
          <span key={s} className="flex items-center gap-1.5 text-[12px] text-muted">
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ background: s === "new" ? "#fff" : STATUS_META[s].color, boxShadow: `inset 0 0 0 2px ${STATUS_META[s].color}` }}
            />
            {STATUS_META[s].label} <span className="font-semibold text-ink">{n}</span>
          </span>
        ))}
      </div>

      {sel && <ConceptSheet concept={sel} concepts={concepts} project={project} onClose={() => setSelected(null)} />}
      <AddConceptSheet open={adding} onClose={() => setAdding(false)} concepts={concepts} projectId={project.id} />
    </div>
  );
}

function ConceptList({ concepts, onSelect }: { concepts: Concept[]; onSelect: (id: string) => void }) {
  const ids = new Set(concepts.map((c) => c.id));
  const kids = new Map<string | undefined, Concept[]>();
  for (const c of concepts) {
    const k = c.parentId && ids.has(c.parentId) && c.parentId !== c.id ? c.parentId : undefined;
    kids.set(k, [...(kids.get(k) ?? []), c]);
  }
  const rows: { c: Concept; depth: number }[] = [];
  const seen = new Set<string>();
  const walk = (k: string | undefined, depth: number) => {
    for (const c of kids.get(k) ?? []) {
      if (seen.has(c.id)) continue;
      seen.add(c.id);
      rows.push({ c, depth });
      walk(c.id, depth + 1);
    }
  };
  walk(undefined, 0);
  for (const c of concepts) if (!seen.has(c.id)) rows.push({ c, depth: 0 });
  const now = Date.now();
  return (
    <ul className="mt-3 divide-y divide-line">
      {rows.map(({ c, depth }) => (
        <li key={c.id}>
          <button onClick={() => onSelect(c.id)} className="flex w-full items-center gap-3 py-2 text-left hover:bg-ink/[0.03]" style={{ paddingLeft: depth * 16 }}>
            <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: STATUS_META[c.status].color }} />
            <span className="min-w-0 flex-1 truncate text-[14px]">{c.name}</span>
            {c.nextReview && c.nextReview <= now && <Clock size={13} className="text-shaky" aria-label="Due for review" />}
            {c.attempts > 0 && (
              <span className="text-[12px] tabular-nums text-muted">
                {c.correct}/{c.attempts}
              </span>
            )}
          </button>
        </li>
      ))}
    </ul>
  );
}

function StatusPicker({ value, onChange }: { value: ConceptStatus; onChange: (s: ConceptStatus) => void }) {
  return (
    <div className="grid grid-cols-4 gap-1.5">
      {(Object.keys(STATUS_META) as ConceptStatus[]).map((s) => (
        <button
          key={s}
          onClick={() => onChange(s)}
          className={cn(
            "flex flex-col items-center gap-1.5 rounded-2xl py-2.5 text-[11px] font-medium ring-1 transition",
            value === s ? "bg-ink text-white ring-ink" : "ring-line hover:bg-black/[0.03]"
          )}
        >
          <span className="h-3 w-3 rounded-full" style={{ background: STATUS_META[s].color }} />
          {STATUS_META[s].label}
        </button>
      ))}
    </div>
  );
}

function ConceptSheet({
  concept,
  concepts,
  project,
  onClose,
}: {
  concept: Concept;
  concepts: Concept[];
  project: Project;
  onClose: () => void;
}) {
  const [name, setName] = useState(concept.name);
  const [note, setNote] = useState(concept.note ?? "");
  const update = (patch: Partial<Concept>) => db.concepts.update(concept.id, { ...patch, updatedAt: Date.now() });
  const blocked = descendantIds(concept.id, concepts);
  const parentOptions = concepts.filter((c) => !blocked.has(c.id));

  const study = (mode: "teach" | "test") => {
    onClose();
    void askLeo(project.id, mode === "teach" ? `Teach me "${concept.name}" at my level.` : `Quiz me on "${concept.name}" — a few questions, one at a time.`);
  };
  const remove = async () => {
    if (!confirmDeletion(`Delete “${concept.name}”${concept.attempts ? ` and its quiz record (${concept.correct}/${concept.attempts})` : ""}? Child concepts move up one level.`)) return;
    const children = concepts.filter((c) => c.parentId === concept.id);
    await Promise.all(children.map((c) => db.concepts.update(c.id, { parentId: concept.parentId })));
    await db.concepts.delete(concept.id);
    onClose();
  };

  return (
    <Sheet open onClose={onClose} title={concept.name}>
      <div className="space-y-4">
        <StatusPicker value={concept.status} onChange={(status) => update({ status })} />
        {concept.attempts > 0 && (
          <div className="flex items-center gap-3 rounded-2xl bg-black/[0.03] p-3 text-sm">
            <Target size={16} className="text-muted" />
            Quiz record: <b>{concept.correct}</b> / {concept.attempts} correct
            <div className="ml-auto h-1.5 w-20 overflow-hidden rounded-full bg-black/[0.08]">
              <div className="h-full bg-solid" style={{ width: `${(concept.correct / concept.attempts) * 100}%` }} />
            </div>
          </div>
        )}
        <Field label="Name">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} onBlur={() => name.trim() && update({ name: name.trim() })} />
        </Field>
        <Field label="Parent">
          <select className={inputCls} value={concept.parentId ?? ""} onChange={(e) => update({ parentId: e.target.value || undefined })}>
            <option value="">— top level —</option>
            {parentOptions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Note">
          <textarea
            className={cn(inputCls, "min-h-[72px] resize-none")}
            value={note}
            placeholder="Anything to remember about this concept"
            onChange={(e) => setNote(e.target.value)}
            onBlur={() => update({ note: note.trim() || undefined })}
          />
        </Field>
        <div className="flex gap-2">
          <Button className="flex-1" onClick={() => study("teach")}>
            <GraduationCap size={16} /> Teach me
          </Button>
          <Button className="flex-1" variant="soft" onClick={() => study("test")}>
            <Target size={16} /> Quiz me
          </Button>
          <Button variant="danger" onClick={remove} aria-label="Delete concept">
            <Trash2 size={16} />
          </Button>
        </div>
      </div>
    </Sheet>
  );
}

function AddConceptSheet({
  open,
  onClose,
  concepts,
  projectId,
}: {
  open: boolean;
  onClose: () => void;
  concepts: Concept[];
  projectId: string;
}) {
  const [name, setName] = useState("");
  const [parent, setParent] = useState("");
  const [status, setStatus] = useState<ConceptStatus>("new");
  const add = async () => {
    if (!name.trim()) return;
    const parentName = concepts.find((c) => c.id === parent)?.name;
    await upsertConcept(projectId, name.trim(), { status }, parentName);
    setName("");
    onClose();
  };
  return (
    <Sheet open={open} onClose={onClose} title="Add concept">
      <div className="space-y-4">
        <Field label="Concept">
          <input autoFocus className={inputCls} value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} />
        </Field>
        <Field label="Parent">
          <select className={inputCls} value={parent} onChange={(e) => setParent(e.target.value)}>
            <option value="">— top level —</option>
            {concepts.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <StatusPicker value={status} onChange={setStatus} />
        <Button size="lg" className="w-full" onClick={add} disabled={!name.trim()}>
          Add
        </Button>
      </div>
    </Sheet>
  );
}
