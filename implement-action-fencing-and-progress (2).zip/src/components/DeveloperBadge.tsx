import { useSettings } from "@/lib/settings";

export default function DeveloperBadge() {
  const active = useSettings((s) => s.developerMode);
  if (!active) return null;
  return (
    <div className="pointer-events-none fixed bottom-[calc(max(env(safe-area-inset-bottom),12px)+76px)] left-3 z-40 rounded-full bg-ink px-2.5 py-1 text-[11px] font-semibold text-white shadow-lg">
      Dev · local mock
    </div>
  );
}
