import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, ChevronDown, Plus, User, X } from "lucide-react";
import AgentAvatar from "./AgentAvatar";
import { accentText } from "@/lib/color";
import { POINT_META, db, type Point, type PointKind } from "@/lib/db";
import { addPoint } from "@/lib/ai/actions";
import { cn } from "@/utils/cn";

const KINDS: PointKind[] = ["careful", "confused", "next"];

export default function PointsCard({ projectId }: { projectId: string }) {
  const points = useLiveQuery(() => db.points.where("projectId").equals(projectId).toArray(), [projectId]) ?? [];
  const [showDone, setShowDone] = useState(false);
  const done = points.filter((p) => p.done);

  return (
    <div className="rounded-2xl bg-card p-4 ring-1 ring-line sm:p-5">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="display text-[22px] leading-none">Points</h3>
          <p className="mt-1 flex items-center gap-1 text-[12px] text-muted">
            Shared memory — you and the AI both write here, and the AI reads it.
          </p>
        </div>
      </div>
      <div className="mt-4 space-y-3">
        {KINDS.map((k) => (
          <Section key={k} kind={k} projectId={projectId} items={points.filter((p) => p.kind === k && !p.done)} />
        ))}
      </div>
      {done.length > 0 && (
        <div className="mt-3">
          <button onClick={() => setShowDone((s) => !s)} className="flex items-center gap-1 text-[12px] font-medium text-muted hover:text-ink">
            <ChevronDown size={14} className={cn("transition", showDone && "rotate-180")} />
            {done.length} resolved
          </button>
          {showDone && (
            <ul className="mt-2 space-y-1">
              {done.map((p) => (
                <Item key={p.id} p={p} />
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function Section({ kind, items, projectId }: { kind: PointKind; items: Point[]; projectId: string }) {
  const meta = POINT_META[kind];
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");
  const submit = async () => {
    if (text.trim()) await addPoint(projectId, kind, text, "user");
    setText("");
  };
  return (
    <div className="rounded-3xl p-3" style={{ background: `color-mix(in srgb, ${meta.color} 12%, var(--card))` }}>
      <div className="flex items-center gap-2 px-1">
        <span className="h-2 w-2 rounded-full" style={{ background: meta.color }} />
        <span className="text-[13px] font-semibold" style={{ color: accentText(meta.color) }}>
          {meta.label}
        </span>
        <span className="text-[12px] text-black/50">{items.length || ""}</span>
        <button
          onClick={() => setAdding((a) => !a)}
          className="ml-auto flex h-7 w-7 items-center justify-center rounded-full transition hover:bg-white/80"
          aria-label={`Add to ${meta.label}`}
        >
          <Plus size={15} className={cn("transition", adding && "rotate-45")} />
        </button>
      </div>
      {items.length > 0 && (
        <ul className="mt-1.5 space-y-1">
          {items.map((p) => (
            <Item key={p.id} p={p} />
          ))}
        </ul>
      )}
      {items.length === 0 && !adding && <p className="px-1 pt-1 text-[12px] text-black/50">Nothing yet</p>}
      {adding && (
        <div className="mt-2 flex gap-1.5">
          <input
            autoFocus
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit();
              if (e.key === "Escape") setAdding(false);
            }}
            placeholder="Write a point…"
            className="min-w-0 flex-1 rounded-full bg-white px-3.5 py-2 text-[16px] outline-none ring-1 ring-black/5 focus:ring-black/20"
          />
          <button onClick={submit} className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-white" aria-label="Add">
            <Check size={15} />
          </button>
        </div>
      )}
    </div>
  );
}

function Item({ p }: { p: Point }) {
  return (
    <li className="group flex items-start gap-2.5 rounded-2xl bg-white/80 px-2.5 py-2">
      <button
        onClick={() => db.points.update(p.id, { done: !p.done })}
        className={cn(
          "mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border-[1.5px] transition",
          p.done ? "border-ink bg-ink text-white" : "border-black/25 hover:border-black/60"
        )}
        aria-label={p.done ? "Reopen" : "Resolve"}
      >
        {p.done && <Check size={11} strokeWidth={3} />}
      </button>
      <span className={cn("flex-1 text-[14px] leading-snug", p.done && "text-muted line-through")} dir="auto">
        {p.text}
        {p.done && p.resolvedBy === "ai" && <span className="ml-1.5 text-[11px] no-underline text-muted">· resolved by Leo</span>}
      </span>
      <span className="mt-0.5 text-black/45" title={p.author === "ai" ? "Added by Leo" : "Added by you"}>
        {p.author === "ai" ? <AgentAvatar size={14} frozenAt={0} /> : <User size={13} />}
      </span>
      <button
        onClick={() => db.points.delete(p.id)}
        className="mt-0.5 text-muted opacity-100 transition hover:text-danger-fg pointer-fine:opacity-0 pointer-fine:group-hover:opacity-100 pointer-fine:focus-visible:opacity-100"
        aria-label="Delete"
      >
        <X size={14} />
      </button>
    </li>
  );
}
