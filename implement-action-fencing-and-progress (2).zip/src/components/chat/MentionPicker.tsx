import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeft, FileText, Film, Image as ImageIcon, Mic, Music, PenTool, Search } from "lucide-react";
import { db, type FileKind, type LibFile, type Note, type Project, type Sketch } from "@/lib/db";
import { formatClock, formatDuration } from "@/lib/media";
import { cn } from "@/utils/cn";
import { clampSegment, describeMention } from "@/lib/mentions";

export type { Mention } from "@/lib/mentions";

const SUPPORTED: FileKind[] = ["pdf", "image", "audio", "video", "text"];
const SEGMENT_PRESETS = [15, 30, 60];

function iconFor(kind: FileKind) {
  if (kind === "image") return <ImageIcon size={18} />;
  if (kind === "video") return <Film size={18} />;
  if (kind === "audio") return <Music size={18} />;
  if (kind === "text") return <FileText size={18} />;
  return <FileText size={18} />;
}

/** Popover above the composer: pick a library file, then the exact PDF page or audio segment. */
import type { Mention as M } from "@/lib/mentions";

export default function MentionPicker({
  project,
  query,
  open,
  onClose,
  onPick,
}: {
  project: Project;
  query: string;
  open: boolean;
  onClose: () => void;
  onPick: (m: M) => void;
}) {
  const files = useLiveQuery(() => db.files.where("projectId").equals(project.id).toArray(), [project.id]) ?? [];
  const notes = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]) ?? [];
  const sketches = useLiveQuery(() => db.sketches.where("projectId").equals(project.id).toArray(), [project.id]) ?? [];
  const [step, setStep] = useState<"list" | "configure">("list");
  const [chosen, setChosen] = useState<LibFile | null>(null);
  const [page, setPage] = useState(1);
  const [start, setStart] = useState(0);
  const [length, setLength] = useState(30);
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (!open) {
      setStep("list");
      setChosen(null);
      setPage(1);
      setStart(0);
      setLength(30);
      setActive(0);
    }
  }, [open]);

  const term = query.trim().toLowerCase();
  const items = files.filter((f) => SUPPORTED.includes(f.kind) && (!term || f.name.toLowerCase().includes(term)));
  type Row = { type: "file"; file: LibFile } | { type: "note"; note: Note } | { type: "sketch"; sketch: Sketch };
  const rows: Row[] = [
    ...items.map((file): Row => ({ type: "file", file })),
    ...notes.filter((n) => !term || n.title.toLowerCase().includes(term)).map((note): Row => ({ type: "note", note })),
    ...sketches.filter((s) => !term || s.title.toLowerCase().includes(term)).map((sketch): Row => ({ type: "sketch", sketch })),
  ];

  // Arrow keys move the highlight; Enter picks it. The composer forwards these while open.
  useEffect(() => setActive(0), [term, open]);
  useEffect(() => {
    if (!open || step !== "list") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        setActive((i) => Math.max(0, Math.min(rows.length - 1, i + (e.key === "ArrowDown" ? 1 : -1))));
      } else if (e.key === "Enter" && rows[active]) {
        e.preventDefault();
        chooseRow(rows[active]);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  });

  const choose = (f: LibFile) => {
    if (f.kind === "pdf" || f.kind === "audio") {
      setChosen(f);
      setPage(Math.max(1, Math.min(f.pages ?? 1, Number(localStorage.getItem("pdfpage." + f.id)) || 1)));
      setStart(0);
      setLength(Math.min(30, Math.ceil(f.duration ?? 30)));
      setStep("configure");
      return;
    }
    onPick(describeMention(f));
    onClose();
  };

  // Notes and sketches attach as-is — no configure step.
  const chooseRow = (row: Row) => {
    if (row.type === "note") {
      onPick({ key: `note:${row.note.id}`, kind: "note", noteId: row.note.id, name: row.note.title || "Untitled" });
      onClose();
      return;
    }
    if (row.type === "sketch") {
      onPick({ key: `sketch:${row.sketch.id}`, kind: "sketch", sketchId: row.sketch.id, name: row.sketch.title || "Untitled sketch" });
      onClose();
      return;
    }
    choose(row.file);
  };

  const confirm = () => {
    if (!chosen) return;
    onPick(describeMention(chosen, { page, start, length }));
    onClose();
  };

  if (!open) return null;

  return (
    <div className="absolute bottom-full left-2 right-2 z-20 mb-2 overflow-hidden rounded-2xl bg-card shadow-[0_16px_40px_rgba(0,0,0,0.18)] ring-1 ring-line" role="dialog" aria-label="Mention a note, sketch or file">
      <div className="flex items-center gap-2 border-b border-line px-3 py-2">
        {step === "configure" && (
          <button onClick={() => setStep("list")} aria-label="Back to files" className="flex h-7 w-7 items-center justify-center rounded-full text-muted hover:bg-ink/[0.06]">
            <ArrowLeft size={15} />
          </button>
        )}
        <span className="min-w-0 flex-1 truncate text-[13px] font-semibold">{step === "list" ? "Mention" : chosen?.name}</span>
        <button onClick={onClose} className="rounded-full px-2 py-1 text-[12px] text-muted hover:bg-ink/[0.06]" aria-label="Close mention picker">Esc</button>
      </div>

      {step === "list" ? (
        <div className="max-h-64 overflow-y-auto p-1.5">
          {rows.length === 0 ? (
            <p className="px-3 py-6 text-center text-[13px] text-muted">{files.length || notes.length || sketches.length ? "Nothing matches. Try another name." : "Your library is empty."}</p>
          ) : (
            rows.map((row, i) =>
              row.type === "file" ? (
                <button
                  key={`file:${row.file.id}`}
                  onClick={() => choose(row.file)}
                  onMouseEnter={() => setActive(i)}
                  data-mention-first={i === 0 ? "" : undefined}
                  aria-selected={i === active}
                  className={cn("flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition-colors", i === active ? "bg-ink/[0.06]" : "hover:bg-ink/[0.04]")}
                >
                  <span className="relative flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-ink/[0.05] text-muted ring-1 ring-line">
                    {row.file.thumb && row.file.kind !== "pdf" ? (
                      <img src={row.file.thumb} alt="" className="h-full w-full object-cover" />
                    ) : row.file.recorded ? (
                      <Mic size={17} />
                    ) : (
                      iconFor(row.file.kind)
                    )}
                    {row.file.kind === "pdf" && row.file.pages ? (
                      <span className="absolute bottom-0 right-0 rounded-tl-md bg-ink px-1 text-[9px] font-semibold tabular-nums text-white">{row.file.pages}</span>
                    ) : null}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium">{row.file.name.replace(/\.[a-z0-9]{1,5}$/i, "")}</span>
                    <span className="block truncate text-[11px] text-muted">
                      {row.file.kind === "pdf" ? `PDF · ${row.file.pages ?? "?"} pages` : row.file.kind === "audio" ? `${row.file.recorded ? "Voice note" : "Audio"} · ${formatDuration(row.file.duration)}` : row.file.kind === "image" ? "Picture" : row.file.kind === "video" ? "Video" : "Text"}
                    </span>
                  </span>
                  {(row.file.kind === "pdf" || row.file.kind === "audio") && <span className="text-[11px] text-muted">choose part</span>}
                </button>
              ) : (
                <button
                  key={row.type === "note" ? `note:${row.note.id}` : `sketch:${row.sketch.id}`}
                  onClick={() => chooseRow(row)}
                  onMouseEnter={() => setActive(i)}
                  aria-selected={i === active}
                  className={cn("flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition-colors", i === active ? "bg-ink/[0.06]" : "hover:bg-ink/[0.04]")}
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ink/[0.05] text-muted ring-1 ring-line">
                    {row.type === "note" ? <FileText size={18} /> : <PenTool size={18} />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium">{row.type === "note" ? row.note.title || "Untitled" : row.sketch.title || "Untitled sketch"}</span>
                    <span className="block truncate text-[11px] text-muted">{row.type === "note" ? "Note" : "Sketch"}</span>
                  </span>
                </button>
              )
            )
          )}
          {rows.length > 0 && (
            <p className="flex items-center gap-1 px-3 py-2 text-[11px] text-muted"><Search size={11} /> Type to filter · ↑↓ to move · Enter to choose</p>
          )}
        </div>
      ) : chosen?.kind === "pdf" ? (
        <div className="space-y-3 p-3">
          <p className="text-[12px] text-muted">Only this page is sent to Leo, with its text and citation.</p>
          <label className="flex items-center gap-3 text-[13px]">
            <span className="font-medium">Page</span>
            <input
              type="number"
              aria-label="Page number"
              min={1}
              max={chosen.pages ?? 10000}
              value={page}
              onChange={(e) => setPage(Math.max(1, Math.min(chosen.pages ?? 10000, Number(e.target.value) || 1)))}
              className="h-9 w-20 rounded-xl bg-ink/[0.05] px-3 text-[16px] outline-none"
            />
            <span className="text-muted">of {chosen.pages ?? "?"}</span>
            <span className="ml-auto flex gap-1">
              <button onClick={() => setPage((v) => Math.max(1, v - 1))} className="h-8 w-8 rounded-full bg-ink/[0.05] text-[16px]" aria-label="Previous page">−</button>
              <button onClick={() => setPage((v) => Math.min(chosen.pages ?? v + 1, v + 1))} className="h-8 w-8 rounded-full bg-ink/[0.05] text-[16px]" aria-label="Next page">+</button>
            </span>
          </label>
          <button onClick={confirm} className="h-10 w-full rounded-full bg-ink text-[13px] font-semibold text-white">Attach page {page}</button>
        </div>
      ) : chosen ? (
        <div className="space-y-3 p-3">
          <p className="text-[12px] text-muted">Choose the exact segment. Leo receives only this clip.</p>
          {chosen.peaks?.length ? (
            <div className="flex h-12 items-end gap-[2px] rounded-xl bg-ink/[0.03] p-1.5">
              {chosen.peaks.map((p, i) => {
                const at = (i / chosen.peaks!.length) * (chosen.duration || 1);
                const inside = at >= start && at <= start + length;
                return <span key={i} className={cn("flex-1 rounded-full", inside ? "bg-ink" : "bg-ink/20")} style={{ height: `${Math.max(8, p * 100)}%` }} />;
              })}
            </div>
          ) : null}
          <div className="grid grid-cols-2 gap-2">
            <label className="block text-[12px] font-medium text-muted">Start
              <input type="number" min={0} step={1} max={Math.max(0, (chosen.duration ?? 0) - 0.5)} value={Math.round(start)} onChange={(e) => setStart(Math.max(0, Number(e.target.value) || 0))} className="mt-1 h-9 w-full rounded-xl bg-ink/[0.05] px-3 text-[16px] text-ink outline-none" />
              <span className="mt-1 block font-normal tabular-nums">{formatClock(start)}</span>
            </label>
            <label className="block text-[12px] font-medium text-muted">Clip length
              <input type="number" min={5} max={120} step={5} value={length} onChange={(e) => setLength(Math.max(5, Math.min(120, Number(e.target.value) || 30)))} className="mt-1 h-9 w-full rounded-xl bg-ink/[0.05] px-3 text-[16px] text-ink outline-none" />
              <span className="mt-1 block font-normal">{formatClock(length)} · max 2 min</span>
            </label>
          </div>
          <div className="flex gap-1.5">
            {SEGMENT_PRESETS.map((n) => (
              <button key={n} onClick={() => setLength(n)} className={cn("h-8 rounded-full px-3 text-[12px] font-medium", length === n ? "bg-ink text-white" : "bg-ink/[0.05] text-muted")}>{n}s</button>
            ))}
            <span className="ml-auto self-center text-[11px] text-muted">
              Ends at {formatClock(clampSegment(chosen.duration ?? start + length, start, length).end)}
            </span>
          </div>
          <button onClick={confirm} className="h-10 w-full rounded-full bg-ink text-[13px] font-semibold text-white">
            Attach {formatClock(clampSegment(chosen.duration ?? start + length, start, length).start)}–
            {formatClock(clampSegment(chosen.duration ?? start + length, start, length).end)}
          </button>
        </div>
      ) : null}
    </div>
  );
}
