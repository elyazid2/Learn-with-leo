/** Markdown files are bundled as their raw text (see the Turbopack rule in next.config.ts). */
declare module "*.md" {
  const content: string;
  export default content;
}
