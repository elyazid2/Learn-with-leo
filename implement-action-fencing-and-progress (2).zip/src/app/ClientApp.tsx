"use client";
import dynamic from "next/dynamic";

const App = dynamic(() => import("@/App"), { ssr: false, loading: () => <div className="h-dvh bg-paper" /> });

export default function ClientApp() {
  return <App />;
}
