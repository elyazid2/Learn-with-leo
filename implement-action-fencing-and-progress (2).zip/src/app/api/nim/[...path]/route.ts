export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * NVIDIA NIM (integrate.api.nvidia.com) sends no CORS headers, so the browser cannot call it
 * directly ("Failed to fetch"). This same-origin proxy forwards the app's requests server-side.
 *
 * Only two upstream paths are reachable, and the upstream host is fixed — a request can never
 * point the proxy at another host. The API key is never logged, never written to disk, and never
 * included in a response.
 */
const NIM_ORIGIN = "https://integrate.api.nvidia.com";
const ALLOWED_PATHS = new Set(["models", "chat/completions"]);

/** The raw key from an "Authorization: Bearer …" header, or null when there is none. */
function stripBearer(header: string | null): string | null {
  if (!header) return null;
  const key = header.replace(/^Bearer\s+/i, "").trim();
  return key || null;
}

function unauthorized() {
  return new Response(JSON.stringify({ error: { message: "No API key received by the server" } }), {
    status: 401,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

async function forward(req: Request, ctx: { params: Promise<{ path: string[] }> }) {
  const { path } = await ctx.params;
  const rel = (path ?? []).join("/");
  if (!ALLOWED_PATHS.has(rel)) {
    return new Response("Not found", { status: 404, headers: { "cache-control": "no-store" } });
  }

  // Custom request headers are stripped along the way, so the key usually arrives in the JSON
  // body as "_key". It is read here and removed again before anything is forwarded upstream.
  const raw = await req.text();
  let body: Record<string, unknown> | null = null;
  if (raw) {
    try {
      const parsed: unknown = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) body = parsed as Record<string, unknown>;
    } catch {
      body = null;
    }
  }
  const inBody = typeof body?._key === "string" ? body._key.trim() : "";
  if (body && "_key" in body) delete body._key;

  // Key source order: body "_key", then x-nim-key, then Authorization.
  const key = inBody || req.headers.get("x-nim-key") || stripBearer(req.headers.get("authorization"));
  if (!key) return unauthorized();

  const headers: Record<string, string> = { authorization: `Bearer ${key}` };
  const accept = req.headers.get("accept");
  if (accept) headers.accept = accept;

  // "models" is always listed fresh with GET and no body; "chat/completions" forwards the body.
  const upstreamMethod = rel === "models" ? "GET" : "POST";
  const init: RequestInit = { method: upstreamMethod, headers, cache: "no-store" };
  if (upstreamMethod === "POST") {
    headers["content-type"] = "application/json";
    init.body = body ? JSON.stringify(body) : raw || undefined;
  }

  let upstream: Response;
  try {
    upstream = await fetch(`${NIM_ORIGIN}/v1/${rel}`, init);
  } catch {
    return new Response("NVIDIA NIM could not be reached from the server", {
      status: 502,
      headers: { "cache-control": "no-store" },
    });
  }

  // Stream the upstream body straight through. content-encoding is deliberately not forwarded:
  // fetch has already decompressed the body, so passing that header on would corrupt it.
  const out = new Headers();
  const type = upstream.headers.get("content-type");
  if (type) out.set("content-type", type);
  out.set("cache-control", "no-store");
  return new Response(upstream.body, { status: upstream.status, headers: out });
}

export async function GET(req: Request, ctx: { params: Promise<{ path: string[] }> }) {
  return forward(req, ctx);
}

export async function POST(req: Request, ctx: { params: Promise<{ path: string[] }> }) {
  return forward(req, ctx);
}
