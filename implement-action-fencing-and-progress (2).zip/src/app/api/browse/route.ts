import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const MAX_BYTES = 4 * 1024 * 1024;

function privateIp(ip: string) {
  if (ip.includes(":")) {
    const v = ip.toLowerCase();
    if (v.startsWith("::ffff:")) return privateIp(v.slice(7));
    return v === "::1" || v === "::" || v.startsWith("fc") || v.startsWith("fd") || v.startsWith("fe80");
  }
  const [a, b] = ip.split(".").map(Number);
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
}

async function assertPublic(u: URL) {
  if (!["http:", "https:"].includes(u.protocol)) throw new Error("Only http and https pages can be opened");
  const host = u.hostname.replace(/^\[|\]$/g, "");
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) throw new Error("Private addresses are blocked");
  const ips = isIP(host) ? [host] : (await lookup(host, { all: true })).map((r) => r.address);
  if (!ips.length || ips.some(privateIp)) throw new Error("Private addresses are blocked");
}

/**
 * The content-script "agent" injected into every page. It runs inside a sandboxed iframe
 * (opaque origin — no access to Harness storage) and talks to Harness only via postMessage:
 *  - reports url/title/readable text after load (so Leo can read the page),
 *  - turns link clicks and GET forms into navigation requests handled by the Harness shell,
 *  - runs learner add-ons (user scripts) the shell sends, matched by host.
 */
function agentScript(pageUrl: string) {
  return `<script>(function(){
var PAGE=${JSON.stringify(pageUrl)};
function post(m){try{parent.postMessage(Object.assign({__harness:1},m),"*")}catch(e){}}
try{Object.defineProperty(document,"cookie",{configurable:true,get:function(){return""},set:function(){}})}catch(e){}
["localStorage","sessionStorage"].forEach(function(n){try{var m={};var st={getItem:function(k){return Object.prototype.hasOwnProperty.call(m,k)?m[k]:null},setItem:function(k,v){m[k]=String(v)},removeItem:function(k){delete m[k]},clear:function(){m={}},key:function(i){return Object.keys(m)[i]||null},get length(){return Object.keys(m).length}};Object.defineProperty(window,n,{configurable:true,get:function(){return st}})}catch(e){}});
function abs(h){try{return new URL(h,PAGE).href}catch(e){return null}}
function readable(){var b=document.body;if(!b)return"";var c=b.cloneNode(true);c.querySelectorAll("script,style,noscript,nav,footer,aside,svg,iframe,form").forEach(function(e){e.remove()});var m=c.querySelector("main,article,[role=main]")||c;return(m.innerText||m.textContent||"").replace(/\\n{3,}/g,"\\n\\n").trim().slice(0,40000)}
function report(){var s=String(getSelection&&getSelection()||"");post({type:"page",url:PAGE,title:document.title||PAGE,text:readable(),selection:s.slice(0,8000)})}
document.addEventListener("click",function(e){var a=e.target&&e.target.closest&&e.target.closest("a[href]");if(!a)return;var h=a.getAttribute("href")||"";if(h.charAt(0)==="#")return;var u=abs(h);if(!u||!/^https?:/.test(u))return;e.preventDefault();post({type:"navigate",url:u})},true);
document.addEventListener("submit",function(e){var f=e.target;if(!f||(f.method||"get").toLowerCase()!=="get")return;e.preventDefault();var u=new URL(f.getAttribute("action")||PAGE,PAGE);new FormData(f).forEach(function(v,k){if(typeof v==="string")u.searchParams.set(k,v)});post({type:"navigate",url:u.href})},true);
var t;document.addEventListener("selectionchange",function(){clearTimeout(t);t=setTimeout(report,400)});
addEventListener("message",function(e){var d=e.data||{};if(!d.__harnessShell)return;
 if(d.type==="addons"){var host=location.hostname||new URL(PAGE).hostname;(d.addons||[]).forEach(function(a){try{if(a.css){var s=document.createElement("style");s.textContent=a.css;document.documentElement.appendChild(s)}if(a.code){new Function(a.code)()}}catch(err){post({type:"addon-error",name:a.name,error:String(err)})}});setTimeout(report,300)}
 if(d.type==="read")report();
 if(d.type==="scroll"){var el=null;if(d.text){var w=document.createTreeWalker(document.body,4);while(w.nextNode()){if(w.currentNode.nodeValue.indexOf(d.text)>=0){el=w.currentNode.parentElement;break}}}if(el){el.scrollIntoView({behavior:"smooth",block:"center"});el.style.background="#ffe08a"}}
});
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){post({type:"ready"});report()});else{post({type:"ready"});report()}
addEventListener("load",function(){setTimeout(report,500)});
})();</script>`;
}

function errorPage(msg: string, url: string) {
  const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
  return `<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:32px;color:#5c5b63;background:#f5f4ef"><h2 style="color:#17171a;margin:0 0 8px">Couldn't open this page</h2><p>${esc(msg)}</p><p style="word-break:break-all;font-size:13px">${esc(url)}</p>${agentScript(url)}</body>`;
}

export async function GET(req: Request) {
  const target = new URL(req.url).searchParams.get("url") ?? "";
  const headers = {
    "content-type": "text/html; charset=utf-8",
    "cache-control": "no-store",
    // The frame is sandboxed by the shell too; this keeps it from ever framing elsewhere.
    // Even if someone opens /api/browse directly, remote scripts get an opaque origin.
    "content-security-policy": "sandbox allow-scripts allow-forms allow-popups",
  };
  let url: URL;
  try {
    url = new URL(target);
    await assertPublic(url);
  } catch (e) {
    return new Response(errorPage((e as Error).message || "Invalid address", target), { headers });
  }

  try {
    let res: Response | null = null;
    let current = url;
    for (let hop = 0; hop < 5; hop++) {
      res = await fetch(current, {
        redirect: "manual",
        signal: AbortSignal.timeout(15000),
        headers: {
          "user-agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36 HarnessLearningBrowser/1.0",
          accept: "text/html,application/xhtml+xml,*/*;q=0.8",
          "accept-language": req.headers.get("accept-language") ?? "en-US,en;q=0.9",
        },
      });
      const loc = res.headers.get("location");
      if (res.status >= 300 && res.status < 400 && loc) {
        current = new URL(loc, current);
        await assertPublic(current);
        continue;
      }
      break;
    }
    if (!res) throw new Error("No response");
    if (res.status === 403 || res.status === 429 || res.status >= 500) {
      return new Response(errorPage(`Site blocked or failed (HTTP ${res.status})`, current.href), { headers });
    }
    const type = res.headers.get("content-type") ?? "";
    if (!type.includes("html")) {
      return new Response(
        errorPage(`This is a ${type.split(";")[0] || "non-HTML"} file. Open it in your system browser or download it and add it to your library.`, current.href),
        { headers }
      );
    }
    const buf = await res.arrayBuffer();
    if (buf.byteLength > MAX_BYTES) throw new Error("Page is too large for the learning browser");
    let html = new TextDecoder("utf-8").decode(buf);
    // Drop the page's own CSP/base so relative assets resolve against the real site.
    html = html.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "").replace(/<base[^>]*>/gi, "");
    const head = `<base href="${current.href.replace(/"/g, "%22")}">${agentScript(current.href)}`;
    html = /<head(\s[^>]*)?>/i.test(html) ? html.replace(/<head(\s[^>]*)?>/i, (m) => m + head) : head + html;
    return new Response(html, { headers: { ...headers, "x-final-url": current.href } });
  } catch (e) {
    return new Response(errorPage((e as Error).message || "Network error", url.href), { headers });
  }
}
