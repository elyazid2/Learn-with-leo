import { useEffect, useState } from "react";

/**
 * The project home is the Library — it holds every kind of item. "notes"/"sketch" open an
 * item editor, "library/:id" opens a file, and "progress" opens the progress sheet over the library.
 */
export type Tab = "library" | "notes" | "sketch" | "progress";

export type Route =
  | { name: "home" }
  | { name: "settings" }
  | { name: "memories" }
  | { name: "dev-avatars" }
  | { name: "project"; projectId: string; tab: Tab; itemId?: string };

export function parseHash(hash: string): Route {
  const parts = hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  if (parts[0] === "settings") return { name: "settings" };
  if (parts[0] === "memories") return { name: "memories" };
  if (parts[0] === "dev" && parts[1] === "avatars") return { name: "dev-avatars" };
  if (parts[0] === "p" && parts[1]) {
    const projectId = parts[1];
    const seg = parts[2];
    // "overview" was the old Map tab; its content now lives in the Progress sheet.
    if (seg === "progress" || seg === "overview") return { name: "project", projectId, tab: "progress" };
    if (seg === "notes") return { name: "project", projectId, tab: "notes", itemId: parts[3] || undefined };
    if (seg === "sketch" && parts[3]) return { name: "project", projectId, tab: seg, itemId: parts[3] };
    if (seg === "library" && parts[3]) return { name: "project", projectId, tab: "library", itemId: parts[3] };
    return { name: "project", projectId, tab: "library" };
  }
  return { name: "home" };
}

export function navigate(path: string, replace = false) {
  const target = "#/" + path.replace(/^\/+/, "");
  if (replace) {
    history.replaceState(null, "", target);
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = target;
  }
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseHash(window.location.hash));
  useEffect(() => {
    const on = () => setRoute(parseHash(window.location.hash));
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

export const projectPath = (projectId: string, tab: Tab = "library", itemId?: string) =>
  `p/${projectId}/${tab}${itemId ? "/" + itemId : ""}`;
