type SpeechRecognitionCtor = new () => {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  continuous: boolean;
  start(): void;
  stop(): void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
};

function recognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SpeechRecognitionCtor; webkitSpeechRecognition?: SpeechRecognitionCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

/** Dictation is available where the browser exposes the Web Speech Recognition API. */
export const speechSupported = () => !!recognitionCtor();

/** One dictation turn. Resolves with the final transcript (empty if unsupported/denied). */
export function listenOnce(): Promise<string> {
  return new Promise((resolve) => {
    const Ctor = recognitionCtor();
    if (!Ctor) return resolve("");
    const rec = new Ctor();
    let text = "";
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      resolve(text.trim());
    };
    rec.lang = navigator.language || "en-US";
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    rec.continuous = false;
    rec.onresult = (event) => {
      let current = "";
      for (let i = 0; i < event.results.length; i++) current += event.results[i][0]?.transcript ?? "";
      text = current;
    };
    rec.onerror = () => finish();
    rec.onend = () => finish();
    try {
      rec.start();
    } catch {
      finish();
    }
    window.setTimeout(() => {
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
      finish();
    }, 30_000);
  });
}

/** Leo can read replies aloud where the Speech Synthesis API exists. */
export const speechOutputSupported = () => typeof window !== "undefined" && "speechSynthesis" in window;

export function speak(text: string, onEnd: () => void): boolean {
  if (!speechOutputSupported()) return false;
  window.speechSynthesis.cancel();
  const plain = text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[#*_`>|]/g, "")
    .replace(/\$[^$]*\$/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 6000);
  if (!plain) return false;
  const u = new SpeechSynthesisUtterance(plain);
  u.lang = navigator.language || "en-US";
  u.rate = 1;
  const voice = window.speechSynthesis.getVoices().find((v) => /en[-_]/i.test(v.lang));
  if (voice) u.voice = voice;
  u.onend = () => {
      onEnd();
  };
  u.onerror = () => {
      onEnd();
  };
  window.speechSynthesis.speak(u);
  return true;
}

export function stopSpeaking() {
  if (speechOutputSupported()) window.speechSynthesis.cancel();
}
