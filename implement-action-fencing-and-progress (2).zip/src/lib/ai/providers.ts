import type { Provider, ProviderType } from "../db";

export interface ChatMsg {
  role: "user" | "assistant";
  content: string;
  images?: string[]; // data URLs
  /** Audio clips. OpenAI-compatible endpoints accept "input_audio"; others get a text note. */
  audio?: { data: string; mime: string; name: string }[];
}

export interface Preset {
  key: string;
  name: string;
  type: ProviderType;
  baseUrl: string;
  models: string[];
  needsKey: boolean;
  hint?: string;
}

export const PRESETS: Preset[] = [
  {
    key: "openai",
    name: "OpenAI",
    type: "openai",
    baseUrl: "https://api.openai.com/v1",
    models: ["gpt-4.1-mini", "gpt-4.1", "gpt-4o-mini"],
    needsKey: true,
  },
  {
    key: "anthropic",
    name: "Anthropic",
    type: "anthropic",
    baseUrl: "https://api.anthropic.com",
    models: ["claude-sonnet-4-5", "claude-haiku-4-5"],
    needsKey: true,
  },
  {
    key: "gemini",
    name: "Google Gemini",
    type: "gemini",
    baseUrl: "https://generativelanguage.googleapis.com",
    models: ["gemini-2.5-flash", "gemini-2.5-pro"],
    needsKey: true,
  },
  {
    key: "openrouter",
    name: "OpenRouter",
    type: "openai",
    baseUrl: "https://openrouter.ai/api/v1",
    models: ["openai/gpt-4.1-mini", "anthropic/claude-sonnet-4.5", "google/gemini-2.5-flash"],
    needsKey: true,
  },
  {
    key: "nvidia",
    name: "NVIDIA NIM",
    type: "openai",
    // Same-origin proxy: NIM blocks browser CORS, so requests go through /api/nim.
    baseUrl: "/api/nim",
    models: ["meta/llama-3.3-70b-instruct", "nvidia/llama-3.1-nemotron-70b-instruct"],
    needsKey: true,
    hint: "build.nvidia.com API key. Fetch models to see what your key can use.",
  },
  {
    key: "groq",
    name: "Groq",
    type: "openai",
    baseUrl: "https://api.groq.com/openai/v1",
    models: ["llama-3.3-70b-versatile"],
    needsKey: true,
  },
  {
    key: "ollama",
    name: "Ollama (local)",
    type: "openai",
    baseUrl: "http://localhost:11434/v1",
    models: ["llama3.2"],
    needsKey: false,
    hint: "Run Ollama with OLLAMA_ORIGINS=* so the browser can reach it. From a phone, replace localhost with your computer's LAN IP.",
  },
  {
    key: "lmstudio",
    name: "LM Studio (local)",
    type: "openai",
    baseUrl: "http://localhost:1234/v1",
    models: [],
    needsKey: false,
    hint: "Enable CORS in LM Studio's server settings.",
  },
  {
    key: "custom",
    name: "Custom (OpenAI-compatible)",
    type: "openai",
    baseUrl: "",
    models: [],
    needsKey: false,
  },
];

export const TYPE_LABEL: Record<ProviderType, string> = {
  openai: "OpenAI-compatible",
  anthropic: "Anthropic",
  gemini: "Gemini",
};

const trimSlash = (s: string) => s.replace(/\/+$/, "");

function splitDataUrl(dataUrl: string) {
  const m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
  return { mime: m?.[1] ?? "image/png", data: m?.[2] ?? "" };
}

async function* sseLines(res: Response, signal?: AbortSignal): AsyncGenerator<string> {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = "";
  try {
    while (true) {
      if (signal?.aborted) break;
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i: number;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (line.startsWith("data:")) {
          const d = line.slice(5).trim();
          if (d && d !== "[DONE]") yield d;
        }
      }
    }
    const rest = buf.trim();
    if (rest.startsWith("data:")) {
      const d = rest.slice(5).trim();
      if (d && d !== "[DONE]") yield d;
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      /* noop */
    }
  }
}

export class ProviderError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
  }
}

/**
 * What one stream reported about itself, for the chat log. Sent progressively (max_tokens when the
 * request is built, finishReason when the stream closes) and merged by the caller.
 */
export interface StreamMeta {
  /** max_tokens actually sent, or null when the request carried none. */
  maxTokens?: number | null;
  /** Why the stream ended, in the provider's own wording (finish_reason / stop_reason / finishReason). */
  finishReason?: string;
}

function linkSignals(timeoutMs: number, signal?: AbortSignal) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(new DOMException("Request timed out", "TimeoutError")), timeoutMs);
  signal?.addEventListener("abort", () => ac.abort(signal.reason), { once: true });
  return { signal: ac.signal, clear: () => clearTimeout(t) };
}

/** POST with a timeout and one retry on 429/5xx/network failure (never retries a user abort). */
async function post(url: string, init: RequestInit, timeoutSec: number, signal?: AbortSignal): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < 2; attempt++) {
    const link = linkSignals(timeoutSec * 1000, signal);
    try {
      const res = await fetch(url, { ...init, signal: link.signal });
      if ((res.status === 429 || res.status >= 500) && attempt === 0) {
        link.clear();
        const retryAfter = Number(res.headers.get("retry-after")) || 1.5;
        await new Promise((r) => setTimeout(r, Math.min(retryAfter, 8) * 1000));
        continue;
      }
      // Keep the timeout alive for the body stream; clear it once the stream closes.
      const body = res.body;
      if (body) {
        const reader = body.getReader();
        const stream = new ReadableStream({
          async pull(c) {
            const { done, value } = await reader.read();
            if (done) {
              link.clear();
              c.close();
            } else c.enqueue(value);
          },
          cancel: () => {
            link.clear();
            return reader.cancel();
          },
        });
        return new Response(stream, { status: res.status, statusText: res.statusText, headers: res.headers });
      }
      link.clear();
      return res;
    } catch (e) {
      link.clear();
      if (signal?.aborted) throw e;
      lastErr = e;
      if (attempt === 0 && !(e instanceof DOMException && e.name === "TimeoutError")) {
        await new Promise((r) => setTimeout(r, 1200));
        continue;
      }
      throw e;
    }
  }
  throw lastErr;
}

async function errorFrom(res: Response): Promise<Error> {
  let text = "";
  try {
    text = await res.text();
    const j = JSON.parse(text);
    text = j?.error?.message || j?.message || j?.error || text;
    if (typeof text !== "string") text = JSON.stringify(text);
  } catch {
    /* keep raw */
  }
  return new ProviderError(`${res.status} ${res.statusText}${text ? " — " + String(text).slice(0, 300) : ""}`, res.status);
}

/** Merge consecutive same-role messages and make sure the list starts with a user turn. */
function normalize(messages: ChatMsg[]): ChatMsg[] {
  const out: ChatMsg[] = [];
  for (const m of messages) {
    const last = out[out.length - 1];
    if (last && last.role === m.role) {
      last.content += "\n\n" + m.content;
      if (m.images?.length) last.images = [...(last.images ?? []), ...m.images];
      if (m.audio?.length) last.audio = [...(last.audio ?? []), ...m.audio];
    } else out.push({ ...m, images: m.images ? [...m.images] : undefined });
  }
  if (out[0]?.role === "assistant") out.unshift({ role: "user", content: "(start)" });
  return out;
}

export async function* streamChat(
  p: Provider,
  model: string,
  system: string,
  messages: ChatMsg[],
  signal?: AbortSignal,
  onMeta?: (meta: StreamMeta) => void
): AsyncGenerator<string> {
  const msgs = normalize(messages).map((m) =>
    m.audio?.length && p.type !== "openai"
      ? { ...m, content: `${m.content}\n\n[Audio attached: ${m.audio.map((a) => a.name).join(", ")} — this model cannot listen to audio directly; ask the learner to describe it or use a transcription note.]`, audio: undefined }
      : m
  );

  const timeout = p.timeout && p.timeout > 0 ? p.timeout : 120;

  if (p.type === "anthropic") {
    // Anthropic requires max_tokens, so a value is always sent.
    const maxTokens = p.maxTokens && p.maxTokens > 0 ? p.maxTokens : 8192;
    onMeta?.({ maxTokens });
    const res = await post(`${trimSlash(p.baseUrl || "https://api.anthropic.com")}/v1/messages`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": p.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        system,
        stream: true,
        messages: msgs.map((m) => ({
          role: m.role,
          content: [
            ...(m.images ?? []).map((u) => {
              const { mime, data } = splitDataUrl(u);
              return { type: "image", source: { type: "base64", media_type: mime, data } };
            }),
            { type: "text", text: m.content || "." },
          ],
        })),
      }),
    }, timeout, signal);
    if (!res.ok) throw await errorFrom(res);
    let stop = "";
    for await (const d of sseLines(res, signal)) {
      try {
        const j = JSON.parse(d);
        if (j.type === "content_block_delta" && j.delta?.type === "text_delta") yield j.delta.text;
        else if (j.type === "message_delta" && typeof j.delta?.stop_reason === "string") stop = j.delta.stop_reason;
        else if (j.type === "error") throw new Error(j.error?.message || "Anthropic error");
      } catch (e) {
        if (!(e instanceof SyntaxError)) throw e;
      }
    }
    if (stop) onMeta?.({ finishReason: stop });
    if (stop === "max_tokens") yield "\n\n*(reply cut off: output limit reached — raise max tokens in Settings → provider)*";
    return;
  }

  if (p.type === "gemini") {
    const base = trimSlash(p.baseUrl || "https://generativelanguage.googleapis.com");
    onMeta?.({ maxTokens: null }); // Gemini gets no output cap from this request
    const res = await post(
      `${base}/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`,
      {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": p.apiKey },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: msgs.map((m) => ({
            role: m.role === "assistant" ? "model" : "user",
            parts: [
              ...(m.images ?? []).map((u) => {
                const { mime, data } = splitDataUrl(u);
                return { inline_data: { mime_type: mime, data } };
              }),
              { text: m.content || "." },
            ],
          })),
        }),
      },
      timeout,
      signal
    );
    if (!res.ok) throw await errorFrom(res);
    let finish = "";
    let blocked = "";
    for await (const d of sseLines(res, signal)) {
      try {
        const j = JSON.parse(d);
        if (j.error) throw new Error(j.error.message || "Gemini error");
        if (j.promptFeedback?.blockReason) blocked = j.promptFeedback.blockReason;
        const cand = j.candidates?.[0];
        if (cand?.finishReason) finish = cand.finishReason;
        const parts = cand?.content?.parts ?? [];
        for (const part of parts) if (part.text && !part.thought) yield part.text as string;
      } catch (e) {
        if (!(e instanceof SyntaxError)) throw e;
      }
    }
    if (finish) onMeta?.({ finishReason: finish });
    if (blocked) throw new Error(`Gemini blocked the prompt (${blocked}). Try rephrasing or detaching context.`);
    if (finish === "SAFETY" || finish === "RECITATION" || finish === "PROHIBITED_CONTENT") throw new Error(`Gemini stopped the reply (${finish}).`);
    if (finish === "MAX_TOKENS") yield "\n\n*(reply cut off: output limit reached)*";
    return;
  }

  // OpenAI-compatible
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (p.apiKey) headers.authorization = `Bearer ${p.apiKey}`;
  // The NIM proxy reads the key from x-nim-key (Authorization can be dropped on redirect hops).
  if (p.apiKey && p.baseUrl.startsWith("/api/nim")) headers["x-nim-key"] = p.apiKey;
  const openRouter = p.baseUrl.includes("openrouter.ai");
  if (openRouter) {
    headers["HTTP-Referer"] = location.origin;
    headers["X-Title"] = "Harness";
  }
  // OpenRouter needs an explicit cap or it truncates replies at its own default.
  const maxTokens = openRouter ? (p.maxTokens && p.maxTokens > 0 ? p.maxTokens : 8192) : null;
  onMeta?.({ maxTokens });
  const res = await post(`${trimSlash(p.baseUrl)}/chat/completions`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model,
      stream: true,
      ...(maxTokens ? { max_tokens: maxTokens } : {}),
      ...(p.apiKey && p.baseUrl.startsWith("/api/nim") ? { _key: p.apiKey } : {}),
      messages: [
        { role: "system", content: system },
        ...msgs.map((m) => {
          if (m.role !== "user" || (!m.images?.length && !m.audio?.length)) return { role: m.role, content: m.content };
          const parts: Record<string, unknown>[] = [{ type: "text", text: m.content }];
          for (const u of m.images ?? []) parts.push({ type: "image_url", image_url: { url: u } });
          for (const a of m.audio ?? []) parts.push({ type: "input_audio", input_audio: { data: a.data.split(",").pop(), format: a.mime.includes("wav") ? "wav" : a.mime.includes("mp4") || a.mime.includes("m4a") ? "m4a" : "mp3" } });
          return { role: m.role, content: parts };
        }),
      ],
    }),
  }, timeout, signal);
  if (!res.ok) throw await errorFrom(res);
  let finish = "";
  for await (const d of sseLines(res, signal)) {
    try {
      const j = JSON.parse(d);
      if (j.error) throw new Error(j.error.message || "Provider error");
      const choice = j.choices?.[0];
      if (choice?.finish_reason) finish = choice.finish_reason;
      const t = choice?.delta?.content;
      if (t) yield t as string;
    } catch (e) {
      if (!(e instanceof SyntaxError)) throw e;
    }
  }
  if (finish) onMeta?.({ finishReason: finish });
  if (finish === "length") yield "\n\n*(reply cut off: output limit reached)*";
  if (finish === "content_filter") throw new Error("The provider's content filter stopped this reply.");
}

/** Drop catalog entries that can't chat (embeddings, speech, image, moderation…). */
const NON_CHAT = /embed|whisper|tts|dall-?e|moderation|rerank|transcribe|imagen|veo|image-(gen|preview)|speech|realtime|audio-preview|guard|aqa|^text-(?:ada|babbage|curie|davinci)/i;
const chatOnly = (ids: string[]) => Array.from(new Set(ids)).filter((id) => !NON_CHAT.test(id));

export async function listModels(p: Pick<Provider, "type" | "baseUrl" | "apiKey">): Promise<string[]> {
  return chatOnly(await listAllModels(p));
}

async function listAllModels(p: Pick<Provider, "type" | "baseUrl" | "apiKey">): Promise<string[]> {
  if (p.type === "anthropic") {
    const res = await fetch(`${trimSlash(p.baseUrl || "https://api.anthropic.com")}/v1/models?limit=100`, {
      headers: {
        "x-api-key": p.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
    });
    if (!res.ok) throw await errorFrom(res);
    const j = await res.json();
    return (j.data ?? []).map((m: { id: string }) => m.id);
  }
  if (p.type === "gemini") {
    const base = trimSlash(p.baseUrl || "https://generativelanguage.googleapis.com");
    const res = await fetch(`${base}/v1beta/models?pageSize=200`, {
      headers: { "x-goog-api-key": p.apiKey },
    });
    if (!res.ok) throw await errorFrom(res);
    const j = await res.json();
    return (j.models ?? [])
      .filter((m: { supportedGenerationMethods?: string[] }) =>
        m.supportedGenerationMethods?.includes("generateContent")
      )
      .map((m: { name: string }) => m.name.replace(/^models\//, ""));
  }
  const headers: Record<string, string> = {};
  if (p.apiKey) headers.authorization = `Bearer ${p.apiKey}`;
  if (p.apiKey && p.baseUrl.startsWith("/api/nim")) headers["x-nim-key"] = p.apiKey;
  const res = await fetch(
    `${trimSlash(p.baseUrl)}/models`,
    p.baseUrl.startsWith("/api/nim")
      ? { method: "POST", headers: { ...headers, "content-type": "application/json" }, body: JSON.stringify({ _key: p.apiKey }) }
      : { headers }
  );
  if (!res.ok) throw await errorFrom(res);
  const j = await res.json();
  return (j.data ?? j.models ?? []).map((m: { id?: string; name?: string }) => m.id ?? m.name ?? "").filter(Boolean);
}

