import type { ChatMode, Project, Provider } from "../db";
import type { ChatMsg } from "./providers";

export const MOCK_PROVIDER: Provider = {
  id: "harness-local-mock",
  name: "Developer mock",
  type: "openai",
  baseUrl: "local://mock",
  apiKey: "",
  models: ["harness-mock"],
  defaultModel: "harness-mock",
  createdAt: 0,
};

function responseFor(project: Project, mode: ChatMode, messages: ChatMsg[]) {
  const latest = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  const lower = latest.toLowerCase();
  const turns = messages.filter((m) => m.role === "user").length;
  const intent =
    mode === "placement"
      ? "placement"
      : /quiz answer/i.test(latest) || /\b(quiz|test me|review|due)\b/.test(lower)
        ? "test"
        : /\b(teach|learn|explain|lesson|next thing)\b/.test(lower)
          ? "teach"
          : "ask";

  if (/avatar|change.*(shape|color|colour)/.test(lower)) {
    return `I've updated my look for **${project.name}**. You can also fine-tune it in Settings.\n\n\`\`\`action\n{"type":"set_avatar","shape":"orb","color":"coral","expression":"bright"}\n\`\`\``;
  }

  if (mode === "placement") {
    if (turns <= 1) {
      return `I'll calibrate this locally with a few adaptive questions. What best describes your current relationship with **${project.name}**?\n\n\`\`\`action\n{"type":"ask","question":"Where are you starting from?","options":["Completely new","I know a few basics","I use it with some confidence","I can teach the fundamentals"]}\n\`\`\``;
    }
    if (turns === 2 || turns === 3) {
      if (turns === 3)
        return `One more to calibrate difficulty.\n\n\`\`\`action\n{"type":"quiz","question":"If an idea only works on the examples you were shown, what is most likely missing?","options":["More vocabulary","A grasp of the idea's conditions and limits","A faster explanation","A longer summary"],"answer":1,"explanation":"Transfer depends on knowing when an idea applies.","concept":"Core mental models"}\n\`\`\``;
      return `Thanks. I'll probe one foundation before choosing a starting point.\n\n\`\`\`action\n{"type":"quiz","question":"Which approach usually leads to durable understanding?","options":["Recognizing a familiar explanation","Retrieving and applying an idea without prompts","Rereading until it feels fluent","Memorizing terminology only"],"answer":1,"explanation":"Retrieval and application expose gaps that recognition can hide.","concept":"Foundations"}\n\`\`\`\n\n\`\`\`action\n{"type":"map","concept":"Foundations","status":"learning"}\n\`\`\``;
    }
    return `That gives me a useful baseline. I'd start with core mental models, then immediately use them on a small example.\n\n\`\`\`action\n{"type":"set_level","level":"Novice","summary":"You have some useful intuition, but benefit from guided retrieval and concrete examples.","startingPoint":"Core mental models for this topic, with short worked examples."}\n\`\`\`\n\n\`\`\`action\n{"type":"map","concept":"Core mental models","status":"learning"}\n\`\`\`\n\n\`\`\`action\n{"type":"map","concept":"Foundations","status":"solid"}\n\`\`\`\n\n\`\`\`action\n{"type":"map","concept":"Independent application","status":"new","parent":"Core mental models"}\n\`\`\`\n\n\`\`\`action\n{"type":"point","kind":"next","text":"Apply one core idea to a small, unworked example"}\n\`\`\``;
  }

  if (intent === "test") {
    return `${/incorrect/i.test(latest) ? "Not quite—use the explanation as a clue, then try this different angle." : "Good. I'll check whether that holds in a slightly different situation."}\n\n\`\`\`action\n{"type":"map","concept":"Independent application","status":"learning","note":"Being checked through varied mock questions"}\n\`\`\`\n\n\`\`\`action\n{"type":"quiz","question":"A method works on a familiar example but fails on a new one. What is the best next step?","options":["Repeat the familiar example","Identify the assumption that changed","Add more terminology","Skip to an advanced topic"],"answer":1,"explanation":"A changed assumption is often what separates recognition from transferable understanding.","concept":"Independent application"}\n\`\`\``;
  }

  if (intent === "teach") {
    return `Start with a **mental model**: understanding is not storing a perfect explanation; it is building a reliable way to predict, explain, and act. For ${project.name}, make each idea answer three questions: *What is it for? When does it fail? How would I use it unprompted?*\n\nTry explaining one core idea in two sentences, then test it against an example that does not quite fit.\n\n\`\`\`action\n{"type":"map","concept":"Core mental models","status":"learning","note":"Introduced through purpose, limits, and retrieval"}\n\`\`\`\n\n\`\`\`action\n{"type":"point","kind":"careful","text":"Feeling familiar with an explanation is not the same as being able to use it"}\n\`\`\`\n\n\`\`\`action\n{"type":"quiz","question":"Which check best reveals whether you can use an idea?","options":["Highlighting its definition","Explaining why a borderline example does or does not fit","Reading a second explanation","Copying a worked solution"],"answer":1,"explanation":"Borderline cases force you to apply the idea's conditions rather than repeat its wording.","concept":"Core mental models"}\n\`\`\``;
  }

  const contextNote = latest.includes("<workspace_context>")
    ? "I can see the workspace context attached to your message, so I'll ground this in that material. "
    : "";
  return `${contextNote}This is Leo's **local mock response** for ${project.name}. It follows the same action protocol as a live tutor: it can update your map and points card, and it can wait for a quiz answer.\n\n\`\`\`action\n{"type":"point","kind":"next","text":"Turn the next explanation into one concrete example of your own"}\n\`\`\`\n\n\`\`\`action\n{"type":"quiz","question":"What makes this developer response useful for testing Harness?","options":["It calls a hidden cloud API","It streams real actions through the normal local workflow","It only displays static text","It replaces your saved projects"],"answer":1,"explanation":"The mock uses the same streaming parser and action executor without making network requests.","concept":"Harness workflow"}\n\`\`\``;
}

function wait(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(new DOMException("Aborted", "AbortError"));
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(new DOMException("Aborted", "AbortError"));
    }, { once: true });
  });
}

/** Offline provider: deterministic content, real delays/chunking, zero fetch calls. */
export async function* streamMockChat(
  project: Project,
  mode: ChatMode,
  messages: ChatMsg[],
  options: { delay: number; behavior: "auto" | "error" },
  signal?: AbortSignal
): AsyncGenerator<string> {
  await wait(options.delay, signal);
  const latest = [...messages].reverse().find((m) => m.role === "user")?.content.toLowerCase() ?? "";
  if (options.behavior === "error" || latest.includes("/error")) {
    throw new Error("Simulated local provider failure. Change Mock response to Auto or send a new message.");
  }
  const response = responseFor(project, mode, messages);
  let cursor = 0;
  while (cursor < response.length) {
    if (signal?.aborted) return;
    const size = 3 + ((cursor * 7) % 6);
    const chunk = response.slice(cursor, cursor + size);
    cursor += chunk.length;
    yield chunk;
    await wait(10 + (cursor % 17), signal);
  }
}
