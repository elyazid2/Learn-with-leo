import { useEffect } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "./db";
import { useApp } from "./store";
import type { AgentState } from "./avatar";
import { useSettings } from "./settings";

/** Resolves the avatar from actual chat/action lifecycle events, not timers alone. */
export function useAgentState(projectId?: string): AgentState {
  const agent = useApp((s) => s.agent);
  const waitingProjectId = useApp((s) => s.waitingProjectId);
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const setAgentActivity = useApp((s) => s.setAgentActivity);
  const developerMode = useSettings((s) => s.developerMode);
  const forcedAgentState = useSettings((s) => s.forcedAgentState);
  const active = agent.projectId === projectId;

  useEffect(() => {
    if (!active || agent.phase !== "done") return;
    const at = agent.at;
    const timer = window.setTimeout(() => {
      if (useApp.getState().agent.at === at) setAgentActivity("idle", projectId ?? null);
    }, Math.max(0, 2600 - (Date.now() - at)));
    return () => window.clearTimeout(timer);
  }, [active, agent.phase, agent.at, projectId, setAgentActivity]);

  if (developerMode && forcedAgentState !== "auto") return forcedAgentState;
  // providerCount is undefined until IndexedDB answers — never report "blocked" before we know.
  if (providerCount === 0 && !developerMode) return "blocked";
  if (active && agent.phase === "blocked" && (agent.reason === "error" || (providerCount === 0 && !developerMode))) return "blocked";
  if (active && agent.phase === "working") return "working";
  if (active && agent.phase === "thinking") return "thinking";
  if (active && agent.phase === "speaking") return "speaking";
  if (active && agent.phase === "listening") return "listening";
  if (waitingProjectId === projectId) return "waiting";
  if (active && agent.phase === "done") return "done";
  return "idle";
}
