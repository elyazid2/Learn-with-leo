/** Color utilities that keep text readable on brand colors in both themes. */

export function parseHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

export function luminance(rgb: [number, number, number]) {
  const f = (v: number) => {
    const c = v / 255;
    return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * f(rgb[0]) + 0.7152 * f(rgb[1]) + 0.0722 * f(rgb[2]);
}

/** WCAG contrast ratio between two hex colors. */
export function contrast(a: string, b: string) {
  const la = luminance(parseHex(a) ?? [0, 0, 0]);
  const lb = luminance(parseHex(b) ?? [0, 0, 0]);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

/** sRGB mix: `t` of `a` plus `1 - t` of `b` (what CSS color-mix(in srgb, a t%, b) does). */
export function mix(a: string, b: string, t: number) {
  const pa = parseHex(a) ?? [0, 0, 0];
  const pb = parseHex(b) ?? [0, 0, 0];
  return "#" + pa.map((v, i) => Math.round(v * t + pb[i] * (1 - t)).toString(16).padStart(2, "0")).join("");
}

export const INK = "#17171a";

/** White or ink — whichever reads better on `hex`. */
export function readableOn(hex: string) {
  if (!parseHex(hex)) return "#ffffff";
  return contrast(hex, "#ffffff") >= contrast(hex, INK) ? "#ffffff" : INK;
}

/** Share of the accent kept in accentText(); verified against AA in contrast.test.ts. */
export const ACCENT_TEXT_SHARE = 0.58;

/**
 * Theme-adaptive text derived from a vivid accent: mixing toward --ink darkens it on light
 * surfaces and lightens it on dark ones, so labels stay ≥ 4.5:1 on tinted chips.
 */
export function accentText(color: string) {
  return `color-mix(in srgb, ${color} ${Math.round(ACCENT_TEXT_SHARE * 100)}%, var(--ink))`;
}
