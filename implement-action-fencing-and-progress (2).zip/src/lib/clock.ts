import { useSyncExternalStore } from "react";

/**
 * One requestAnimationFrame loop shared by every animated avatar. Runs only while something
 * subscribes, renders at display rate for smooth motion, and pauses when the tab is hidden.
 */
const FPS = 60;
let listeners = new Set<() => void>();
let frame = 0;
let last = 0;
let now = 0;
const start = performance.now();

function tick(t: number) {
  frame = 0;
  if (!listeners.size) return;
  if (t - last >= 1000 / FPS) {
    last = t;
    now = (t - start) / 1000;
    // All subscribers update in one callback → React batches them into one render pass.
    for (const l of listeners) l();
  }
  if (document.visibilityState !== "hidden") frame = requestAnimationFrame(tick);
}

function ensureRunning() {
  if (!frame && listeners.size && document.visibilityState !== "hidden") frame = requestAnimationFrame(tick);
}

if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
    } else ensureRunning();
  });
}

function subscribe(l: () => void) {
  listeners.add(l);
  ensureRunning();
  return () => {
    listeners.delete(l);
    if (!listeners.size && frame) {
      cancelAnimationFrame(frame);
      frame = 0;
    }
  };
}

const getSnapshot = () => now;
const noop = () => () => {};
const zero = () => 0;

/** Seconds since app start, updating ~24×/s while `active`; frozen at the last value otherwise. */
export function useSharedClock(active: boolean) {
  return useSyncExternalStore(active ? subscribe : noop, active ? getSnapshot : zero, zero);
}
