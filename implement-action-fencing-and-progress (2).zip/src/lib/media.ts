import { db, uid, type FileKind, type LibFile } from "./db";
import type { PDFWorker } from "pdfjs-dist/legacy/build/pdf.mjs";

type PdfJs = typeof import("pdfjs-dist/legacy/build/pdf.mjs");
let pdfjsPromise: Promise<PdfJs> | null = null;

export function getPdfjs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    pdfjsPromise = (async () => {
      const lib = await import("pdfjs-dist/legacy/build/pdf.mjs");
      lib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      return lib;
    })();
  }
  return pdfjsPromise;
}

let sharedWorker: PDFWorker | null = null;

/**
 * Open a PDF with scripting-free rendering. Every document (reader, thumbnails, indexing) shares
 * one pdf.js worker, so a phone never runs several worker threads each holding a copy of the file.
 * Call `closePdf(doc)` when done.
 */
export async function openPdf(blob: Blob) {
  const pdfjs = await getPdfjs();
  const bytes = await blob.arrayBuffer();
  const attempt = () => {
    if (!sharedWorker || sharedWorker.destroyed) sharedWorker = new pdfjs.PDFWorker();
    // pdf.js 6 has no eval-based font path; we never mount annotation/forms layers,
    // so document JavaScript is never evaluated. XFA stays off.
    return pdfjs.getDocument({ data: new Uint8Array(bytes.slice(0)), enableXfa: false, worker: sharedWorker }).promise;
  };
  try {
    return await attempt();
  } catch (e) {
    // The OS can kill a worker under memory pressure: start a fresh one and try once more.
    if (sharedWorker?.destroyed || /worker/i.test(String((e as Error)?.message ?? e))) {
      sharedWorker = null;
      return attempt();
    }
    throw e;
  }
}

export function closePdf(doc: { loadingTask: { destroy(): Promise<void> } } | null | undefined) {
  doc?.loadingTask.destroy().catch(() => {});
}

let readers = 0;
/** The PDF reader announces itself so background indexing can step aside while you read. */
export function setPdfReaderActive(active: boolean) {
  readers = Math.max(0, readers + (active ? 1 : -1));
}
export const isPdfReaderActive = () => readers > 0;
export async function waitForReaderIdle() {
  while (readers > 0) await new Promise((r) => setTimeout(r, 800));
}

/** Max bytes we fully decode for a waveform. Larger audio gets a placeholder waveform. */
export const AUDIO_DECODE_LIMIT = 40 * 1024 * 1024;
/** Refuse single files above this; IndexedDB and memory both suffer beyond it. */
export const MAX_FILE_BYTES = 512 * 1024 * 1024;

export function kindOf(file: { type: string; name: string }): FileKind | null {
  const n = file.name.toLowerCase();
  if (file.type === "application/pdf" || n.endsWith(".pdf")) return "pdf";
  if (file.type.startsWith("image/") || /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/.test(n)) return "image";
  if (file.type === "video/webm" && n.includes("recording")) return "audio";
  if (file.type.startsWith("video/") || /\.(mp4|mov|webm|mkv|m4v|avi|ogv)$/.test(n)) return "video";
  if (file.type.startsWith("audio/") || /\.(mp3|m4a|wav|ogg|oga|aac|flac|opus|weba)$/.test(n)) return "audio";
  if (file.type.startsWith("text/") || /\.(txt|md|markdown)$/.test(n)) return "text";
  return null;
}

export async function storageHeadroom(bytes: number) {
  const est = await navigator.storage?.estimate?.().catch(() => undefined);
  if (!est?.quota) return true;
  return (est.usage ?? 0) + bytes < est.quota * 0.95;
}

async function loadImage(blob: Blob): Promise<HTMLImageElement> {
  const url = URL.createObjectURL(blob);
  try {
    const img = new Image();
    img.decoding = "async";
    img.src = url;
    await img.decode();
    return img;
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

export async function imageToDataUrl(blob: Blob, max = 1280, quality = 0.85): Promise<string | null> {
  try {
    const img = await loadImage(blob);
    const scale = Math.min(1, max / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
    const w = Math.max(1, Math.round((img.naturalWidth || max) * scale));
    const h = Math.max(1, Math.round((img.naturalHeight || max) * scale));
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return c.toDataURL("image/jpeg", quality);
  } catch {
    return null;
  }
}

/**
 * Square project icon from an image. Opaque photos are center-cropped (cover); images with
 * transparency (logos) are fitted whole with a little padding and stay transparent.
 */
export async function iconFromImage(blob: Blob, size = 256): Promise<string | null> {
  try {
    const img = await loadImage(blob);
    const w = img.naturalWidth || size;
    const h = img.naturalHeight || size;
    const probe = document.createElement("canvas");
    probe.width = 32;
    probe.height = 32;
    const pg = probe.getContext("2d", { willReadFrequently: true })!;
    pg.drawImage(img, 0, 0, 32, 32);
    const px = pg.getImageData(0, 0, 32, 32).data;
    let transparent = false;
    for (let i = 3; i < px.length; i += 4)
      if (px[i] < 250) {
        transparent = true;
        break;
      }
    const c = document.createElement("canvas");
    c.width = size;
    c.height = size;
    const g = c.getContext("2d")!;
    g.imageSmoothingQuality = "high";
    if (transparent) {
      const box = size * 0.84;
      const s = Math.min(box / w, box / h);
      g.drawImage(img, (size - w * s) / 2, (size - h * s) / 2, w * s, h * s);
      return c.toDataURL("image/png");
    }
    const s = Math.max(size / w, size / h);
    g.drawImage(img, (size - w * s) / 2, (size - h * s) / 2, w * s, h * s);
    return c.toDataURL("image/jpeg", 0.88);
  } catch {
    return null;
  }
}

/** Draw the video's current frame (null until a frame is decoded). */
export function frameDataUrl(v: HTMLVideoElement | null, max = 1280): string | null {
  if (!v || v.readyState < 2 || !v.videoWidth) return null;
  const scale = Math.min(1, max / Math.max(v.videoWidth, v.videoHeight));
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(v.videoWidth * scale));
  c.height = Math.max(1, Math.round(v.videoHeight * scale));
  c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.82);
}

function meanBrightness(v: HTMLVideoElement) {
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const g = c.getContext("2d", { willReadFrequently: true })!;
  g.drawImage(v, 0, 0, 16, 16);
  const d = g.getImageData(0, 0, 16, 16).data;
  let sum = 0;
  for (let i = 0; i < d.length; i += 4) sum += (d[i] + d[i + 1] + d[i + 2]) / 3;
  return sum / (d.length / 4);
}

/** Poster frame + duration. Seeks before drawing (a fresh element only has a black frame) and skips black intros. */
export async function videoInfo(blob: Blob): Promise<{ thumb?: string; duration?: number; thumbVersion?: number }> {
  if (typeof document === "undefined") return {};
  const url = URL.createObjectURL(blob);
  const v = document.createElement("video");
  const once = (ev: string, ms: number) =>
    new Promise<boolean>((res) => {
      const done = (ok: boolean) => {
        clearTimeout(t);
        v.removeEventListener(ev, h);
        res(ok);
      };
      const h = () => done(true);
      const t = setTimeout(() => done(false), ms);
      v.addEventListener(ev, h);
    });
  const seekTo = async (time: number) => {
    const seeked = once("seeked", 3000);
    v.currentTime = time;
    await seeked;
    if (v.readyState < 2) await once("loadeddata", 1500);
    const rvfc = (v as HTMLVideoElement & { requestVideoFrameCallback?: (cb: () => void) => number }).requestVideoFrameCallback;
    if (rvfc) await Promise.race([new Promise<void>((r) => rvfc.call(v, () => r())), new Promise<void>((r) => setTimeout(r, 300))]);
  };
  try {
    v.muted = true;
    v.playsInline = true;
    v.preload = "auto";
    const meta = once("loadedmetadata", 6000);
    v.src = url;
    v.load();
    if (!(await meta)) return {};
    let duration = isFinite(v.duration) && v.duration > 0 ? v.duration : undefined;
    if (!duration) {
      // MediaRecorder WebM reports Infinity until you seek past the end.
      const changed = once("durationchange", 1500);
      v.currentTime = 1e7;
      await changed;
      duration = isFinite(v.duration) && v.duration > 0 ? v.duration : undefined;
    }
    await seekTo(duration ? Math.min(Math.max(0.1, duration * 0.2), Math.max(0, duration - 0.1)) : 0.1);
    if (duration && duration > 2 && v.readyState >= 2 && meanBrightness(v) < 8) await seekTo(duration * 0.5);
    const thumb = frameDataUrl(v, 420);
    return { thumb: thumb ?? undefined, duration, thumbVersion: thumb ? 2 : undefined };
  } catch {
    return {};
  } finally {
    v.removeAttribute("src");
    v.load();
    URL.revokeObjectURL(url);
  }
}

export async function pdfInfo(blob: Blob): Promise<{ thumb?: string; pages?: number }> {
  try {
    const doc = await openPdf(blob);
    const page = await doc.getPage(1);
    const vp0 = page.getViewport({ scale: 1 });
    const vp = page.getViewport({ scale: 320 / vp0.width });
    const c = document.createElement("canvas");
    c.width = Math.round(vp.width);
    c.height = Math.round(vp.height);
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp, canvas: c }).promise;
    const pages = doc.numPages;
    closePdf(doc);
    return { thumb: c.toDataURL("image/jpeg", 0.75), pages };
  } catch (e) {
    console.warn("pdf thumb failed", e);
    return {};
  }
}

export async function audioInfo(blob: Blob, bars = 56): Promise<{ peaks?: number[]; duration?: number }> {
  if (blob.size > AUDIO_DECODE_LIMIT) return {};
  try {
    const AC: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    const buf = await ctx.decodeAudioData(await blob.arrayBuffer());
    const data = buf.getChannelData(0);
    const step = Math.max(1, Math.floor(data.length / bars));
    const peaks: number[] = [];
    for (let i = 0; i < bars; i++) {
      let max = 0;
      const start = i * step;
      for (let j = start; j < Math.min(start + step, data.length); j += 16) {
        const v = Math.abs(data[j]);
        if (v > max) max = v;
      }
      peaks.push(max);
    }
    const top = Math.max(...peaks, 0.01);
    ctx.close().catch(() => {});
    return { peaks: peaks.map((p) => Math.round((p / top) * 100) / 100), duration: buf.duration };
  } catch (e) {
    console.warn("audio decode failed", e);
    return {};
  }
}

export async function addFile(
  projectId: string,
  blob: Blob,
  name: string,
  opts: { recorded?: boolean; duration?: number; kind?: FileKind } = {}
): Promise<LibFile | null> {
  const kind = opts.kind ?? kindOf({ type: blob.type, name });
  if (!kind) return null;
  if (blob.size > MAX_FILE_BYTES) throw new Error(`${name} is larger than ${formatBytes(MAX_FILE_BYTES)}`);
  if (!(await storageHeadroom(blob.size))) throw new Error("Not enough storage left on this device");
  const f: LibFile = {
    id: uid(),
    projectId,
    name,
    kind,
    mime: blob.type || (kind === "pdf" ? "application/pdf" : ""),
    size: blob.size,
    blob,
    recorded: opts.recorded,
    duration: opts.duration,
    indexed: kind === "pdf" || kind === "text" ? "pending" : "none",
    createdAt: Date.now(),
  };
  if (kind === "image") f.thumb = (await imageToDataUrl(blob, 420, 0.75)) ?? undefined;
  if (kind === "video") Object.assign(f, await videoInfo(blob));
  if (kind === "pdf") Object.assign(f, await pdfInfo(blob));
  if (kind === "audio") {
    const info = await audioInfo(blob);
    f.peaks = info.peaks;
    if (info.duration && isFinite(info.duration)) f.duration = info.duration;
  }
  try {
    await db.files.add(f);
  } catch (e) {
    const name = `${(e as { name?: string })?.name ?? ""} ${(e as { inner?: { name?: string } })?.inner?.name ?? ""}`;
    if (/Quota/i.test(name)) throw new Error("This device is out of storage for Harness");
    if (/DataClone|Unknown|InvalidState/i.test(name))
      throw new Error("This browser couldn't store the file. Safari Private Browsing can't save files — open Harness in a normal tab.");
    throw e;
  }
  await db.projects.update(projectId, { updatedAt: Date.now() });
  if (f.indexed === "pending") {
    const { queueIndex } = await import("./retrieval");
    queueIndex(f.id);
  }
  return f;
}

export async function removeFile(file: LibFile) {
  await db.transaction("rw", [db.files, db.chunks], async () => {
    await db.chunks.where("sourceId").equals(file.id).delete();
    await db.files.delete(file.id);
  });
}

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export function formatDuration(s?: number) {
  if (!s || !isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export function timeAgo(t: number) {
  const d = (Date.now() - t) / 1000;
  if (d < 60) return "just now";
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  if (d < 86400 * 7) return `${Math.floor(d / 86400)}d ago`;
  return new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function blobToDataUrl(blob: Blob): Promise<string> {
  if (typeof FileReader === "undefined") {
    return blob.arrayBuffer().then((buf) => {
      let bin = "";
      const bytes = new Uint8Array(buf);
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return `data:${blob.type || "application/octet-stream"};base64,${btoa(bin)}`;
    });
  }
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export async function dataUrlToBlob(url: string): Promise<Blob> {
  const res = await fetch(url);
  return res.blob();
}

/** Exact text of one PDF page (used by @mentions). */
export async function pdfPageText(blob: Blob, page: number): Promise<string> {
  const doc = await openPdf(blob);
  try {
    const n = Math.min(Math.max(1, page), doc.numPages);
    const tc = await (await doc.getPage(n)).getTextContent();
    return tc.items
      .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
      .join("")
      .replace(/[ \t]+/g, " ")
      .trim();
  } finally {
    closePdf(doc);
  }
}

function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  const write = (offset: number, text: string) => [...text].forEach((c, i) => view.setUint8(offset + i, c.charCodeAt(0)));
  write(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, samples.length * 2, true);
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}

/** A precise audio segment as a WAV data URL, so a model that accepts audio hears exactly that part. */
export async function audioSegment(
  blob: Blob,
  start: number,
  end: number
): Promise<{ dataUrl: string; duration: number } | null> {
  if (typeof window === "undefined" || blob.size > 80 * 1024 * 1024) return null;
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  try {
    const buf = await ctx.decodeAudioData(await blob.arrayBuffer());
    const from = Math.max(0, Math.min(start, buf.duration));
    const to = Math.max(from + 0.1, Math.min(end, buf.duration, from + 120));
    const sr = buf.sampleRate;
    const data = buf.getChannelData(0);
    const samples = data.slice(Math.floor(from * sr), Math.floor(to * sr));
    return { dataUrl: await blobToDataUrl(encodeWav(samples, sr)), duration: to - from };
  } catch {
    return null;
  } finally {
    ctx.close().catch(() => {});
  }
}

export function formatClock(s: number) {
  const m = Math.floor(Math.max(0, s) / 60);
  const sec = Math.floor(Math.max(0, s) % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}
