/**
 * Markdown block helpers for the live-preview note editor. A note is a list of blocks
 * separated by blank lines; fenced code and $$ display math stay intact across blank lines.
 */
export function splitBlocks(md: string): string[] {
  const lines = md.replace(/\r/g, "").split("\n");
  const blocks: string[] = [];
  let cur: string[] = [];
  let fence: string | null = null;
  let math = false;
  const flush = () => {
    if (cur.length) blocks.push(cur.join("\n"));
    cur = [];
  };
  for (const line of lines) {
    const t = line.trim();
    if (fence) {
      cur.push(line);
      if (t.startsWith(fence)) fence = null;
      continue;
    }
    if (math) {
      cur.push(line);
      if (t.endsWith("$$")) math = false;
      continue;
    }
    if (/^(```|~~~)/.test(t)) {
      fence = t.slice(0, 3);
      cur.push(line);
      continue;
    }
    if (t.startsWith("$$") && !(t.length > 2 && t.endsWith("$$"))) {
      math = true;
      cur.push(line);
      continue;
    }
    if (t === "") {
      flush();
      continue;
    }
    cur.push(line);
  }
  flush();
  return blocks;
}

export function joinBlocks(blocks: string[]) {
  return blocks.filter((b) => b.trim() !== "").join("\n\n");
}

/** Flip the nth task-list checkbox in markdown source. */
export function toggleTask(src: string, nth: number, checked: boolean) {
  let i = -1;
  return src.replace(/^(\s*(?:[-*+]|\d+\.)\s+)\[( |x|X)\]/gm, (m, prefix: string) => {
    i++;
    return i === nth ? `${prefix}[${checked ? "x" : " "}]` : m;
  });
}

/** True when the text before the caret is inside an unclosed code fence. */
export function inFence(textBefore: string) {
  return (textBefore.match(/^\s*(```|~~~)/gm) ?? []).length % 2 === 1;
}

/** Matches a list/quote marker at the start of a line. */
export const LIST_RE = /^(\s*)([-*+] \[[ xX]\] |[-*+] |\d+[.)] |> )/;

/** The marker to continue a list with after Enter. */
export function nextMarker(marker: string) {
  const m = /^(\s*)(?:([-*+]) \[[ xX]\] |([-*+]) |(\d+)([.)]) |(>) )$/.exec(marker);
  if (!m) return marker;
  const [, indent, cb, bullet, num, delim, quote] = m;
  if (cb) return `${indent}${cb} [ ] `;
  if (bullet) return `${indent}${bullet} `;
  if (num) return `${indent}${Number(num) + 1}${delim} `;
  if (quote) return `${indent}> `;
  return marker;
}

const SYMBOLS: Record<string, string> = {
  alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", theta: "θ", lambda: "λ", mu: "μ", pi: "π", sigma: "σ",
  phi: "φ", omega: "ω", Delta: "Δ", Sigma: "Σ", Omega: "Ω", infty: "∞", cdot: "·", times: "×", to: "→", leq: "≤",
  geq: "≥", neq: "≠", det: "det",
};

/** A short, readable plain-text preview of a markdown note (math made legible, syntax removed). */
export function snippetOf(md: string, max = 160) {
  return md
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/\$\$[\s\S]*?\$\$/g, " ∑ ")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/\\(?:mathbf|mathrm|text|operatorname)\{([^}]*)\}/g, "$1")
    .replace(/\\([A-Za-z]+)/g, (_m, w: string) => SYMBOLS[w] ?? w)
    .replace(/\$/g, "")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/^\s*(?:[-*+]|\d+[.)])\s+(?:\[[ xX]\]\s+)?/gm, "")
    .replace(/[*_`~>#|]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}
