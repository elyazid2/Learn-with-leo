/**
 * Agent avatar model. Inspired by the Grok bot: one solid body, two slanted capsule eyes cut
 * out of it (they show whatever is behind), no mouth. Life comes from saccades and blinks;
 * state changes are exponential ease-outs (never overshooting). Pure data + pure functions so
 * any frame can be sampled deterministically (frozenAt, tests, the avatar sheet).
 */
export type AgentState = "idle" | "listening" | "thinking" | "speaking" | "working" | "waiting" | "blocked" | "done";
export type AvatarShape = "orb" | "mark" | "seed";
export type AvatarColor = "graphite" | "cobalt" | "moss" | "marigold" | "coral" | "violet" | "lagoon" | "clay";
export type AvatarExpression = "calm" | "curious" | "focused" | "bright" | "unsure" | "alert" | "pleased";

export interface AvatarLook {
  shape: AvatarShape;
  color: AvatarColor;
  expression: AvatarExpression;
}

function superellipse(a: number, b: number, n: number, steps = 120) {
  const pts: string[] = [];
  for (let i = 0; i < steps; i++) {
    const t = (i / steps) * Math.PI * 2;
    const c = Math.cos(t);
    const s = Math.sin(t);
    const x = 50 + a * Math.sign(c) * Math.pow(Math.abs(c), 2 / n);
    const y = 50 + b * Math.sign(s) * Math.pow(Math.abs(s), 2 / n);
    pts.push(`${x.toFixed(2)} ${y.toFixed(2)}`);
  }
  return `M${pts[0]} L${pts.slice(1).join(" L")}Z`;
}

export const AVATAR_SHAPES: Record<AvatarShape, { label: string; path: string }> = {
  orb: { label: "Orb", path: "M4 50a46 46 0 1 0 92 0a46 46 0 1 0 -92 0Z" },
  mark: { label: "Squircle", path: superellipse(45, 45, 4.2) },
  seed: { label: "Pebble", path: superellipse(47, 43, 2.5) },
};

export const AVATAR_COLORS: Record<AvatarColor, { label: string; hex: string }> = {
  graphite: { label: "Obsidian", hex: "#111114" },
  cobalt: { label: "Cobalt", hex: "#2f64e6" },
  moss: { label: "Moss", hex: "#168262" },
  marigold: { label: "Marigold", hex: "#e0991d" },
  coral: { label: "Coral", hex: "#df515b" },
  violet: { label: "Violet", hex: "#6f50d6" },
  lagoon: { label: "Lagoon", hex: "#12859a" },
  clay: { label: "Clay", hex: "#b86144" },
};

/** One eye: capsule centered at (x, y), w×h, rotated r degrees; lid 0..1 pushes a cheek up (smile). */
export interface EyeParams {
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
  lid: number;
}
export type FaceParams = [EyeParams, EyeParams];

const eye = (x: number, y: number, w: number, h: number, r: number, lid = 0): EyeParams => ({ x, y, w, h, r, lid });
const pair = (dx: number, y: number, w: number, h: number, r: number, lid = 0): FaceParams => [eye(50 - dx, y, w, h, r, lid), eye(50 + dx, y, w, h, r, lid)];

/** Rest expressions (user-selectable). Eyes lean backslash-style, ~26° off vertical. */
export const AVATAR_EXPRESSIONS: Record<AvatarExpression, { label: string; face: FaceParams }> = {
  calm: { label: "Calm", face: pair(12, 47, 10, 26, -26) },
  curious: { label: "Curious", face: [eye(38, 45.5, 9.5, 20, -31), eye(62, 47, 10.5, 28, -22)] },
  focused: { label: "Focused", face: pair(12, 48, 9, 17, -26) },
  bright: { label: "Bright", face: pair(12.5, 47, 11, 29, -24) },
  unsure: { label: "Unsure", face: [eye(38, 49.5, 10, 15, -10), eye(62, 46.5, 10, 25, -34)] },
  alert: { label: "Alert", face: pair(13, 47, 12, 30, -14) },
  pleased: { label: "Pleased", face: pair(13, 46, 14, 16, -12, 1) },
};

/** Faces the agent wears for non-idle states (idle uses the user's rest expression). */
export const STATE_FACES: Partial<Record<AgentState, FaceParams>> = {
  listening: pair(13, 46, 12.5, 31, -20),
  thinking: pair(12, 46, 10, 20, -26),
  working: pair(12, 48.5, 9, 15, -26),
  speaking: pair(12.5, 47, 9.5, 19, -28),
  waiting: AVATAR_EXPRESSIONS.bright.face,
  blocked: pair(12.5, 49, 12, 7, -6),
  done: AVATAR_EXPRESSIONS.pleased.face,
};

/** Where the eyes rest for each state (gaze offset in viewBox units). */
export const REST_GAZE: Record<AgentState, [number, number]> = {
  idle: [0, 0],
  listening: [0, 0],
  thinking: [3, -4.2],
  speaking: [0, 0],
  working: [0, 1.6],
  waiting: [0, 3],
  blocked: [-1.5, 2.6],
  done: [0, -2.2],
};

export const AGENT_STATE_META: Record<AgentState, { label: string; short: string }> = {
  idle: { label: "Ready", short: "Ask Leo" },
  listening: { label: "Listening", short: "Listening" },
  thinking: { label: "Thinking", short: "Leo is thinking…" },
  speaking: { label: "Speaking", short: "Leo is speaking…" },
  working: { label: "Working in your workspace", short: "Working…" },
  waiting: { label: "Waiting for your answer", short: "Your turn" },
  blocked: { label: "Needs attention", short: "Leo needs attention" },
  done: { label: "Reply ready", short: "Leo replied" },
};

export const DEFAULT_AVATAR: AvatarLook = { shape: "orb", color: "graphite", expression: "calm" };

export function faceFor(look: AvatarLook, state: AgentState): FaceParams {
  return STATE_FACES[state] ?? AVATAR_EXPRESSIONS[look.expression].face;
}

const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const lerpEye = (a: EyeParams, b: EyeParams, k: number): EyeParams => ({
  x: lerp(a.x, b.x, k),
  y: lerp(a.y, b.y, k),
  w: lerp(a.w, b.w, k),
  h: lerp(a.h, b.h, k),
  r: lerp(a.r, b.r, k),
  lid: lerp(a.lid, b.lid, k),
});
export const lerpFace = (a: FaceParams, b: FaceParams, k: number): FaceParams => [lerpEye(a[0], b[0], k), lerpEye(a[1], b[1], k)];

const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** Quick exponential move to a new target every `period` seconds, then hold (like real eye saccades). */
function saccade(t: number, period: number, rest: [number, number], target: (k: number) => [number, number]): [number, number] {
  const k = Math.floor(t / period);
  const prev = k <= 0 ? rest : target(k - 1);
  const cur = k < 0 ? rest : target(k);
  const e = 1 - Math.exp(-(t - k * period) / 0.07);
  return [lerp(prev[0], cur[0], e), lerp(prev[1], cur[1], e)];
}

export function gazeFor(state: AgentState, t: number, seed = 0): [number, number] {
  const rest = REST_GAZE[state];
  switch (state) {
    case "thinking":
      return saccade(t, 1.25, rest, (k) => (k === 0 ? rest : k % 2 ? [-3.6, -4.2] : [3.6, -4.6]));
    case "working":
      return saccade(t, 0.42, rest, (k) => (k === 0 ? rest : k % 2 ? [-4.2, 1.6] : [4.2, 1.6]));
    case "waiting":
      return saccade(t + seed, 2.2, rest, (k) => (k === 0 ? rest : [(rnd(k + seed) * 2 - 1) * 1.3, 3 + (rnd(k + seed + 9) * 2 - 1) * 0.7]));
    case "idle":
      return saccade(t + seed * 0.37, 2.6, rest, (k) =>
        k === 0 || rnd(k + seed) < 0.35 ? rest : [(rnd(k + seed + 3) * 2 - 1) * 3.6, (rnd(k + seed + 7) * 2 - 1) * 2.4]
      );
    default:
      return rest;
  }
}

/** 1 = open, ~0.08 = closed. One quick blink per window at a pseudo-random moment. */
export function opennessFor(state: AgentState, t: number, seed = 0) {
  if (state === "speaking") return t === 0 ? 1 : 0.86 + 0.12 * Math.abs(Math.sin(t * 7 + seed));
  const every = state === "idle" ? 3.8 : state === "waiting" ? 2.6 : state === "thinking" ? 4.8 : state === "blocked" ? 4.4 : 0;
  if (!every || t < 0.5) return 1;
  const tt = t + seed * 0.13;
  const k = Math.floor(tt / every);
  const at = k * every + 0.3 + rnd(k * 3.1 + seed) * (every - 0.6);
  const d = tt - at;
  if (d < 0 || d > 0.17) return 1;
  return 1 - Math.sin((d / 0.17) * Math.PI) * 0.92;
}

export function isAvatarShape(v: unknown): v is AvatarShape {
  return typeof v === "string" && v in AVATAR_SHAPES;
}
export function isAvatarColor(v: unknown): v is AvatarColor {
  return typeof v === "string" && v in AVATAR_COLORS;
}
export function isAvatarExpression(v: unknown): v is AvatarExpression {
  return typeof v === "string" && v in AVATAR_EXPRESSIONS;
}

export function normalizeAvatarLook(value: unknown, fallback = DEFAULT_AVATAR): AvatarLook {
  const v = (value ?? {}) as Partial<AvatarLook>;
  return {
    shape: isAvatarShape(v.shape) ? v.shape : fallback.shape,
    color: isAvatarColor(v.color) ? v.color : fallback.color,
    expression: isAvatarExpression(v.expression) ? v.expression : fallback.expression,
  };
}
