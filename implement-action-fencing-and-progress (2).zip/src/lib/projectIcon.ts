import type { Project, ProjectIcon } from "./db";

/** A sensible default emoji for common tags, so a project never shows a bare letter. */
const TAG_EMOJI: Record<string, string> = {
  language: "🗣️",
  languages: "🗣️",
  math: "📐",
  maths: "📐",
  mathematics: "📐",
  code: "💻",
  coding: "💻",
  programming: "💻",
  science: "🔬",
  physics: "⚛️",
  chemistry: "🧪",
  biology: "🧬",
  music: "🎵",
  history: "🏛️",
  design: "🎨",
  art: "🎨",
  exam: "📝",
  exams: "📝",
  medicine: "🩺",
  law: "⚖️",
  finance: "📈",
  business: "💼",
  writing: "✍️",
  philosophy: "🦉",
  geography: "🌍",
};

/** Curated, study-flavoured picks (8 per row in the picker). */
export const EMOJI_CHOICES = [
  "📚", "📘", "📝", "✏️", "🧠", "💡", "🎓", "🎯",
  "📐", "🧮", "📊", "📈", "🔬", "🧪", "🧬", "🔭",
  "⚛️", "💻", "🤖", "⚙️", "🐍", "🦀", "🌍", "🗺️",
  "🏛️", "🗣️", "✍️", "🦉", "🎨", "🎵", "🎸", "🎹",
  "🎬", "📷", "🩺", "⚖️", "💼", "🌱", "🧘", "🏃",
  "🍳", "♟️", "🧩", "🚀", "⭐", "🔥", "🌙", "☕",
];

export function defaultEmojiFor(tag?: string) {
  return TAG_EMOJI[(tag ?? "").trim().toLowerCase()] ?? "📚";
}

/** The icon to show for a project: its chosen emoji/image, else an emoji derived from its tag. */
export function iconOf(p: Pick<Project, "icon" | "tag">): ProjectIcon {
  const i = p.icon;
  if (i?.kind === "image" && i.src) return i;
  if (i?.kind === "emoji" && i.emoji) return i;
  return { kind: "emoji", emoji: defaultEmojiFor(p.tag) };
}

type SegmenterCtor = new (locale?: string, options?: { granularity: "grapheme" }) => { segment(input: string): Iterable<{ segment: string }> };

/** Split into user-perceived characters (keeps ZWJ sequences, flags and skin tones whole). */
export function graphemes(s: string): string[] {
  const Seg = (Intl as unknown as { Segmenter?: SegmenterCtor }).Segmenter;
  if (Seg) return Array.from(new Seg(undefined, { granularity: "grapheme" }).segment(s), (x) => x.segment);
  return Array.from(s);
}

const EMOJI_RE = /\p{Extended_Pictographic}|\p{Regional_Indicator}/u;

/** From typed/pasted text, the first emoji (or, failing that, the first visible character). */
export function pickIconChar(s: string) {
  const parts = graphemes(s.trim()).filter((g) => g.trim());
  return parts.find((g) => EMOJI_RE.test(g)) ?? parts[0] ?? "";
}

let probe: CanvasRenderingContext2D | null | undefined;
const supported = new Map<string, boolean>();

/**
 * Some devices (and stripped-down Linux images) have no emoji font, where an emoji renders as an
 * empty "tofu" box. Detect that once per character so a project badge can fall back to its initial.
 */
export function emojiRenders(char: string): boolean {
  if (!char) return false;
  const cached = supported.get(char);
  if (cached !== undefined) return cached;
  if (typeof document === "undefined") return true;
  if (probe === undefined) {
    try {
      const c = document.createElement("canvas");
      c.width = 24;
      c.height = 24;
      probe = c.getContext("2d", { willReadFrequently: true });
      if (probe) probe.font = '20px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
    } catch {
      probe = null;
    }
  }
  if (!probe) return true;
  const ink = (text: string) => {
    probe!.clearRect(0, 0, 24, 24);
    probe!.fillText(text, 1, 20);
    const data = probe!.getImageData(0, 0, 24, 24).data;
    let filled = 0;
    for (let i = 3; i < data.length; i += 4) if (data[i] > 8) filled++;
    return filled;
  };
  // A missing glyph draws the same hollow box as U+FFFF; a real emoji differs from it.
  const tofu = ink("\uFFFF");
  const drawn = ink(char);
  const ok = drawn > 12 && Math.abs(drawn - tofu) > 6;
  supported.set(char, ok);
  return ok;
}
