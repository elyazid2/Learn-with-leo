/**
 * Human label for a model ID: family + version (+ tier/size), then "brain" — e.g. "Opus 5.5 brain".
 * The version always comes from the ID itself, never from a lookup table, so new models just work.
 */
const BRAND: Record<string, string> = { gpt: "GPT", deepseek: "DeepSeek", llama: "Llama", openai: "OpenAI", glm: "GLM", qwq: "QwQ", phi: "Phi" };
const NOISE = new Set(["latest", "preview", "instruct", "chat", "it", "exp", "experimental", "hf", "gguf", "fp16", "fp8", "bf16", "turbo-preview", "online", "free", "thinking-preview"]);

const cap = (s: string) => BRAND[s.toLowerCase()] ?? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();

/** Strip provider prefixes, dates, and release-channel noise from an ID. */
function clean(id: string) {
  let s = id.trim().toLowerCase().split("/").pop() ?? id;
  s = s.replace(/^models[-_]/, "");
  s = s.replace(/[-_]\d{4}-\d{2}-\d{2}$/, "").replace(/[-_]\d{8}$/, "").replace(/@.*$/, "");
  return s;
}

const words = (s: string) =>
  s.split(/[-_ ]+/).filter((w) => w && !NOISE.has(w) && !/^\d{4}$/.test(w) && !/^\d{6,}$/.test(w)).map(cap).join(" ");

export function modelLabel(id: string): string {
  if (!id?.trim()) return "Choose model";
  const s = clean(id);
  let m: RegExpExecArray | null;

  // Claude: both "claude-opus-4-5" and the older "claude-3-5-sonnet" orderings.
  if ((m = /claude[-_](opus|sonnet|haiku)[-_](\d+)(?:[-_.](\d{1,2}))?(?!\d)/.exec(s))) return `${cap(m[1])} ${m[2]}${m[3] ? "." + m[3] : ""} brain`;
  if ((m = /claude[-_](\d+)(?:[-_.](\d{1,2}))?[-_](opus|sonnet|haiku)/.exec(s))) return `${cap(m[3])} ${m[1]}${m[2] ? "." + m[2] : ""} brain`;
  if ((m = /claude[-_](opus|sonnet|haiku)/.exec(s))) return `${cap(m[1])} brain`;
  if (/^claude/.test(s)) return `${words(s)} brain`;

  // OpenAI o-series: o3, o4-mini, o1-pro
  if ((m = /^o(\d+)(?:[-_](mini|pro|high|low))?/.exec(s))) return `O${m[1]}${m[2] ? " " + cap(m[2]) : ""} brain`;

  // GPT: gpt-4o, gpt-4.1-mini, gpt-5.1-codex, gpt-oss-120b
  if ((m = /^gpt[-_ ]?(\d+(?:\.\d+)?)(o)?(?:[-_](.+))?$/.exec(s))) return `GPT-${m[1]}${m[2] ?? ""}${m[3] ? " " + words(m[3]) : ""} brain`;
  if ((m = /^gpt[-_]oss[-_]?(\d+b)?/.exec(s))) return `GPT-OSS${m[1] ? " " + m[1].toUpperCase() : ""} brain`;

  // Gemini: gemini-2.5-flash-lite, gemini-3-pro-preview
  if ((m = /^gemini[-_ ]?(\d+(?:\.\d+)?)(?:[-_](.+))?$/.exec(s))) return `Gemini ${m[1]}${m[2] && words(m[2]) ? " " + words(m[2]) : ""} brain`;
  if ((m = /^gemini[-_](pro|flash|ultra|nano)(?:[-_](.+))?$/.exec(s))) return `Gemini ${words(m[1] + (m[2] ? "-" + m[2] : ""))} brain`;

  // Generic: "qwen2.5-coder:7b", "llama3.1:8b", "kimi-k2-0905", "mistral-large-latest", "grok-4"
  const spaced = s
    .replace(/:/g, "-")
    .replace(/^([a-z]+)(\d[\d.]*)/, "$1-$2") // qwen2.5 → qwen-2.5
    .replace(/(^|-)([a-z])(\d)/g, "$1$2$3");
  const label = spaced
    .split(/[-_ ]+/)
    .filter((w) => w && !NOISE.has(w) && !/^\d{4}$/.test(w) && !/^\d{6,}$/.test(w))
    .map((w) => (/^\d+(\.\d+)?b$/.test(w) ? w.toUpperCase() : /^[a-z]\d/.test(w) ? w.toUpperCase() : cap(w)))
    .join(" ");
  return `${label || cap(s)} brain`;
}

export const enabledModels = (p: { models?: string[] }) => p.models ?? [];

/** The model actually in use must always be one the learner enabled for that provider. */
export function resolveEnabled(
  provider: { id: string; models: string[]; defaultModel: string },
  requested?: string
): string {
  const enabled = enabledModels(provider);
  if (requested && enabled.includes(requested)) return requested;
  if (enabled.includes(provider.defaultModel)) return provider.defaultModel;
  return enabled[0] ?? "";
}
