import { db, type Message, type Thread, type TurnMeta } from "./db";
import { parseSegments } from "./ai/actions";

/**
 * Chat logs export: exactly what the model saw and did — visible and hidden messages,
 * raw content (action blocks included), the parsed segments, per-turn provider/stream details,
 * apiContent, action results, answers and context tags. Images and audio are replaced with a
 * placeholder, and provider settings/API keys never appear.
 */

const IMAGE_PLACEHOLDER = "[image omitted]";
const AUDIO_PLACEHOLDER = "[audio omitted]";

/** Defensive: strip any inline base64 data URL that made it into a text field. */
function scrub(text: string) {
  return text.replace(/data:[a-z0-9.+-]+\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]+/gi, "[base64 data omitted]");
}

/** One parsed piece of a message, so the log shows what the harness made of the reply. */
export interface ChatLogSegment {
  kind: "text" | "action" | "invalid" | "pending";
  /** Action type, when the segment is an action. */
  type?: string;
  /** Characters of text, when the segment is text. */
  chars?: number;
  /** Why an invalid segment was skipped. */
  reason?: string;
}

/** Per-turn details as logged on the message. The system prompt is reported once per thread. */
export interface ChatLogTurn extends Omit<TurnMeta, "systemPrompt"> {}

export interface ChatLogMessage {
  role: Message["role"];
  createdAt: number;
  hidden: boolean;
  error: boolean;
  partial: boolean;
  content: string;
  apiContent?: string;
  segments?: ChatLogSegment[];
  turn?: ChatLogTurn;
  actionResults?: Message["actionResults"];
  answers?: Message["answers"];
  context?: Message["context"];
  images?: string[];
  audios?: string[];
}

export interface ChatLogThread {
  id: string;
  title: string;
  mode: Thread["mode"];
  providerId?: string;
  model?: string;
  /** The system prompt sent on the thread's last turn. */
  systemPrompt?: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatLogMessage[];
}

/** Counts at the top of the file, so a log can be read without opening every thread. */
export interface ChatLogSummary {
  threads: number;
  messages: number;
  /** Assistant turns with logged details. */
  turns: number;
  /** Turns the provider ended with finish reason "length" (output limit reached). */
  finishReasonLength: number;
  /** Every finish reason the providers reported, with counts. */
  finishReasons: Record<string, number>;
  /** Messages containing at least one invalid (skipped) action segment. */
  messagesWithInvalidSegments: number;
  /** Invalid segment reasons, most common first. */
  invalidReasons: { count: number; reason: string }[];
}

export interface ChatLogsFile {
  app: "harness";
  kind: "chat-logs";
  exportedAt: number;
  scope: "last" | "all";
  summary: ChatLogSummary;
  threads: ChatLogThread[];
}

/** parseSegments() → the compact form the log carries. `streaming` is false for saved messages. */
function segmentLog(m: Message): ChatLogSegment[] | undefined {
  const segs = parseSegments(m.content);
  if (segs.length <= 1 && segs[0]?.kind === "text") return undefined;
  return segs.map((s) => {
    if (s.kind === "text") return { kind: "text" as const, chars: s.text.length };
    if (s.kind === "action") return { kind: "action" as const, type: s.action.type };
    if (s.kind === "invalid") return { kind: "invalid" as const, reason: s.reason };
    return { kind: "pending" as const };
  });
}

function messageLog(m: Message): ChatLogMessage {
  const segments = segmentLog(m);
  const { systemPrompt: _systemPrompt, ...turn } = m.turn ?? {};
  return {
    role: m.role,
    createdAt: m.createdAt,
    hidden: !!m.hidden,
    error: !!m.error,
    partial: !!m.partial,
    content: scrub(m.content),
    ...(m.apiContent !== undefined ? { apiContent: scrub(m.apiContent) } : {}),
    ...(segments ? { segments } : {}),
    ...(m.turn ? { turn } : {}),
    ...(m.actionResults ? { actionResults: m.actionResults } : {}),
    ...(m.answers ? { answers: m.answers } : {}),
    ...(m.context ? { context: m.context } : {}),
    ...(m.images?.length ? { images: m.images.map(() => IMAGE_PLACEHOLDER) } : {}),
    ...(m.audios?.length ? { audios: m.audios.map(() => AUDIO_PLACEHOLDER) } : {}),
  };
}

/** "last" is the most recently updated conversation; "all" is every thread, newest first. */
export async function buildChatLogs(scope: "last" | "all"): Promise<ChatLogsFile> {
  const threads = await db.threads.orderBy("updatedAt").toArray();
  const chosen = scope === "last" ? threads.slice(-1) : threads.slice().reverse();
  const finishReasons: Record<string, number> = {};
  const invalidReasons = new Map<string, number>();
  let messageCount = 0;
  let turnCount = 0;
  let finishReasonLength = 0;
  let messagesWithInvalidSegments = 0;
  const out: ChatLogThread[] = [];
  for (const t of chosen) {
    const messages = await db.messages.where("threadId").equals(t.id).sortBy("createdAt");
    messageCount += messages.length;
    let systemPrompt: string | undefined;
    for (const m of messages) {
      if (m.turn?.systemPrompt) systemPrompt = m.turn.systemPrompt;
      if (m.turn) {
        turnCount++;
        const reason = m.turn.finishReason;
        if (reason) {
          finishReasons[reason] = (finishReasons[reason] ?? 0) + 1;
          if (reason.toLowerCase() === "length") finishReasonLength++;
        }
      }
      const segs = segmentLog(m) ?? [];
      const reasons = segs.filter((s) => s.kind === "invalid" && s.reason) as { reason: string }[];
      if (reasons.length) {
        messagesWithInvalidSegments++;
        for (const r of reasons) invalidReasons.set(r.reason, (invalidReasons.get(r.reason) ?? 0) + 1);
      }
    }
    out.push({
      id: t.id,
      title: t.title,
      mode: t.mode,
      providerId: t.providerId,
      model: t.model,
      ...(systemPrompt !== undefined ? { systemPrompt: scrub(systemPrompt) } : {}),
      createdAt: t.createdAt,
      updatedAt: t.updatedAt,
      messages: messages.map(messageLog),
    });
  }
  return {
    app: "harness",
    kind: "chat-logs",
    exportedAt: Date.now(),
    scope,
    summary: {
      threads: out.length,
      messages: messageCount,
      turns: turnCount,
      finishReasonLength,
      finishReasons,
      messagesWithInvalidSegments,
      invalidReasons: [...invalidReasons]
        .map(([reason, count]) => ({ count, reason }))
        .sort((a, b) => b.count - a.count || a.reason.localeCompare(b.reason)),
    },
    threads: out,
  };
}

export const chatLogsFilename = () => `harness-chat-logs-${new Date().toISOString().slice(0, 10)}.json`;
