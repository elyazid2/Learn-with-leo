import { db, uid, type Chunk, type LibFile, type Note } from "./db";

const CHUNK_CHARS = 900;
const OVERLAP = 120;

/** Split text into overlapping chunks on sentence-ish boundaries. */
export function chunkText(text: string): string[] {
  const clean = text.replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
  if (!clean) return [];
  if (clean.length <= CHUNK_CHARS) return [clean];
  const out: string[] = [];
  let i = 0;
  while (i < clean.length) {
    let end = Math.min(clean.length, i + CHUNK_CHARS);
    if (end < clean.length) {
      const window = clean.slice(i + CHUNK_CHARS * 0.6, end);
      const cut = Math.max(window.lastIndexOf(". "), window.lastIndexOf("\n"), window.lastIndexOf("? "), window.lastIndexOf("! "));
      if (cut > 0) end = i + Math.floor(CHUNK_CHARS * 0.6) + cut + 1;
    }
    out.push(clean.slice(i, end).trim());
    if (end >= clean.length) break;
    i = Math.max(end - OVERLAP, i + 1);
  }
  return out.filter(Boolean);
}

const STOP = new Set(
  "a an the and or but if then else of to in on at by for with from as is are was were be been being it its this that these those i you he she we they me him her us them my your our their what which who whom how when where why not no yes do does did done have has had having can could should would will shall may might must so than too very just about into over under again further once here there all any both each few more most other some such only own same s t don now".split(" ")
);

export function tokenize(text: string): string[] {
  return (text.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu) ?? [])
    .map((t) => t.replace(/^['’-]+|['’-]+$/g, ""))
    .filter((t) => t.length > 1 && !STOP.has(t));
}

export interface Hit {
  chunk: Chunk;
  score: number;
}

/** BM25 over the project's chunks. Small corpora (a few thousand chunks) score in-memory fast enough. */
export function rankChunks(query: string, chunks: Chunk[], limit = 6): Hit[] {
  const q = Array.from(new Set(tokenize(query)));
  if (!q.length || !chunks.length) return [];
  const docs = chunks.map((c) => tokenize(c.text));
  const avg = docs.reduce((s, d) => s + d.length, 0) / docs.length || 1;
  const df = new Map<string, number>();
  for (const d of docs) for (const t of new Set(d)) df.set(t, (df.get(t) ?? 0) + 1);
  const N = docs.length;
  const k1 = 1.4;
  const b = 0.75;
  const hits: Hit[] = [];
  docs.forEach((d, i) => {
    if (!d.length) return;
    const tf = new Map<string, number>();
    for (const t of d) tf.set(t, (tf.get(t) ?? 0) + 1);
    let score = 0;
    for (const t of q) {
      const f = tf.get(t);
      if (!f) continue;
      const n = df.get(t) ?? 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      score += idf * ((f * (k1 + 1)) / (f + k1 * (1 - b + (b * d.length) / avg)));
    }
    if (score > 0) hits.push({ chunk: chunks[i], score });
  });
  return hits.sort((a, b2) => b2.score - a.score).slice(0, limit);
}

export async function retrieve(projectId: string, query: string, limit = 6): Promise<Hit[]> {
  const chunks = await db.chunks.where("projectId").equals(projectId).toArray();
  return rankChunks(query, chunks, limit);
}

export function citation(c: Chunk) {
  return c.sourceKind === "file" && c.page > 0 ? `${c.sourceName}, p.${c.page}` : c.sourceName;
}

/** Format hits for the model with explicit, citable labels. */
export function formatSources(hits: Hit[]) {
  return hits
    .map((h, i) => `[S${i + 1}] (${citation(h.chunk)})\n${h.chunk.text.slice(0, 1200)}`)
    .join("\n\n");
}

async function replaceChunks(projectId: string, sourceId: string, rows: Omit<Chunk, "id" | "projectId" | "sourceId">[]) {
  await db.transaction("rw", db.chunks, async () => {
    await db.chunks.where("sourceId").equals(sourceId).delete();
    if (rows.length) await db.chunks.bulkAdd(rows.map((r) => ({ ...r, id: uid(), projectId, sourceId })));
  });
}

export async function indexNote(note: Note) {
  const rows = chunkText(note.content).map((text) => ({
    sourceKind: "note" as const,
    sourceName: `note “${note.title || "Untitled"}”`,
    page: 0,
    text,
  }));
  await replaceChunks(note.projectId, note.id, rows);
}

export async function removeChunks(sourceId: string) {
  await db.chunks.where("sourceId").equals(sourceId).delete();
}

let indexing = false;
const queue: string[] = [];

/** Extract text from a PDF page by page and store chunks. Runs one file at a time in the background. */
export function queueIndex(fileId: string) {
  if (!queue.includes(fileId)) queue.push(fileId);
  if (!indexing) void drain();
}

async function drain() {
  indexing = true;
  try {
    while (queue.length) {
      const id = queue.shift()!;
      const file = await db.files.get(id);
      if (!file) continue;
      try {
        await indexFile(file);
      } catch (e) {
        console.warn("index failed", file.name, e);
        await db.files.update(id, { indexed: "failed" });
      }
    }
  } finally {
    indexing = false;
  }
}

async function indexFile(file: LibFile) {
  if (file.kind === "text") {
    const text = await file.blob.text();
    const rows = chunkText(text).map((t) => ({ sourceKind: "file" as const, sourceName: file.name, page: 0, text: t }));
    await replaceChunks(file.projectId, file.id, rows);
    await db.files.update(file.id, { indexed: rows.length ? "done" : "none" });
    return;
  }
  if (file.kind !== "pdf") {
    await db.files.update(file.id, { indexed: "none" });
    return;
  }
  const { openPdf, closePdf, isPdfReaderActive, waitForReaderIdle } = await import("./media");
  await waitForReaderIdle();
  let doc = await openPdf(file.blob);
  const numPages = doc.numPages;
  const rows: Omit<Chunk, "id" | "projectId" | "sourceId">[] = [];
  try {
    for (let p = 1; p <= numPages; p++) {
      if (isPdfReaderActive()) {
        // Someone opened the reader: release this copy, wait, then continue where we left off.
        closePdf(doc);
        await waitForReaderIdle();
        doc = await openPdf(file.blob);
      }
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const text = tc.items
        .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
        .join("")
        .trim();
      page.cleanup();
      for (const t of chunkText(text)) rows.push({ sourceKind: "file", sourceName: file.name, page: p, text: t });
      if (rows.length > 20000) break; // hard cap: ~18 MB of text
    }
  } finally {
    closePdf(doc);
  }
  await replaceChunks(file.projectId, file.id, rows);
  await db.files.update(file.id, { indexed: rows.length ? "done" : "none", pages: numPages });
}

/** Re-index anything left pending (e.g. after the v2 migration or an interrupted session). */
export async function resumeIndexing() {
  const pending = await db.files.where("projectId").notEqual("").filter((f) => f.indexed === "pending").primaryKeys();
  for (const id of pending) queueIndex(id as string);
}
