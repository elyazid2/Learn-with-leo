import { db, uid, type Note } from "./db";

/*
 * Obsidian-style note helpers: [[wikilinks]], #tags, folders, backlinks and link-safe renames.
 * Everything here is pure except the DB helpers at the bottom.
 */

const CODE_SPLIT = /(```[\s\S]*?```|`[^`\n]*`)/;

/** Apply `fn` to prose only; fenced and inline code pass through untouched. */
export function mapProse(src: string, fn: (prose: string) => string): string {
  return src
    .split(CODE_SPLIT)
    .map((part, i) => (i % 2 === 1 ? part : fn(part)))
    .join("");
}

/** Groups: 1 "!" (embed), 2 target, 3 "#heading" (optional), 4 "|alias" (optional). */
export const WIKI_RE = /(!?)\[\[([^\]\n|#]+)(#[^\]\n|]*)?(\|[^\]\n]*)?\]\]/g;
/** Groups: 1 leading separator, 2 tag name. A tag needs a letter right after "#", so headings never match. */
const TAG_RE = /(^|[\s(])#([\w\u00C0-\uFFFF][\w\u00C0-\uFFFF\/-]*)/gm;

export const pathOf = (n: Pick<Note, "title" | "folder">) => (n.folder ? `${n.folder}/${n.title}` : n.title);
export const parentOf = (folder: string) => (folder.includes("/") ? folder.slice(0, folder.lastIndexOf("/")) : "");
export const leafOf = (folder: string) => folder.slice(folder.lastIndexOf("/") + 1);

/** Titles are file names: no path separators or characters that would break [[links]]. Keeps trailing spaces while typing. */
export const softTitle = (raw: string) => raw.replace(/[\\\/:*?"<>|#^[\]\r\n]/g, "-").slice(0, 120);
export const cleanTitle = (raw: string) => softTitle(raw).replace(/\s+/g, " ").trim();
export const cleanFolder = (raw: string) => raw.split("/").map(cleanTitle).filter(Boolean).join("/");

export function extractLinks(content: string): string[] {
  const out: string[] = [];
  mapProse(content, (s) => {
    for (const m of s.matchAll(WIKI_RE)) out.push(m[2].trim());
    return s;
  });
  return out;
}

export function extractTags(content: string): string[] {
  const tags = new Set<string>();
  mapProse(content, (s) => {
    for (const m of s.matchAll(TAG_RE)) tags.add(m[2].toLowerCase());
    return s;
  });
  return [...tags];
}

/** Resolve a link target: exact "folder/title" first, then plain title (case-insensitive). */
export function resolveLink(target: string, notes: Note[]): Note | undefined {
  const t = target.trim().toLowerCase();
  if (!t) return undefined;
  return (
    notes.find((n) => pathOf(n).toLowerCase() === t) ??
    notes.find((n) => n.title.toLowerCase() === t) ??
    notes.find((n) => n.title.toLowerCase() === leafOf(t))
  );
}

export interface Backlink {
  note: Note;
  line: string;
}

export function backlinksOf(target: Note, notes: Note[]): Backlink[] {
  const out: Backlink[] = [];
  for (const n of notes) {
    if (n.id === target.id) continue;
    for (const line of n.content.split("\n")) {
      if (extractLinks(line).some((t) => resolveLink(t, notes)?.id === target.id)) {
        out.push({ note: n, line: line.trim().slice(0, 240) });
        break;
      }
    }
  }
  return out;
}

export function tagCounts(notes: Note[]): [string, number][] {
  const m = new Map<string, number>();
  for (const n of notes) for (const t of extractTags(n.content)) m.set(t, (m.get(t) ?? 0) + 1);
  return [...m].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
}

/** Every folder path, including ancestors of folders that only exist implicitly through their notes. */
export function allFolders(notes: Note[], folders: { path: string }[]): string[] {
  const set = new Set<string>();
  const add = (path: string) => {
    const parts = path.split("/").filter(Boolean);
    for (let i = 1; i <= parts.length; i++) set.add(parts.slice(0, i).join("/"));
  };
  for (const f of folders) add(f.path);
  for (const n of notes) if (n.folder) add(n.folder);
  return [...set].sort((a, b) => a.localeCompare(b));
}

/** Quick-switcher ranking: exact > prefix > substring in title > path > body text. */
export function rankNotes(notes: Note[], query: string, limit = 12): Note[] {
  const q = query.trim().toLowerCase();
  if (!q) return [...notes].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, limit);
  const score = (n: Note) => {
    const t = n.title.toLowerCase();
    if (t === q) return 0;
    if (t.startsWith(q)) return 1;
    if (t.includes(q)) return 2;
    if (pathOf(n).toLowerCase().includes(q)) return 3;
    if (n.content.toLowerCase().includes(q)) return 4;
    return 99;
  };
  return notes
    .map((n) => ({ n, s: score(n) }))
    .filter((x) => x.s < 99)
    .sort((a, b) => a.s - b.s || a.n.title.localeCompare(b.n.title))
    .slice(0, limit)
    .map((x) => x.n);
}

/** Turn [[links]] into clickable markdown links and #tags into tag links. Used for rendering only. */
export function renderableMarkdown(src: string): string {
  return mapProse(src, (s) =>
    s
      .replace(WIKI_RE, (_m, _bang: string, target: string, _h: string | undefined, alias: string | undefined) => {
        const t = target.trim();
        const label = (alias ? alias.slice(1) : t).replace(/[[\]]/g, "").trim() || t;
        return `[${label}](wikilink:${encodeURIComponent(t)})`;
      })
      .replace(TAG_RE, (_m, pre: string, tag: string) => `${pre}[#${tag}](tag:${encodeURIComponent(tag.toLowerCase())})`)
  );
}

/* ------------------------------------------------------------------ DB helpers */

export async function uniqueTitle(projectId: string, folder: string, base: string, exceptId?: string) {
  const all = await db.notes.where("projectId").equals(projectId).toArray();
  const taken = new Set(all.filter((n) => (n.folder ?? "") === folder && n.id !== exceptId).map((n) => n.title.toLowerCase()));
  let title = base;
  let i = 2;
  while (taken.has(title.toLowerCase())) title = `${base} ${i++}`;
  return title;
}

export async function createNote(projectId: string, opts: { folder?: string; title?: string; content?: string } = {}) {
  const folder = cleanFolder(opts.folder ?? "");
  const title = await uniqueTitle(projectId, folder, cleanTitle(opts.title ?? "") || "Untitled");
  const now = Date.now();
  const id = uid();
  await db.transaction("rw", db.notes, db.projects, async () => {
    await db.notes.add({ id, projectId, title, content: opts.content ?? "", folder, createdAt: now, updatedAt: now });
    await db.projects.update(projectId, { updatedAt: now });
  });
  return id;
}

export async function createFolder(projectId: string, raw: string) {
  const path = cleanFolder(raw);
  if (!path) return "";
  const existing = await db.folders.where("projectId").equals(projectId).toArray();
  if (!existing.some((f) => f.path === path)) await db.folders.add({ id: uid(), projectId, path, createdAt: Date.now() });
  return path;
}

/** Rename the file (title). Links in other notes that point at it are rewritten so nothing breaks. */
export async function renameNote(notes: Note[], note: Note, raw: string): Promise<string> {
  const next = cleanTitle(raw) || "Untitled";
  if (next === note.title) return note.title;
  const title = await uniqueTitle(note.projectId, note.folder ?? "", next, note.id);
  const now = Date.now();
  await db.transaction("rw", db.notes, async () => {
    await db.notes.update(note.id, { title, updatedAt: now });
    for (const other of notes) {
      if (other.id === note.id || !other.content.includes("[[")) continue;
      const content = rewriteLinks(other.content, notes, note, title);
      if (content !== other.content) await db.notes.update(other.id, { content, updatedAt: now });
    }
  });
  return title;
}

function rewriteLinks(content: string, notes: Note[], target: Note, newTitle: string) {
  return mapProse(content, (s) =>
    s.replace(WIKI_RE, (m, bang: string, t: string, heading: string | undefined, alias: string | undefined) => {
      if (resolveLink(t, notes)?.id !== target.id) return m;
      const trimmed = t.trim();
      const slash = trimmed.lastIndexOf("/");
      const nextTarget = slash >= 0 ? `${trimmed.slice(0, slash + 1)}${newTitle}` : newTitle;
      return `${bang}[[${nextTarget}${heading ?? ""}${alias ?? ""}]]`;
    })
  );
}

export async function moveNote(note: Note, folderRaw: string) {
  const folder = cleanFolder(folderRaw);
  if (folder === (note.folder ?? "")) return;
  const title = await uniqueTitle(note.projectId, folder, note.title, note.id);
  await db.notes.update(note.id, { folder, title, updatedAt: Date.now() });
}

const isWithin = (path: string, root: string) => path === root || path.startsWith(root + "/");

/** Deleting a folder keeps its notes: they move up one level. */
export async function deleteFolder(projectId: string, path: string) {
  const parent = parentOf(path);
  await db.transaction("rw", db.notes, db.folders, async () => {
    const notes = await db.notes.where("projectId").equals(projectId).toArray();
    for (const n of notes) {
      if (!isWithin(n.folder ?? "", path)) continue;
      const title = await uniqueTitle(projectId, parent, n.title, n.id);
      await db.notes.update(n.id, { folder: parent, title, updatedAt: Date.now() });
    }
    const folders = await db.folders.where("projectId").equals(projectId).toArray();
    for (const f of folders) if (isWithin(f.path, path)) await db.folders.delete(f.id);
  });
}
