/**
 * Page reader for the learning browser.
 *
 * A PWA cannot script another origin's DOM, but it *can* fetch a page when that site sends
 * permissive CORS headers (Wikipedia, MDN, most docs sites do). We fetch, parse off-document with
 * DOMParser (no scripts ever execute), strip chrome, and return readable text + links. Sites that
 * block cross-origin reads fall back to the explicit Leo companion bookmarklet.
 */

export interface ReaderLink {
  href: string;
  text: string;
}

export type ReadResult =
  | { ok: true; url: string; title: string; text: string; links: ReaderLink[]; words: number }
  | { ok: false; url: string; reason: string };

const CHROME = [
  "script", "style", "noscript", "iframe", "svg", "canvas", "form", "nav", "footer", "header",
  "aside", "[role=navigation]", "[role=banner]", "[role=contentinfo]", "[aria-hidden=true]",
  ".sidebar", ".nav", ".menu", ".advert", ".ads", ".cookie", ".comments", "#comments",
].join(",");

const MAIN = ["article", "main", "[role=main]", "#content", ".content", "#mw-content-text", ".markdown-body"];

export function extractReadable(html: string, url: string): { title: string; text: string; links: ReaderLink[] } {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll(CHROME).forEach((el) => el.remove());

  let root: Element | null = null;
  for (const sel of MAIN) {
    const found = doc.querySelector(sel);
    if (found && (found.textContent ?? "").trim().length > 240) {
      root = found;
      break;
    }
  }
  root ??= doc.body;

  const links: ReaderLink[] = [];
  const seen = new Set<string>();
  root?.querySelectorAll("a[href]").forEach((a) => {
    const text = (a.textContent ?? "").replace(/\s+/g, " ").trim();
    if (text.length < 3 || text.length > 90) return;
    let href = "";
    try {
      const u = new URL(a.getAttribute("href") ?? "", url);
      if (!["http:", "https:"].includes(u.protocol)) return;
      u.hash = "";
      href = u.href;
    } catch {
      return;
    }
    if (seen.has(href) || href === url) return;
    seen.add(href);
    if (links.length < 24) links.push({ href, text });
  });

  // Block-level breaks keep paragraphs legible instead of one run-on string.
  root?.querySelectorAll("p,h1,h2,h3,h4,h5,li,blockquote,pre,tr,section,article,div").forEach((el) => el.append("\n\n"));
  root?.querySelectorAll("br").forEach((el) => el.replaceWith("\n"));

  const title = (doc.querySelector("title")?.textContent ?? doc.querySelector("h1")?.textContent ?? url)
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 300);

  const paragraphs = (root?.textContent ?? "")
    .replace(/[ \t\u00a0]+/g, " ")
    .split(/\n\s*\n/)
    .map((p) => p.replace(/\s*\n\s*/g, " ").trim())
    .filter(Boolean);

  // An article usually repeats its title as the first heading; don't show it twice.
  const bare = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  if (paragraphs.length && title && bare(paragraphs[0]) === bare(title)) paragraphs.shift();
  if (paragraphs.length && title && title.includes(paragraphs[0]) && paragraphs[0].length < 90) paragraphs.shift();

  return { title, text: paragraphs.join("\n\n").slice(0, 60000), links };
}

export async function readPage(url: string, signal?: AbortSignal): Promise<ReadResult> {
  let target: URL;
  try {
    target = new URL(url);
  } catch {
    return { ok: false, url, reason: "That isn't a valid web address." };
  }
  if (!["http:", "https:"].includes(target.protocol)) {
    return { ok: false, url, reason: "Only http and https pages can be read." };
  }

  const timeout = new AbortController();
  const timer = setTimeout(() => timeout.abort(), 12000);
  const onAbort = () => timeout.abort();
  signal?.addEventListener("abort", onAbort, { once: true });

  try {
    const res = await fetch(target.href, { signal: timeout.signal, mode: "cors", credentials: "omit", redirect: "follow" });
    if (!res.ok) return { ok: false, url: target.href, reason: `The site answered ${res.status}.` };
    const type = res.headers.get("content-type") ?? "";
    if (type && !/text\/html|application\/xhtml|text\/plain/i.test(type)) {
      return { ok: false, url: target.href, reason: "That address isn't a readable web page." };
    }
    const html = await res.text();
    const { title, text, links } = type.includes("text/plain")
      ? { title: target.hostname, text: html.slice(0, 60000), links: [] as ReaderLink[] }
      : extractReadable(html, target.href);
    if (text.trim().length < 80) {
      return { ok: false, url: target.href, reason: "This page builds its content with scripts, so there's nothing to read here." };
    }
    return { ok: true, url: target.href, title, text, links, words: text.split(/\s+/).filter(Boolean).length };
  } catch (e) {
    if (signal?.aborted) return { ok: false, url: target.href, reason: "Cancelled." };
    const name = (e as Error)?.name ?? "";
    return {
      ok: false,
      url: target.href,
      reason:
        name === "AbortError"
          ? "The site took too long to answer."
          : "This site doesn't allow other apps to read it. Open it in your browser and use the Leo companion.",
    };
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
  }
}
