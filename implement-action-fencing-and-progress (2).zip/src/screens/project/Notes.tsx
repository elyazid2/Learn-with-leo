import { useEffect, useMemo, useState, type ReactNode, type TouchEvent as RTouchEvent } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { BookOpen, Info, Menu, Network, Search, X } from "lucide-react";
import { db, type Note, type Project } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { confirmDeletion } from "@/lib/settings";
import { removeChunks } from "@/lib/retrieval";
import { createNote, leafOf, parentOf, resolveLink } from "@/lib/notes";
import NoteEditor, { useIsWide } from "@/components/notes/NoteEditor";
import { FileTree, InfoPanel } from "@/components/notes/NoteSidebar";
import { GraphOverlay, QuickSwitcher } from "@/components/notes/NoteOverlays";
import { cn } from "@/utils/cn";
import "@/components/notes/notes.css";

const tabsKey = (projectId: string) => `harness.notes.tabs.${projectId}`;

function readTabs(projectId: string): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(tabsKey(projectId)) || "[]");
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

/**
 * Obsidian-style notes workspace: collapsible file tree (a drawer on phones), tabs, a live
 * markdown editor with reading mode, backlinks / tags panel, quick switcher and graph view.
 */
export default function Notes({ project, noteId }: { project: Project; noteId?: string }) {
  const notesQ = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]);
  const foldersQ = useLiveQuery(() => db.folders.where("projectId").equals(project.id).toArray(), [project.id]);
  const list = useMemo(() => notesQ ?? [], [notesQ]);
  const folders = useMemo(() => foldersQ ?? [], [foldersQ]);
  const wide = useIsWide();

  const [tabs, setTabs] = useState<string[]>(() => readTabs(project.id));
  const [sideOpen, setSideOpen] = useState(true);
  const [infoOpen, setInfoOpen] = useState(false);
  const [drawer, setDrawer] = useState<"left" | "right" | null>(null);
  const [switcher, setSwitcher] = useState(false);
  const [graph, setGraph] = useState(false);
  const [folder, setFolder] = useState("");
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [swipe, setSwipe] = useState<{ x: number; y: number } | null>(null);

  const active = noteId ? list.find((n) => n.id === noteId) : undefined;

  useEffect(() => {
    if (noteId) setTabs((t) => (t.includes(noteId) ? t : [...t, noteId]));
  }, [noteId]);

  useEffect(() => {
    localStorage.setItem(tabsKey(project.id), JSON.stringify(tabs));
  }, [tabs, project.id]);

  // Forget tabs whose notes were deleted elsewhere.
  useEffect(() => {
    if (!notesQ) return;
    const ids = new Set(notesQ.map((n) => n.id));
    setTabs((t) => {
      const kept = t.filter((id) => ids.has(id));
      return kept.length === t.length ? t : kept;
    });
  }, [notesQ]);

  // Ctrl/⌘+O opens the quick switcher.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "o") {
        e.preventDefault();
        setSwitcher(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const open = (id: string) => {
    setDrawer(null);
    setSwitcher(false);
    setGraph(false);
    navigate(projectPath(project.id, "notes", id));
  };

  const newNote = async (inFolder: string) => {
    const id = await createNote(project.id, { folder: inFolder });
    open(id);
  };

  const openLink = async (target: string) => {
    const hit = resolveLink(target, list);
    if (hit) {
      open(hit.id);
      return;
    }
    // Like Obsidian: following a link to a note that does not exist creates it.
    const id = await createNote(project.id, { title: leafOf(target), folder: target.includes("/") ? parentOf(target) : "" });
    open(id);
  };

  const removeNote = async (n: Note) => {
    if (!confirmDeletion(`Delete "${n.title}"? This cannot be undone.`)) return;
    const rest = tabs.filter((t) => t !== n.id);
    setTabs(rest);
    if (n.id === noteId) navigate(rest.length ? projectPath(project.id, "notes", rest[rest.length - 1]) : projectPath(project.id));
    await db.notes.delete(n.id);
    await removeChunks(n.id);
  };

  const closeTab = (id: string) => {
    const idx = tabs.indexOf(id);
    const rest = tabs.filter((t) => t !== id);
    setTabs(rest);
    if (id === noteId) {
      const next = rest[idx] ?? rest[idx - 1];
      navigate(next ? projectPath(project.id, "notes", next) : projectPath(project.id));
    }
  };

  // Phones: swipe in from the left edge to open files, swipe back to close. Right edge opens links.
  const onTouchStart = (e: RTouchEvent<HTMLDivElement>) => {
    const t = e.touches[0];
    setSwipe(t ? { x: t.clientX, y: t.clientY } : null);
  };
  const onTouchEnd = (e: RTouchEvent<HTMLDivElement>) => {
    const s = swipe;
    setSwipe(null);
    const t = e.changedTouches[0];
    if (!s || !t || wide) return;
    const dx = t.clientX - s.x;
    const dy = t.clientY - s.y;
    if (Math.abs(dy) > Math.abs(dx) * 0.7) return;
    if (!drawer && s.x < 28 && dx > 56) setDrawer("left");
    else if (!drawer && s.x > window.innerWidth - 28 && dx < -56) setDrawer("right");
    else if (drawer === "left" && dx < -56) setDrawer(null);
    else if (drawer === "right" && dx > 56) setDrawer(null);
  };

  const sidebar = (
    <FileTree
      projectId={project.id}
      notes={list}
      folders={folders}
      activeId={noteId}
      selectedFolder={folder}
      onSelectFolder={setFolder}
      onOpen={open}
      onNewNote={(f) => void newNote(f)}
      onDelete={(n) => void removeNote(n)}
      tagFilter={tagFilter}
      onTagFilter={setTagFilter}
      onClose={wide ? undefined : () => setDrawer(null)}
    />
  );

  const info = active ? (
    <InfoPanel
      note={active}
      notes={list}
      onOpen={open}
      onOpenLink={(t) => void openLink(t)}
      onTag={(t) => {
        setTagFilter(t);
        if (!wide) setDrawer("left");
      }}
    />
  ) : null;

  return (
    <div className="obs absolute inset-0 flex" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      {wide && sideOpen && <aside className="flex w-60 shrink-0 flex-col overflow-hidden border-r border-white/[0.06] bg-[var(--obs-side)] lg:w-64">{sidebar}</aside>}

      {!wide && drawer === "left" && (
        <div className="fixed inset-0 z-[70]">
          <button type="button" aria-label="Close file list" className="absolute inset-0 bg-black/55" onClick={() => setDrawer(null)} />
          <aside className="absolute inset-y-0 left-0 flex w-[84vw] max-w-[340px] flex-col bg-[var(--obs-side)] pt-[env(safe-area-inset-top)] shadow-2xl">{sidebar}</aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-11 shrink-0 items-center gap-0.5 border-b border-white/[0.06] bg-[var(--obs-bg)] pl-1 pr-1.5">
          <BarBtn label={wide ? (sideOpen ? "Hide file list" : "Show file list") : "Open file list"} onClick={() => (wide ? setSideOpen((s) => !s) : setDrawer("left"))}>
            <Menu size={18} />
          </BarBtn>
          <div role="tablist" aria-label="Open notes" className="no-scrollbar flex min-w-0 flex-1 items-stretch gap-0.5 overflow-x-auto">
            {tabs.map((id) => {
              const n = list.find((x) => x.id === id);
              const title = n?.title ?? "Untitled";
              const on = id === noteId;
              return (
                <div
                  key={id}
                  role="tab"
                  aria-selected={on}
                  className={cn(
                    "group flex h-9 max-w-[200px] shrink-0 items-center self-end rounded-t-lg pl-3 pr-1 text-[13px] transition-colors",
                    on ? "bg-[#262626] text-[#f2f2f3]" : "text-[#8e8e93] hover:bg-white/[0.04] hover:text-[#dcddde]"
                  )}
                >
                  <button type="button" onClick={() => open(id)} className="min-w-0 flex-1 truncate py-1 text-left">
                    {title}
                  </button>
                  <button type="button" aria-label={`Close ${title}`} onClick={() => closeTab(id)} className="ml-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[#8e8e93] hover:bg-white/10 hover:text-white">
                    <X size={13} />
                  </button>
                </div>
              );
            })}
          </div>
          <BarBtn label="Quick switcher (Ctrl+O)" onClick={() => setSwitcher(true)}>
            <Search size={17} />
          </BarBtn>
          <BarBtn label="Graph view" onClick={() => setGraph(true)}>
            <Network size={17} />
          </BarBtn>
          <BarBtn
            label="Links, backlinks and tags"
            active={wide ? infoOpen : drawer === "right"}
            onClick={() => (wide ? setInfoOpen((i) => !i) : setDrawer((d) => (d === "right" ? null : "right")))}
          >
            <Info size={17} />
          </BarBtn>
        </header>

        <div className="relative min-h-0 flex-1">
          {noteId ? (
            <NoteEditor
              key={noteId}
              noteId={noteId}
              notes={list}
              onOpenLink={(t) => void openLink(t)}
              onTag={(t) => {
                setTagFilter(t);
                if (!wide) setDrawer("left");
              }}
              onDelete={() => {
                if (active) void removeNote(active);
              }}
            />
          ) : (
            <Welcome hasNotes={list.length > 0} onNew={() => void newNote(folder)} onSwitch={() => setSwitcher(true)} />
          )}
        </div>
      </div>

      {wide && infoOpen && info && <aside className="flex w-72 shrink-0 flex-col overflow-hidden border-l border-white/[0.06] bg-[var(--obs-side)]">{info}</aside>}
      {!wide && drawer === "right" && (
        <div className="fixed inset-0 z-[70]">
          <button type="button" aria-label="Close panel" className="absolute inset-0 bg-black/55" onClick={() => setDrawer(null)} />
          <aside className="absolute inset-y-0 right-0 flex w-[88vw] max-w-[360px] flex-col bg-[var(--obs-side)] pt-[env(safe-area-inset-top)] shadow-2xl">{info}</aside>
        </div>
      )}

      {switcher && (
        <QuickSwitcher
          notes={list}
          onClose={() => setSwitcher(false)}
          onPick={(id) => open(id)}
          onCreate={(title) => {
            setSwitcher(false);
            void createNote(project.id, { title, folder }).then(open);
          }}
        />
      )}
      {graph && <GraphOverlay notes={list} activeId={noteId} onOpen={open} onClose={() => setGraph(false)} />}
    </div>
  );
}

function BarBtn({ label, onClick, active, children }: { label: string; onClick: () => void; active?: boolean; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg transition-colors md:h-8 md:w-8",
        active ? "bg-white/[0.1] text-white" : "text-[#9a9aa0] hover:bg-white/[0.07] hover:text-white"
      )}
    >
      {children}
    </button>
  );
}

function Welcome({ hasNotes, onNew, onSwitch }: { hasNotes: boolean; onNew: () => void; onSwitch: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 px-6 text-center">
      <BookOpen size={36} className="text-[#8e8e93]" />
      <p className="text-[18px] font-semibold text-[#e5e5e7]">{hasNotes ? "No note open" : "Your notes live here"}</p>
      <p className="max-w-sm text-[14px] leading-relaxed text-[#8e8e93]">
        Pick a note from the file list, or create one. Link notes with [[wikilinks]] and tag them with #tags.
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        <button type="button" onClick={onNew} className="h-11 rounded-xl bg-[#7c6af0] px-5 text-[14px] font-semibold text-white">
          New note
        </button>
        <button type="button" onClick={onSwitch} className="h-11 rounded-xl bg-white/[0.07] px-5 text-[14px] font-medium text-[#dcddde]">
          Quick switcher
        </button>
      </div>
    </div>
  );
}
