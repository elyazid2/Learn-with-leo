import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowUpRight, BookOpen, Brain, Compass, Plus, Settings2 } from "lucide-react";
import { db, PROJECT_COLORS, colorOf, uid, type Project, type ProjectIcon } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { startPlacement } from "@/lib/chat";
import ProjectIconPicker from "@/components/ProjectIconPicker";
import { defaultEmojiFor } from "@/lib/projectIcon";
import { timeAgo } from "@/lib/media";
import { Button, Field, IconBtn, Sheet, StatusBar, inputCls } from "@/components/ui";
import { cn } from "@/utils/cn";
import ProjectAvatar from "@/components/ProjectAvatar";
import AgentAvatar from "@/components/AgentAvatar";
import { useSettings } from "@/lib/settings";
import { accentText } from "@/lib/color";

const TAG_SUGGESTIONS = ["Language", "Math", "Code", "Science", "Music", "History", "Design", "Exam"];

function countBy(keys: string[]) {
  const m: Record<string, number> = {};
  for (const k of keys) m[k] = (m[k] ?? 0) + 1;
  return m;
}

export default function Home() {
  const projects = useLiveQuery(() => db.projects.orderBy("updatedAt").reverse().toArray(), []);
  const concepts = useLiveQuery(() => db.concepts.toArray(), []);
  // Index keys only — never pulls file blobs into memory just to count them.
  const fileCounts = useLiveQuery(async () => countBy((await db.files.orderBy("projectId").keys()) as string[]), []);
  const noteCounts = useLiveQuery(async () => countBy((await db.notes.orderBy("projectId").keys()) as string[]), []);
  const sketchCounts = useLiveQuery(async () => countBy((await db.sketches.orderBy("projectId").keys()) as string[]), []);
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const [creating, setCreating] = useState(false);
  const developerMode = useSettings((s) => s.developerMode);

  return (
    <div className="mx-auto min-h-full max-w-5xl px-5 pb-32 pt-[max(env(safe-area-inset-top),20px)]">
      <header className="flex items-center justify-between py-3">
        <div className="flex items-center gap-2.5">
          <Logo />
          <span className="display text-[26px] leading-none">Harness</span>
        </div>
        <IconBtn onClick={() => navigate("settings")} aria-label="Settings">
          <Settings2 size={19} />
        </IconBtn>
      </header>

      <section className="mt-6 mb-8">
        <h1 className="max-w-lg display text-[38px] leading-[1.06] sm:text-[48px]">
          What are you <span className="text-muted">learning</span>?
        </h1>
        <p className="mt-3 max-w-md text-[15px] text-muted">
          Your projects, your materials, an AI that meets you where you are. Your library and notes stay on this device; only what you choose to attach is sent to your AI provider.
        </p>
      </section>

      {providerCount === 0 && !developerMode && (
        <button
          onClick={() => navigate("settings")}
          className="mb-6 flex w-full items-center gap-3 rounded-3xl border border-dashed border-black/15 bg-white/60 p-4 text-left transition hover:bg-white"
        >
          <AgentAvatar state="blocked" size={40} />
          <div className="flex-1">
            <div className="text-sm font-semibold">Connect an AI provider for Leo</div>
            <div className="text-[13px] text-muted">OpenAI, Anthropic, Gemini, OpenRouter, Ollama…</div>
          </div>
          <ArrowUpRight size={18} className="text-muted" />
        </button>
      )}

      {projects && projects.length === 0 && <Intro onCreate={() => setCreating(true)} />}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {projects?.map((p) => {
          const pc = concepts?.filter((c) => c.projectId === p.id) ?? [];
          const solid = pc.filter((c) => c.status === "solid").length;
          const col = colorOf(p.color);
          const libraryTotal = (fileCounts?.[p.id] ?? 0) + (noteCounts?.[p.id] ?? 0) + (sketchCounts?.[p.id] ?? 0);
          return (
            <button
              key={p.id}
              onClick={() => navigate(projectPath(p.id))}
              className="group relative overflow-hidden rounded-2xl bg-card p-4 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.02] sm:p-5"
            >
              <div className="flex items-center gap-3.5">
                <ProjectAvatar project={p} size={44} animate={false} />
                <div className="min-w-0 flex-1">
                  <div className="truncate display text-[20px] leading-tight">{p.name}</div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    {p.tag && (
                      <span className="rounded-full px-2 py-0.5 text-[11px] font-medium" style={{ background: `color-mix(in srgb, ${col.hex} 13%, var(--card))`, color: accentText(col.hex) }}>
                        {p.tag}
                      </span>
                    )}
                    <LevelChip project={p} />
                  </div>
                </div>
                <span className="shrink-0 self-start text-[12px] text-muted">{timeAgo(p.updatedAt)}</span>
              </div>
              <div className="mt-4">
                <StatusBar concepts={pc} />
                <div className="mt-2.5 flex items-center gap-3.5 text-[12px] text-muted">
                  <span className="flex items-center gap-1">
                    <Brain size={13} /> {solid}/{pc.length} solid
                  </span>
                  <span className="flex items-center gap-1">
                    <BookOpen size={13} /> {libraryTotal} {libraryTotal === 1 ? "item" : "items"}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 flex justify-center pb-[max(env(safe-area-inset-bottom),20px)] pointer-events-none">
        <Button size="lg" className="pointer-events-auto shadow-[0_12px_32px_rgba(0,0,0,0.16)]" onClick={() => setCreating(true)}>
          <Plus size={18} /> New project
        </Button>
      </div>

      <NewProjectSheet open={creating} onClose={() => setCreating(false)} hasProvider={!!providerCount || developerMode} />
    </div>
  );
}

export function LevelChip({ project }: { project: Project }) {
  const pl = project.placement;
  if (pl.status === "done")
    return <span className="rounded-full bg-black/[0.05] px-2 py-0.5 text-[11px] font-medium">{pl.level}</span>;
  return (
    <span className="flex items-center gap-1 rounded-full border border-dashed border-black/15 px-2 py-0.5 text-[11px] text-muted">
      <Compass size={11} /> {pl.status === "in_progress" ? "Placing…" : "Unplaced"}
    </span>
  );
}

export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect width="32" height="32" rx="10" fill="#17171a" />
      <circle cx="16" cy="16" r="4" fill="#fff" />
      <circle cx="16" cy="16" r="9" fill="none" stroke="#fff" strokeOpacity=".45" strokeWidth="1.5" strokeDasharray="3 3" />
      <circle cx="25" cy="16" r="2" fill="#22b07d" />
      <circle cx="10" cy="9.5" r="2" fill="#4f8ff7" />
      <circle cx="10" cy="22.5" r="2" fill="#f0a52b" />
    </svg>
  );
}

function Intro({ onCreate }: { onCreate: () => void }) {
  const steps = [
    { icon: <Compass size={18} />, title: "Placement", text: "A few adaptive questions find your level and starting point." },
    { icon: <Brain size={18} />, title: "Teach & test", text: "Lessons at your level. Quizzes update your knowledge map." },
    { icon: <BookOpen size={18} />, title: "Your tools", text: "Library, notes, sketches — Leo sees what you share." },
  ];
  return (
    <div className="mb-8 grid gap-3 sm:grid-cols-3">
      {steps.map((s, i) => (
        <div key={s.title} className="rise rounded-2xl bg-card p-5 ring-1 ring-line" style={{ animationDelay: `${i * 60}ms` }}>
          <div className="flex items-center justify-between">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-black/[0.05]">{s.icon}</div>
            <span className="display text-2xl text-black/40">0{i + 1}</span>
          </div>
          <div className="mt-4 font-semibold">{s.title}</div>
          <p className="mt-1 text-[13px] leading-relaxed text-muted">{s.text}</p>
        </div>
      ))}
      <button
        onClick={onCreate}
        className="flex items-center justify-center gap-2 rounded-2xl border border-dashed border-black/15 p-5 text-sm font-medium text-muted transition hover:bg-white sm:col-span-3"
      >
        <Plus size={16} /> Start your first project
      </button>
    </div>
  );
}

function NewProjectSheet({ open, onClose, hasProvider }: { open: boolean; onClose: () => void; hasProvider: boolean }) {
  const [name, setName] = useState("");
  const [tag, setTag] = useState("");
  const [color, setColor] = useState("blue");
  const [placement, setPlacement] = useState(true);
  const [icon, setIcon] = useState<ProjectIcon>({ kind: "emoji", emoji: defaultEmojiFor("") });
  const [iconTouched, setIconTouched] = useState(false);
  // Until you pick an icon yourself, it follows the tag (Math → 📐, Language → 🗣️…).
  const changeTag = (t: string) => {
    setTag(t);
    if (!iconTouched) setIcon({ kind: "emoji", emoji: defaultEmojiFor(t) });
  };

  const create = async () => {
    if (!name.trim()) return;
    const now = Date.now();
    const p: Project = {
      id: uid(),
      name: name.trim(),
      tag: tag.trim(),
      color,
      icon,
      createdAt: now,
      updatedAt: now,
      placement: { status: "pending" },
    };
    await db.projects.add(p);
    setName("");
    setTag("");
    setIcon({ kind: "emoji", emoji: defaultEmojiFor("") });
    setIconTouched(false);
    onClose();
    navigate(projectPath(p.id));
    if (placement && hasProvider) setTimeout(() => void startPlacement(p.id), 250);
  };

  return (
    <Sheet open={open} onClose={onClose} title="New project">
      <div className="space-y-5">
        <Field label="Topic">
          <input
            autoFocus
            className={inputCls}
            placeholder="e.g. Linear algebra, Japanese, Rust…"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && create()}
          />
        </Field>
        <Field label="Tag">
          <input className={inputCls} placeholder="Short label" value={tag} onChange={(e) => changeTag(e.target.value)} />
          <div className="mt-2 flex flex-wrap gap-1.5">
            {TAG_SUGGESTIONS.map((t) => (
              <button
                key={t}
                onClick={() => changeTag(t)}
                className={cn(
                  "rounded-full px-2.5 py-1 text-xs transition",
                  tag === t ? "bg-ink text-white" : "bg-black/[0.05] text-muted hover:text-ink"
                )}
              >
                {t}
              </button>
            ))}
          </div>
        </Field>
        <div>
          <span className="mb-1.5 block text-[12px] font-medium text-muted">Icon</span>
          <ProjectIconPicker
            value={icon}
            onChange={(v) => {
              setIcon(v);
              setIconTouched(true);
            }}
            color={color}
            tag={tag}
          />
        </div>
        <Field label="Color">
          <div className="flex flex-wrap gap-2">
            {Object.entries(PROJECT_COLORS).map(([k, c]) => (
              <button
                key={k}
                onClick={() => setColor(k)}
                aria-label={c.name}
                className={cn("h-9 w-9 rounded-full transition", color === k ? "ring-2 ring-offset-2 ring-ink" : "hover:scale-110")}
                style={{ background: c.hex }}
              />
            ))}
          </div>
        </Field>
        <label className="flex items-center gap-3 rounded-2xl bg-black/[0.03] p-3.5">
          <input type="checkbox" checked={placement} onChange={(e) => setPlacement(e.target.checked)} className="h-4 w-4 accent-black" />
          <div className="text-sm">
            <div className="font-medium">Start with placement</div>
            <div className="text-[12px] text-muted">
              {hasProvider ? "Leo asks a few adaptive questions to find your level." : "Add an AI provider for Leo in Settings first."}
            </div>
          </div>
        </label>
        <Button size="lg" className="w-full" disabled={!name.trim()} onClick={create}>
          Create project
        </Button>
      </div>
    </Sheet>
  );
}
