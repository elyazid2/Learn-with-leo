import type { ReactNode } from "react";
import { ArrowLeft } from "lucide-react";
import AgentAvatar from "@/components/AgentAvatar";
import {
  AGENT_STATE_META,
  AVATAR_COLORS,
  AVATAR_EXPRESSIONS,
  AVATAR_SHAPES,
  type AgentState,
  type AvatarColor,
  type AvatarExpression,
  type AvatarShape,
} from "@/lib/avatar";
import { navigate } from "@/lib/router";
import { useSettings } from "@/lib/settings";
import { IconBtn } from "@/components/ui";

const STATES: AgentState[] = ["idle", "listening", "thinking", "speaking", "working", "waiting", "blocked", "done"];

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-7">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">{title}</h2>
      <div className="rounded-2xl bg-card p-4 ring-1 ring-line">{children}</div>
    </section>
  );
}

function Cell({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 text-center">
      {children}
      <span className="text-[12px] text-muted">{label}</span>
    </div>
  );
}

/** QA board for the agent avatar: live states, frozen expressions and real-size legibility. */
export default function DevAvatars() {
  const look = useSettings((s) => s.avatar);
  return (
    <div className="mx-auto max-w-3xl px-5 pb-24 pt-[max(env(safe-area-inset-top),16px)]">
      <header className="flex items-center gap-2 py-3">
        <IconBtn onClick={() => navigate("settings")} aria-label="Back">
          <ArrowLeft size={19} />
        </IconBtn>
        <h1 className="display text-[24px] leading-none">Leo avatar sheet</h1>
      </header>
      <p className="text-[14px] text-muted">Live states run on the shared clock. Expressions are frozen frames. Sizes match where the avatar is used.</p>

      <Section title="States (live)">
        <div className="grid grid-cols-3 gap-4 sm:grid-cols-6">
          {STATES.map((s) => (
            <Cell key={s} label={AGENT_STATE_META[s].label}>
              <AgentAvatar state={s} look={look} size={84} />
            </Cell>
          ))}
        </div>
      </Section>

      <Section title="Rest expressions">
        <div className="grid grid-cols-4 gap-4 sm:grid-cols-7">
          {(Object.keys(AVATAR_EXPRESSIONS) as AvatarExpression[]).map((e) => (
            <Cell key={e} label={AVATAR_EXPRESSIONS[e].label}>
              <AgentAvatar look={{ ...look, expression: e }} size={60} frozenAt={0} />
            </Cell>
          ))}
        </div>
      </Section>

      <Section title="Sizes">
        <div className="flex flex-wrap items-end gap-5">
          {[14, 18, 24, 28, 40, 56, 88].map((s) => (
            <Cell key={s} label={`${s}px`}>
              <AgentAvatar look={look} size={s} />
            </Cell>
          ))}
        </div>
      </Section>

      <Section title="Shapes and colors">
        <div className="flex flex-wrap gap-5">
          {(Object.keys(AVATAR_SHAPES) as AvatarShape[]).map((sh) => (
            <Cell key={sh} label={AVATAR_SHAPES[sh].label}>
              <AgentAvatar look={{ ...look, shape: sh }} size={56} frozenAt={0} />
            </Cell>
          ))}
        </div>
        <div className="mt-5 flex flex-wrap gap-4">
          {(Object.keys(AVATAR_COLORS) as AvatarColor[]).map((c) => (
            <Cell key={c} label={AVATAR_COLORS[c].label}>
              <AgentAvatar look={{ ...look, color: c }} size={44} frozenAt={0} />
            </Cell>
          ))}
        </div>
      </Section>
    </div>
  );
}
