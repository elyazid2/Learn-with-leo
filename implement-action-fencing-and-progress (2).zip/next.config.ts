import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Markdown files are imported as raw strings (e.g. Leo's on-demand guides).
  turbopack: {
    rules: {
      "*.md": {
        loaders: ["raw-loader"],
        as: "*.js",
      },
    },
  },
};

export default nextConfig;
