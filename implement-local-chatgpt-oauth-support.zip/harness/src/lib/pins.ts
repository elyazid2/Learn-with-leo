import { db, type LibFile, type Note, type Sketch, type ToolItem } from "./db";
import { live } from "./trash";

/** Pins: items that are always in Leo's context for one project. Never global. */

export type PinKind = "note" | "sketch" | "file" | "tool";
export type Pinnable = Note | Sketch | LibFile | ToolItem;

export async function setPinned(kind: PinKind, id: string, pinned: boolean) {
  if (kind === "note") await db.notes.update(id, { pinned });
  else if (kind === "sketch") await db.sketches.update(id, { pinned });
  else if (kind === "file") await db.files.update(id, { pinned });
  else await db.tools.update(id, { pinned });
}

export interface PinnedItem {
  kind: PinKind;
  id: string;
  title: string;
  subtitle: string;
  /** Excerpt or summary included in Leo's project context. */
  content?: string;
  chars: number;
}

function summarizeSketch(scene: string): string {
  try {
    const els = (JSON.parse(scene || "{}") as { elements?: { type?: string; text?: string; isDeleted?: boolean }[] }).elements;
    const active = Array.isArray(els) ? els.filter((e) => !e.isDeleted) : [];
    if (!active.length) return "(empty sketch)";
    const labels = active.map((e) => e.text?.trim()).filter(Boolean);
    return `${active.length} elements${labels.length ? `: ${labels.slice(0, 12).join(" · ")}` : ""}`;
  } catch {
    return "";
  }
}

function summarizeTool(t: ToolItem): string {
  const s = t.state ?? {};
  if (t.kind === "checklist") {
    const items = Array.isArray(s.items) ? (s.items as { text?: string; done?: boolean }[]) : [];
    return items.length
      ? items.slice(0, 20).map((i) => `[${i.done ? "x" : " "}] ${i.text ?? ""}`).join("\n")
      : "(empty checklist)";
  }
  if (t.kind === "flashcards") {
    const cards = Array.isArray(s.cards) ? (s.cards as { front?: string; back?: string; inSack?: boolean }[]) : [];
    return cards.length
      ? cards.slice(0, 15).map((c) => `Q: ${c.front ?? ""} → A: ${c.back ?? ""}${c.inSack ? "" : " (learned)"}`).join("\n")
      : "(no flash cards)";
  }
  if (t.kind === "calculator") return s.expr ? `Expression: ${String(s.expr)}` : "(calculator)";
  if (t.kind === "converter") return `${String(s.value ?? "1")} ${String(s.from ?? "m")} → ${String(s.to ?? "ft")} (${String(s.cat ?? "Length")})`;
  return `Mode: ${String(s.tab ?? "pomodoro")} · focus ${String(s.work ?? 25)}m / break ${String(s.brk ?? 5)}m`;
}

/** Everything pinned in a single project, with content excerpts for Leo. Trashed items never pin. */
export async function pinnedItems(projectId: string): Promise<PinnedItem[]> {
  const [notes, sketches, files, tools, chunks] = await Promise.all([
    db.notes.where("projectId").equals(projectId).toArray(),
    db.sketches.where("projectId").equals(projectId).toArray(),
    db.files.where("projectId").equals(projectId).toArray(),
    db.tools.where("projectId").equals(projectId).toArray(),
    db.chunks.where("projectId").equals(projectId).toArray(),
  ]);
  const out: PinnedItem[] = [];
  for (const n of live(notes).filter((x) => x.pinned)) {
    const content = n.content.slice(0, 4000);
    out.push({
      kind: "note",
      id: n.id,
      title: n.title || "Untitled note",
      subtitle: n.folder ? `Note · ${n.folder}` : "Note",
      content,
      chars: content.length,
    });
  }
  for (const s of live(sketches).filter((x) => x.pinned)) {
    const content = summarizeSketch(s.scene);
    out.push({
      kind: "sketch",
      id: s.id,
      title: s.title || "Sketch",
      subtitle: "Sketch",
      content,
      chars: content.length,
    });
  }
  for (const f of live(files).filter((x) => x.pinned)) {
    const fileChunks = chunks
      .filter((c) => c.sourceId === f.id)
      .sort((a, b) => a.page - b.page || (a.t0 ?? 0) - (b.t0 ?? 0));
    const joined = fileChunks.map((c) => (c.page > 0 ? `[p.${c.page}] ${c.text}` : c.text)).join("\n").slice(0, 4000);
    const transcript = !joined && f.transcript?.length
      ? f.transcript.map((seg) => seg.text).join(" ").slice(0, 4000)
      : "";
    const content = joined || transcript || undefined;
    out.push({
      kind: "file",
      id: f.id,
      title: f.name,
      subtitle: f.youtubeId ? "YouTube video" : f.kind.toUpperCase(),
      content,
      chars: content?.length ?? 0,
    });
  }
  for (const t of live(tools).filter((x) => x.pinned)) {
    const content = summarizeTool(t);
    out.push({
      kind: "tool",
      id: t.id,
      title: t.title,
      subtitle: `Tool · ${t.kind}`,
      content,
      chars: content.length,
    });
  }
  return out;
}
