import { db } from "./db";

/** Project-scoped, reversible deletion. A row remains in IndexedDB until explicitly deleted for good. */
export type TrashKind = "note" | "sketch" | "file" | "tool" | "thread" | "concept" | "point" | "memory" | "test";

export const live = <T extends { deletedAt?: number }>(items: T[]) => items.filter((item) => !item.deletedAt);
export const trashed = <T extends { deletedAt?: number }>(items: T[]) => items.filter((item) => !!item.deletedAt).sort((a, b) => (b.deletedAt ?? 0) - (a.deletedAt ?? 0));

/** Hide an item without deleting its files, messages, versions, links or other restore data. */
export async function trashItem(kind: TrashKind, id: string): Promise<void> {
  const deletedAt = Date.now();
  let projectId: string | undefined;
  switch (kind) {
    case "note": projectId = (await db.notes.get(id))?.projectId; await db.notes.update(id, { deletedAt }); break;
    case "sketch": await db.sketches.update(id, { deletedAt }); break;
    case "file": projectId = (await db.files.get(id))?.projectId; await db.files.update(id, { deletedAt }); break;
    case "tool": await db.tools.update(id, { deletedAt }); break;
    case "thread": await db.threads.update(id, { deletedAt }); break;
    case "concept": await db.concepts.update(id, { deletedAt }); break;
    case "point": await db.points.update(id, { deletedAt }); break;
    case "memory": await db.memories.update(id, { deletedAt }); break;
    case "test": await db.tests.update(id, { deletedAt }); break;
  }
  if (projectId) {
    const { invalidateIndex } = await import("./retrieval");
    invalidateIndex(projectId);
  }
}

/** Bring a trashed item back, with its original ID and all its data intact. */
export async function restoreItem(kind: TrashKind, id: string): Promise<void> {
  let projectId: string | undefined;
  switch (kind) {
    case "note": projectId = (await db.notes.get(id))?.projectId; await db.notes.update(id, { deletedAt: undefined, updatedAt: Date.now() }); break;
    case "sketch": await db.sketches.update(id, { deletedAt: undefined, updatedAt: Date.now() }); break;
    case "file": projectId = (await db.files.get(id))?.projectId; await db.files.update(id, { deletedAt: undefined }); break;
    case "tool": await db.tools.update(id, { deletedAt: undefined, updatedAt: Date.now() }); break;
    case "thread": await db.threads.update(id, { deletedAt: undefined }); break;
    case "concept": await db.concepts.update(id, { deletedAt: undefined }); break;
    case "point": await db.points.update(id, { deletedAt: undefined }); break;
    case "memory": await db.memories.update(id, { deletedAt: undefined }); break;
    case "test": await db.tests.update(id, { deletedAt: undefined }); break;
  }
  if (projectId) {
    const { invalidateIndex } = await import("./retrieval");
    invalidateIndex(projectId);
  }
}

/** The only permanent deletion path in the project Trash. Also clean dependent data. */
export async function deleteForever(kind: TrashKind, id: string): Promise<void> {
  // Never silently erase a live item through this API.
  const row = kind === "note" ? await db.notes.get(id)
    : kind === "sketch" ? await db.sketches.get(id)
    : kind === "file" ? await db.files.get(id)
    : kind === "tool" ? await db.tools.get(id)
    : kind === "thread" ? await db.threads.get(id)
    : kind === "concept" ? await db.concepts.get(id)
    : kind === "point" ? await db.points.get(id)
    : kind === "memory" ? await db.memories.get(id) : await db.tests.get(id);
  if (!row?.deletedAt) return;
  const projectId = row.projectId;
  switch (kind) {
    case "note":
      await db.transaction("rw", [db.notes, db.chunks], async () => {
        await db.chunks.where("sourceId").equals(id).delete();
        await db.notes.delete(id);
      });
      break;
    case "sketch": await db.sketches.delete(id); break;
    case "file":
      await db.transaction("rw", [db.files, db.chunks, db.pdfAnnotations], async () => {
        await db.chunks.where("sourceId").equals(id).delete();
        await db.pdfAnnotations.where("fileId").equals(id).delete();
        await db.files.delete(id);
      });
      break;
    case "tool": await db.tools.delete(id); break;
    case "thread":
      await db.transaction("rw", [db.threads, db.messages], async () => {
        await db.messages.where("threadId").equals(id).delete();
        await db.threads.delete(id);
      });
      break;
    case "concept": await db.concepts.delete(id); break;
    case "point": await db.points.delete(id); break;
    case "memory": await db.memories.delete(id); break;
    case "test": await db.tests.delete(id); break;
  }
  if (kind === "file" || kind === "note") {
    const { invalidateIndex } = await import("./retrieval");
    invalidateIndex(projectId);
  }
}
