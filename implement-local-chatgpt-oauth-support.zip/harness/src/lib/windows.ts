import { create } from "zustand";
import { persist } from "zustand/middleware";

/** A floating window opened over a project: a library tool or the project's scratchpad. */
export interface FloatWin {
  /** Stable id: `tool:<toolId>` or `scratch:<projectId>`. */
  id: string;
  kind: "tool" | "scratch";
  projectId: string;
  toolId?: string;
}

interface WindowsState {
  /** Open windows; the last one is on top. */
  wins: FloatWin[];
  open: (w: FloatWin) => void;
  close: (id: string) => void;
  focus: (id: string) => void;
  toggle: (w: FloatWin) => void;
}

export const toolWinId = (toolId: string) => `tool:${toolId}`;
export const scratchWinId = (projectId: string) => `scratch:${projectId}`;

export const useWindows = create<WindowsState>()(
  persist(
    (set, get) => ({
      wins: [],
      open: (w) => set({ wins: [...get().wins.filter((x) => x.id !== w.id), w] }),
      close: (id) => set({ wins: get().wins.filter((x) => x.id !== id) }),
      focus: (id) => {
        const wins = get().wins;
        const w = wins.find((x) => x.id === id);
        if (!w || wins[wins.length - 1]?.id === id) return;
        set({ wins: [...wins.filter((x) => x.id !== id), w] });
      },
      toggle: (w) => (get().wins.some((x) => x.id === w.id) ? get().close(w.id) : get().open(w)),
    }),
    { name: "harness.windows", partialize: (s) => ({ wins: s.wins }) }
  )
);

/** Open a library tool as a floating window (never as a full page). */
export const openToolWindow = (projectId: string, toolId: string) => useWindows.getState().open({ id: toolWinId(toolId), kind: "tool", projectId, toolId });
