import { db, type ItemMetadataVersion, type LibFile, type ToolItem } from "./db";

export const ITEM_HISTORY_LIMIT = 20;
export type MetadataKind = "file" | "tool";

/** Store the current metadata before Leo applies an approved rename/tag. Files never duplicate their Blob. */
export async function snapshotMetadata(kind: MetadataKind, id: string, replacedBy: "ai" | "user" = "ai") {
  const current = kind === "file" ? await db.files.get(id) : await db.tools.get(id);
  if (!current || current.deletedAt) return;
  const previous: ItemMetadataVersion = kind === "file"
    ? { name: (current as LibFile).name, tags: current.tags, at: Date.now(), replacedBy }
    : { name: (current as ToolItem).title, tags: current.tags, state: structuredClone((current as ToolItem).state), at: Date.now(), replacedBy };
  const versions = [...(current.versions ?? []), previous].slice(-ITEM_HISTORY_LIMIT);
  if (kind === "file") await db.files.update(id, { versions });
  else await db.tools.update(id, { versions });
}

/** Restore a selected version and retain the replaced current state as a new version. */
export async function restoreMetadata(kind: MetadataKind, id: string, index: number): Promise<boolean> {
  const current = kind === "file" ? await db.files.get(id) : await db.tools.get(id);
  if (!current || current.deletedAt) return false;
  const target = current.versions?.[index];
  if (!target) return false;
  const now = Date.now();
  const previous: ItemMetadataVersion = kind === "file"
    ? { name: (current as LibFile).name, tags: current.tags, at: now, replacedBy: "user" }
    : { name: (current as ToolItem).title, tags: current.tags, state: structuredClone((current as ToolItem).state), at: now, replacedBy: "user" };
  const versions = [...(current.versions ?? []), previous].slice(-ITEM_HISTORY_LIMIT);
  if (kind === "file") await db.files.update(id, { name: target.name, tags: target.tags, versions });
  else await db.tools.update(id, { title: target.name, tags: target.tags, state: structuredClone(target.state ?? {}), versions, updatedAt: now });
  return true;
}
