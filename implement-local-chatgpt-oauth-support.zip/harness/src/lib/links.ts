import { db, uid, type ItemLink, type Note } from "./db";
import { live } from "./trash";
import { backlinksOf } from "./notes";

/** Direct links between items: a note → a PDF page, a video timestamp, a sketch or another note. */

export function linkLabel(link: ItemLink, targetName?: string): string {
  const base = link.label || targetName || "Linked item";
  if (link.page) return `${base} · p.${link.page}`;
  if (link.t0 !== undefined) return `${base} · ${clock(link.t0)}`;
  return base;
}

export const clock = (s: number) => {
  const t = Math.max(0, Math.round(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}` : `${m}:${String(t % 60).padStart(2, "0")}`;
};

export async function addLink(noteId: string, link: Omit<ItemLink, "id">) {
  const note = await db.notes.get(noteId);
  if (!note || note.deletedAt || (link.targetKind === "note" && link.targetId === noteId)) return;
  const target = link.targetKind === "note" ? await db.notes.get(link.targetId)
    : link.targetKind === "sketch" ? await db.sketches.get(link.targetId)
    : await db.files.get(link.targetId);
  if (!target || target.deletedAt || target.projectId !== note.projectId) return;
  if (note.links?.some((old) => old.targetKind === link.targetKind && old.targetId === link.targetId && old.page === link.page && old.t0 === link.t0)) return;
  await db.notes.update(noteId, { links: [...(note.links ?? []), { ...link, id: uid() }], updatedAt: Date.now() });
}

export async function removeLink(noteId: string, linkId: string) {
  const note = await db.notes.get(noteId);
  if (!note) return;
  await db.notes.update(noteId, { links: (note.links ?? []).filter((l) => l.id !== linkId), updatedAt: Date.now() });
}

/** Notes that link to this item (the "Linked from" list on the target). */
export async function linkedFrom(projectId: string, targetKind: ItemLink["targetKind"], targetId: string): Promise<{ note: Note; link: ItemLink }[]> {
  const notes = live(await db.notes.where("projectId").equals(projectId).toArray());
  const out: { note: Note; link: ItemLink }[] = [];
  for (const n of notes) for (const l of n.links ?? []) if (l.targetKind === targetKind && l.targetId === targetId) out.push({ note: n, link: l });
  if (targetKind === "note") {
    const target = notes.find((n) => n.id === targetId);
    if (target) for (const { note } of backlinksOf(target, notes)) {
      if (!out.some((entry) => entry.note.id === note.id))
        out.push({ note, link: { id: `wiki:${note.id}:${targetId}`, targetKind: "note", targetId } });
    }
  }
  return out;
}
