/**
 * "Jump to this spot" requests between items: a note link to a PDF page or a video timestamp
 * sets a target here; the file view consumes it when it opens.
 */
const key = (fileId: string) => `harness.seek.${fileId}`;

export function requestSeek(fileId: string, target: { page?: number; t?: number }) {
  try {
    localStorage.setItem(key(fileId), JSON.stringify(target));
  } catch {
    /* storage unavailable: an already-open viewer can still receive the event */
  }
  window.dispatchEvent(new CustomEvent("harness:seek", { detail: { fileId, ...target } }));
}

export function takeSeek(fileId: string): { page?: number; t?: number } | null {
  try {
    const raw = localStorage.getItem(key(fileId));
    if (!raw) return null;
    localStorage.removeItem(key(fileId));
    const v = JSON.parse(raw) as { page?: number; t?: number };
    return v && (typeof v.page === "number" || typeof v.t === "number") ? v : null;
  } catch {
    return null;
  }
}
