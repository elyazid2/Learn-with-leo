import type { ThinkingLevel } from "../db";

export type { ThinkingLevel };

export interface ThinkingOption {
  value: ThinkingLevel;
  label: string;
  hint: string;
  /** 0–4: how many bars of the level meter are filled. */
  bars: number;
}

export const THINKING_LEVELS: ThinkingOption[] = [
  { value: "auto", label: "Auto", hint: "The model decides", bars: 0 },
  { value: "low", label: "Low", hint: "Fast answers, light reasoning", bars: 1 },
  { value: "medium", label: "Medium", hint: "Balanced speed and depth", bars: 2 },
  { value: "high", label: "High", hint: "Deeper reasoning, slower", bars: 3 },
  { value: "xhigh", label: "Extra high", hint: "Maximum effort, slowest", bars: 4 },
];

export const thinkingOption = (level?: ThinkingLevel) => THINKING_LEVELS.find((o) => o.value === level) ?? THINKING_LEVELS[0];

/**
 * OpenAI-style `reasoning_effort`. The local ChatGPT OAuth endpoint always understands it; for other
 * OpenAI-compatible hosts it is only sent to models that are known to reason, so Ollama, Groq and
 * friends never see a field they might reject.
 */
export function reasoningEffort(level: ThinkingLevel | undefined, model: string, always: boolean): string | null {
  if (!level || level === "auto") return null;
  if (!always && !/(^|[/:])(o\d|gpt-5)/i.test(model)) return null;
  return level;
}

/** Anthropic extended-thinking budget in tokens (null = off). Only for models that support it. */
export function anthropicBudget(level: ThinkingLevel | undefined, model: string): number | null {
  if (!level || level === "auto") return null;
  if (!/claude-(opus|sonnet)-\d|claude-3-7/i.test(model)) return null;
  return { low: 2048, medium: 8192, high: 16000, xhigh: 32000 }[level];
}

/** Gemini `thinkingBudget` in tokens (null = leave to the model). Only 2.5+ models take it. */
export function geminiBudget(level: ThinkingLevel | undefined, model: string): number | null {
  if (!level || level === "auto") return null;
  if (!/gemini-(2\.5|3)/i.test(model)) return null;
  return { low: 1024, medium: 8192, high: 24576, xhigh: 32768 }[level];
}

const STORE_KEY = "harness.thinking";

/** The level last picked in any chat; new chats start there. */
export function storedThinking(): ThinkingLevel {
  try {
    const v = localStorage.getItem(STORE_KEY);
    return THINKING_LEVELS.some((o) => o.value === v) ? (v as ThinkingLevel) : "auto";
  } catch {
    return "auto";
  }
}

export function rememberThinking(level: ThinkingLevel) {
  try {
    localStorage.setItem(STORE_KEY, level);
  } catch {
    /* private mode: the level still applies to this chat */
  }
}
