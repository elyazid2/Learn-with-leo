import { Suspense, lazy, useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { History, Link2, Loader2, PenTool, Pin, RotateCcw, Trash2 } from "lucide-react";
import { db, type Project, type Sketch } from "@/lib/db";
import { queueSketchPreviews } from "@/lib/sketchPreviews";
import { Button, Empty, IconBtn, Sheet } from "@/components/ui";
import { confirmDeletion, useSettings } from "@/lib/settings";
import { trashItem } from "@/lib/trash";
import { setPinned } from "@/lib/pins";
import { SKETCH_VERSION_LIMIT } from "@/lib/db";
import { LinkedFrom } from "@/components/notes/LinksSection";
import { navigate, projectPath } from "@/lib/router";
import { useApp } from "@/lib/store";
import { useLive } from "@/lib/live";
import { PaneBar, usePane } from "@/components/Pane";

import { normalizeAvatarLook } from "@/lib/avatar";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

const SketchCanvas = lazy(() => import("@/components/SketchCanvas"));

export default function Sketches({ project, sketchId }: { project: Project; sketchId: string }) {
  return <SketchEditor key={sketchId} project={project} sketchId={sketchId} />;
}

/** Sketchboard: its title, save state, Leo and delete sit in the pane's one top bar; the rest is canvas. */
function SketchEditor({ project, sketchId }: { project: Project; sketchId: string }) {
  const sketch = useLiveQuery(() => db.sketches.get(sketchId), [sketchId], null as Sketch | null | undefined);
  const [title, setTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [linkedOpen, setLinkedOpen] = useState(false);
  const setChatOpen = useApp((s) => s.setChatOpen);
  const drawing = useLive((s) => s.sketchId === sketchId);
  const pane = usePane();

  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);

  useEffect(() => {
    if (sketch) setTitle(sketch.title);
  }, [sketch?.id, sketch?.title]); // eslint-disable-line react-hooks/exhaustive-deps

  if (sketch === null)
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="animate-spin text-muted" />
      </div>
    );
  if (!sketch || sketch.deletedAt)
    return (
      <Empty icon={<PenTool />} title="Sketch not found">
        <Button onClick={() => pane.close()}>{pane.primary ? "Back to library" : "Close"}</Button>
      </Empty>
    );

  const saveTitle = () => void db.sketches.update(sketch.id, { title: title.trim() || "Sketch", updatedAt: Date.now() });
  const remove = async () => {
    if (!(await confirmDeletion("Delete this sketch? It goes to the Trash — you can restore it from there."))) return;
    pane.close(true);
    await trashItem("sketch", sketch.id);
  };

  return (
    <div className="flex h-full flex-col">
      <PaneBar>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onBlur={saveTitle}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          aria-label="Sketch title"
          dir="auto"
          className="min-w-[6rem] flex-1 basis-[6rem] truncate rounded-lg bg-transparent px-1.5 py-1 text-[16px] font-semibold outline-none focus:bg-ink/[0.05]"
        />
        <span className="flex shrink-0 items-center gap-1.5 px-1.5 text-[12px] text-muted" aria-live="polite" title={drawing ? "Leo is drawing" : saving ? "Saving" : "Saved"}>
          <span className={cn("h-1.5 w-1.5 rounded-full transition-colors", drawing || saving ? "bg-shaky" : "bg-solid")} />
          <span className="hidden sm:inline">{drawing ? "Leo is drawing" : saving ? "Saving" : "Saved"}</span>
        </span>
        <button
          onClick={() => setChatOpen(true)}
          aria-label="Ask Leo about this sketch"
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-full py-1 pl-1 pr-3 text-[14px] font-semibold transition-colors hover:bg-ink/[0.06]"
        >
          <AgentAvatar state={drawing ? "working" : "idle"} look={look} size={28} frozenAt={drawing ? undefined : 0} /> Leo
        </button>
        <IconBtn onClick={() => void setPinned("sketch", sketch.id, !sketch.pinned)} aria-label={sketch.pinned ? "Unpin from Leo's context" : "Pin for Leo"} aria-pressed={!!sketch.pinned} className={sketch.pinned ? "bg-ink text-on-ink hover:bg-ink/90" : ""}>
          <Pin size={16} fill={sketch.pinned ? "currentColor" : "none"} />
        </IconBtn>
        <IconBtn onClick={() => setHistoryOpen(true)} aria-label="Version history" title={sketch.versions?.length ? `Version history (${sketch.versions.length} saved)` : "Version history"}>
          <History size={16} />
        </IconBtn>
        <IconBtn onClick={() => setLinkedOpen(true)} aria-label="Linked from" title="Linked from">
          <Link2 size={16} />
        </IconBtn>
        <IconBtn onClick={() => void remove()} aria-label="Delete sketch" className="hover:text-danger-fg">
          <Trash2 size={17} />
        </IconBtn>
      </PaneBar>
      <div className="relative min-h-0 flex-1">
        <Suspense
          fallback={
            <div className="flex h-full items-center justify-center">
              <Loader2 className="animate-spin text-muted" />
            </div>
          }
        >
          <SketchCanvas sketch={sketch} title={title} onSaving={setSaving} />
        </Suspense>
        {drawing && (
          <div className="pointer-events-none absolute inset-x-0 bottom-4 z-10 flex justify-center" role="status">
            <span className="rise flex items-center gap-2 rounded-full bg-elevated py-1.5 pl-1.5 pr-3.5 text-[13px] font-semibold shadow-[0_8px_24px_rgba(0,0,0,0.16)] ring-1 ring-line">
              <AgentAvatar state="working" look={look} size={24} /> Leo is drawing
            </span>
          </div>
        )}
      </div>
      <SketchHistorySheet sketch={sketch} open={historyOpen} onClose={() => setHistoryOpen(false)} />
      <Sheet open={linkedOpen} onClose={() => setLinkedOpen(false)} title="Linked from">
        <LinkedFrom projectId={project.id} targetKind="sketch" targetId={sketch.id} onOpen={(noteId) => { setLinkedOpen(false); navigate(projectPath(project.id, "notes", noteId)); }} />
      </Sheet>
    </div>
  );
}

/** Sketch version history: every edit Leo made saved the previous scene. */
function SketchHistorySheet({ sketch, open, onClose }: { sketch: Sketch; open: boolean; onClose: () => void }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [restoring, setRestoring] = useState(false);
  const versions = sketch.versions ?? [];
  const chosen = selected !== null ? versions[selected] : undefined;
  const parseElements = (scene: string) => {
    try {
      const els = (JSON.parse(scene || "{}") as { elements?: { type?: string; text?: string; isDeleted?: boolean }[] }).elements;
      return Array.isArray(els) ? els.filter((e) => !e.isDeleted) : [];
    } catch {
      return [];
    }
  };
  const summarize = (scene: string) => {
    const els = parseElements(scene);
    if (!els.length) return "(empty canvas)";
    return els.map((e, idx) => `${idx + 1}. ${e.type ?? "shape"}${e.text ? ` — "${e.text.replace(/\s+/g, " ").slice(0, 60)}"` : ""}`).join("\n");
  };
  const restore = async () => {
    if (selected === null || restoring) return;
    setRestoring(true);
    const target = versions[selected];
    const now = Date.now();
    await db.sketches.update(sketch.id, {
      scene: target.scene,
      ...(target.title ? { title: target.title } : {}),
      ...("tags" in target ? { tags: target.tags } : {}),
      versions: [...versions, { scene: sketch.scene, title: sketch.title, tags: sketch.tags, at: now, replacedBy: "user" as const }].slice(-SKETCH_VERSION_LIMIT),
      updatedAt: now,
    });
    const api = useApp.getState().sketchApi;
    if (api && api.sketchId === sketch.id) {
      const els = parseElements(target.scene);
      api.updateScene({ elements: els });
      api.fit?.(els);
    }
    queueSketchPreviews(sketch.id);
    setRestoring(false);
    useApp.getState().showToast("Restored that version", { tone: "success" });
    onClose();
  };
  return (
    <Sheet open={open} onClose={onClose} title="History" wide>
      {versions.length === 0 ? (
        <div className="flex flex-col items-center py-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/[0.05] text-muted"><History size={20} /></span>
          <p className="mt-3 text-[14px] font-semibold">No earlier versions</p>
          <p className="mt-0.5 max-w-[280px] text-[13px] text-muted">Every edit Leo makes saves the previous drawing here automatically.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <ul className="divide-y divide-line overflow-hidden rounded-2xl ring-1 ring-line">
            {[...versions].reverse().map((v, ri) => {
              const i = versions.length - 1 - ri;
              const active = selected === i;
              const els = parseElements(v.scene);
              return (
                <li key={`${v.at}-${i}`}>
                  <button onClick={() => setSelected(active ? null : i)} aria-pressed={active} className={cn("flex w-full items-center gap-3 px-3.5 py-2.5 text-left transition-colors", active ? "bg-ink/[0.06]" : "hover:bg-ink/[0.03]")}>
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink/[0.05] text-[12px] font-bold text-muted">{v.replacedBy === "ai" ? "L" : "You"}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium">{v.title || sketch.title} · {els.length} {els.length === 1 ? "element" : "elements"}</span>
                      <span className="block text-[12px] text-muted">{new Date(v.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} · replaced by {v.replacedBy === "ai" ? "Leo" : "you"}</span>
                    </span>
                    {active && <span className="shrink-0 rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">Viewing</span>}
                  </button>
                </li>
              );
            })}
          </ul>
          {chosen && (
            <div className="fade-in">
              <div className="grid gap-3 sm:grid-cols-2">
                <section className="overflow-hidden rounded-2xl ring-1 ring-line">
                  <h3 className="border-b border-line bg-ink/[0.03] px-3.5 py-2 text-[12px] font-semibold text-muted">That version</h3>
                  <div className="border-b border-line px-3.5 py-2 text-[12px] text-muted"><strong className="font-semibold text-ink">{chosen.title || sketch.title}</strong>{chosen.tags?.length ? ` · ${chosen.tags.map((t) => `#${t}`).join(" ")}` : ""}</div>
                  <pre className="max-h-[36dvh] overflow-y-auto whitespace-pre-wrap p-3.5 text-[12.5px] leading-relaxed">{summarize(chosen.scene)}</pre>
                </section>
                <section className="overflow-hidden rounded-2xl ring-1 ring-line">
                  <h3 className="border-b border-line bg-ink/[0.03] px-3.5 py-2 text-[12px] font-semibold text-muted">Current</h3>
                  <div className="border-b border-line px-3.5 py-2 text-[12px] text-muted"><strong className="font-semibold text-ink">{sketch.title}</strong>{sketch.tags?.length ? ` · ${sketch.tags.map((t) => `#${t}`).join(" ")}` : ""}</div>
                  <pre className="max-h-[36dvh] overflow-y-auto whitespace-pre-wrap p-3.5 text-[12.5px] leading-relaxed">{summarize(sketch.scene)}</pre>
                </section>
              </div>
              <Button size="lg" className="mt-3 w-full" disabled={restoring} onClick={() => void restore()}>
                <RotateCcw size={16} /> {restoring ? "Restoring…" : "Restore this version"}
              </Button>
            </div>
          )}
        </div>
      )}
    </Sheet>
  );
}
