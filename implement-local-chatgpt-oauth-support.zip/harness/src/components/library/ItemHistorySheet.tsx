import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { History, RotateCcw } from "lucide-react";
import { db, type ItemMetadataVersion, type LibFile, type ToolItem } from "@/lib/db";
import { restoreMetadata, type MetadataKind } from "@/lib/itemVersions";
import { useApp } from "@/lib/store";
import { Button, Sheet } from "@/components/ui";
import { cn } from "@/utils/cn";

/** Metadata history for a file or tool. A file's Blob is never duplicated. */
export default function ItemHistorySheet({ kind, id, open, onClose }: { kind: MetadataKind; id: string; open: boolean; onClose: () => void }) {
  const item = useLiveQuery(async (): Promise<LibFile | ToolItem | undefined> => (kind === "file" ? db.files.get(id) : db.tools.get(id)), [kind, id]);
  const [selected, setSelected] = useState<number | null>(null);
  const [restoring, setRestoring] = useState(false);
  useEffect(() => { if (!open) setSelected(null); }, [open]);
  const versions = item?.versions ?? [];
  const selectedVersion = selected === null ? undefined : versions[selected];
  const current: ItemMetadataVersion | undefined = item ? {
    name: "name" in item ? item.name : item.title,
    tags: item.tags,
    state: "state" in item ? item.state : undefined,
    at: Date.now(),
    replacedBy: "user",
  } : undefined;

  const restore = async () => {
    if (selected === null || restoring) return;
    setRestoring(true);
    try {
      const ok = await restoreMetadata(kind, id, selected);
      useApp.getState().showToast(ok ? "Restored that version" : "Version unavailable", { tone: ok ? "success" : "error" });
      if (ok) onClose();
    } catch {
      useApp.getState().showToast("Could not restore that version", { tone: "error" });
    } finally {
      setRestoring(false);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="History" wide>
      {!item ? <p className="py-6 text-center text-[13px] text-muted">Loading…</p> : versions.length === 0 ? (
        <div className="flex flex-col items-center py-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/[0.05] text-muted"><History size={20} /></span>
          <p className="mt-3 text-[14px] font-semibold">No earlier versions</p>
          <p className="mt-1 max-w-[300px] text-[13px] text-muted">Leo’s approved edits will be saved here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <ul className="max-h-48 divide-y divide-line overflow-y-auto rounded-2xl ring-1 ring-line">
            {[...versions].reverse().map((v, reverseIndex) => {
              const index = versions.length - reverseIndex - 1;
              return (
                <li key={`${v.at}-${index}`}>
                  <button
                    onClick={() => setSelected(index)}
                    aria-pressed={selected === index}
                    className={cn("flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors", selected === index ? "bg-ink/[0.06]" : "hover:bg-ink/[0.03]")}
                  >
                    <span className="min-w-0 flex-1 truncate text-[14px] font-medium" dir="auto">{v.name}</span>
                    <span className="shrink-0 text-[11px] text-muted">{new Date(v.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                    <span className="shrink-0 text-[11px] text-muted">{v.replacedBy === "ai" ? "Leo" : "You"}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          {selectedVersion && current && (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                <VersionColumn title="That version" version={selectedVersion} kind={kind} />
                <VersionColumn title="Current" version={current} kind={kind} />
              </div>
              <Button size="lg" className="w-full" disabled={restoring} onClick={() => void restore()}>
                <RotateCcw size={16} /> {restoring ? "Restoring…" : "Restore this version"}
              </Button>
            </>
          )}
        </div>
      )}
    </Sheet>
  );
}

function VersionColumn({ title, version, kind }: { title: string; version: ItemMetadataVersion; kind: MetadataKind }) {
  return (
    <section className="min-w-0 overflow-hidden rounded-2xl ring-1 ring-line">
      <h3 className="border-b border-line bg-ink/[0.03] px-3.5 py-2 text-[12px] font-semibold text-muted">{title}</h3>
      <div className="max-h-64 space-y-2 overflow-y-auto p-3.5 text-[13px]">
        <p className="break-words font-semibold" dir="auto">{version.name}</p>
        <p className="text-muted">{version.tags?.length ? version.tags.map((t) => `#${t}`).join(" ") : "No tags"}</p>
        {kind === "tool" && <pre className="overflow-auto whitespace-pre-wrap break-words rounded-xl bg-ink/[0.04] p-2 text-[11px]">{JSON.stringify(version.state ?? {}, null, 2).slice(0, 3000)}</pre>}
      </div>
    </section>
  );
}
