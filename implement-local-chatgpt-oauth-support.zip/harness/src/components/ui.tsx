import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ButtonHTMLAttributes, type PointerEvent as RPointerEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AlertTriangle, CheckCircle2, Info, X } from "lucide-react";
import { cn } from "@/utils/cn";
import { STATUS_META, type Concept, type ConceptStatus } from "@/lib/db";
import { useApp } from "@/lib/store";
import { useConfirm } from "@/lib/confirm";
import { useSheetViewport } from "@/lib/sheetViewport";
import { usePresence } from "@/lib/motion";

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "soft" | "ghost" | "danger" | "outline" | "danger-solid";
  size?: "sm" | "md" | "lg";
};

export function Button({ variant = "primary", size = "md", className, type = "button", ...rest }: BtnProps) {
  return (
    <button
      type={type}
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full font-medium transition-[transform,background-color,box-shadow,opacity] duration-150 active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none select-none",
        size === "sm" && "h-8 px-3 text-[13px]",
        size === "md" && "h-10 px-4 text-sm",
        size === "lg" && "h-12 px-6 text-[15px]",
        variant === "primary" && "bg-ink text-white shadow-[0_1px_0_rgba(255,255,255,0.08)_inset,0_1px_2px_rgba(0,0,0,0.12)] hover:bg-ink/90",
        variant === "soft" && "bg-black/[0.05] text-ink hover:bg-black/[0.08]",
        variant === "ghost" && "text-ink hover:bg-black/[0.05]",
        variant === "outline" && "border border-line bg-white text-ink hover:bg-black/[0.03]",
        variant === "danger" && "bg-danger-bg text-danger-fg hover:bg-danger-line",
        variant === "danger-solid" && "bg-danger-fg text-on-ink hover:opacity-90",
        className
      )}
    />
  );
}

export function IconBtn({ className, type = "button", ...rest }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type={type}
      title={rest.title ?? (typeof rest["aria-label"] === "string" ? rest["aria-label"] : undefined)}
      {...rest}
      className={cn(
        "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-ink/80 transition hover:bg-black/[0.06] hover:text-ink active:scale-95 disabled:opacity-30",
        className
      )}
    />
  );
}

let sheetSeq = 0;
const sheetStack: number[] = [];
/** Page scroll state from before the first sheet opened; restored when the last one closes. */
let bodyOverflowBefore = "";
/** True when any Sheet (or confirm dialog) is open — global shortcuts stay quiet underneath. */
export const isSheetOpen = () => sheetStack.length > 0;

export function Sheet({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  wide,
  layer = 60,
  role = "dialog",
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  /** Actions remain visible above the keyboard while the form scrolls. */
  footer?: ReactNode;
  wide?: boolean;
  /** z-index; dialogs that must sit above other overlays (confirmations) pass a higher value. */
  layer?: number;
  role?: "dialog" | "alertdialog";
}) {
  const panel = useRef<HTMLDivElement>(null);
  const viewport = useSheetViewport(open, panel);
  // The sheet stays mounted while it slides away, showing what it showed last: callers often clear
  // the content at the same moment they close it.
  const { mounted, closing, end } = usePresence(open);
  const kept = useRef({ title, description, children, footer });
  if (open) kept.current = { title, description, children, footer };
  else ({ title, description, children, footer } = kept.current);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const idRef = useRef(0);
  if (!idRef.current) idRef.current = ++sheetSeq;
  const titleId = `sheet-title-${idRef.current}`;
  // Swipe-down-to-dismiss on touch (from the grab handle / header only, so content can scroll).
  const [dragY, setDragY] = useState(0);
  const drag = useRef<{ y: number; t: number } | null>(null);

  useEffect(() => {
    if (!open) return;
    setDragY(0);
    const me = idRef.current;
    if (!sheetStack.length) bodyOverflowBefore = document.body.style.overflow;
    sheetStack.push(me);
    const previous = document.activeElement as HTMLElement | null;
    const focusable = () =>
      Array.from(
        panel.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])') ?? []
      ).filter((el) => el.offsetParent !== null);
    const raf = requestAnimationFrame(() => {
      if (panel.current?.contains(document.activeElement)) return;
      const first = focusable().find((el) => el.tagName !== "BUTTON");
      (first ?? panel.current)?.focus({ preventScroll: true });
    });
    const on = (e: KeyboardEvent) => {
      if (sheetStack[sheetStack.length - 1] !== me) return;
      if (e.key === "Escape") {
        // Marked as handled: one Esc closes one thing, never the sheet and what is under it.
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== "Tab") return;
      const els = focusable();
      if (!els.length) return;
      const i = els.indexOf(document.activeElement as HTMLElement);
      if (e.shiftKey && i <= 0) {
        e.preventDefault();
        els[els.length - 1].focus();
      } else if (!e.shiftKey && (i === els.length - 1 || i === -1)) {
        e.preventDefault();
        els[0].focus();
      }
    };
    window.addEventListener("keydown", on);
    document.body.style.overflow = "hidden";
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", on);
      const idx = sheetStack.lastIndexOf(me);
      if (idx >= 0) sheetStack.splice(idx, 1);
      // Sheets can close in any order; the page only scrolls again once none is left.
      if (!sheetStack.length) {
        document.body.style.overflow = bodyOverflowBefore;
        previous?.focus?.({ preventScroll: true });
      }
    };
  }, [open]);

  const onDragStart = (e: RPointerEvent) => {
    if (e.pointerType === "mouse") return;
    if ((e.target as HTMLElement).closest("button,input,select,textarea,a")) return;
    drag.current = { y: e.clientY, t: Date.now() };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onDragMove = (e: RPointerEvent) => {
    if (!drag.current) return;
    setDragY(Math.max(0, e.clientY - drag.current.y));
  };
  const onDragEnd = () => {
    const d = drag.current;
    drag.current = null;
    if (!d) return;
    const fast = dragY / Math.max(1, Date.now() - d.t) > 0.6;
    if (dragY > 110 || (fast && dragY > 30)) onCloseRef.current();
    else setDragY(0);
  };

  if (!mounted) return null;
  return createPortal(
    <div
      className={cn("fixed inset-x-0 flex items-end justify-center sm:items-center sm:p-4", closing && "pointer-events-none")}
      aria-hidden={closing || undefined}
      style={{ zIndex: layer, top: viewport.top, bottom: viewport.bottom }}
      data-sheet-viewport
      role={role}
      aria-modal="true"
      aria-labelledby={title ? titleId : undefined}
    >
      <div className={cn(closing ? "fade-out" : "fade-in", "absolute inset-0 bg-[#000]/35 backdrop-blur-[3px]")} onClick={() => onCloseRef.current()} />
      <div
        ref={panel}
        tabIndex={-1}
        onAnimationEnd={(e) => {
          if (closing && e.target === e.currentTarget) end();
        }}
        className={cn(
          closing ? "sheet-out" : "sheet-in",
          "relative flex w-full flex-col overflow-hidden rounded-t-[28px] bg-card px-5 shadow-2xl outline-none ring-1 ring-line sm:rounded-3xl",
          wide ? "sm:max-w-2xl" : "sm:max-w-md"
        )}
        style={{ maxHeight: Math.max(100, Math.min(viewport.height * 0.92, viewport.height - 12)), ...(dragY ? { transform: `translateY(${dragY}px)`, transition: "none" } : { transition: "transform .2s ease" }) }}
      >
        <div
          className={cn("relative z-10 -mx-5 shrink-0 bg-card/95 px-5 pt-3 backdrop-blur-md sm:pt-5", title ? "pb-3" : "pb-1")}
          onPointerDown={onDragStart}
          onPointerMove={onDragMove}
          onPointerUp={onDragEnd}
          onPointerCancel={onDragEnd}
          style={{ touchAction: "none" }}
        >
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-black/15 sm:hidden" aria-hidden />
          {title && (
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 pt-1">
                <h2 id={titleId} className="display text-[22px] leading-none">
                  {title}
                </h2>
                {description && <p className="mt-1.5 text-[13px] leading-snug text-muted">{description}</p>}
              </div>
              <IconBtn onClick={() => onCloseRef.current()} aria-label="Close" className="-mr-1.5 -mt-0.5">
                <X size={18} />
              </IconBtn>
            </div>
          )}
        </div>
        <div data-sheet-scroll className={cn("-mx-5 min-h-0 overflow-y-auto overscroll-contain px-5", title && "pt-1", footer ? "pb-4" : "pb-[max(2rem,env(safe-area-inset-bottom))] sm:pb-5")}>
          {children}
        </div>
        {footer && <div data-sheet-footer className="-mx-5 shrink-0 border-t border-line bg-card px-5 pt-3 pb-[max(1rem,env(safe-area-inset-bottom))]">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-medium text-muted">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-2xl border border-line bg-white px-4 py-3 text-[16px] outline-none transition-[border-color,box-shadow] placeholder:text-muted/70 focus:border-ink/40 focus:ring-4 focus:ring-black/[0.06]";

export function StatusBar({ concepts, className }: { concepts: Concept[]; className?: string }) {
  const total = concepts.length;
  const order: ConceptStatus[] = ["solid", "learning", "shaky", "new"];
  const label = total
    ? order
        .map((s) => `${concepts.filter((c) => c.status === s).length} ${STATUS_META[s].label.toLowerCase()}`)
        .join(", ")
    : "No concepts mapped yet";
  return (
    <div role="img" aria-label={label} title={label} className={cn("reveal-x flex h-1.5 w-full gap-[2px] overflow-hidden rounded-full bg-black/[0.06]", className)}>
      {total > 0 &&
        order.map((s) => {
          const n = concepts.filter((c) => c.status === s).length;
          if (!n) return null;
          return (
            <div
              key={s}
              className="h-full rounded-full transition-[width] duration-500"
              style={{ width: `${(n / total) * 100}%`, background: STATUS_META[s].color }}
            />
          );
        })}
    </div>
  );
}

export function Ring({ value, size = 44, stroke = 4, color = "var(--ink)", children }: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  // The arc starts empty and draws to its value, on arrival and whenever the value changes.
  const [drawn, setDrawn] = useState(0);
  useEffect(() => {
    const id = requestAnimationFrame(() => setDrawn(v));
    return () => cancelAnimationFrame(id);
  }, [v]);
  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(v * 100)}
    >
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - drawn)}
          style={{ transition: "stroke-dashoffset .8s var(--ease-out)" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-[11px] font-semibold tabular-nums">{children}</div>
    </div>
  );
}

export function Empty({ icon, title, text, children, className }: { icon: ReactNode; title: string; text?: string; children?: ReactNode; className?: string }) {
  return (
    <div className={cn("rise flex flex-col items-center justify-center px-6 py-14 text-center", className)}>
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-ink/70 shadow-sm ring-1 ring-line">{icon}</div>
      <h3 className="display text-2xl text-balance">{title}</h3>
      {text && <p className="mt-1.5 max-w-xs text-sm text-muted text-pretty">{text}</p>}
      {children && <div className="mt-5 flex flex-wrap justify-center gap-2">{children}</div>}
    </div>
  );
}

/** Loading placeholder that keeps layout stable while IndexedDB answers. */
export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={cn("shimmer rounded-xl", className)} />;
}

export function Kbd({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <kbd
      className={cn(
        "inline-flex h-5 min-w-5 items-center justify-center rounded-md border border-line bg-paper px-1.5 font-sans text-[11px] font-medium text-muted shadow-[0_1px_0_var(--line)]",
        className
      )}
    >
      {children}
    </kbd>
  );
}

export function Toast() {
  const live = useApp((s) => s.toast);
  const dismiss = useApp((s) => s.dismissToast);
  // The last toast stays up while it animates away.
  const { mounted, closing, end } = usePresence(!!live);
  const last = useRef(live);
  if (live) last.current = live;
  const toast = mounted ? (live ?? last.current) : null;
  return (
    <div className="pointer-events-none fixed inset-x-0 top-[max(env(safe-area-inset-top),16px)] z-[120] flex justify-center px-4" role="status" aria-live="polite" aria-atomic="true">
      {toast && (
        <div
          key={toast.id}
          onAnimationEnd={(e) => {
            if (closing && e.target === e.currentTarget) end();
          }}
          className={cn(
            closing ? "toast-out pointer-events-none" : "toast-in pointer-events-auto",
            "flex max-w-[min(92vw,520px)] items-center gap-2.5 rounded-2xl py-2 pl-3 pr-2 text-sm shadow-[0_12px_32px_rgba(0,0,0,0.22)]",
            toast.tone === "error" ? "bg-danger-bg text-danger-fg ring-1 ring-danger-line" : "bg-ink text-white"
          )}
        >
          {toast.tone === "error" ? (
            <AlertTriangle size={16} className="shrink-0" />
          ) : toast.tone === "success" ? (
            <CheckCircle2 size={16} className="shrink-0 text-solid" />
          ) : (
            <Info size={16} className="shrink-0 opacity-70" />
          )}
          <span className="min-w-0 flex-1 py-0.5 leading-snug">{toast.text}</span>
          {toast.action && (
            <button
              onClick={() => {
                toast.action?.onClick();
                dismiss();
              }}
              className={cn(
                "shrink-0 rounded-full px-3 py-1 text-[13px] font-semibold transition-colors",
                toast.tone === "error" ? "bg-danger-fg/10 hover:bg-danger-fg/20" : "bg-white/15 hover:bg-white/25"
              )}
            >
              {toast.action.label}
            </button>
          )}
          <button onClick={dismiss} aria-label="Dismiss" className="relative shrink-0 rounded-full p-1 opacity-60 transition-opacity before:absolute before:-inset-2.5 hover:opacity-100">
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}

/** Renders the in-app confirmation dialog requested through confirmDialog()/confirmDeletion(). */
export function ConfirmHost() {
  const current = useConfirm((s) => s.current);
  const settle = useConfirm((s) => s.settle);
  const danger = current?.tone === "danger";
  return (
    <Sheet open={!!current} onClose={() => settle(false)} layer={110} role="alertdialog">
      {current && (
        <div key={current.id} className="pt-1 sm:pt-0">
          <div className="flex items-start gap-3.5">
            <span
              className={cn(
                "flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl",
                danger ? "bg-danger-bg text-danger-fg" : "bg-ink/[0.06] text-ink"
              )}
            >
              {danger ? <AlertTriangle size={20} /> : <Info size={20} />}
            </span>
            <div className="min-w-0 pt-0.5">
              <h2 className="display text-[20px] leading-tight">{current.title ?? "Are you sure?"}</h2>
              <p className="mt-1.5 text-[14px] leading-relaxed text-muted text-pretty">{current.message}</p>
            </div>
          </div>
          <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button variant="soft" size="lg" className="sm:h-10 sm:text-sm" onClick={() => settle(false)}>
              {current.cancelLabel ?? "Cancel"}
            </Button>
            <Button variant={danger ? "danger-solid" : "primary"} size="lg" className="sm:h-10 sm:text-sm" autoFocus onClick={() => settle(true)}>
              {current.confirmLabel ?? "Confirm"}
            </Button>
          </div>
        </div>
      )}
    </Sheet>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", checked ? "bg-ink" : "bg-ink/15")}
    >
      <span className={cn("absolute left-0 top-1 h-5 w-5 rounded-full shadow-sm transition-transform", checked ? "translate-x-6 bg-on-ink" : "translate-x-1 bg-[#fff]")} />
    </button>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
  label,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
  label?: string;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  // The selected option sits on a thumb that slides between options instead of jumping.
  const [thumb, setThumb] = useState<{ left: number; width: number } | null>(null);
  const [slide, setSlide] = useState(false);
  const measure = useCallback(() => {
    const el = wrap.current?.querySelector<HTMLElement>('[aria-checked="true"]');
    const next = el ? { left: el.offsetLeft, width: el.offsetWidth } : null;
    setThumb((t) => (t?.left === next?.left && t?.width === next?.width ? t : next));
  }, []);
  // After every render: the selection, or the width of a label, may have changed.
  useLayoutEffect(measure);
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    // The thumb appears in place; only later moves are animated.
    const id = requestAnimationFrame(() => setSlide(true));
    return () => {
      ro.disconnect();
      cancelAnimationFrame(id);
    };
  }, [measure]);
  return (
    <div ref={wrap} role="radiogroup" aria-label={label} className={cn("relative inline-flex rounded-full bg-black/[0.05] p-0.5", className)}>
      {thumb && (
        <span
          aria-hidden
          className="pointer-events-none absolute bottom-0.5 left-0 top-0.5 rounded-full bg-white shadow-sm"
          style={{ width: thumb.width, transform: `translateX(${thumb.left}px)`, transition: slide ? "transform .24s var(--ease-out), width .24s var(--ease-out)" : "none" }}
        />
      )}
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn("relative rounded-full px-3 py-1 text-[13px] font-medium transition-colors", value === o.value ? "text-ink" : "text-muted hover:text-ink")}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
