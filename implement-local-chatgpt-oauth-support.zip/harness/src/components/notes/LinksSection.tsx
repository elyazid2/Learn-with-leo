import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { FileText, Film, Link2, PenTool, Plus, X } from "lucide-react";
import { db, type FileKind, type ItemLink, type Note } from "@/lib/db";
import { addLink, clock, linkLabel, linkedFrom, removeLink } from "@/lib/links";
import { live } from "@/lib/trash";
import { requestSeek } from "@/lib/seek";
import { navigate, projectPath } from "@/lib/router";
import { Sheet, Button } from "@/components/ui";

/** Jump to a link's target spot: a PDF page, a video/audio timestamp, a sketch or a note. */
export function openLinkTarget(projectId: string, link: ItemLink) {
  if (link.targetKind === "note") return navigate(projectPath(projectId, "notes", link.targetId));
  if (link.targetKind === "sketch") return navigate(projectPath(projectId, "sketch", link.targetId));
  if (link.page) requestSeek(link.targetId, { page: link.page });
  else if (link.t0 !== undefined) requestSeek(link.targetId, { t: link.t0 });
  navigate(projectPath(projectId, "library", link.targetId));
}

/** The links under a note: tap to jump to the spot, plus an "Add link" picker. */
export default function LinksSection({ note }: { note: Note }) {
  const [adding, setAdding] = useState(false);
  const links = note.links ?? [];
  const targets = useLiveQuery(async () => {
    const [files, notes, sketches] = await Promise.all([
      db.files.where("projectId").equals(note.projectId).toArray(),
      db.notes.where("projectId").equals(note.projectId).toArray(),
      db.sketches.where("projectId").equals(note.projectId).toArray(),
    ]);
    const nameOf = (l: ItemLink) =>
      l.targetKind === "note"
        ? live(notes).find((n) => n.id === l.targetId)?.title || "Untitled note"
        : l.targetKind === "sketch"
          ? live(sketches).find((s) => s.id === l.targetId)?.title || "Sketch"
          : live(files).find((f) => f.id === l.targetId)?.name.replace(/\.[a-z0-9]+$/i, "") || "File";
    return { nameOf };
  }, [note.projectId, note.links]);

  return (
    <section className="mt-10 border-t border-line pt-5" aria-label="Links">
      <div className="mb-2.5 flex items-center justify-between">
        <h2 className="flex items-center gap-1.5 text-[13px] font-semibold text-muted">
          <Link2 size={13} /> Links
        </h2>
        <button onClick={() => setAdding(true)} className="flex items-center gap-1 rounded-full px-2.5 py-1 text-[12px] font-medium text-ink ring-1 ring-line transition-colors hover:bg-ink/[0.04]">
          <Plus size={12} /> Add link
        </button>
      </div>
      {links.length === 0 ? (
        <p className="text-[13px] text-muted">Link to a PDF page, a video moment, a sketch or another note.</p>
      ) : (
        <ul className="space-y-1.5">
          {links.map((l) => (
            <li key={l.id} className="group flex items-center gap-1 rounded-xl bg-card ring-1 ring-line">
              <button onClick={() => openLinkTarget(note.projectId, l)} className="flex min-w-0 flex-1 items-center gap-2.5 px-3 py-2 text-left">
                <LinkIcon kind={l.targetKind} />
                <span className="min-w-0 flex-1 truncate text-[14px] font-medium" dir="auto">
                  {linkLabel(l, targets?.nameOf(l))}
                </span>
              </button>
              <button onClick={() => void removeLink(note.id, l.id)} aria-label="Remove link" className="mr-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-muted hover:bg-danger-bg hover:text-danger-fg">
                <X size={13} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <AddLinkSheet note={note} open={adding} onClose={() => setAdding(false)} />
    </section>
  );
}

function LinkIcon({ kind }: { kind: ItemLink["targetKind"] }) {
  return (
    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink/[0.05] text-muted">
      {kind === "note" ? <FileText size={13} /> : kind === "sketch" ? <PenTool size={13} /> : <Film size={13} />}
    </span>
  );
}

/** Pick what to link to; PDFs ask for a page, audio/video for a timestamp. */
function AddLinkSheet({ note, open, onClose }: { note: Note; open: boolean; onClose: () => void }) {
  const files = useLiveQuery(() => db.files.where("projectId").equals(note.projectId).toArray(), [note.projectId]);
  const notes = useLiveQuery(() => db.notes.where("projectId").equals(note.projectId).toArray(), [note.projectId]);
  const sketches = useLiveQuery(() => db.sketches.where("projectId").equals(note.projectId).toArray(), [note.projectId]);
  const [q, setQ] = useState("");
  const [picked, setPicked] = useState<{ kind: ItemLink["targetKind"]; id: string; name: string; fileKind?: FileKind; pages?: number; duration?: number } | null>(null);
  const [page, setPage] = useState(1);
  const [time, setTime] = useState("0:00");

  const term = q.trim().toLowerCase();
  const match = (name: string) => !term || name.toLowerCase().includes(term);
  const rows: { kind: ItemLink["targetKind"]; id: string; name: string; sub: string; fileKind?: FileKind; pages?: number; duration?: number }[] = [
    ...live(notes ?? []).filter((n) => n.id !== note.id && match(n.title || "Untitled")).map((n) => ({ kind: "note" as const, id: n.id, name: n.title || "Untitled note", sub: "Note" })),
    ...live(sketches ?? []).filter((s) => match(s.title || "Sketch")).map((s) => ({ kind: "sketch" as const, id: s.id, name: s.title || "Sketch", sub: "Sketch" })),
    ...live(files ?? []).filter((f) => match(f.name)).map((f) => ({ kind: "file" as const, id: f.id, name: f.name.replace(/\.[a-z0-9]+$/i, ""), sub: f.kind === "pdf" ? `PDF${f.pages ? ` · ${f.pages} pages` : ""}` : f.kind === "video" ? "Video" : f.kind === "audio" ? "Audio" : f.kind === "image" ? "Picture" : "Text", fileKind: f.kind, pages: f.pages, duration: f.duration })),
  ];

  const confirm = async () => {
    if (!picked) return;
    const link: Omit<ItemLink, "id"> = { targetKind: picked.kind, targetId: picked.id };
    if (picked.fileKind === "pdf") link.page = Math.max(1, Math.min(picked.pages ?? 10000, page));
    else if (picked.fileKind === "video" || picked.fileKind === "audio") link.t0 = Math.min(picked.duration ?? Infinity, parseClock(time));
    await addLink(note.id, link);
    setPicked(null);
    setPage(1);
    setTime("0:00");
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title="Add link">
      {!picked ? (
        <>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find a note, sketch or file" aria-label="Find what to link to" className="mb-3 h-10 w-full rounded-full bg-ink/[0.05] px-4 text-[14px] outline-none placeholder:text-muted/80 focus:ring-1 focus:ring-ink/15" dir="auto" />
          <ul className="max-h-[50dvh] divide-y divide-line overflow-y-auto rounded-2xl ring-1 ring-line">
            {rows.length === 0 ? (
              <li className="px-4 py-6 text-center text-[13px] text-muted">Nothing matches.</li>
            ) : (
              rows.slice(0, 40).map((r) => (
                <li key={`${r.kind}-${r.id}`}>
                  <button
                    onClick={() => {
                      setPicked(r);
                      setPage(1);
                      setTime("0:00");
                    }}
                    className="flex w-full items-center gap-3 px-3.5 py-2.5 text-left transition-colors hover:bg-ink/[0.03]"
                  >
                    <LinkIcon kind={r.kind} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium" dir="auto">{r.name}</span>
                      <span className="block text-[12px] text-muted">{r.sub}</span>
                    </span>
                  </button>
                </li>
              ))
            )}
          </ul>
        </>
      ) : (
        <div className="space-y-3">
          <p className="truncate text-[14px] font-medium" dir="auto">
            {picked.name}
          </p>
          {picked.fileKind === "pdf" ? (
            <label className="flex items-center gap-3 text-[13px]">
              <span className="font-medium">Page</span>
              <input type="number" min={1} max={picked.pages ?? 10000} value={page} onChange={(e) => setPage(Math.max(1, Math.min(picked.pages ?? 10000, Number(e.target.value) || 1)))} aria-label="Page number" className="h-10 w-24 rounded-xl bg-ink/[0.05] px-3 text-[16px] outline-none" />
              {picked.pages && <span className="text-muted">of {picked.pages}</span>}
            </label>
          ) : picked.fileKind === "video" || picked.fileKind === "audio" ? (
            <label className="flex items-center gap-3 text-[13px]">
              <span className="font-medium">Timestamp</span>
              <input value={time} onChange={(e) => setTime(e.target.value)} inputMode="numeric" placeholder="3:25" aria-label="Timestamp (minutes:seconds)" className="h-10 w-28 rounded-xl bg-ink/[0.05] px-3 text-[16px] tabular-nums outline-none" />
              {picked.duration !== undefined && <span className="text-muted">of {clock(picked.duration)}</span>}
            </label>
          ) : (
            <p className="text-[13px] text-muted">The whole item is linked.</p>
          )}
          <div className="flex gap-2">
            <Button variant="soft" className="flex-1" onClick={() => setPicked(null)}>
              Back
            </Button>
            <Button className="flex-1" onClick={() => void confirm()}>
              Add link
            </Button>
          </div>
        </div>
      )}
    </Sheet>
  );
}

const parseClock = (v: string): number => {
  const parts = v.trim().split(":").map(Number);
  if (parts.some((n) => !Number.isFinite(n) || n < 0) || parts.length > 3) return 0;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] ?? 0;
};

/** "Linked from" list shown on a link target (a file, note or sketch). */
export function LinkedFrom({ projectId, targetKind, targetId, onOpen }: { projectId: string; targetKind: ItemLink["targetKind"]; targetId: string; onOpen: (noteId: string) => void }) {
  const from = useLiveQuery(() => linkedFrom(projectId, targetKind, targetId), [projectId, targetKind, targetId]);
  if (!from?.length) return null;
  return (
    <section className="mt-6" aria-label="Linked from">
      <h3 className="mb-2 flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-muted">
        <Link2 size={12} /> Linked from
      </h3>
      <ul className="space-y-1.5">
        {from.map(({ note, link }) => (
          <li key={link.id}>
            <button onClick={() => onOpen(note.id)} className="flex w-full items-center gap-2.5 rounded-xl bg-card px-3 py-2 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.03]">
              <FileText size={14} className="shrink-0 text-muted" />
              <span className="min-w-0 flex-1 truncate text-[13px] font-medium" dir="auto">
                {note.title || "Untitled note"}
              </span>
              {(link.page || link.t0 !== undefined) && <span className="shrink-0 text-[12px] tabular-nums text-muted">{link.page ? `p.${link.page}` : clock(link.t0 ?? 0)}</span>}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

