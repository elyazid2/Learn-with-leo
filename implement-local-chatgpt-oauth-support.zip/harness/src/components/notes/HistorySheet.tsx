import { useEffect, useState } from "react";
import { History, RotateCcw } from "lucide-react";
import { db, type Note } from "@/lib/db";
import { listVersions, restoreVersion } from "@/lib/noteVersions";
import { useApp } from "@/lib/store";
import { Sheet, Button } from "@/components/ui";
import { cn } from "@/utils/cn";

/**
 * Version history for a note: every approved edit Leo made saved the previous version.
 * Pick one to see it next to the current text, then restore it with one tap (the current
 * text is kept as a version too, so restoring is undoable).
 */
export default function HistorySheet({ noteId, open, onClose }: { noteId: string; open: boolean; onClose: () => void }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [note, setNote] = useState<Note | null>(null);

  // Load fresh whenever the sheet opens.
  useEffect(() => {
    if (!open) {
      setNote(null);
      setSelected(null);
      return;
    }
    let alive = true;
    void db.notes.get(noteId).then((n) => {
      if (alive) setNote(n ?? null);
    });
    return () => {
      alive = false;
    };
  }, [open, noteId]);

  const versions = note ? listVersions(note) : [];
  const current = note?.content ?? "";
  const chosen = selected !== null ? versions[selected] : undefined;

  const restore = async () => {
    if (selected === null || restoring) return;
    setRestoring(true);
    const ok = await restoreVersion(noteId, selected);
    setRestoring(false);
    if (ok) {
      useApp.getState().showToast("Restored that version", { tone: "success" });
      onClose();
    } else useApp.getState().showToast("That version is no longer available");
  };

  return (
    <Sheet open={open} onClose={onClose} title="History" wide>
      {!note ? (
        <p className="py-6 text-center text-[13px] text-muted">Loading…</p>
      ) : versions.length === 0 ? (
        <div className="flex flex-col items-center py-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/[0.05] text-muted">
            <History size={20} />
          </span>
          <p className="mt-3 text-[14px] font-semibold">No earlier versions</p>
          <p className="mt-0.5 max-w-[280px] text-[13px] text-muted">Every edit Leo makes saves the previous version here automatically.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <ul className="divide-y divide-line overflow-hidden rounded-2xl ring-1 ring-line">
            {[...versions].reverse().map((v, ri) => {
              const i = versions.length - 1 - ri;
              const active = selected === i;
              return (
                <li key={`${v.at}-${i}`}>
                  <button
                    onClick={() => setSelected(active ? null : i)}
                    aria-pressed={active}
                    className={cn("flex w-full items-center gap-3 px-3.5 py-2.5 text-left transition-colors", active ? "bg-ink/[0.06]" : "hover:bg-ink/[0.03]")}
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink/[0.05] text-[12px] font-bold text-muted">
                      {v.replacedBy === "ai" ? "L" : "You"}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium" dir="auto">
                        {v.title || "Untitled"}
                      </span>
                      <span className="block text-[12px] text-muted">
                        {new Date(v.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} · replaced by {v.replacedBy === "ai" ? "Leo" : "you"}
                      </span>
                    </span>
                    {active && <span className="shrink-0 rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">Viewing</span>}
                  </button>
                </li>
              );
            })}
          </ul>

          {chosen && (
            <div className="fade-in">
              <div className="grid gap-3 sm:grid-cols-2">
                <section className="overflow-hidden rounded-2xl ring-1 ring-line">
                  <h3 className="border-b border-line bg-ink/[0.03] px-3.5 py-2 text-[12px] font-semibold text-muted">That version</h3>
                  <div className="border-b border-line px-3.5 py-2 text-[12px] text-muted"><strong className="font-semibold text-ink">{chosen.title || "Untitled"}</strong>{chosen.folder ? ` · ${chosen.folder}` : ""}{chosen.tags?.length ? ` · ${chosen.tags.map((tag) => `#${tag}`).join(" ")}` : ""}</div>
                  <pre className="max-h-[40dvh] overflow-y-auto whitespace-pre-wrap p-3.5 text-[13px] leading-relaxed" dir="auto">
                    {chosen.content || "(empty)"}
                  </pre>
                </section>
                <section className="overflow-hidden rounded-2xl ring-1 ring-line">
                  <h3 className="border-b border-line bg-ink/[0.03] px-3.5 py-2 text-[12px] font-semibold text-muted">Current</h3>
                  <div className="border-b border-line px-3.5 py-2 text-[12px] text-muted"><strong className="font-semibold text-ink">{note.title || "Untitled"}</strong>{note.folder ? ` · ${note.folder}` : ""}{note.tags?.length ? ` · ${note.tags.map((tag) => `#${tag}`).join(" ")}` : ""}</div>
                  <pre className="max-h-[40dvh] overflow-y-auto whitespace-pre-wrap p-3.5 text-[13px] leading-relaxed" dir="auto">
                    {current || "(empty)"}
                  </pre>
                </section>
              </div>
              <Button size="lg" className="mt-3 w-full" disabled={restoring} onClick={() => void restore()}>
                <RotateCcw size={16} /> {restoring ? "Restoring…" : "Restore this version"}
              </Button>
            </div>
          )}
        </div>
      )}
    </Sheet>
  );
}
