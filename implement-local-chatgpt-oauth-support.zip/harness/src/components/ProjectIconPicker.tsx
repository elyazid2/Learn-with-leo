import { useRef, useState } from "react";
import { ChevronDown, ChevronUp, ImagePlus, Loader2, Search } from "lucide-react";
import type { ProjectIcon } from "@/lib/db";
import { COMMON_ICONS, ICON_CHOICES, ICON_GROUPS, defaultIconFor, iconComponent, iconLabel, iconOf } from "@/lib/projectIcon";
import { iconFromImage } from "@/lib/media";
import ProjectAvatar from "./ProjectAvatar";
import { Button, Segmented } from "./ui";
import { cn } from "@/utils/cn";

type Tab = "icon" | "image";

/** Choose a project icon: a minimal line icon from a curated set, or an uploaded image/logo. */
export default function ProjectIconPicker({ value, onChange, tag }: { value?: ProjectIcon; onChange: (icon: ProjectIcon) => void; tag: string }) {
  // Older projects may hold an emoji; the picker works with the line icon that stands in for it.
  const shown = iconOf({ icon: value, tag });
  const [tab, setTab] = useState<Tab>(shown.kind);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  // Only a short row of icons is shown at first; "More icons" opens the whole set, grouped and searchable.
  const [more, setMore] = useState(false);
  const [query, setQuery] = useState("");
  const lastIcon = useRef(shown.kind === "icon" ? shown.name : defaultIconFor(tag));
  const lastImage = useRef(shown.kind === "image" ? shown.src : "");

  const term = query.trim().toLowerCase();
  const matches = term ? ICON_CHOICES.filter((n) => n.replace(/-/g, " ").includes(term)) : [];
  // An icon chosen from the full set (or a tag's default) stays visible in the short row.
  const picked = shown.kind === "icon" ? shown.name : "";
  const commonWithSelected = picked && !COMMON_ICONS.includes(picked) ? [...COMMON_ICONS.slice(0, COMMON_ICONS.length - 1), picked] : COMMON_ICONS;

  const chooseIcon = (name: string) => {
    lastIcon.current = name;
    onChange({ kind: "icon", name });
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setError("");
    if (t === "icon" && shown.kind !== "icon") onChange({ kind: "icon", name: lastIcon.current });
    if (t === "image" && shown.kind !== "image" && lastImage.current) onChange({ kind: "image", src: lastImage.current });
  };

  const onFile = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    setError("");
    const src = await iconFromImage(file);
    setBusy(false);
    if (!src) {
      setError("That image couldn't be read. Try a PNG, JPG, SVG or WebP.");
      return;
    }
    lastImage.current = src;
    onChange({ kind: "image", src });
  };

  return (
    <div>
      <div className="flex items-center gap-4">
        <ProjectAvatar project={{ icon: shown, tag, name: "Preview" }} size={60} />
        <Segmented<Tab>
          value={tab}
          onChange={switchTab}
          options={[
            { value: "icon", label: "Icon" },
            { value: "image", label: "Image or logo" },
          ]}
        />
      </div>

      {tab === "icon" ? (
        <div className="mt-3">
          {more && (
            <label className="fade-in relative mb-2 block">
              <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={`Search ${ICON_CHOICES.length} icons`}
                aria-label="Search icons"
                className="h-9 w-full rounded-full bg-ink/[0.05] pl-9 pr-3 text-[16px] outline-none placeholder:text-muted/80 focus:ring-1 focus:ring-ink/15 sm:text-[14px]"
              />
            </label>
          )}
          {!more ? (
            <IconGrid names={commonWithSelected} shown={shown} onChoose={chooseIcon} />
          ) : (
            <div className="max-h-[17rem] space-y-3 overflow-y-auto overscroll-contain pr-0.5" role="presentation">
              {term ? (
                matches.length ? (
                  <IconGrid names={matches} shown={shown} onChoose={chooseIcon} />
                ) : (
                  <p className="py-6 text-center text-[13px] text-muted">No icon matches “{query}”.</p>
                )
              ) : (
                ICON_GROUPS.map((g) => (
                  <section key={g.label}>
                    <h4 className="mb-1 px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">{g.label}</h4>
                    <IconGrid names={g.icons} shown={shown} onChoose={chooseIcon} />
                  </section>
                ))
              )}
            </div>
          )}
          <button
            type="button"
            onClick={() => {
              setMore((m) => !m);
              setQuery("");
            }}
            aria-expanded={more}
            className="mt-2 inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-[13px] font-medium text-muted ring-1 ring-line transition-colors hover:bg-ink/[0.04] hover:text-ink"
          >
            {more ? (
              <>
                <ChevronUp size={15} /> Fewer icons
              </>
            ) : (
              <>
                <ChevronDown size={15} /> More icons
                <span className="tabular-nums text-muted/80">· {ICON_CHOICES.length} in all</span>
              </>
            )}
          </button>
        </div>
      ) : (
        <div className="mt-3 rounded-2xl bg-ink/[0.035] p-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <Button type="button" variant="soft" onClick={() => fileRef.current?.click()} disabled={busy}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} />}
              {shown.kind === "image" ? "Change image" : "Choose image"}
            </Button>
            {shown.kind === "image" && (
              <Button type="button" variant="ghost" onClick={() => switchTab("icon")}>
                Use an icon instead
              </Button>
            )}
          </div>
          <p className="mt-2 text-[12px] leading-relaxed text-muted">Photos are cropped to a square. Logos with a transparent background are kept whole.</p>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              void onFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </div>
      )}
      {error && <p className="mt-2 text-[12px] text-danger-fg">{error}</p>}
    </div>
  );
}

function IconGrid({ names, shown, onChoose }: { names: string[]; shown: ReturnType<typeof iconOf>; onChoose: (name: string) => void }) {
  return (
    <div className="grid grid-cols-8 gap-1" role="listbox" aria-label="Icon">
      {names.map((name) => {
        const selected = shown.kind === "icon" && shown.name === name;
        const Glyph = iconComponent(name);
        return (
          <button
            key={name}
            type="button"
            role="option"
            aria-selected={selected}
            aria-label={iconLabel(name)}
            title={iconLabel(name)}
            onClick={() => onChoose(name)}
            className={cn(
              "flex aspect-square items-center justify-center rounded-xl transition-[background-color,color,transform] active:scale-90",
              selected ? "bg-ink/[0.08] text-ink ring-2 ring-ink" : "text-ink/70 hover:bg-ink/[0.05] hover:text-ink"
            )}
          >
            <Glyph size={20} strokeWidth={1.75} />
          </button>
        );
      })}
    </div>
  );
}
