import { useEffect, useLayoutEffect, useRef, useState, type PointerEvent as RPointerEvent, type ReactNode } from "react";
import { Calculator, Check, CheckSquare, Clock, Copy, Delete, Flag, History, Layers, ListChecks, Minus, Pause, Pencil, Play, Plus, RotateCcw, Ruler, Shuffle, ArrowUpDown, Trash2, X } from "lucide-react";
import { uid, type ToolItem, type ToolKind } from "@/lib/db";
import { saveToolState } from "@/lib/tools";
import { useApp } from "@/lib/store";
import { Button, inputCls } from "@/components/ui";
import { cn } from "@/utils/cn";

export const TOOL_ICON: Record<ToolKind, (size: number) => ReactNode> = {
  clock: (s) => <Clock size={s} />,
  calculator: (s) => <Calculator size={s} />,
  converter: (s) => <Ruler size={s} />,
  checklist: (s) => <CheckSquare size={s} />,
  flashcards: (s) => <Layers size={s} />,
};

/** First-time size of each tool's floating window. */
export const TOOL_SIZE: Record<ToolKind, { w: number; h: number }> = {
  clock: { w: 340, h: 500 },
  calculator: { w: 320, h: 500 },
  converter: { w: 360, h: 380 },
  checklist: { w: 340, h: 440 },
  flashcards: { w: 380, h: 540 },
};

/** Keeps a tool's state locally and writes every change through to the library item. */
function useToolState<T extends Record<string, unknown>>(tool: ToolItem, defaults: T): [T, (patch: Partial<T> | ((s: T) => Partial<T>)) => void] {
  const [state, setState] = useState<T>(() => ({ ...defaults, ...(tool.state as Partial<T>) }));
  const ref = useRef(state);
  const set = (patch: Partial<T> | ((s: T) => Partial<T>)) => {
    const next = { ...ref.current, ...(typeof patch === "function" ? patch(ref.current) : patch) };
    ref.current = next;
    setState(next);
    void saveToolState(tool.id, next);
  };
  return [state, set];
}

function useTick(active: boolean, ms = 200) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [active, ms]);
  return active ? now : Date.now();
}

function beep() {
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    [0, 0.35, 0.7].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.25);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.3);
    });
    window.setTimeout(() => void ctx.close(), 1500);
  } catch {
    /* no audio */
  }
  navigator.vibrate?.([200, 100, 200]);
}

const fmt = (ms: number, tenths = false) => {
  const total = Math.max(0, ms);
  const h = Math.floor(total / 3_600_000);
  const m = Math.floor((total % 3_600_000) / 60_000);
  const s = Math.floor((total % 60_000) / 1000);
  const d = Math.floor((total % 1000) / 100);
  return `${h ? `${h}:` : ""}${h ? String(m).padStart(2, "0") : m}:${String(s).padStart(2, "0")}${tenths ? `.${d}` : ""}`;
};

const roundBtn = "flex h-12 w-12 items-center justify-center rounded-full transition-[transform,background-color] active:scale-95";
const softBtn = "bg-ink/[0.06] text-ink hover:bg-ink/10 disabled:opacity-40";
const mainBtn = "h-14 w-14 bg-ink text-on-ink shadow-[0_6px_18px_rgba(0,0,0,0.18)] hover:bg-ink/90 disabled:opacity-40";

/* ------------------------------------------------------------ shared bits */

/** A clear segmented control: a tinted track with a raised pill on the active option. */
function Tabs<T extends string>({ value, options, onChange, label }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div role="tablist" aria-label={label} className="grid auto-cols-fr grid-flow-col gap-1 rounded-full bg-ink/[0.06] p-1">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={cn(
              "h-8 truncate rounded-full px-2 text-[13px] font-semibold transition-[background-color,color,box-shadow]",
              active ? "bg-card text-ink shadow-[0_1px_4px_rgba(0,0,0,0.12)] ring-1 ring-black/[0.04]" : "text-muted hover:text-ink"
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/** A thick circular progress ring with content in the middle. */
function Ring({ progress, tone = "text-ink", children }: { progress: number; tone?: string; children: ReactNode }) {
  const R = 52;
  const C = 2 * Math.PI * R;
  const p = Math.min(1, Math.max(0, progress));
  return (
    <div className="relative mx-auto aspect-square w-[min(74cqw,240px)]">
      <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full -rotate-90" aria-hidden>
        <circle cx="60" cy="60" r={R} fill="none" stroke="currentColor" strokeWidth="9" className="text-ink/[0.07]" />
        <circle
          cx="60"
          cy="60"
          r={R}
          fill="none"
          stroke="currentColor"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - p)}
          className={cn("transition-[stroke-dashoffset] duration-200 ease-linear", tone)}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

/** A labelled number field with − / + steppers, for minutes and seconds. */
function Stepper({ label, value, min, max, onChange, disabled }: { label: string; value: number; min: number; max: number; onChange: (v: number) => void; disabled?: boolean }) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  const commit = (raw: string) => {
    const n = Math.round(Number(raw));
    if (raw.trim() === "" || !Number.isFinite(n)) return setDraft(String(value));
    const v = Math.max(min, Math.min(max, n));
    setDraft(String(v));
    if (v !== value) onChange(v);
  };
  const step = (d: number) => onChange(Math.max(min, Math.min(max, value + d)));
  return (
    <div className={cn("rounded-2xl bg-ink/[0.035] px-2 pb-2 pt-1.5 ring-1 ring-line", disabled && "opacity-50")}>
      <div className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">{label}</div>
      <div className="mt-1 flex items-center gap-1">
        <button type="button" disabled={disabled || value <= min} onClick={() => step(-1)} aria-label={`Less ${label.toLowerCase()}`} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-card ring-1 ring-line transition-colors hover:bg-ink/[0.04] disabled:opacity-40">
          <Minus size={14} />
        </button>
        <input
          type="text"
          inputMode="numeric"
          disabled={disabled}
          value={draft}
          aria-label={label}
          onChange={(e) => {
            const v = e.target.value.replace(/[^\d]/g, "").slice(0, 3);
            setDraft(v);
            if (v !== "" && Number(v) >= min && Number(v) <= max) onChange(Number(v));
          }}
          onBlur={(e) => commit(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && commit(e.currentTarget.value)}
          className="h-8 min-w-0 flex-1 rounded-lg bg-transparent text-center text-[19px] font-semibold tabular-nums outline-none focus:bg-card focus:ring-1 focus:ring-ink/15"
        />
        <button type="button" disabled={disabled || value >= max} onClick={() => step(1)} aria-label={`More ${label.toLowerCase()}`} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-card ring-1 ring-line transition-colors hover:bg-ink/[0.04] disabled:opacity-40">
          <Plus size={14} />
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ clock */

type ClockState = {
  tab: "pomodoro" | "stopwatch" | "countdown";
  work: number;
  brk: number;
  phase: "work" | "break";
  pEndsAt: number | null;
  pLeft: number | null;
  rounds: number;
  swStart: number | null;
  swElapsed: number;
  laps: number[];
  cdMinutes: number;
  cdSeconds: number;
  cdEndsAt: number | null;
  cdLeft: number | null;
};

const CLOCK_DEFAULTS: ClockState = {
  tab: "pomodoro",
  work: 25,
  brk: 5,
  phase: "work",
  pEndsAt: null,
  pLeft: null,
  rounds: 0,
  swStart: null,
  swElapsed: 0,
  laps: [],
  cdMinutes: 5,
  cdSeconds: 0,
  cdEndsAt: null,
  cdLeft: null,
};

const ringDigits = "display leading-none tabular-nums text-[clamp(30px,13cqw,56px)]";

function ClockTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<ClockState>(tool, CLOCK_DEFAULTS);
  const running = s.pEndsAt !== null || s.swStart !== null || s.cdEndsAt !== null;
  const now = useTick(true, running ? 100 : 1000);

  // Finishing a pomodoro phase or a countdown rings once and stops.
  useEffect(() => {
    if (s.pEndsAt !== null && now >= s.pEndsAt) {
      beep();
      const nextPhase = s.phase === "work" ? "break" : "work";
      set({ pEndsAt: null, pLeft: null, phase: nextPhase, rounds: s.phase === "work" ? s.rounds + 1 : s.rounds });
      useApp.getState().showToast(s.phase === "work" ? "Focus block done — take a break" : "Break over — back to it");
    }
    if (s.cdEndsAt !== null && now >= s.cdEndsAt) {
      beep();
      set({ cdEndsAt: null, cdLeft: null });
      useApp.getState().showToast("Countdown finished");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [now]);

  const phaseMs = (s.phase === "work" ? s.work : s.brk) * 60_000;
  const pLeft = s.pEndsAt !== null ? s.pEndsAt - now : s.pLeft ?? phaseMs;
  const sw = s.swElapsed + (s.swStart !== null ? now - s.swStart : 0);
  const cdTotal = (s.cdMinutes * 60 + s.cdSeconds) * 1000;
  const cdLeft = s.cdEndsAt !== null ? s.cdEndsAt - now : s.cdLeft ?? cdTotal;
  const cdIdle = s.cdEndsAt === null && s.cdLeft === null;
  const pIdle = s.pEndsAt === null && s.pLeft === null;

  return (
    <div className="flex min-h-full flex-col gap-4 px-4 pb-6 pt-3">
      <Tabs
        value={s.tab}
        onChange={(tab) => set({ tab })}
        label="Clock mode"
        options={[
          { value: "pomodoro", label: "Pomodoro" },
          { value: "stopwatch", label: "Stopwatch" },
          { value: "countdown", label: "Timer" },
        ]}
      />
      <div className="-mt-1 text-center text-[12px] font-medium tabular-nums text-muted">{new Date(now).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}</div>

      {s.tab === "pomodoro" && (
        <div className="flex flex-col items-center gap-4">
          <Ring progress={1 - pLeft / phaseMs} tone={s.phase === "work" ? "text-ink" : "text-solid"}>
            <span className={cn("mb-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold", s.phase === "work" ? "bg-ink text-on-ink" : "bg-ok-bg text-ok-fg")}>
              {s.phase === "work" ? "Focus" : "Break"} · {s.rounds + 1}
            </span>
            <span className={ringDigits} role="timer">
              {fmt(pLeft)}
            </span>
          </Ring>
          <div className="flex items-center justify-center gap-4">
            <button className={cn(roundBtn, softBtn)} aria-label="Reset" onClick={() => set({ pEndsAt: null, pLeft: null })}>
              <RotateCcw size={19} />
            </button>
            {s.pEndsAt !== null ? (
              <button className={cn(roundBtn, mainBtn)} aria-label="Pause" onClick={() => set({ pEndsAt: null, pLeft: s.pEndsAt! - Date.now() })}>
                <Pause size={22} />
              </button>
            ) : (
              <button className={cn(roundBtn, mainBtn)} aria-label="Start" onClick={() => set({ pEndsAt: Date.now() + (s.pLeft ?? phaseMs) })}>
                <Play size={22} className="ml-0.5" />
              </button>
            )}
            <button className={cn(roundBtn, softBtn)} aria-label="Skip phase" title="Skip phase" onClick={() => set({ pEndsAt: null, pLeft: null, phase: s.phase === "work" ? "break" : "work" })}>
              <Flag size={19} />
            </button>
          </div>
          <div className="grid w-full max-w-xs grid-cols-2 gap-2.5">
            <Stepper label="Focus" value={s.work} min={1} max={180} disabled={!pIdle} onChange={(work) => set({ work, pLeft: null })} />
            <Stepper label="Break" value={s.brk} min={1} max={60} disabled={!pIdle} onChange={(brk) => set({ brk, pLeft: null })} />
          </div>
        </div>
      )}

      {s.tab === "stopwatch" && (
        <div className="flex flex-col items-center gap-5 pt-4">
          <div className="display leading-none tabular-nums text-[clamp(40px,17cqw,80px)]" role="timer">
            {fmt(sw, true)}
          </div>
          <div className="flex items-center justify-center gap-4">
            <button className={cn(roundBtn, softBtn)} aria-label="Reset" onClick={() => set({ swStart: null, swElapsed: 0, laps: [] })}>
              <RotateCcw size={19} />
            </button>
            {s.swStart !== null ? (
              <button className={cn(roundBtn, mainBtn)} aria-label="Pause" onClick={() => set({ swStart: null, swElapsed: sw })}>
                <Pause size={22} />
              </button>
            ) : (
              <button className={cn(roundBtn, mainBtn)} aria-label="Start" onClick={() => set({ swStart: Date.now() })}>
                <Play size={22} className="ml-0.5" />
              </button>
            )}
            <button className={cn(roundBtn, softBtn)} aria-label="Lap" disabled={!sw} onClick={() => set({ laps: [sw, ...s.laps].slice(0, 50) })}>
              <Flag size={19} />
            </button>
          </div>
          {s.laps.length > 0 && (
            <ol className="w-full max-w-xs divide-y divide-line rounded-2xl bg-card text-[14px] tabular-nums ring-1 ring-line">
              {s.laps.map((l, i) => (
                <li key={i} className="flex justify-between px-4 py-2">
                  <span className="text-muted">Lap {s.laps.length - i}</span>
                  <span className="font-medium">{fmt(l, true)}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      )}

      {s.tab === "countdown" && (
        <div className="flex flex-col items-center gap-4">
          <Ring progress={cdIdle || !cdTotal ? 0 : 1 - cdLeft / Math.max(cdTotal, cdLeft)} tone={cdLeft < 10_000 && !cdIdle ? "text-danger-fg" : "text-ink"}>
            <span className={ringDigits} role="timer">
              {fmt(cdLeft)}
            </span>
          </Ring>
          <div className="flex items-center justify-center gap-4">
            <button className={cn(roundBtn, softBtn)} aria-label="Reset" onClick={() => set({ cdEndsAt: null, cdLeft: null })}>
              <RotateCcw size={19} />
            </button>
            {s.cdEndsAt !== null ? (
              <button className={cn(roundBtn, mainBtn)} aria-label="Pause" onClick={() => set({ cdEndsAt: null, cdLeft: s.cdEndsAt! - Date.now() })}>
                <Pause size={22} />
              </button>
            ) : (
              <button className={cn(roundBtn, mainBtn)} disabled={!cdTotal && !s.cdLeft} aria-label="Start" onClick={() => set({ cdEndsAt: Date.now() + (s.cdLeft ?? cdTotal) })}>
                <Play size={22} className="ml-0.5" />
              </button>
            )}
          </div>
          <div className="grid w-full max-w-xs grid-cols-2 gap-2.5">
            <Stepper label="Minutes" value={s.cdMinutes} min={0} max={600} disabled={!cdIdle} onChange={(cdMinutes) => set({ cdMinutes })} />
            <Stepper label="Seconds" value={s.cdSeconds} min={0} max={59} disabled={!cdIdle} onChange={(cdSeconds) => set({ cdSeconds })} />
          </div>
          {cdIdle && (
            <div className="no-scrollbar -mx-4 flex w-[calc(100%+2rem)] gap-1.5 overflow-x-auto px-4">
              {[1, 5, 10, 15, 30, 45, 60].map((m) => (
                <button
                  key={m}
                  onClick={() => set({ cdMinutes: m, cdSeconds: 0 })}
                  className={cn(
                    "h-8 shrink-0 rounded-full px-3 text-[12px] font-semibold transition-colors",
                    s.cdMinutes === m && s.cdSeconds === 0 ? "bg-ink text-on-ink" : "bg-ink/[0.05] text-ink/80 hover:bg-ink/[0.09]"
                  )}
                >
                  {m} min
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------- calculator */

const FUNCS: Record<string, (x: number, deg: boolean) => number> = {
  sqrt: (x) => Math.sqrt(x),
  abs: (x) => Math.abs(x),
  ln: (x) => Math.log(x),
  log: (x) => Math.log10(x),
  sin: (x, d) => Math.sin(d ? (x * Math.PI) / 180 : x),
  cos: (x, d) => Math.cos(d ? (x * Math.PI) / 180 : x),
  tan: (x, d) => Math.tan(d ? (x * Math.PI) / 180 : x),
};

/** A small recursive-descent evaluator: + − × ÷ ^ %, parentheses, functions, π and e. No eval. */
export function evaluate(input: string, deg = true): number {
  const src = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/π/g, "pi").replace(/\s+/g, "");
  let i = 0;
  const peek = () => src[i];
  const expect = (c: string) => {
    if (src[i] !== c) throw new Error(`Expected ${c}`);
    i++;
  };
  const primary = (): number => {
    const c = peek();
    if (c === "(") {
      i++;
      const v = expr();
      expect(")");
      return v;
    }
    if (c === "-") {
      i++;
      return -power();
    }
    if (c === "+") {
      i++;
      return power();
    }
    const num = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(src.slice(i));
    if (num) {
      i += num[0].length;
      return parseFloat(num[0]);
    }
    const id = /^[a-z]+/i.exec(src.slice(i));
    if (id) {
      const name = id[0].toLowerCase();
      i += id[0].length;
      if (name === "pi") return Math.PI;
      if (name === "e") return Math.E;
      const f = FUNCS[name];
      if (!f) throw new Error(`Unknown function ${name}`);
      expect("(");
      const v = expr();
      expect(")");
      return f(v, deg);
    }
    throw new Error("Unexpected input");
  };
  const postfix = (): number => {
    let v = primary();
    while (peek() === "%") {
      i++;
      v = v / 100;
    }
    return v;
  };
  const power = (): number => {
    const base = postfix();
    if (peek() === "^") {
      i++;
      return Math.pow(base, power());
    }
    return base;
  };
  const term = (): number => {
    let v = power();
    while (peek() === "*" || peek() === "/") {
      const op = src[i++];
      const r = power();
      v = op === "*" ? v * r : v / r;
    }
    return v;
  };
  const expr = (): number => {
    let v = term();
    while (peek() === "+" || peek() === "-") {
      const op = src[i++];
      const r = term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  };
  if (!src) throw new Error("Empty");
  const v = expr();
  if (i < src.length) throw new Error("Unexpected input");
  return v;
}

const showNum = (v: number) => (Number.isFinite(v) ? String(Number(v.toPrecision(12))) : v > 0 ? "∞" : v < 0 ? "-∞" : "Error");

/** Font size that shrinks as a line grows, so long numbers stay readable instead of being cut off. */
const fitSize = (len: number, big: number, small: number) => Math.max(small, Math.min(big, big - (len - 10) * 0.9));

function CalculatorTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ expr: string; deg: boolean; history: { e: string; r: string }[] }>(tool, { expr: "", deg: true, history: [] });
  const [showHistory, setShowHistory] = useState(false);
  const exprRef = useRef<HTMLInputElement>(null);
  let preview = "";
  try {
    preview = s.expr ? showNum(evaluate(s.expr, s.deg)) : "";
  } catch {
    preview = "";
  }
  // Keep the end of a long expression in view as you type on the keypad.
  useLayoutEffect(() => {
    const el = exprRef.current;
    if (el && document.activeElement !== el) el.scrollLeft = el.scrollWidth;
  }, [s.expr]);

  const press = (k: string) => {
    if (k === "C") return set({ expr: "" });
    if (k === "⌫") return set({ expr: s.expr.slice(0, -1) });
    if (k === "=") {
      try {
        const r = showNum(evaluate(s.expr, s.deg));
        set({ expr: r === "Error" ? s.expr : r, history: [{ e: s.expr, r }, ...s.history].slice(0, 20) });
      } catch {
        useApp.getState().showToast("That expression isn't complete");
      }
      return;
    }
    set({ expr: s.expr + k });
  };
  const keys = ["C", "(", ")", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "⌫", "="];
  const fns: [string, string][] = [
    ["√", "sqrt("],
    ["xʸ", "^"],
    ["%", "%"],
    ["π", "π"],
    ["e", "e"],
    ["sin", "sin("],
    ["cos", "cos("],
    ["tan", "tan("],
    ["log", "log("],
    ["ln", "ln("],
    ["|x|", "abs("],
  ];
  const result = preview && preview !== s.expr ? preview : "";

  return (
    <div className="flex h-full min-h-[340px] flex-col gap-2 p-3">
      <div className="shrink-0 rounded-2xl bg-card px-3.5 pb-2 pt-2.5 ring-1 ring-line">
        <input
          ref={exprRef}
          value={s.expr}
          onChange={(e) => set({ expr: e.target.value })}
          onKeyDown={(e) => e.key === "Enter" && press("=")}
          aria-label="Expression"
          inputMode="decimal"
          spellCheck={false}
          className={cn("w-full bg-transparent text-right tabular-nums outline-none transition-[font-size] duration-150 placeholder:text-muted/50", result ? "font-medium text-ink/65" : "display text-ink")}
          style={{ fontSize: result ? fitSize(s.expr.length, 20, 13) : fitSize(s.expr.length, 36, 16) }}
          placeholder="0"
        />
        {/* The live result line: empty until the expression has something to work out, then the expression shrinks above it. */}
        <div className="no-scrollbar min-h-[28px] overflow-x-auto whitespace-nowrap text-right" aria-live="polite" aria-label="Result">
          {result && (
            <span className="display tabular-nums leading-tight" style={{ fontSize: fitSize(result.length + 2, 34, 16) }}>
              = {result}
            </span>
          )}
        </div>
      </div>

      <div className="no-scrollbar -mx-3 flex shrink-0 gap-1 overflow-x-auto px-3" role="toolbar" aria-label="Scientific functions">
        <button onClick={() => set({ deg: !s.deg })} className="h-8 shrink-0 rounded-full bg-ink px-2.5 text-[11px] font-bold tracking-wide text-on-ink" aria-label={`Angle unit: ${s.deg ? "degrees" : "radians"}`}>
          {s.deg ? "DEG" : "RAD"}
        </button>
        {fns.map(([label, insert]) => (
          <button key={label} onClick={() => press(insert)} className="h-8 min-w-9 shrink-0 rounded-full bg-ink/[0.05] px-2.5 text-[13px] font-medium transition-colors hover:bg-ink/[0.09]">
            {label}
          </button>
        ))}
        <button onClick={() => setShowHistory((v) => !v)} aria-pressed={showHistory} aria-label="History" title="History" className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-colors", showHistory ? "bg-ink text-on-ink" : "bg-ink/[0.05] hover:bg-ink/[0.09]")}>
          <History size={14} />
        </button>
      </div>

      {showHistory ? (
        <div className="min-h-0 flex-1 overflow-y-auto rounded-2xl bg-card ring-1 ring-line">
          {s.history.length === 0 ? (
            <p className="px-3 py-8 text-center text-[13px] text-muted">No calculations yet</p>
          ) : (
            <ul className="divide-y divide-line text-[13px]">
              {s.history.map((h, i) => (
                <li key={i}>
                  <button
                    onClick={() => {
                      set({ expr: h.r });
                      setShowHistory(false);
                    }}
                    className="flex w-full flex-col items-end px-3 py-2 tabular-nums hover:bg-ink/[0.03]"
                  >
                    <span className="max-w-full truncate text-muted">{h.e}</span>
                    <span className="font-semibold">{h.r}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : (
        <div className="grid min-h-0 flex-1 grid-cols-4 grid-rows-5 gap-1.5">
          {keys.map((k) => (
            <button
              key={k}
              onClick={() => press(k)}
              aria-label={k === "⌫" ? "Backspace" : k === "C" ? "Clear" : undefined}
              className={cn(
                "flex min-h-9 items-center justify-center rounded-xl text-[clamp(15px,6.5cqw,22px)] font-medium transition-[transform,background-color] active:scale-[0.96]",
                k === "=" ? "bg-ink text-on-ink hover:bg-ink/90" : /[÷×−+]/.test(k) ? "bg-ink/10 hover:bg-ink/15" : k === "C" ? "bg-ink/[0.07] text-danger-fg hover:bg-ink/10" : "bg-card ring-1 ring-line hover:bg-ink/[0.03]"
              )}
            >
              {k === "⌫" ? <Delete size={18} /> : k}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* --------------------------------------------------------- unit converter */

const UNITS: Record<string, Record<string, number>> = {
  Length: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344 },
  Mass: { mg: 1e-6, g: 0.001, kg: 1, t: 1000, oz: 0.028349523125, lb: 0.45359237 },
  Volume: { ml: 0.001, l: 1, "m³": 1000, tsp: 0.00492892, tbsp: 0.0147868, cup: 0.236588, "fl oz": 0.0295735, gal: 3.785411784 },
  Area: { "cm²": 1e-4, "m²": 1, ha: 1e4, "km²": 1e6, "ft²": 0.09290304, acre: 4046.8564224 },
  Speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704, knot: 0.514444 },
  Time: { s: 1, min: 60, h: 3600, day: 86400, week: 604800, year: 31557600 },
  Data: { B: 1, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1048576, GiB: 1073741824 },
  Temperature: { "°C": 1, "°F": 1, K: 1 },
};

function convertTemp(v: number, from: string, to: string) {
  const c = from === "°C" ? v : from === "°F" ? ((v - 32) * 5) / 9 : v - 273.15;
  return to === "°C" ? c : to === "°F" ? (c * 9) / 5 + 32 : c + 273.15;
}

/** About six significant digits: enough for study work, without floating-point noise. */
export function round6(v: number): string {
  if (!Number.isFinite(v)) return "—";
  if (v === 0) return "0";
  const a = Math.abs(v);
  if (a >= 1e12 || a < 1e-6) return v.toExponential(5).replace(/\.?0+e/, "e");
  return String(Number(v.toPrecision(6)));
}

type ConverterState = { cat: string; from: string; to: string; value: string };
const CONVERTER_DEFAULTS: ConverterState = { cat: "Length", from: "m", to: "ft", value: "1" };

function convert(s: ConverterState) {
  const table = UNITS[s.cat] ?? UNITS.Length;
  const v = parseFloat(s.value.replace(",", "."));
  if (!Number.isFinite(v) || !(s.from in table) || !(s.to in table)) return { v, out: NaN };
  return { v, out: s.cat === "Temperature" ? convertTemp(v, s.from, s.to) : (v * table[s.from]) / table[s.to] };
}

function ConverterTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<ConverterState>(tool, CONVERTER_DEFAULTS);
  const [copied, setCopied] = useState(false);
  const units = Object.keys(UNITS[s.cat] ?? UNITS.Length);
  const { out } = convert(s);
  const shown = round6(out);
  const rowRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    rowRef.current?.querySelector<HTMLElement>('[aria-selected="true"]')?.scrollIntoView({ inline: "nearest", block: "nearest" });
  }, [s.cat]);
  const copy = async () => {
    if (!Number.isFinite(out)) return;
    try {
      await navigator.clipboard.writeText(shown);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      useApp.getState().showToast("Couldn't copy to the clipboard");
    }
  };
  return (
    <div className="flex flex-col gap-3 p-3">
      <div ref={rowRef} role="tablist" aria-label="Category" className="no-scrollbar -mx-3 flex snap-x gap-1.5 overflow-x-auto px-3">
        {Object.keys(UNITS).map((c) => (
          <button
            key={c}
            role="tab"
            aria-selected={c === s.cat}
            onClick={() => {
              const u = Object.keys(UNITS[c]);
              set({ cat: c, from: u[0], to: u[1] ?? u[0] });
            }}
            className={cn("h-8 shrink-0 snap-start whitespace-nowrap rounded-full px-3 text-[13px] font-medium transition-colors", c === s.cat ? "bg-ink text-on-ink" : "bg-ink/[0.05] hover:bg-ink/[0.09]")}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="relative space-y-1.5">
        <div className="flex items-center gap-2 rounded-2xl bg-card p-1.5 pl-3.5 ring-1 ring-line focus-within:ring-ink/25">
          <input value={s.value} onChange={(e) => set({ value: e.target.value })} inputMode="decimal" aria-label="Value" className="min-w-0 flex-1 bg-transparent text-[22px] font-medium tabular-nums outline-none" />
          <select value={s.from} onChange={(e) => set({ from: e.target.value })} aria-label="From unit" className="h-10 shrink-0 rounded-xl bg-ink/[0.05] px-2.5 text-[14px] font-medium outline-none">
            {units.map((u) => (
              <option key={u}>{u}</option>
            ))}
          </select>
        </div>
        <button
          onClick={() => set({ from: s.to, to: s.from })}
          aria-label="Swap units"
          className="absolute left-1/2 top-1/2 z-10 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-paper ring-1 ring-line transition-colors hover:bg-card"
        >
          <ArrowUpDown size={14} />
        </button>
        <div className="flex items-center gap-2 rounded-2xl bg-ink/[0.04] p-1.5 pl-3.5 ring-1 ring-line">
          <output className="no-scrollbar min-w-0 flex-1 overflow-x-auto whitespace-nowrap text-[22px] font-semibold tabular-nums" aria-live="polite">
            {shown}
          </output>
          <button onClick={() => void copy()} disabled={!Number.isFinite(out)} aria-label={copied ? "Copied" : "Copy result"} title="Copy" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-ink/70 transition-colors hover:bg-ink/[0.06] hover:text-ink disabled:opacity-30">
            {copied ? <Check size={16} className="text-ok-fg" /> : <Copy size={16} />}
          </button>
          <select value={s.to} onChange={(e) => set({ to: e.target.value })} aria-label="To unit" className="h-10 shrink-0 rounded-xl bg-card px-2.5 text-[14px] font-medium outline-none ring-1 ring-line">
            {units.map((u) => (
              <option key={u}>{u}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- checklist */

type CheckItem = { id: string; text: string; done: boolean };

/** One checklist row: tap to check, swipe left (or the trash button) to delete, pencil to edit. */
function CheckRow({ item, onToggle, onDelete, onEdit }: { item: CheckItem; onToggle: () => void; onDelete: () => void; onEdit: (text: string) => void }) {
  const [dx, setDx] = useState(0);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(item.text);
  const start = useRef<{ x: number; y: number; swiping: boolean; moved: boolean } | null>(null);
  const SWIPE = 84;

  const down = (e: RPointerEvent) => {
    if (editing || (e.target as HTMLElement).closest("button,input")) return;
    start.current = { x: e.clientX, y: e.clientY, swiping: false, moved: false };
  };
  const move = (e: RPointerEvent) => {
    const st = start.current;
    if (!st) return;
    const mx = e.clientX - st.x;
    const my = e.clientY - st.y;
    if (!st.swiping && Math.abs(mx) > 8 && Math.abs(mx) > Math.abs(my)) {
      st.swiping = true;
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    }
    if (Math.hypot(mx, my) > 6) st.moved = true;
    if (st.swiping) setDx(Math.min(0, Math.max(-160, mx)));
  };
  const up = () => {
    const st = start.current;
    start.current = null;
    if (!st) return;
    if (st.swiping) {
      if (dx <= -SWIPE) onDelete();
      setDx(0);
    } else if (!st.moved) onToggle();
  };
  const commit = () => {
    const t = draft.trim();
    if (t && t !== item.text) onEdit(t.slice(0, 300));
    else setDraft(item.text);
    setEditing(false);
  };

  return (
    <li className="relative overflow-hidden rounded-xl">
      <div aria-hidden className={cn("absolute inset-0 flex items-center justify-end rounded-xl pr-4 text-white transition-colors", dx <= -SWIPE ? "bg-danger-fg" : "bg-danger-fg/70")}>
        <Trash2 size={16} />
      </div>
      <div
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={() => {
          start.current = null;
          setDx(0);
        }}
        style={{ transform: dx ? `translateX(${dx}px)` : undefined }}
        className={cn("group relative flex cursor-pointer touch-pan-y select-none items-center gap-3 rounded-xl bg-card px-3 py-2.5 ring-1 ring-line", !dx && "transition-transform")}
      >
        <button
          onClick={onToggle}
          role="checkbox"
          aria-checked={item.done}
          aria-label={item.text}
          className={cn("flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-full ring-[1.5px] transition-colors", item.done ? "bg-ink text-on-ink ring-ink" : "ring-ink/30 hover:ring-ink/60")}
        >
          {item.done && <Check size={13} strokeWidth={3} />}
        </button>
        {editing ? (
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") commit();
              if (e.key === "Escape") {
                setDraft(item.text);
                setEditing(false);
              }
            }}
            aria-label="Edit item"
            dir="auto"
            className="min-w-0 flex-1 bg-transparent text-[15px] outline-none"
          />
        ) : (
          <span className={cn("min-w-0 flex-1 break-words text-[15px] leading-snug transition-colors", item.done && "text-muted line-through decoration-ink/30")} dir="auto">
            {item.text}
          </span>
        )}
        {!editing && (
          <span className="flex shrink-0 items-center opacity-100 transition-opacity [@media(hover:hover)]:opacity-0 [@media(hover:hover)]:group-hover:opacity-100 [@media(hover:hover)]:group-focus-within:opacity-100">
            <button
              onClick={() => {
                setDraft(item.text);
                setEditing(true);
              }}
              aria-label={`Edit “${item.text}”`}
              className="flex h-7 w-7 items-center justify-center rounded-full text-muted hover:bg-ink/[0.06] hover:text-ink"
            >
              <Pencil size={13} />
            </button>
            <button onClick={onDelete} aria-label={`Delete “${item.text}”`} className="flex h-7 w-7 items-center justify-center rounded-full text-muted hover:bg-danger-bg hover:text-danger-fg">
              <X size={15} />
            </button>
          </span>
        )}
      </div>
    </li>
  );
}

function ChecklistTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ items: CheckItem[] }>(tool, { items: [] });
  const [text, setText] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const done = s.items.filter((i) => i.done).length;
  const add = () => {
    const t = text.trim();
    if (!t) return inputRef.current?.focus();
    set({ items: [...s.items, { id: uid(), text: t.slice(0, 300), done: false }] });
    setText("");
    inputRef.current?.focus();
  };
  const patch = (id: string, p: Partial<CheckItem>) => set((st) => ({ items: st.items.map((x) => (x.id === id ? { ...x, ...p } : x)) }));
  return (
    <div className="flex min-h-full flex-col">
      {s.items.length > 0 && (
        <div className="shrink-0 px-3 pt-3">
          <div className="mb-1.5 flex items-center justify-between text-[12px]">
            <span className="font-semibold tabular-nums">
              {done}/{s.items.length} <span className="font-normal text-muted">done</span>
            </span>
            {done > 0 && (
              <button onClick={() => set({ items: s.items.filter((i) => !i.done) })} className="rounded-full px-2 py-0.5 font-medium text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink">
                Clear done
              </button>
            )}
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-ink/[0.08]">
            <div className="h-full rounded-full bg-ink transition-[width] duration-300" style={{ width: `${(done / s.items.length) * 100}%` }} />
          </div>
        </div>
      )}
      <div className="flex-1 px-3 py-3">
        {s.items.length === 0 ? (
          <div className="flex h-full min-h-[160px] flex-col items-center justify-center text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/[0.05] text-ink/60">
              <ListChecks size={22} />
            </span>
            <p className="mt-3 text-[15px] font-semibold">No items yet</p>
            <p className="mt-0.5 text-[13px] text-muted">Add your first task below.</p>
          </div>
        ) : (
          <ul className="space-y-1.5">
            {s.items.map((it) => (
              <CheckRow
                key={it.id}
                item={it}
                onToggle={() => patch(it.id, { done: !it.done })}
                onEdit={(t) => patch(it.id, { text: t })}
                onDelete={() => set((st) => ({ items: st.items.filter((x) => x.id !== it.id) }))}
              />
            ))}
          </ul>
        )}
      </div>
      <form
        className="sticky bottom-0 flex shrink-0 gap-2 border-t border-line/70 bg-paper/95 p-3 backdrop-blur"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <input ref={inputRef} value={text} onChange={(e) => setText(e.target.value)} placeholder="Add an item" aria-label="New checklist item" className={cn(inputCls, "h-10 flex-1")} dir="auto" />
        <Button type="submit" className="h-10 shrink-0">
          <Plus size={16} /> Add
        </Button>
      </form>
    </div>
  );
}

/* -------------------------------------------------------------- flash cards */

type FlashCard = { id: string; front: string; back: string; inSack: boolean };

function FlashcardsTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ cards: FlashCard[] }>(tool, { cards: [] });
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [current, setCurrent] = useState<string | null>(null);
  const [flipped, setFlipped] = useState(false);
  const sack = s.cards.filter((c) => c.inSack);
  const card = s.cards.find((c) => c.id === current && c.inSack) ?? null;

  const draw = (exclude?: string) => {
    const pool = s.cards.filter((c) => c.inSack && c.id !== exclude);
    const from = pool.length ? pool : s.cards.filter((c) => c.inSack);
    setCurrent(from.length ? from[Math.floor(Math.random() * from.length)].id : null);
    setFlipped(false);
  };
  const gotIt = () => {
    if (!card) return;
    const cards = s.cards.map((c) => (c.id === card.id ? { ...c, inSack: false } : c));
    set({ cards });
    const pool = cards.filter((c) => c.inSack);
    setCurrent(pool.length ? pool[Math.floor(Math.random() * pool.length)].id : null);
    setFlipped(false);
  };

  return (
    <div className="px-3 pb-5 pt-3">
      <div className="mb-3 flex items-center justify-between text-[13px] text-muted">
        <span>
          {sack.length} in the sack · {s.cards.length - sack.length} learned
        </span>
        {s.cards.length > 0 && sack.length < s.cards.length && (
          <button onClick={() => set({ cards: s.cards.map((c) => ({ ...c, inSack: true })) })} className="flex items-center gap-1 font-medium hover:text-ink">
            <RotateCcw size={13} /> Refill sack
          </button>
        )}
      </div>
      {card ? (
        <div>
          <button
            onClick={() => setFlipped((f) => !f)}
            className="flex min-h-[220px] w-full flex-col items-center justify-center rounded-3xl bg-card p-6 text-center shadow-[0_10px_30px_rgba(0,0,0,0.08)] ring-1 ring-line transition-transform active:scale-[0.99]"
            aria-label={flipped ? "Show front" : "Flip card"}
          >
            <span className="mb-3 text-[11px] font-semibold uppercase tracking-wide text-muted">{flipped ? "Back" : "Front"}</span>
            <span className="whitespace-pre-wrap text-[20px] font-medium leading-snug" dir="auto">
              {flipped ? card.back : card.front}
            </span>
            {!flipped && <span className="mt-4 text-[12px] text-muted">Tap to flip</span>}
          </button>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button size="lg" variant="soft" onClick={() => draw(card.id)}>
              <Shuffle size={16} /> Again later
            </Button>
            <Button size="lg" onClick={gotIt} disabled={!flipped}>
              <Check size={16} /> Got it
            </Button>
          </div>
        </div>
      ) : (
        <div className="rounded-3xl bg-ink/[0.035] p-6 text-center ring-1 ring-line">
          <Layers size={26} className="mx-auto text-muted" />
          <p className="mt-2 text-[14px] text-muted">{s.cards.length === 0 ? "Add a few cards below, then draw from the sack." : sack.length ? "Ready when you are." : "The sack is empty — you got them all. Refill it to go again."}</p>
          {sack.length > 0 && (
            <Button className="mt-3" onClick={() => draw()}>
              <Shuffle size={16} /> Draw a card
            </Button>
          )}
        </div>
      )}
      <form
        className="mt-6 space-y-2 rounded-2xl bg-card p-3 ring-1 ring-line"
        onSubmit={(e) => {
          e.preventDefault();
          if (!front.trim() || !back.trim()) return;
          set({ cards: [...s.cards, { id: uid(), front: front.trim(), back: back.trim(), inSack: true }] });
          setFront("");
          setBack("");
        }}
      >
        <div className="text-[13px] font-semibold">New card</div>
        <input value={front} onChange={(e) => setFront(e.target.value)} placeholder="Front (question)" aria-label="Card front" className={inputCls} dir="auto" />
        <input value={back} onChange={(e) => setBack(e.target.value)} placeholder="Back (answer)" aria-label="Card back" className={inputCls} dir="auto" />
        <Button type="submit" className="w-full" disabled={!front.trim() || !back.trim()}>
          <Plus size={16} /> Put in the sack
        </Button>
      </form>
      {s.cards.length > 0 && (
        <ul className="mt-4 divide-y divide-line rounded-2xl text-[13px] ring-1 ring-line">
          {s.cards.map((c) => (
            <li key={c.id} className="flex items-center gap-2 px-3 py-2">
              <span className={cn("h-2 w-2 shrink-0 rounded-full", c.inSack ? "bg-ink/30" : "bg-[#16a072]")} title={c.inSack ? "In the sack" : "Learned"} />
              <span className="min-w-0 flex-1 truncate" dir="auto">
                {c.front} <span className="text-muted">— {c.back}</span>
              </span>
              <button onClick={() => set({ cards: s.cards.filter((x) => x.id !== c.id) })} aria-label={`Delete card ${c.front}`} className="rounded-lg p-1 text-muted hover:bg-danger-bg hover:text-danger-fg">
                <X size={14} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* -------------------------------------------------------------- the body */

/** A tool's live content, shown inside its floating window. */
export function ToolBody({ tool }: { tool: ToolItem }) {
  if (tool.kind === "clock") return <ClockTool key={tool.id} tool={tool} />;
  if (tool.kind === "calculator") return <CalculatorTool key={tool.id} tool={tool} />;
  if (tool.kind === "converter") return <ConverterTool key={tool.id} tool={tool} />;
  if (tool.kind === "checklist") return <ChecklistTool key={tool.id} tool={tool} />;
  return <FlashcardsTool key={tool.id} tool={tool} />;
}

/* ----------------------------------------------------------- card previews */

function ClockPreview({ tool }: { tool: ToolItem }) {
  const s = { ...CLOCK_DEFAULTS, ...(tool.state as Partial<ClockState>) };
  const now = useTick(true, 1000);
  const d = new Date(now);
  const hm = d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  const status =
    s.pEndsAt !== null
      ? `${s.phase === "work" ? "Focus" : "Break"} · ${fmt(s.pEndsAt - now)}`
      : s.cdEndsAt !== null
        ? `Timer · ${fmt(s.cdEndsAt - now)}`
        : s.swStart !== null
          ? `Stopwatch · ${fmt(s.swElapsed + now - s.swStart)}`
          : null;
  return (
    <div className="flex h-full min-h-0 flex-col items-center justify-center gap-1 overflow-hidden p-2">
      <div className="flex max-w-full items-baseline gap-1 tabular-nums">
        <span className="display whitespace-nowrap text-[clamp(19px,11cqw,34px)] leading-none">{hm}</span>
        <span className="text-[13px] font-semibold text-muted">{String(d.getSeconds()).padStart(2, "0")}</span>
      </div>
      {status ? (
        <span className="flex items-center gap-1.5 rounded-full bg-ink px-2.5 py-0.5 text-[11px] font-semibold tabular-nums text-on-ink">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-on-ink" />
          {status}
        </span>
      ) : (
        <span className="max-w-full truncate text-[11px] font-medium text-muted">{d.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "short" })}</span>
      )}
    </div>
  );
}

function CalculatorPreview({ tool }: { tool: ToolItem }) {
  const state = tool.state as { expr?: string; deg?: boolean };
  const [expression, setExpression] = useState(state.expr ?? "");
  const current = useRef(expression);
  useEffect(() => {
    const next = (tool.state as { expr?: string }).expr ?? "";
    current.current = next;
    setExpression(next);
  }, [tool.state]);
  let result = "";
  try { result = expression ? showNum(evaluate(expression, state.deg ?? true)) : ""; } catch { /* an incomplete expression is normal */ }
  const keys = ["7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "⌫", "="];
  const press = (key: string) => {
    let next = current.current;
    if (key === "⌫") next = next.slice(0, -1);
    else if (key === "=") { try { next = showNum(evaluate(next, state.deg ?? true)); } catch { return; } }
    else next += key;
    current.current = next;
    setExpression(next);
    void saveToolState(tool.id, { ...tool.state, expr: next });
  };
  return (
    <div className="flex h-full min-h-0 flex-col gap-1 overflow-hidden p-1.5 @sm:p-2.5">
      <div className="shrink-0 rounded-lg bg-ink/[0.04] px-2 py-1 text-right tabular-nums">
        <div className="truncate text-[10px] text-muted">{expression && result !== expression ? expression : " "}</div>
        <div className="truncate text-[clamp(12px,8cqw,17px)] font-semibold leading-tight">{result || expression || "0"}</div>
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-4 grid-rows-4 gap-[2px]">
        {keys.map((key) => (
          <button
            key={key}
            type="button"
            onClick={(e) => { e.stopPropagation(); press(key); }}
            aria-label={`Calculator ${key}`}
            className={cn("flex min-h-0 items-center justify-center rounded-[5px] text-[9px] font-semibold transition-colors hover:bg-ink/[0.12]", key === "=" ? "bg-ink text-on-ink" : /[÷×−]/.test(key) ? "bg-ink/10" : "bg-ink/[0.04]")}
          >
            {key}
          </button>
        ))}
      </div>
    </div>
  );
}

function ConverterPreview({ tool }: { tool: ToolItem }) {
  const s = { ...CONVERTER_DEFAULTS, ...(tool.state as Partial<ConverterState>) };
  const { out } = convert(s);
  return (
    <div className="flex h-full min-h-0 flex-col justify-center gap-1 overflow-hidden p-2.5">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-muted">{s.cat}</span>
      <div className="truncate text-[15px] font-medium tabular-nums text-muted">
        {s.value || "0"} {s.from}
      </div>
      <div className="truncate display text-[clamp(17px,9cqw,26px)] leading-tight tabular-nums">
        {round6(out)} <span className="text-[16px] text-muted">{s.to}</span>
      </div>
    </div>
  );
}

function ChecklistPreview({ tool }: { tool: ToolItem }) {
  const items = ((tool.state as { items?: CheckItem[] }).items ?? []).filter((i) => i && typeof i.text === "string");
  const done = items.filter((i) => i.done).length;
  if (!items.length)
    return (
      <div className="flex h-full flex-col items-center justify-center gap-1.5 text-muted">
        <ListChecks size={22} />
        <span className="text-[12px] font-medium">No items yet</span>
      </div>
    );
  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden p-2.5">
      <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold tabular-nums">
        <span>
          {done}/{items.length} done
        </span>
        <span className="h-1 w-12 overflow-hidden rounded-full bg-ink/10">
          <span className="block h-full rounded-full bg-ink" style={{ width: `${(done / items.length) * 100}%` }} />
        </span>
      </div>
      <ul className="min-h-0 flex-1 space-y-1 overflow-hidden">
        {items.slice(0, 4).map((it) => (
          <li key={it.id} className="flex items-center gap-1.5 text-[12px] leading-tight">
            <span className={cn("flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full ring-1", it.done ? "bg-ink text-on-ink ring-ink" : "ring-ink/30")}>{it.done && <Check size={9} strokeWidth={3.5} />}</span>
            <span className={cn("truncate", it.done && "text-muted line-through")} dir="auto">
              {it.text}
            </span>
          </li>
        ))}
      </ul>
      {items.length > 4 && <span className="mt-auto text-[11px] text-muted">+{items.length - 4} more</span>}
    </div>
  );
}

function FlashcardsPreview({ tool }: { tool: ToolItem }) {
  const cards = (tool.state as { cards?: FlashCard[] }).cards ?? [];
  const sack = cards.filter((c) => c.inSack).length;
  const first = cards.find((c) => c.inSack) ?? cards[0];
  return (
    <div className="flex h-full flex-col items-center justify-center gap-2 p-3">
      <div className="relative w-[78%]">
        <span aria-hidden className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-xl bg-ink/[0.06]" />
        <div className="relative flex min-h-[54px] items-center justify-center rounded-xl bg-card px-2.5 py-2 text-center text-[12px] font-medium shadow-sm ring-1 ring-line" dir="auto">
          <span className="line-clamp-2">{first ? first.front : "No cards yet"}</span>
        </div>
      </div>
      <span className="text-[11px] font-medium tabular-nums text-muted">
        {sack} in the sack · {cards.length - sack} learned
      </span>
    </div>
  );
}

/** What a library card shows: the tool itself, live (the ticking clock, the calculator's display…). */
export function ToolPreview({ tool }: { tool: ToolItem }) {
  if (tool.kind === "clock") return <ClockPreview tool={tool} />;
  if (tool.kind === "calculator") return <CalculatorPreview tool={tool} />;
  if (tool.kind === "converter") return <ConverterPreview tool={tool} />;
  if (tool.kind === "checklist") return <ChecklistPreview tool={tool} />;
  return <FlashcardsPreview tool={tool} />;
}
