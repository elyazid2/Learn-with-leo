import { useEffect, useState } from "react";
import { History, MessageCircle, PenLine, Sparkles } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { askLeo } from "@/lib/chat";
import { useApp } from "@/lib/store";
import { Button, Sheet } from "@/components/ui";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

const words = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0);
const day = (t: number) => new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

type Step = "first" | "write" | "show";

/**
 * "How would you explain it?" — opened from the @ menu in Leo's chat, next to "Practice test".
 *
 * The first time it asks for your explanation of the project's topic and saves it. Every time after
 * that it asks for a fresh one and puts the two side by side. Leo never prompts for it on his own.
 */
export function ExplainSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const before = project.explanation?.before;
  const after = project.explanation?.after;
  const [step, setStep] = useState<Step>(before ? "write" : "first");
  const [draft, setDraft] = useState("");

  // Start fresh every time the sheet opens: the first explanation, or a new one to compare.
  useEffect(() => {
    if (!open) return;
    const b = project.explanation?.before;
    setStep(b ? "write" : "first");
    setDraft(b ? project.explanation?.after?.text ?? "" : "");
    // Only when it opens: live project updates must never clobber what is being typed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const text = draft.trim();

  const saveFirst = async (thenAsk: boolean) => {
    if (!text) return;
    await db.projects.update(project.id, { explanation: { ...project.explanation, before: { text, at: Date.now() } } });
    onClose();
    if (thenAsk) {
      void askLeo(
        project.id,
        `Here's how I'd explain ${project.name} right now, in my own words. Tell me what I've got right, what's missing or wrong, and where I should start. Don't re-teach everything.\n\nMY EXPLANATION:\n${text}`
      );
    } else {
      useApp.getState().showToast("Saved. Mention “How would you explain it?” later to compare.", { tone: "success" });
    }
  };

  const compare = async () => {
    if (!text) return;
    await db.projects.update(project.id, { explanation: { ...project.explanation, after: { text, at: Date.now() } } });
    setStep("show");
  };
  const now = step === "show" && before ? { text, at: after?.text === text ? after.at : Date.now() } : null;

  const discuss = () => {
    if (!now || !before) return;
    onClose();
    void askLeo(
      project.id,
      `Here's how I explained ${project.name} at the start (${day(before.at)}) and how I'd explain it now. Show them side by side, point out what I now understand better, what's still missing or wrong, and suggest one thing to work on.\n\nTHEN:\n${before.text}\n\nNOW:\n${now.text}`
    );
  };

  const area = (rows: number, label: string) => (
    <textarea
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      rows={rows}
      dir="auto"
      autoFocus
      placeholder={`${project.name} is…`}
      aria-label={label}
      className="w-full resize-y rounded-2xl bg-ink/[0.035] p-3.5 text-[15px] leading-relaxed outline-none ring-1 ring-line transition-shadow focus:ring-ink/30"
    />
  );

  return (
    <Sheet
      open={open}
      onClose={onClose}
      wide
      title={step === "first" ? `How would you explain ${project.name}?` : step === "write" ? "How would you explain it now?" : "Then and now"}
      description={
        step === "first"
          ? "Write it in your own words, as you understand it today. Don't look anything up."
          : step === "write"
            ? "Write it fresh, without looking. Then Leo puts both side by side."
            : undefined
      }
    >
      {step === "first" ? (
        <div>
          {area(6, "Your explanation")}
          <div className="mt-1.5 flex items-center justify-between text-[12px] text-muted">
            <span>Optional, and there are no wrong answers.</span>
            <span className="tabular-nums">{words(draft)} words</span>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="lg" variant="soft" disabled={!text} onClick={() => void saveFirst(false)}>
              <PenLine size={16} /> Save it
            </Button>
            <Button size="lg" className="min-w-[10rem] flex-1" disabled={!text} onClick={() => void saveFirst(true)}>
              <Sparkles size={16} /> Save and ask Leo
            </Button>
          </div>
        </div>
      ) : step === "write" && before ? (
        <div>
          <div className="mb-3 flex items-center gap-3 rounded-2xl bg-ink/[0.035] px-3.5 py-2.5 ring-1 ring-line">
            <History size={16} className="shrink-0 text-muted" />
            <div className="min-w-0 flex-1 text-[13px]">
              <span className="font-semibold">Your first explanation</span>
              <span className="text-muted">
                {" "}
                · {day(before.at)} · {words(before.text)} words
              </span>
            </div>
          </div>
          {area(7, "Your explanation now")}
          <Button size="lg" className="mt-3 w-full" disabled={!text} onClick={() => void compare()}>
            Compare with then
          </Button>
        </div>
      ) : (
        now &&
        before && (
          <div>
            <div className="mb-4 flex items-center gap-3">
              <AgentAvatar state="speaking" size={36} />
              <p className="text-[14px] leading-snug">Here's how you explained it then, next to how you explain it now.</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { label: "Then", e: before },
                { label: "Now", e: now },
              ].map(({ label, e }) => (
                <div key={label} className={cn("min-w-0 rounded-2xl p-4 ring-1", label === "Now" ? "bg-card ring-ink/20" : "bg-ink/[0.035] ring-line")}>
                  <div className="mb-1.5 flex items-baseline justify-between gap-2">
                    <span className="text-[12px] font-semibold uppercase tracking-wide text-muted">{label}</span>
                    <span className="text-[11.5px] tabular-nums text-muted">
                      {day(e.at)} · {words(e.text)} words
                    </span>
                  </div>
                  <p className="whitespace-pre-wrap text-[14.5px] leading-relaxed" dir="auto">
                    {e.text}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="soft" onClick={() => setStep("write")}>
                Edit now
              </Button>
              <Button className="flex-1" onClick={discuss}>
                <MessageCircle size={16} /> Ask Leo what changed
              </Button>
            </div>
          </div>
        )
      )}
    </Sheet>
  );
}
