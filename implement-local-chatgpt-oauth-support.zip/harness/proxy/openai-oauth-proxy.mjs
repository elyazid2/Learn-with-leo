#!/usr/bin/env node
/**
 * Harness ⇄ openai-oauth CORS proxy.
 *
 * `npx openai-oauth@latest` exposes your ChatGPT account as an OpenAI-compatible API at
 * http://127.0.0.1:10531/v1, but browsers can't call it directly (CORS). This tiny, dependency-free
 * Node.js server sits in front of it, adds the CORS headers and streams everything through untouched
 * (including `text/event-stream` chat completions).
 *
 *   npm run proxy                                  # http://127.0.0.1:10532  ->  http://127.0.0.1:10531
 *   PORT=10540 UPSTREAM=http://127.0.0.1:10531 npm run proxy
 *   ALLOWED_ORIGINS=https://my-harness.example npm run proxy
 *
 * Environment (or the equivalent --flag, e.g. --port 10540):
 *   HOST             interface to bind                    (default 127.0.0.1)
 *   PORT             port to listen on                    (default 10532)
 *   UPSTREAM         the openai-oauth server              (default http://127.0.0.1:10531)
 *   ALLOWED_ORIGINS  comma-separated web origins allowed in addition to localhost; "*" allows any
 *
 * Safety: the proxy fronts your signed-in ChatGPT account, so it only talks to loopback upstreams and
 * only answers pages served from localhost unless you allow another origin explicitly.
 */
import http from "node:http";

const args = Object.fromEntries(
  process.argv.slice(2).flatMap((a, i, all) => {
    const m = /^--([a-z-]+)(?:=(.*))?$/.exec(a);
    return m ? [[m[1], m[2] ?? (all[i + 1] && !all[i + 1].startsWith("--") ? all[i + 1] : "true")]] : [];
  })
);
const opt = (flag, env, fallback) => args[flag] ?? process.env[env] ?? fallback;

const HOST = opt("host", "HOST", "127.0.0.1");
const PORT = Number(opt("port", "PORT", "10532"));
const UPSTREAM = new URL(opt("upstream", "UPSTREAM", "http://127.0.0.1:10531"));
const EXTRA_ORIGINS = String(opt("allowed-origins", "ALLOWED_ORIGINS", ""))
  .split(",")
  .map((s) => s.trim().replace(/\/+$/, ""))
  .filter(Boolean);

const LOOPBACK = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);
const isLoopbackHost = (h) => LOOPBACK.has(h);
const isLocalOrigin = (o) => {
  try {
    return isLoopbackHost(new URL(o).hostname);
  } catch {
    return false;
  }
};
const originAllowed = (origin) => !origin || isLocalOrigin(origin) || EXTRA_ORIGINS.includes("*") || EXTRA_ORIGINS.includes(origin);

if (!isLoopbackHost(UPSTREAM.hostname)) {
  console.error(`Refusing to proxy to ${UPSTREAM.origin}: the upstream must be on this machine (127.0.0.1 / localhost).`);
  process.exit(1);
}

/** Headers that must not be forwarded to the upstream. */
const DROP_REQUEST = new Set(["host", "origin", "referer", "connection", "x-oauth-upstream", "content-length", "access-control-request-method", "access-control-request-headers", "access-control-request-private-network"]);
const DROP_RESPONSE = new Set(["connection", "transfer-encoding", "access-control-allow-origin", "access-control-allow-headers", "access-control-allow-methods", "access-control-expose-headers", "access-control-allow-credentials"]);

function cors(req, res) {
  const origin = req.headers.origin;
  res.setHeader("access-control-allow-origin", origin ?? "*");
  res.setHeader("vary", "Origin");
  res.setHeader("access-control-allow-methods", "GET, POST, OPTIONS");
  res.setHeader("access-control-allow-headers", req.headers["access-control-request-headers"] || "content-type, authorization, x-oauth-upstream");
  res.setHeader("access-control-expose-headers", "*");
  // Chrome's Private Network Access: a public page may call a loopback server only if it opts in.
  res.setHeader("access-control-allow-private-network", "true");
  res.setHeader("access-control-max-age", "600");
}

function json(req, res, status, body) {
  cors(req, res);
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}

/** The upstream for this request: the x-oauth-upstream header (loopback only) or the configured default. */
function pickUpstream(req) {
  const asked = req.headers["x-oauth-upstream"];
  if (!asked) return UPSTREAM;
  const u = new URL(Array.isArray(asked) ? asked[0] : asked);
  if (!/^https?:$/.test(u.protocol) || !isLoopbackHost(u.hostname)) throw new Error(`upstream ${u.origin} is not a local address`);
  return u;
}

const server = http.createServer((req, res) => {
  const origin = req.headers.origin;
  if (!originAllowed(origin)) {
    return json(req, res, 403, {
      error: {
        message: `Origin ${origin} isn't allowed by the Harness proxy. Restart it with ALLOWED_ORIGINS=${origin} npm run proxy`,
      },
    });
  }
  if (req.method === "OPTIONS") {
    cors(req, res);
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url ?? "/", "http://proxy.local");
  if (url.pathname === "/__health") {
    let target;
    try {
      target = pickUpstream(req);
    } catch (e) {
      return json(req, res, 400, { error: { message: e.message } });
    }
    const probe = http.get(new URL("/v1/models", target), { timeout: 4000 }, (r) => {
      r.resume();
      json(req, res, 200, { ok: true, proxy: true, upstream: target.origin, upstreamStatus: r.statusCode });
    });
    probe.on("timeout", () => probe.destroy(new Error("timeout")));
    probe.on("error", (e) => json(req, res, 502, { ok: false, proxy: true, upstream: target.origin, error: { message: e.message } }));
    return;
  }

  let target;
  try {
    target = pickUpstream(req);
  } catch (e) {
    return json(req, res, 400, { error: { message: e.message } });
  }

  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) if (!DROP_REQUEST.has(k)) headers[k] = v;
  headers.host = target.host;

  const up = http.request(
    { protocol: target.protocol, hostname: target.hostname, port: target.port || (target.protocol === "https:" ? 443 : 80), method: req.method, path: url.pathname + url.search, headers },
    (upRes) => {
      cors(req, res);
      const out = {};
      for (const [k, v] of Object.entries(upRes.headers)) if (!DROP_RESPONSE.has(k) && v !== undefined) out[k] = v;
      res.writeHead(upRes.statusCode ?? 502, out);
      res.flushHeaders?.();
      upRes.pipe(res); // streamed as it arrives, so SSE tokens reach the browser immediately
      upRes.on("error", () => res.destroy());
    }
  );
  up.on("error", (e) => {
    if (res.headersSent) return res.destroy();
    json(req, res, 502, { error: { message: `Can't reach openai-oauth at ${target.origin} (${e.code || e.message}). Is \`npx openai-oauth@latest\` running?` } });
  });
  // Stop the upstream request (and the ChatGPT stream) when the browser aborts or navigates away.
  res.on("close", () => {
    if (!res.writableFinished) up.destroy();
  });
  req.pipe(up);
});

server.on("error", (e) => {
  console.error(e.code === "EADDRINUSE" ? `Port ${PORT} is already in use. Pick another with PORT=… or --port …` : e.message);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log(`Harness ⇄ openai-oauth proxy ready`);
  console.log(`  listening  http://${HOST}:${PORT}/v1   (use this as the CORS proxy in Settings)`);
  console.log(`  forwarding ${UPSTREAM.origin}`);
  console.log(`  origins    localhost${EXTRA_ORIGINS.length ? ", " + EXTRA_ORIGINS.join(", ") : ""}`);
});
