import { redirect } from "next/navigation";

/**
 * The app is Learning Harness (Learn with Leo): a single-file Vite build served from /public/harness.
 * Its source, local ChatGPT OAuth proxy and docs live in /harness.
 */
export default function HomePage() {
  redirect("/harness/index.html");
}
