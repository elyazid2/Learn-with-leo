import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { useShallow } from "zustand/react/shallow";
import { ArrowLeft, ArrowLeftRight, BookOpen, ChevronRight, LayoutGrid, LayoutPanelLeft, Maximize2, Minimize2, MoreHorizontal, Search, Trash2, TrendingUp, X } from "lucide-react";
import { db, deleteProject, type Project, type ProjectIcon } from "@/lib/db";
import { navigate, projectPath, type Route } from "@/lib/router";
import { NARROW, dockOf, effectiveDock, routeTarget, sameTarget, targetPath, useLayout, type PaneTarget, type SplitDir } from "@/lib/layout";
import { useApp } from "@/lib/store";
import { confirmDeletion } from "@/lib/settings";
import { Button, Empty, Field, IconBtn, Sheet, Skeleton, inputCls, isSheetOpen } from "@/components/ui";
import { cn } from "@/utils/cn";
import Library from "./project/Library";
import Notes from "./project/Notes";
import Sketches from "./project/Sketches";
import ChatPanel from "@/components/chat/ChatPanel";
import ProjectAvatar from "@/components/ProjectAvatar";
import ProjectIconPicker from "@/components/ProjectIconPicker";
import SearchSheet from "@/components/SearchSheet";
import Dock from "@/components/Dock";
import { ProgressSheet } from "@/components/Progress";
import { Divider, LayoutSheet, PaneShell } from "@/components/Pane";
import { BrowserView } from "@/components/BrowserPanel";

/** Window width and the visible height (which shrinks when a phone keyboard opens). */
function useScreen() {
  const read = () => ({ small: window.innerWidth < NARROW, height: Math.round(window.visualViewport?.height ?? window.innerHeight) });
  const [screen, setScreen] = useState(read);
  useEffect(() => {
    const on = () => setScreen((s) => {
      const next = read();
      return next.small === s.small && next.height === s.height ? s : next;
    });
    window.addEventListener("resize", on);
    window.visualViewport?.addEventListener("resize", on);
    return () => {
      window.removeEventListener("resize", on);
      window.visualViewport?.removeEventListener("resize", on);
    };
  }, []);
  return screen;
}

/** What the second pane shows. Each item brings its own bar into the pane's single top bar. */
function PaneBody({ project, target }: { project: Project; target: PaneTarget }) {
  if (target.kind === "file") return <Library project={project} fileId={target.id} />;
  if (target.kind === "note") return <Notes project={project} noteId={target.id} />;
  if (target.kind === "sketch") return <Sketches project={project} sketchId={target.id} />;
  return <Library project={project} />;
}

export default function ProjectScreen({ route }: { route: Extract<Route, { name: "project" }> }) {
  const project = useLiveQuery(() => db.projects.get(route.projectId), [route.projectId], null as Project | null | undefined);
  const [editing, setEditing] = useState(false);
  const [searching, setSearching] = useState(false);
  const [arranging, setArranging] = useState(false);
  const chatOpen = useApp((s) => s.chatOpen);
  const layout = useLayout(
    useShallow((s) => ({ chatDock: dockOf(s), splitDir: s.splitDir, ratio: s.ratio, chatShare: s.chatShare, side: s.side, sideProject: s.sideProject, focus: s.focus, swapped: s.swapped }))
  );
  const screen = useScreen();
  const mainRef = useRef<HTMLDivElement>(null);
  const rowRef = useRef<HTMLDivElement>(null);
  const splitRef = useRef<HTMLDivElement>(null);
  const libraryScroll = useRef(0);
  const lastView = useRef("");
  const pid = route.projectId;

  const atLibrary = route.tab === "progress" || (route.tab === "library" && !route.itemId);
  const view = atLibrary ? "library" : `${route.tab}/${route.itemId ?? ""}`;
  const main = useMemo(() => routeTarget(route), [route]);
  const isDoc = main.kind !== "library";

  // ⌘K opens this project's search.
  const searchRequest = useApp((s) => s.searchRequest);
  const firstSearchRequest = useRef(searchRequest);
  useEffect(() => {
    if (searchRequest !== firstSearchRequest.current) setSearching(true);
  }, [searchRequest]);

  const projectName = project?.name;
  useEffect(() => {
    if (projectName) document.title = `${projectName} · Harness`;
  }, [projectName]);

  useEffect(() => {
    return () => {
      const s = useApp.getState();
      s.setSelection(null);
      s.setNote(null);
      s.setPdf(null);
      s.setImage(null);
      s.setSketch(null);
      s.setVideo(null);
      s.setChatOpen(false);
      s.setAddOpen(false);
      useLayout.getState().leaveProject();
    };
  }, []);

  // Starting a chat from the Progress sheet closes it, so the chat panel is never hidden behind it.
  useEffect(() => {
    if (chatOpen && route.tab === "progress") navigate(projectPath(pid), true);
  }, [chatOpen, route.tab, pid]);

  // Opening Leo while a pane is fullscreen leaves fullscreen, so the chat is never opened out of sight.
  const wasChatOpen = useRef(chatOpen);
  useEffect(() => {
    if (chatOpen && !wasChatOpen.current && useLayout.getState().focus) useLayout.getState().setFocus(null);
    // Closing the chat ends any placement Leo chose for it; next time it opens where you keep it.
    if (!chatOpen && useLayout.getState().tempDock) useLayout.getState().setTempDock(null);
    wasChatOpen.current = chatOpen;
  }, [chatOpen]);

  // Esc leaves a fullscreen pane.
  useEffect(() => {
    if (!layout.focus) return;
    const on = (e: KeyboardEvent) => {
      if (e.key !== "Escape" || e.defaultPrevented || isSheetOpen()) return;
      const el = document.activeElement as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) return;
      useLayout.getState().setFocus(null);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [layout.focus]);

  // Items open at the top; coming back to the library restores where you were.
  useLayoutEffect(() => {
    const el = mainRef.current;
    if (!el || lastView.current === view) return;
    el.scrollTop = view === "library" ? libraryScroll.current : 0;
    lastView.current = view;
  }, [view, project]);

  const closeMain = useCallback((replace?: boolean) => navigate(projectPath(pid), replace), [pid]);
  const openMain = useCallback((t: PaneTarget) => navigate(targetPath(pid, t)), [pid]);
  const closeSide = useCallback(() => useLayout.getState().closeSide(), []);
  const openSide = useCallback((t: PaneTarget) => useLayout.getState().openSide(pid, t), [pid]);

  if (project === null)
    return (
      <div className="flex h-dvh flex-col" aria-busy="true" aria-label="Loading project">
        <div className="border-b border-line/70 pt-[env(safe-area-inset-top)]">
          <div className="mx-auto flex h-14 max-w-5xl items-center gap-3 px-3">
            <Skeleton className="h-8 w-8 rounded-full" />
            <Skeleton className="h-8 w-8 rounded-xl" />
            <Skeleton className="h-4 w-40" />
          </div>
        </div>
        <div className="mx-auto grid w-full max-w-5xl grid-cols-2 gap-3 p-4 sm:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="aspect-[4/3] rounded-2xl" />
          ))}
        </div>
      </div>
    );
  if (!project)
    return (
      <Empty className="min-h-dvh" icon={<LayoutGrid />} title="Project not found" text="It may have been deleted, or the link is from another device.">
        <Button onClick={() => navigate("")}>Go to your projects</Button>
      </Empty>
    );

  /* --------------------------------------------------------------- layout */

  const small = screen.small;
  // The second pane never repeats what the main pane already shows.
  const side = layout.sideProject === pid && layout.side && !sameTarget(layout.side, main) ? layout.side : null;
  const focus = layout.focus === "side" && !side ? null : layout.focus;
  const dock = effectiveDock(layout.chatDock, small);
  const chatInline = chatOpen && !focus && (dock === "left" || dock === "right" || dock === "bottom");
  const dir: SplitDir = small ? "column" : layout.splitDir;
  const showMain = focus !== "side";
  const showSide = !!side && focus !== "main";
  const two = showMain && showSide;
  const chatShare = dock === "bottom" ? Math.max(layout.chatShare, small ? 0.44 : 0.3) : layout.chatShare;
  // Sketching gets the whole pane: no dock over the canvas.
  const immersive = main.kind === "sketch";

  const chat = <ChatPanel project={project} placement={chatInline ? "inline" : focus ? "hidden" : dock === "full" ? "full" : "float"} />;

  const fullscreenBtn = (pane: "main" | "side") =>
    focus === pane ? (
      <IconBtn onClick={() => useLayout.getState().setFocus(null)} aria-label="Exit fullscreen" title="Exit fullscreen (Esc)">
        <Minimize2 size={17} />
      </IconBtn>
    ) : null;

  const sideTools = (
    <>
      {two && (
        <IconBtn onClick={() => useLayout.getState().swap()} aria-label="Swap panes" className="hidden sm:inline-flex">
          <ArrowLeftRight size={16} />
        </IconBtn>
      )}
      {focus === "side" ? (
        fullscreenBtn("side")
      ) : (
        <IconBtn onClick={() => useLayout.getState().setFocus("side")} aria-label="Fullscreen">
          <Maximize2 size={16} />
        </IconBtn>
      )}
    </>
  );

  const mainPane = (
    <div key="main" className={cn("min-h-0 min-w-0", showMain ? "flex" : "hidden")} style={{ flex: two ? `${layout.ratio} 1 0%` : "1 1 0%" }}>
      <PaneShell
        label={isDoc ? "Open item" : `${project.name} library`}
        primary
        close={closeMain}
        open={openMain}
        wide={isDoc}
        compact={main.kind === "sketch"}
        topInset={!(two && dir === "column" && layout.swapped)}
        leading={
          <IconBtn onClick={() => navigate(atLibrary ? "" : projectPath(project.id))} aria-label={atLibrary ? "All projects" : "Back to library"}>
            <ArrowLeft size={19} />
          </IconBtn>
        }
        bar={
          isDoc ? null : (
            <>
              {/* The project's name and icon are the way into editing it; it is not on the page otherwise. */}
              <button
                onClick={() => setEditing(true)}
                aria-label={`Edit project: ${project.name}`}
                title="Edit project"
                className="flex min-w-0 flex-1 items-center gap-2.5 rounded-xl px-1 py-1 text-left transition-colors hover:bg-ink/[0.04]"
              >
                <ProjectAvatar project={project} size={34} />
                <div className="min-w-0">
                  <div className="truncate display text-[18px] leading-tight">{project.name}</div>
                  {project.tag && <div className="truncate text-[12px] text-muted">{project.tag}</div>}
                </div>
              </button>
              <IconBtn onClick={() => setSearching(true)} aria-label="Search this project">
                <Search size={18} />
              </IconBtn>
            </>
          )
        }
        trailing={
          <>
            {fullscreenBtn("main")}
            <IconBtn onClick={() => setArranging(true)} aria-label="Layout" title="Layout: panes, splits and fullscreen">
              <LayoutPanelLeft size={18} />
            </IconBtn>
            {!isDoc && (
              <IconBtn onClick={() => navigate("settings")} aria-label="App settings">
                <MoreHorizontal size={19} />
              </IconBtn>
            )}
          </>
        }
        bodyRef={mainRef}
        onBodyScroll={(e) => {
          if (atLibrary) libraryScroll.current = e.currentTarget.scrollTop;
        }}
        bodyClass={main.kind === "sketch" || route.tab === "notes" ? "overflow-hidden" : "overflow-y-auto"}
        overlay={immersive ? null : <Dock project={project} route={route} chatDocked={chatInline} />}
      >
        {route.tab === "notes" ? (
          <Notes project={project} noteId={route.itemId} />
        ) : route.tab === "sketch" && route.itemId ? (
          <Sketches project={project} sketchId={route.itemId} />
        ) : (
          <Library project={project} fileId={route.tab === "library" ? route.itemId : undefined} />
        )}
      </PaneShell>
    </div>
  );

  const sideTopInset = dir === "row" || layout.swapped || !showMain;
  const sidePane = side ? (
    <div key="side" className={cn("min-h-0 min-w-0", showSide ? "flex" : "hidden")} style={{ flex: two ? `${1 - layout.ratio} 1 0%` : "1 1 0%" }}>
      {side.kind === "browser" ? (
        <SideBrowser onClose={closeSide} tools={sideTools} topInset={sideTopInset} />
      ) : (
        <PaneShell
          label="Second pane"
          primary={false}
          close={closeSide}
          open={openSide}
          wide
          compact={side.kind === "sketch"}
          topInset={sideTopInset}
          bar={
            side.kind === "library" ? (
              <div className="flex min-w-0 flex-1 items-center gap-2 px-1.5">
                <BookOpen size={17} className="shrink-0 text-muted" />
                <span className="truncate text-[15px] font-semibold">Library</span>
              </div>
            ) : null
          }
          trailing={
            <>
              {sideTools}
              <IconBtn onClick={closeSide} aria-label="Close second pane">
                <X size={18} />
              </IconBtn>
            </>
          }
          bodyClass={side.kind === "library" || side.kind === "file" ? "overflow-y-auto" : "overflow-hidden"}
        >
          <PaneBody project={project} target={side} />
        </PaneShell>
      )}
    </div>
  ) : null;

  const paneDivider = two ? (
    <Divider key="divider" dir={dir} container={splitRef} value={layout.ratio} invert={layout.swapped} onChange={(v) => useLayout.getState().setRatio(v)} label="Resize panes" />
  ) : null;

  const chatColumn = chatInline ? (
    <div
      key="chat"
      className={cn("min-h-0 min-w-0 bg-paper", dock !== "bottom" && "pt-[env(safe-area-inset-top)]")}
      style={{ flex: `0 0 ${Math.round(chatShare * 1000) / 10}%` }}
      data-chat-column
    >
      {chat}
    </div>
  ) : null;
  const chatDivider = chatInline ? (
    <Divider
      key="chat-divider"
      dir={dock === "bottom" ? "column" : "row"}
      container={rowRef}
      value={layout.chatShare}
      invert={dock !== "left"}
      onChange={(v) => useLayout.getState().setChatShare(v)}
      label="Resize Leo's chat"
    />
  ) : null;

  return (
    // On phones the visible height is used, so a docked chat stays above the keyboard.
    <div className="flex h-dvh flex-col overflow-hidden" style={small && chatInline ? { height: screen.height } : undefined}>
      <div ref={rowRef} className={cn("flex min-h-0 flex-1", dock === "bottom" ? "flex-col" : "flex-row")}>
        {dock === "left" && chatColumn}
        {dock === "left" && chatDivider}
        <div ref={splitRef} className={cn("flex min-h-0 min-w-0 flex-1", dir === "row" ? "flex-row" : "flex-col")}>
          {layout.swapped ? [sidePane, paneDivider, mainPane] : [mainPane, paneDivider, sidePane]}
        </div>
        {dock !== "left" && chatDivider}
        {dock !== "left" && chatColumn}
      </div>
      {!chatInline && chat}
      <ProgressSheet project={project} open={route.tab === "progress"} onClose={() => navigate(projectPath(project.id), true)} />
      <EditProjectSheet project={project} open={editing} onClose={() => setEditing(false)} />
      <SearchSheet project={project} open={searching} onClose={() => setSearching(false)} />
      <LayoutSheet project={project} open={arranging} onClose={() => setArranging(false)} main={main} small={small} />
    </div>
  );
}

/** The browser as the second pane. While it is showing, the app treats the browser as open. */
function SideBrowser({ onClose, tools, topInset }: { onClose: () => void; tools: React.ReactNode; topInset: boolean }) {
  useEffect(() => {
    useApp.getState().setBrowserOpen(true);
    return () => useApp.getState().setBrowserOpen(false);
  }, []);
  return <BrowserView variant="pane" onClose={onClose} tools={tools} topInset={topInset} />;
}

function EditProjectSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const [name, setName] = useState(project.name);
  const [tag, setTag] = useState(project.tag);
  const [icon, setIcon] = useState<ProjectIcon | undefined>(project.icon);
  const wasOpen = useRef(false);
  // Reset the form only when the sheet opens, so live project updates never clobber unsaved edits.
  useEffect(() => {
    if (open && !wasOpen.current) {
      setName(project.name);
      setTag(project.tag);
      setIcon(project.icon);
    }
    wasOpen.current = open;
  }, [open, project]);

  const save = async () => {
    await db.projects.update(project.id, { name: name.trim() || project.name, tag: tag.trim(), icon, updatedAt: Date.now() });
    onClose();
  };
  const remove = async () => {
    if (
      !(await confirmDeletion(`Everything in "${project.name}" — files, notes, sketches, chats and the knowledge map — will be removed from this device. This cannot be undone.`, {
        title: "Delete project?",
        confirmLabel: "Delete project",
      }))
    )
      return;
    navigate("", true);
    await deleteProject(project.id);
  };
  return (
    <Sheet open={open} onClose={onClose} title="Project" description="Rename, change the icon or delete this project.">
      <div className="space-y-5">
        <button
          onClick={() => {
            onClose();
            navigate(projectPath(project.id, "progress"));
          }}
          className="flex w-full items-center gap-3 rounded-2xl bg-ink/[0.035] p-3.5 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.06]"
        >
          <TrendingUp size={18} className="text-muted" />
          <span className="flex-1 text-[14px] font-medium">Progress and knowledge map</span>
          <ChevronRight size={16} className="text-muted" />
        </button>
        <div>
          <span className="mb-1.5 block text-[12px] font-medium text-muted">Icon</span>
          <ProjectIconPicker value={icon} onChange={setIcon} tag={tag} />
        </div>
        <Field label="Topic">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Tag">
          <input className={inputCls} value={tag} onChange={(e) => setTag(e.target.value)} />
        </Field>
        <div className="flex gap-2">
          <Button size="lg" className="flex-1" onClick={() => void save()}>
            Save
          </Button>
          <Button size="lg" variant="danger" onClick={() => void remove()}>
            <Trash2 size={16} /> Delete
          </Button>
        </div>
      </div>
    </Sheet>
  );
}
