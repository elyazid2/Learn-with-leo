import { useEffect, useMemo, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowRight, ArrowUpRight, BookOpen, Brain, Compass, KeyRound, Keyboard, Plus, RotateCcw, Search, Settings2 } from "lucide-react";
import { db, uid, type Concept, type Project, type ProjectIcon } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { startPlacement } from "@/lib/chat";
import ProjectIconPicker from "@/components/ProjectIconPicker";
import { defaultIconFor } from "@/lib/projectIcon";
import { timeAgo } from "@/lib/media";
import { Button, Empty, Field, IconBtn, Kbd, Segmented, Sheet, Skeleton, StatusBar, inputCls } from "@/components/ui";
import { useApp } from "@/lib/store";
import { MOD } from "@/components/ShortcutsSheet";
import { cn } from "@/utils/cn";
import ProjectAvatar from "@/components/ProjectAvatar";
import AgentAvatar from "@/components/AgentAvatar";
import { useSettings } from "@/lib/settings";
import { projectTourPending, useTour } from "@/lib/tour";

const TAG_SUGGESTIONS = ["Language", "Math", "Code", "Science", "Music", "History", "Design", "Exam"];

/** One-tap starting points for the New project sheet, so nobody faces an empty field. */
const TOPIC_IDEAS = [
  { name: "Spanish", tag: "Language" },
  { name: "Linear algebra", tag: "Math" },
  { name: "Python", tag: "Code" },
  { name: "Music theory", tag: "Music" },
];

function countBy(keys: string[]) {
  const m: Record<string, number> = {};
  for (const k of keys) m[k] = (m[k] ?? 0) + 1;
  return m;
}

type SortKey = "recent" | "name" | "progress";

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Up late" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export default function Home() {
  const projects = useLiveQuery(() => db.projects.orderBy("updatedAt").reverse().toArray(), []);
  const concepts = useLiveQuery(() => db.concepts.toArray(), []);
  // Index keys only — never pulls file blobs into memory just to count them.
  const fileCounts = useLiveQuery(async () => countBy((await db.files.orderBy("projectId").keys()) as string[]), []);
  const noteCounts = useLiveQuery(async () => countBy((await db.notes.orderBy("projectId").keys()) as string[]), []);
  const sketchCounts = useLiveQuery(async () => countBy((await db.sketches.orderBy("projectId").keys()) as string[]), []);
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const [creating, setCreating] = useState(false);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>(() => (localStorage.getItem("harness.homeSort") as SortKey) || "recent");
  const developerMode = useSettings((s) => s.developerMode);
  const searchRef = useRef<HTMLInputElement>(null);
  const searchRequest = useApp((s) => s.searchRequest);

  // ⌘K on the home screen focuses the project filter.
  useEffect(() => {
    if (searchRequest) searchRef.current?.focus();
  }, [searchRequest]);

  // Leo's tour ends with "Create a project": it asks this screen to open the sheet.
  const createRequest = useTour((s) => s.createRequest);
  const handledCreate = useRef(createRequest);
  useEffect(() => {
    if (createRequest === handledCreate.current) return;
    handledCreate.current = createRequest;
    setCreating(true);
  }, [createRequest]);

  const now = Date.now();
  const byProject = useMemo(() => {
    const m = new Map<string, { all: Concept[]; solid: number; due: number }>();
    for (const c of concepts ?? []) {
      const e = m.get(c.projectId) ?? { all: [], solid: 0, due: 0 };
      e.all.push(c);
      if (c.status === "solid") e.solid++;
      if (c.nextReview && c.nextReview <= now) e.due++;
      m.set(c.projectId, e);
    }
    return m;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [concepts]);

  const totalDue = [...byProject.values()].reduce((n, e) => n + e.due, 0);
  const totalSolid = [...byProject.values()].reduce((n, e) => n + e.solid, 0);
  const totalConcepts = concepts?.length ?? 0;
  const mostDue = projects?.map((p) => ({ p, n: byProject.get(p.id)?.due ?? 0 })).filter((x) => x.n > 0).sort((a, b) => b.n - a.n)[0];

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = (projects ?? []).filter((p) => !q || p.name.toLowerCase().includes(q) || p.tag.toLowerCase().includes(q));
    const pct = (p: Project) => {
      const e = byProject.get(p.id);
      return e && e.all.length ? e.solid / e.all.length : -1;
    };
    if (sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === "progress") list.sort((a, b) => pct(b) - pct(a));
    return list;
  }, [projects, query, sort, byProject]);

  const changeSort = (s: SortKey) => {
    setSort(s);
    localStorage.setItem("harness.homeSort", s);
  };

  const loading = projects === undefined;
  const hasProjects = !!projects && projects.length > 0;
  const firstRun = !!projects && projects.length === 0;
  const needsProvider = providerCount === 0 && !developerMode;

  return (
    <div className="mx-auto min-h-full max-w-5xl px-5 pb-32 pt-[max(env(safe-area-inset-top),20px)]">
      <header className="flex items-center justify-between py-3">
        <div className="flex items-center gap-2.5">
          <Logo />
          <span className="display text-[26px] leading-none">Harness</span>
        </div>
        <div className="flex items-center gap-0.5">
          <IconBtn onClick={() => useApp.getState().setShortcutsOpen(true)} aria-label="Keyboard shortcuts" className="hidden sm:inline-flex">
            <Keyboard size={18} />
          </IconBtn>
          <IconBtn onClick={() => navigate("settings")} aria-label="Settings" data-tour="settings">
            <Settings2 size={19} />
          </IconBtn>
        </div>
      </header>

      <section className="mb-7 mt-6">
        {hasProjects && <div className="mb-2 text-[14px] font-medium text-muted">{greeting()}</div>}
        <h1 className="max-w-lg display text-[38px] leading-[1.06] sm:text-[48px]">
          What are you <span className="text-muted">learning</span>?
        </h1>
        {!hasProjects && (
          <p className="mt-3 max-w-md text-[15px] text-muted text-pretty">
            Your projects, your materials, an AI that meets you where you are. Your library and notes stay on this device; only what you choose to attach is sent to your AI provider.
          </p>
        )}
      </section>

      {firstRun && <Welcome onCreate={() => setCreating(true)} onTour={() => useTour.getState().replay()} />}

      {needsProvider && (
        <button
          onClick={() => navigate("settings")}
          data-tour="provider"
          className="lift mb-6 flex w-full items-center gap-3 rounded-3xl border border-dashed border-black/15 bg-white/60 p-4 text-left transition hover:bg-white"
        >
          {firstRun ? (
            // Leo already greets new learners just above; one face is enough.
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-ink/[0.06]">
              <KeyRound size={18} />
            </span>
          ) : (
            <AgentAvatar state="blocked" size={40} />
          )}
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold">Connect an AI provider for Leo</div>
            <div className="text-[13px] text-muted">OpenAI, Anthropic, Gemini, OpenRouter, Ollama… or try Developer mode with no key.</div>
          </div>
          <ArrowUpRight size={18} className="shrink-0 text-muted" />
        </button>
      )}

      {hasProjects && (
        <section aria-label="Your learning at a glance" className="mb-6 grid grid-cols-3 gap-2.5">
          <Stat label={projects.length === 1 ? "Project" : "Projects"} value={projects.length} />
          <Stat label="Concepts solid" value={totalConcepts ? `${totalSolid}/${totalConcepts}` : "—"} />
          <Stat label="Due for review" value={totalDue} accent={totalDue > 0} />
        </section>
      )}

      {mostDue && (
        <button
          onClick={() => navigate(projectPath(mostDue.p.id, "progress"))}
          className="lift rise mb-6 flex w-full items-center gap-3.5 rounded-2xl bg-ink p-4 text-left text-white"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10">
            <RotateCcw size={19} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[15px] font-semibold">Time for a quick review</span>
            <span className="block truncate text-[13px] opacity-70">
              {mostDue.n} {mostDue.n === 1 ? "concept is" : "concepts are"} due in {mostDue.p.name}
              {totalDue > mostDue.n ? ` · ${totalDue - mostDue.n} more elsewhere` : ""}
            </span>
          </span>
          <ArrowRight size={18} className="shrink-0 opacity-70" />
        </button>
      )}

      {firstRun && <Pillars />}

      {hasProjects && projects.length >= 4 && (
        <div className="mb-4 flex flex-col gap-2.5 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input
              ref={searchRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Escape" && (setQuery(""), e.currentTarget.blur())}
              placeholder="Filter projects"
              aria-label="Filter projects"
              className="h-10 w-full rounded-full border border-line bg-card pl-10 pr-16 text-[15px] outline-none transition-[border-color,box-shadow] placeholder:text-muted/70 focus:border-ink/30 focus:ring-4 focus:ring-black/[0.05]"
            />
            <Kbd className="absolute right-3 top-1/2 hidden -translate-y-1/2 sm:inline-flex">{MOD} K</Kbd>
          </div>
          <Segmented
            label="Sort projects"
            value={sort}
            onChange={changeSort}
            options={[
              { value: "recent", label: "Recent" },
              { value: "name", label: "A–Z" },
              { value: "progress", label: "Progress" },
            ]}
          />
        </div>
      )}

      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true" aria-label="Loading projects">
          {[0, 1, 2].map((i) => (
            <div key={i} className="rounded-2xl bg-card p-5 ring-1 ring-line">
              <div className="flex items-center gap-3.5">
                <Skeleton className="h-11 w-11 rounded-2xl" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              </div>
              <Skeleton className="mt-5 h-1.5 w-full rounded-full" />
            </div>
          ))}
        </div>
      ) : (
        <div className="stagger grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((p) => {
            const e = byProject.get(p.id);
            const pc = e?.all ?? [];
            const solid = e?.solid ?? 0;
            const due = e?.due ?? 0;
            const libraryTotal = (fileCounts?.[p.id] ?? 0) + (noteCounts?.[p.id] ?? 0) + (sketchCounts?.[p.id] ?? 0);
            return (
              <button
                key={p.id}
                onClick={() => navigate(projectPath(p.id))}
                data-tour="project"
                className="lift group relative overflow-hidden rounded-2xl bg-card p-4 text-left ring-1 ring-line hover:bg-ink/[0.015] sm:p-5"
              >
                <div className="flex items-center gap-3.5">
                  <ProjectAvatar project={p} size={44} animate={false} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate display text-[20px] leading-tight">{p.name}</div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      {p.tag && (
                        <span className="rounded-full bg-ink/[0.05] px-2 py-0.5 text-[11px] font-medium text-ink/75">
                          {p.tag}
                        </span>
                      )}
                      <LevelChip project={p} />
                      {due > 0 && (
                        <span className="flex items-center gap-1 rounded-full bg-warn-bg px-2 py-0.5 text-[11px] font-semibold text-warn-fg">
                          <RotateCcw size={10} strokeWidth={2.6} /> {due} due
                        </span>
                      )}
                    </div>
                  </div>
                  <span className="shrink-0 self-start text-[12px] text-muted">{timeAgo(p.updatedAt)}</span>
                </div>
                <div className="mt-4">
                  <StatusBar concepts={pc} />
                  <div className="mt-2.5 flex items-center gap-3.5 text-[12px] text-muted">
                    <span className="flex items-center gap-1">
                      <Brain size={13} /> {pc.length ? `${solid}/${pc.length} solid` : "No concepts yet"}
                    </span>
                    <span className="flex items-center gap-1">
                      <BookOpen size={13} /> {libraryTotal} {libraryTotal === 1 ? "item" : "items"}
                    </span>
                    <ArrowRight size={14} className="ml-auto -translate-x-1 opacity-0 transition-[opacity,transform] group-hover:translate-x-0 group-hover:opacity-100" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {hasProjects && shown.length === 0 && (
        <Empty icon={<Search size={24} />} title="No matching projects" text={`Nothing called "${query}". Try another word, or start a new project.`}>
          <Button variant="soft" onClick={() => setQuery("")}>
            Clear filter
          </Button>
          <Button onClick={() => setCreating(true)}>
            <Plus size={16} /> New project
          </Button>
        </Empty>
      )}

      {/* New learners start from Leo's welcome card above; the floating button is for everyone after that. */}
      {hasProjects && (
        <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center bg-gradient-to-t from-paper via-paper/70 to-transparent pb-[max(env(safe-area-inset-bottom),20px)] pt-10">
          <Button size="lg" data-tour="new-project" className="pointer-events-auto shadow-[0_12px_32px_rgba(0,0,0,0.16)]" onClick={() => setCreating(true)}>
            <Plus size={18} /> New project
          </Button>
        </div>
      )}

      <NewProjectSheet open={creating} onClose={() => setCreating(false)} hasProvider={!!providerCount || developerMode} />
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number | string; accent?: boolean }) {
  return (
    <div className={cn("rounded-2xl p-3.5 ring-1", accent ? "bg-warn-bg ring-transparent" : "bg-card ring-line")}>
      <div className={cn("display text-[24px] leading-none tabular-nums", accent && "text-warn-fg")}>{value}</div>
      <div className={cn("mt-1.5 text-[12px] leading-tight", accent ? "text-warn-fg/80" : "text-muted")}>{label}</div>
    </div>
  );
}

export function LevelChip({ project }: { project: Project }) {
  const pl = project.placement;
  if (pl.status === "done")
    return <span className="rounded-full bg-black/[0.05] px-2 py-0.5 text-[11px] font-medium">{pl.level}</span>;
  return (
    <span className="flex items-center gap-1 rounded-full border border-dashed border-black/15 px-2 py-0.5 text-[11px] text-muted">
      <Compass size={11} /> {pl.status === "in_progress" ? "Finding level…" : "No level yet"}
    </span>
  );
}

export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect width="32" height="32" rx="10" style={{ fill: "var(--ink)" }} />
      <circle cx="16" cy="16" r="4" style={{ fill: "var(--paper)" }} />
      <circle cx="16" cy="16" r="9" fill="none" style={{ stroke: "var(--paper)" }} strokeOpacity=".45" strokeWidth="1.5" strokeDasharray="3 3" />
      <circle cx="25" cy="16" r="2" fill="#22b07d" />
      <circle cx="10" cy="9.5" r="2" fill="#4f8ff7" />
      <circle cx="10" cy="22.5" r="2" fill="#f0a52b" />
    </svg>
  );
}

/** First visit: Leo introduces himself and offers the two ways in. */
function Welcome({ onCreate, onTour }: { onCreate: () => void; onTour: () => void }) {
  return (
    <section aria-label="Getting started" className="rise mb-4 flex flex-col gap-4 rounded-3xl bg-card p-5 ring-1 ring-line sm:flex-row sm:items-center sm:gap-5 sm:p-6">
      <AgentAvatar state="waiting" size={56} label="Leo" />
      <div className="min-w-0 flex-1">
        <h2 className="display text-[21px] leading-tight">New here? I'm Leo, your tutor.</h2>
        <p className="mt-1 text-[14px] leading-relaxed text-muted text-pretty">I can show you around in about a minute, or you can jump straight in.</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="soft" onClick={onTour}>
          <Compass size={16} /> Take the tour
        </Button>
        <Button data-tour="new-project" onClick={onCreate}>
          <Plus size={16} /> Start your first project
        </Button>
      </div>
    </section>
  );
}

function Pillars() {
  const steps = [
    { icon: <Compass size={18} />, title: "Placement", text: "A few adaptive questions find your level and starting point." },
    { icon: <Brain size={18} />, title: "Teach & test", text: "Lessons at your level. Quizzes update your knowledge map." },
    { icon: <BookOpen size={18} />, title: "Your tools", text: "Library, notes, sketches — Leo sees what you share." },
  ];
  return (
    <section aria-label="How Harness works" className="mb-8 grid gap-3 sm:grid-cols-3">
      {steps.map((s, i) => (
        <div key={s.title} className="rise rounded-2xl bg-card p-5 ring-1 ring-line" style={{ animationDelay: `${i * 60}ms` }}>
          <div className="flex items-center justify-between">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-black/[0.05]">{s.icon}</div>
            <span className="display text-2xl text-black/40">0{i + 1}</span>
          </div>
          <div className="mt-4 font-semibold">{s.title}</div>
          <p className="mt-1 text-[13px] leading-relaxed text-muted">{s.text}</p>
        </div>
      ))}
    </section>
  );
}

function NewProjectSheet({ open, onClose, hasProvider }: { open: boolean; onClose: () => void; hasProvider: boolean }) {
  const [name, setName] = useState("");
  const [tag, setTag] = useState("");
  // The color picker is gone; new projects keep the previous default for the few accents that still use it.
  const color = "blue";
  const [placement, setPlacement] = useState(true);
  const [icon, setIcon] = useState<ProjectIcon>({ kind: "icon", name: defaultIconFor("") });
  const [iconTouched, setIconTouched] = useState(false);
  const submitting = useRef(false);
  // Until you pick an icon yourself, it follows the tag (Math → 📐, Language → 🗣️…).
  const changeTag = (t: string) => {
    setTag(t);
    if (!iconTouched) setIcon({ kind: "icon", name: defaultIconFor(t) });
  };

  const create = async () => {
    // Guarded: a held Enter key must not create the same project twice.
    if (!name.trim() || submitting.current) return;
    submitting.current = true;
    try {
      const now = Date.now();
      const p: Project = {
        id: uid(),
        name: name.trim(),
        tag: tag.trim(),
        color,
        icon,
        createdAt: now,
        updatedAt: now,
        placement: { status: "pending" },
      };
      await db.projects.add(p);
      setName("");
      setTag("");
      setIcon({ kind: "icon", name: defaultIconFor("") });
      setIconTouched(false);
      onClose();
      navigate(projectPath(p.id));
      if (placement && hasProvider) {
        // On the very first project Leo shows the room before the placement chat opens over it.
        if (projectTourPending()) useTour.getState().deferPlacement(p.id);
        else setTimeout(() => void startPlacement(p.id), 250);
      }
    } finally {
      submitting.current = false;
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="New project" description="One project per thing you want to learn.">
      <div className="space-y-5">
        <Field label="Topic">
          <input
            autoFocus
            className={inputCls}
            placeholder="e.g. Linear algebra, Japanese, Rust…"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void create()}
            maxLength={80}
          />
          {!name.trim() && (
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="text-[12px] text-muted">Ideas</span>
              {TOPIC_IDEAS.map((idea) => (
                <button
                  key={idea.name}
                  type="button"
                  onClick={() => {
                    setName(idea.name);
                    if (!tag.trim()) changeTag(idea.tag);
                  }}
                  className="rounded-full border border-dashed border-black/20 px-2.5 py-1 text-xs text-muted transition hover:border-black/40 hover:text-ink"
                >
                  {idea.name}
                </button>
              ))}
            </div>
          )}
        </Field>
        <Field label="Tag">
          <input className={inputCls} placeholder="Short label" value={tag} onChange={(e) => changeTag(e.target.value)} maxLength={24} />
          <div className="mt-2 flex flex-wrap gap-1.5">
            {TAG_SUGGESTIONS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => changeTag(t)}
                aria-pressed={tag === t}
                className={cn(
                  "rounded-full px-2.5 py-1 text-xs transition",
                  tag === t ? "bg-ink text-white" : "bg-black/[0.05] text-muted hover:text-ink"
                )}
              >
                {t}
              </button>
            ))}
          </div>
        </Field>
        <div>
          <span className="mb-1.5 block text-[12px] font-medium text-muted">Icon</span>
          <ProjectIconPicker
            value={icon}
            onChange={(v) => {
              setIcon(v);
              setIconTouched(true);
            }}
            tag={tag}
          />
        </div>
        <label className={cn("flex items-center gap-3 rounded-2xl bg-black/[0.03] p-3.5", !hasProvider && "opacity-70")}>
          <input type="checkbox" checked={placement && hasProvider} disabled={!hasProvider} onChange={(e) => setPlacement(e.target.checked)} className="h-4 w-4 accent-[var(--ink)]" />
          <div className="text-sm">
            <div className="font-medium">Start with placement</div>
            <div className="text-[12px] text-muted">
              {hasProvider ? "Leo asks a few adaptive questions to find your level." : "Add an AI provider for Leo in Settings first."}
            </div>
          </div>
        </label>
        <Button size="lg" className="w-full" disabled={!name.trim()} onClick={() => void create()}>
          Create project
        </Button>
      </div>
    </Sheet>
  );
}
