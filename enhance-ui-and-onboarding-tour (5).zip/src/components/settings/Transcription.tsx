import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { Button, Field, inputCls } from "@/components/ui";
import { queueIndex } from "@/lib/retrieval";
import { useApp } from "@/lib/store";

/**
 * Settings → Transcription: imported audio and video audio are transcribed (16 kHz mono, 10-minute
 * pieces) with an OpenAI-compatible /audio/transcriptions endpoint or Gemini, so Leo can search and
 * read them with timestamps.
 */
export default function TranscriptionSection() {
  const providers = useLiveQuery(() => db.providers.toArray(), []);
  const { transcriptionProviderId, transcriptionModel, setSettings } = useSettings();
  const usable = (providers ?? []).filter((p) => p.type !== "anthropic");
  const chosen = usable.find((p) => p.id === transcriptionProviderId);
  const suggestion = chosen?.type === "gemini" ? "gemini-2.5-flash" : chosen?.baseUrl.includes("groq") ? "whisper-large-v3" : "whisper-1";

  const transcribeExisting = async () => {
    const files = await db.files.filter((f) => (f.kind === "audio" || f.kind === "video") && f.indexed !== "done").toArray();
    for (const f of files) {
      await db.files.update(f.id, { indexed: "pending", indexNote: undefined });
      queueIndex(f.id);
    }
    useApp.getState().showToast(files.length ? `Transcribing ${files.length} file${files.length === 1 ? "" : "s"}…` : "Nothing left to transcribe");
  };

  return (
    <section className="mt-10">
      <h2 className="text-[13px] font-semibold text-muted">Transcription</h2>
      <p className="mt-0.5 mb-3 text-[13px] text-muted">
        Transcribe imported audio and video so Leo can search, read and cite them by timestamp. Audio is sent to the provider you pick.
      </p>
      <p className="-mt-1.5 mb-3 text-[13px] text-muted">
        YouTube videos work differently: their captions are used when YouTube shares them. Otherwise a Gemini provider (the one picked here, or any you have added) transcribes the video from its link.
      </p>
      <div className="space-y-4 rounded-2xl bg-card p-4 ring-1 ring-line">
        <Field label="Provider" hint="OpenAI-compatible (/audio/transcriptions — OpenAI, Groq, local Whisper servers) or Gemini.">
          <select className={inputCls} value={chosen ? chosen.id : ""} onChange={(e) => setSettings({ transcriptionProviderId: e.target.value })}>
            <option value="">Off</option>
            {usable.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>
        {chosen && (
          <Field label="Model" hint={`Leave empty for ${suggestion}.`}>
            <input
              className={inputCls}
              value={transcriptionModel}
              placeholder={suggestion}
              onChange={(e) => setSettings({ transcriptionModel: e.target.value.trim() })}
            />
          </Field>
        )}
        {chosen && (
          <Button variant="soft" onClick={() => void transcribeExisting()}>
            Transcribe existing audio & video
          </Button>
        )}
      </div>
    </section>
  );
}
