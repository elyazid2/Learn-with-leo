import { useCallback, useEffect, useImperativeHandle, useRef, useState, type KeyboardEvent as RKeyboardEvent, type RefObject } from "react";
import { ExternalLink, Loader2, Maximize2, Minimize2, Pause, Play, RotateCcw, TriangleAlert, Volume2, VolumeX } from "lucide-react";
import { cn } from "@/utils/cn";

/**
 * A clean YouTube player: the video and nothing else.
 *
 * YouTube only plays inside its own frame, so the frame is still there, but its interface is not:
 * it is asked for no controls, it is taller than the box that shows it (the title and logo sit in
 * the parts that are clipped away), and a layer on top takes every tap, so nothing of YouTube's
 * ever appears on hover. Play, seek, volume, speed and fullscreen are this app's own controls,
 * talking to the frame through YouTube's embed messages.
 *
 * If those messages never arrive, the player falls back to YouTube's standard embed so the video
 * still plays.
 */

const EMBED = "https://www.youtube-nocookie.com";
const RATES = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

/** YouTube's embed error codes, in plain language. */
function reasonFor(code: number) {
  if (code === 2) return "The link doesn't point to a valid video.";
  if (code === 100) return "This video was removed or is private.";
  if (code === 101 || code === 150) return "YouTube won't play this video inside other pages. The owner may have turned that off, or YouTube wants you to sign in on its own site first.";
  if (code === 153) return "YouTube needs to know which page is playing the video, and this page can't tell it (it happens when the app is opened as a local file).";
  return "YouTube couldn't play this video here.";
}

const clock = (s: number) => {
  const t = Math.max(0, Math.floor(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = String(t % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
};

/** What a parent can ask of the player (a transcript uses it to jump to a line). */
export interface PlayerHandle {
  seekTo: (seconds: number) => void;
  getTime: () => number;
}

export default function YouTubePlayer({
  id,
  start = 0,
  vertical = false,
  clean = true,
  title,
  handle,
  onProgress,
}: {
  id: string;
  start?: number;
  vertical?: boolean;
  clean?: boolean;
  title?: string;
  handle?: RefObject<PlayerHandle | null>;
  /** Called as the video plays, with the time and the length in seconds (0 until known). */
  onProgress?: (time: number, duration: number) => void;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLIFrameElement>(null);
  const alive = useRef(false);
  const timer = useRef<number | undefined>(undefined);
  const [started, setStarted] = useState(false);
  const [basic, setBasic] = useState(!clean);
  /** YouTube player state: -1 unstarted, 0 ended, 1 playing, 2 paused, 3 buffering, 5 cued. */
  const [ps, setPs] = useState(-1);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [rate, setRate] = useState(1);
  const [error, setError] = useState<number | null>(null);
  const [fs, setFs] = useState(false);
  const [seeking, setSeeking] = useState<number | null>(null);
  const [startAt, setStartAt] = useState(Math.max(0, Math.floor(start)));
  const [reloads, setReloads] = useState(0);
  const position = useRef({ time: Math.max(0, start), duration: 0 });
  const progress = useRef(onProgress);
  progress.current = onProgress;

  const watchUrl = `https://www.youtube.com/watch?v=${id}`;
  const origin = /^https?:$/.test(window.location.protocol) ? `&origin=${encodeURIComponent(window.location.origin)}` : "";
  const from = startAt ? `&start=${startAt}` : "";
  const src = basic
    ? `${EMBED}/embed/${id}?autoplay=1&rel=0&playsinline=1${from}`
    : `${EMBED}/embed/${id}?autoplay=1&controls=0&rel=0&playsinline=1&iv_load_policy=3&disablekb=1&fs=0&cc_load_policy=0&enablejsapi=1${from}${origin}`;

  const post = useCallback((msg: Record<string, unknown>) => {
    frame.current?.contentWindow?.postMessage(JSON.stringify({ ...msg, id: 1, channel: "widget" }), EMBED);
  }, []);
  const cmd = useCallback((func: string, ...args: unknown[]) => post({ event: "command", func, args }), [post]);
  const subscribe = useCallback(() => {
    post({ event: "listening" });
    for (const name of ["onReady", "onStateChange", "onError"]) cmd("addEventListener", name);
  }, [post, cmd]);

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (e.origin !== EMBED || e.source !== frame.current?.contentWindow) return;
      let d: { event?: string; info?: unknown } | null = null;
      try {
        d = typeof e.data === "string" ? JSON.parse(e.data) : e.data;
      } catch {
        return;
      }
      if (!d || typeof d !== "object") return;
      if (!alive.current) {
        alive.current = true;
        subscribe();
      }
      if (d.event === "onError") return setError(Number(d.info) || 5);
      if (d.event === "onStateChange") return setPs(Number(d.info));
      if (d.event !== "infoDelivery" && d.event !== "initialDelivery") return;
      const i = (d.info ?? {}) as { currentTime?: number; duration?: number; playerState?: number; muted?: boolean; playbackRate?: number };
      if (typeof i.currentTime === "number") {
        setTime(i.currentTime);
        position.current.time = i.currentTime;
      }
      if (typeof i.duration === "number" && i.duration > 0) {
        setDuration(i.duration);
        position.current.duration = i.duration;
      }
      if (typeof i.currentTime === "number" || typeof i.duration === "number") progress.current?.(position.current.time, position.current.duration);
      if (typeof i.playerState === "number") setPs(i.playerState);
      if (typeof i.muted === "boolean") setMuted(i.muted);
      if (typeof i.playbackRate === "number") setRate(i.playbackRate);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [subscribe]);

  useEffect(() => () => window.clearInterval(timer.current), []);

  useEffect(() => {
    const on = () => setFs(document.fullscreenElement === wrap.current);
    document.addEventListener("fullscreenchange", on);
    return () => document.removeEventListener("fullscreenchange", on);
  }, []);

  /** The frame says nothing until it is spoken to, so keep saying hello until it answers. */
  const onLoad = () => {
    if (basic) return;
    let tries = 0;
    subscribe();
    window.clearInterval(timer.current);
    timer.current = window.setInterval(() => {
      if (alive.current) return window.clearInterval(timer.current);
      if (++tries > 14) {
        window.clearInterval(timer.current);
        setBasic(true);
        return;
      }
      subscribe();
    }, 500);
  };

  const playing = ps === 1;
  const ended = ps === 0;
  const waiting = started && !error && (ps === 3 || ps === -1 || ps === 5);

  const toggle = () => {
    if (!started) return setStarted(true);
    if (ended) {
      cmd("seekTo", 0, true);
      cmd("playVideo");
    } else if (playing) cmd("pauseVideo");
    else cmd("playVideo");
  };
  const seekTo = (s: number) => {
    const t = Math.max(0, Math.min(duration || s, s));
    cmd("seekTo", t, true);
    setTime(t);
  };
  const toggleMute = () => {
    cmd(muted ? "unMute" : "mute");
    setMuted(!muted);
  };
  const changeRate = (r: number) => {
    cmd("setPlaybackRate", r);
    setRate(r);
  };
  const toggleFs = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void wrap.current?.requestFullscreen?.().catch(() => {});
  };

  useImperativeHandle(
    handle,
    () => ({
      seekTo: (seconds: number) => {
        const t = Math.max(0, Math.floor(seconds));
        position.current.time = t;
        // Not playing yet, or YouTube's own player is showing: (re)load the video at that moment.
        if (!started || basic || !alive.current) {
          setStartAt(t);
          setReloads((n) => n + 1);
          setStarted(true);
          return;
        }
        cmd("seekTo", t, true);
        cmd("playVideo");
        setTime(t);
      },
      getTime: () => position.current.time,
    }),
    [started, basic, cmd]
  );

  const onKey = (e: RKeyboardEvent) => {
    const tag = (e.target as HTMLElement).tagName;
    if (basic || !started || tag === "SELECT" || tag === "INPUT") return;
    const k = e.key.toLowerCase();
    // A focused button already handles Space itself; handling it here too would toggle twice.
    if (k === " " && tag === "BUTTON") return;
    if (k === " " || k === "k") toggle();
    else if (k === "arrowleft") seekTo(time - 5);
    else if (k === "arrowright") seekTo(time + 5);
    else if (k === "m") toggleMute();
    else if (k === "f") toggleFs();
    else return;
    e.preventDefault();
  };

  const ratio = vertical ? 9 / 16 : 16 / 9;
  const boxStyle = fs
    ? { aspectRatio: String(ratio), width: `min(100vw, calc((100vh - 56px) * ${ratio}))` }
    : { aspectRatio: String(ratio), width: vertical ? `min(100%, calc(70dvh * ${ratio}))` : "100%" };
  const canFs = typeof document !== "undefined" && document.fullscreenEnabled;

  return (
    <div
      ref={wrap}
      tabIndex={0}
      onKeyDown={onKey}
      role="group"
      aria-label={title ? `Video: ${title}` : "Video player"}
      className={cn("overflow-hidden bg-[#000] text-[#fff] outline-none ring-1 ring-line", fs ? "flex h-screen w-screen flex-col items-center justify-center" : "rounded-2xl")}
    >
      <div className="relative mx-auto overflow-hidden bg-[#000]" style={boxStyle}>
        {started && !error && (
          <iframe
            key={basic ? `basic${reloads}` : "clean"}
            ref={frame}
            src={src}
            title={title || "YouTube video"}
            onLoad={onLoad}
            allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen={basic}
            referrerPolicy="strict-origin-when-cross-origin"
            tabIndex={basic ? 0 : -1}
            // Three times the height of the box: YouTube's title and logo land in the clipped thirds.
            className={cn("absolute left-0 w-full border-0", basic ? "top-0 h-full" : "-top-full h-[300%]")}
          />
        )}

        {!basic && !error && (
          <button
            type="button"
            onClick={toggle}
            onDoubleClick={canFs ? toggleFs : undefined}
            aria-label={!started ? "Play video" : ended ? "Play again" : playing ? "Pause" : "Play"}
            className="absolute inset-0 flex items-center justify-center outline-none"
          >
            {(!started || ended) && <img src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`} alt="" draggable={false} className="absolute inset-0 h-full w-full object-cover" />}
            {(!started || ended || ps === 2) && <span className="absolute inset-0 bg-[#000]/35" />}
            {waiting ? (
              <Loader2 size={34} className="relative animate-spin opacity-90" />
            ) : !playing ? (
              <span className="relative flex h-16 w-16 items-center justify-center rounded-full bg-[#fff]/95 text-[#17171a] shadow-lg">
                {ended ? <RotateCcw size={26} /> : <Play size={28} fill="currentColor" className="ml-1" />}
              </span>
            ) : null}
          </button>
        )}

        {error !== null && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center" role="alert">
            <TriangleAlert size={26} className="opacity-80" />
            <div className="text-[16px] font-semibold">This video can't be played here</div>
            <p className="max-w-sm text-[13px] leading-relaxed opacity-75">{reasonFor(error)}</p>
            <a href={watchUrl} target="_blank" rel="noopener noreferrer" className="inline-flex h-9 items-center gap-1.5 rounded-full bg-[#fff] px-4 text-[13px] font-semibold text-[#17171a]">
              <ExternalLink size={14} /> Open on YouTube
            </a>
          </div>
        )}
      </div>

      {started && !basic && !error && (
        <div className={cn("flex items-center gap-1.5 px-2 py-1.5 text-[12px] tabular-nums", fs && "w-full max-w-5xl")}>
          <button type="button" onClick={toggle} aria-label={playing ? "Pause" : "Play"} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-[#fff]/15">
            {playing ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}
          </button>
          <span className="shrink-0">{clock(seeking ?? time)}</span>
          <input
            type="range"
            min={0}
            max={duration || 0}
            step="any"
            value={seeking ?? Math.min(time, duration || time)}
            disabled={!duration}
            onChange={(e) => setSeeking(Number(e.target.value))}
            onPointerUp={() => {
              if (seeking !== null) seekTo(seeking);
              setSeeking(null);
            }}
            onKeyUp={() => {
              if (seeking !== null) seekTo(seeking);
              setSeeking(null);
            }}
            aria-label="Seek"
            aria-valuetext={`${clock(seeking ?? time)} of ${clock(duration)}`}
            className="h-1 min-w-0 flex-1 cursor-pointer accent-[#fff]"
          />
          <span className="shrink-0 opacity-70">{duration ? clock(duration) : "--:--"}</span>
          <button type="button" onClick={toggleMute} aria-label={muted ? "Unmute" : "Mute"} aria-pressed={muted} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-[#fff]/15">
            {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
          </button>
          <select
            value={rate}
            onChange={(e) => changeRate(Number(e.target.value))}
            aria-label="Playback speed"
            className="h-8 shrink-0 cursor-pointer rounded-full bg-[#fff]/10 px-2 text-[12px] font-medium text-[#fff] outline-none"
          >
            {RATES.map((r) => (
              <option key={r} value={r} className="text-[#17171a]">
                {r}×
              </option>
            ))}
          </select>
          {canFs && (
            <button type="button" onClick={toggleFs} aria-label={fs ? "Exit fullscreen" : "Fullscreen"} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-[#fff]/15">
              {fs ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>
          )}
        </div>
      )}
      {basic && started && clean && !error && <p className="px-3 py-2 text-[12px] opacity-70">The clean player couldn't connect, so this is YouTube's own player.</p>}
    </div>
  );
}
