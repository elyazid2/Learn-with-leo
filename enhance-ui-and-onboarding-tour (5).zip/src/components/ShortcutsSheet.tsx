import { useEffect } from "react";
import { useApp } from "@/lib/store";
import { navigate, useRoute } from "@/lib/router";
import { Kbd, Sheet, isSheetOpen } from "@/components/ui";

const isMac = typeof navigator !== "undefined" && /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
export const MOD = isMac ? "⌘" : "Ctrl";

function isTypingTarget(el: Element | null) {
  if (!el) return false;
  const h = el as HTMLElement;
  return h.isContentEditable || h.tagName === "TEXTAREA" || h.tagName === "SELECT" || (h.tagName === "INPUT" && !["checkbox", "radio", "range", "button", "submit"].includes((h as HTMLInputElement).type));
}

/** App-wide keyboard shortcuts. Quiet while a sheet is open or the learner is typing (except ⌘ combos). */
export function useGlobalShortcuts() {
  const route = useRoute();
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.defaultPrevented) return;
      const mod = e.metaKey || e.ctrlKey;
      const s = useApp.getState();
      const inProject = route.name === "project";
      const typing = isTypingTarget(document.activeElement);

      if (mod && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "k") {
        if (isSheetOpen()) return;
        e.preventDefault();
        s.requestSearch();
        return;
      }
      if (mod && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "j" && inProject) {
        if (isSheetOpen()) return;
        e.preventDefault();
        s.setChatOpen(!s.chatOpen);
        return;
      }
      if (mod && e.key === ",") {
        e.preventDefault();
        navigate("settings");
        return;
      }
      if (typing || mod || e.altKey || isSheetOpen()) return;
      if (e.key === "?") {
        e.preventDefault();
        s.setShortcutsOpen(true);
      } else if (e.key === "/" && inProject && !s.chatOpen) {
        e.preventDefault();
        s.setChatOpen(true);
      }
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [route.name]);
}

const GROUPS: { title: string; items: { keys: string[]; label: string }[] }[] = [
  {
    title: "Anywhere",
    items: [
      { keys: [MOD, "K"], label: "Search" },
      { keys: [MOD, ","], label: "Settings" },
      { keys: ["?"], label: "Show these shortcuts" },
      { keys: ["Esc"], label: "Close a sheet, dialog or Leo" },
    ],
  },
  {
    title: "In a project",
    items: [
      { keys: [MOD, "J"], label: "Open or close Leo" },
      { keys: ["/"], label: "Ask Leo" },
      { keys: ["@"], label: "Mention a note, page or file (in the chat box)" },
      { keys: ["Shift", "Enter"], label: "New line in a message" },
      { keys: [MOD, "V"], label: "Paste a YouTube link or a picture into the library" },
    ],
  },
  {
    title: "In a PDF",
    items: [
      { keys: [MOD, "Z"], label: "Undo a highlight, drawing or note" },
      { keys: [MOD, "Shift", "Z"], label: "Redo" },
      { keys: ["Esc"], label: "Put the pen down (back to selecting text)" },
    ],
  },
];

export default function ShortcutsSheet() {
  const open = useApp((s) => s.shortcutsOpen);
  const setOpen = useApp((s) => s.setShortcutsOpen);
  return (
    <Sheet open={open} onClose={() => setOpen(false)} title="Keyboard shortcuts" description="Work faster on a computer. On phones, everything is a tap away.">
      <div className="space-y-5">
        {GROUPS.map((g) => (
          <section key={g.title}>
            <h3 className="mb-1.5 text-[12px] font-semibold uppercase tracking-wide text-muted">{g.title}</h3>
            <ul className="divide-y divide-line rounded-2xl ring-1 ring-line">
              {g.items.map((it) => (
                <li key={it.label} className="flex items-center justify-between gap-3 px-3.5 py-2.5 text-[14px]">
                  <span>{it.label}</span>
                  <span className="flex shrink-0 items-center gap-1">
                    {it.keys.map((k) => (
                      <Kbd key={k}>{k}</Kbd>
                    ))}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </Sheet>
  );
}
