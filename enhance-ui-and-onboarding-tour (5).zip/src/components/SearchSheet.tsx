import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { AlignLeft, FileText, Film, Flag, Image as ImageIcon, MessageCircle, Mic, Music, PenTool, Play, Search, X } from "lucide-react";
import { colorOf, db, POINT_META, STATUS_META, type Chunk, type LibFile, type Note, type Project, type Sketch } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { stripActions } from "@/lib/ai/actions";
import { snippetOf } from "@/lib/blocks";
import { timeAgo } from "@/lib/media";
import { useApp } from "@/lib/store";
import AgentAvatar from "./AgentAvatar";

type LibItem = { kind: "note"; note: Note; at: number } | { kind: "sketch"; sketch: Sketch; at: number } | { kind: "file"; file: LibFile; at: number };

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const WIDE = /\p{Extended_Pictographic}|\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Script=Hangul}/u;
const wordsOf = (q: string) =>
  Array.from(new Set(q.toLowerCase().split(/\s+/).filter((w) => w.length >= 2 || (w && WIDE.test(w))))).slice(0, 8);
const matchesAll = (text: string, words: string[]) => {
  const t = text.toLowerCase();
  return words.every((w) => t.includes(w));
};

function around(text: string, words: string[], len = 150) {
  const flat = text.replace(/\s+/g, " ").trim();
  const lower = flat.toLowerCase();
  let at = -1;
  for (const w of words) {
    const i = lower.indexOf(w);
    if (i >= 0 && (at < 0 || i < at)) at = i;
  }
  if (at < 0) return flat.slice(0, len);
  const start = Math.max(0, at - Math.floor(len / 3));
  return (start > 0 ? "…" : "") + flat.slice(start, start + len) + (start + len < flat.length ? "…" : "");
}

function Highlight({ text, words }: { text: string; words: string[] }) {
  if (!words.length) return <>{text}</>;
  const re = new RegExp(`(${words.map(escapeRe).join("|")})`, "gi");
  return (
    <>
      {text.split(re).map((part, i) =>
        i % 2 === 1 ? (
          <mark key={i} className="rounded-[3px] bg-mark px-0.5 text-ink">
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </>
  );
}

const titleOf = (it: LibItem) => (it.kind === "note" ? it.note.title || "Untitled note" : it.kind === "sketch" ? it.sketch.title || "Sketch" : it.file.name.replace(/\.[a-z0-9]{1,5}$/i, ""));
const FILE_WORD = { pdf: "PDF", image: "Picture", video: "Video", audio: "Audio", text: "Text file" } as const;
const metaOf = (it: LibItem) =>
  it.kind === "note"
    ? `Note · edited ${timeAgo(it.at)}`
    : it.kind === "sketch"
      ? `Sketch · ${timeAgo(it.at)}`
      : `${it.file.kind === "audio" && it.file.recorded ? "Voice note" : FILE_WORD[it.file.kind]} · ${timeAgo(it.at)}`;

/** One stable empty list, so the search index is only rebuilt when the data really changes. */
const NONE: never[] = [];

/** Full-screen project search: titles, words inside notes and PDFs, Leo chats, concepts and points. */
export default function SearchSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  if (!open) return null;
  return createPortal(<SearchOverlay project={project} onClose={onClose} />, document.body);
}

function SearchOverlay({ project, onClose }: { project: Project; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [dq, setDq] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDq(q.trim()), 120);
    return () => clearTimeout(t);
  }, [q]);
  useEffect(() => {
    inputRef.current?.focus();
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const words = useMemo(() => wordsOf(dq), [dq]);
  const has = words.length > 0;

  const notes = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]) ?? NONE;
  const sketches = useLiveQuery(() => db.sketches.where("projectId").equals(project.id).toArray(), [project.id]) ?? NONE;
  const files = useLiveQuery(() => db.files.where("projectId").equals(project.id).toArray(), [project.id]) ?? NONE;
  const concepts = useLiveQuery(() => (has ? db.concepts.where("projectId").equals(project.id).toArray() : []), [project.id, has]) ?? NONE;
  const points = useLiveQuery(() => (has ? db.points.where("projectId").equals(project.id).toArray() : []), [project.id, has]) ?? NONE;
  const threads = useLiveQuery(() => (has ? db.threads.where("projectId").equals(project.id).toArray() : []), [project.id, has]) ?? NONE;
  const messages =
    useLiveQuery(() => (has ? db.messages.where("projectId").equals(project.id).filter((m) => !m.hidden && !m.error).toArray() : []), [project.id, has]) ?? NONE;
  const chunks =
    useLiveQuery((): Promise<Chunk[]> | Chunk[] => (has ? db.chunks.where("projectId").equals(project.id).filter((c) => c.sourceKind === "file").toArray() : []), [project.id, has]) ?? NONE;

  const all = useMemo<LibItem[]>(
    () =>
      [
        ...notes.map((note) => ({ kind: "note" as const, note, at: note.updatedAt })),
        ...sketches.map((sketch) => ({ kind: "sketch" as const, sketch, at: sketch.updatedAt })),
        ...files.map((file) => ({ kind: "file" as const, file, at: file.createdAt })),
      ].sort((a, b) => b.at - a.at),
    [notes, sketches, files]
  );

  const library = useMemo(() => {
    if (!has) return [];
    const out: { it: LibItem; score: number; snippet: string }[] = [];
    for (const it of all) {
      if (matchesAll(titleOf(it), words)) out.push({ it, score: 2, snippet: "" });
      else if (it.kind === "note" && matchesAll(it.note.content, words)) out.push({ it, score: 1, snippet: around(snippetOf(it.note.content, 100000), words) });
    }
    return out.sort((a, b) => b.score - a.score || b.it.at - a.it.at).slice(0, 10);
  }, [all, words, has]);

  // Substring match (so "eigen" finds "eigenvalue"), ranked by how often the words occur.
  const passages = useMemo(() => {
    if (!has) return [];
    const scored: { chunk: Chunk; score: number }[] = [];
    for (const c of chunks) {
      const t = c.text.toLowerCase();
      if (!words.every((w) => t.includes(w))) continue;
      let score = 0;
      for (const w of words) for (let i = t.indexOf(w); i >= 0; i = t.indexOf(w, i + w.length)) score++;
      scored.push({ chunk: c, score });
    }
    return scored.sort((a, b) => b.score - a.score).slice(0, 8);
  }, [has, words, chunks]);

  const threadTitle = useMemo(() => new Map(threads.map((t) => [t.id, t.title])), [threads]);
  const chats = useMemo(() => {
    if (!has) return [];
    return messages
      .map((m) => ({ m, text: stripActions(m.content) }))
      .filter((x) => x.text && matchesAll(x.text, words))
      .sort((a, b) => b.m.createdAt - a.m.createdAt)
      .slice(0, 6);
  }, [messages, words, has]);

  const learning = useMemo(() => {
    if (!has) return [];
    return [
      ...concepts.filter((c) => matchesAll(`${c.name} ${c.note ?? ""}`, words)).map((c) => ({ kind: "concept" as const, c })),
      ...points.filter((p) => matchesAll(p.text, words)).map((p) => ({ kind: "point" as const, p })),
    ].slice(0, 8);
  }, [concepts, points, words, has]);

  const fileById = useMemo(() => new Map(files.map((f) => [f.id, f])), [files]);
  const indexing = files.filter((f) => f.indexed === "pending").length;

  const close = (fn: () => void) => () => {
    onClose();
    fn();
  };
  const openItem = (it: LibItem) =>
    close(() => {
      if (it.kind === "note") navigate(projectPath(project.id, "notes", it.note.id));
      else if (it.kind === "sketch") navigate(projectPath(project.id, "sketch", it.sketch.id));
      else navigate(projectPath(project.id, "library", it.file.id));
    });
  const openPassage = (c: Chunk) =>
    close(() => {
      if (c.page > 0) localStorage.setItem("pdfpage." + c.sourceId, String(c.page));
      navigate(projectPath(project.id, "library", c.sourceId));
    });
  const openChat = (threadId: string) =>
    close(() => {
      useApp.getState().setActiveThread(project.id, threadId);
      useApp.getState().setChatOpen(true);
    });
  const openProgress = close(() => navigate(projectPath(project.id, "progress")));

  const first = library[0] ? openItem(library[0].it) : passages[0] ? openPassage(passages[0].chunk) : chats[0] ? openChat(chats[0].m.threadId) : learning[0] ? openProgress : null;
  const total = library.length + passages.length + chats.length + learning.length;

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-paper" role="dialog" aria-modal="true" aria-label={`Search ${project.name}`}>
      <div className="shrink-0 border-b border-line bg-paper/95 pt-[env(safe-area-inset-top)] backdrop-blur">
        <div className="mx-auto flex h-16 max-w-2xl items-center gap-2 px-3">
          <div className="relative min-w-0 flex-1">
            <Search size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input
              ref={inputRef}
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") first?.();
                if (e.key === "Escape") onClose();
              }}
              placeholder={`Search ${project.name}`}
              enterKeyHint="search"
              aria-label="Search"
              dir="auto"
              className="h-11 w-full rounded-full bg-card pl-10 pr-10 text-[16px] outline-none ring-1 ring-line placeholder:text-muted/80 focus:ring-2 focus:ring-ink/25 [&::-webkit-search-cancel-button]:hidden"
            />
            {q && (
              <button
                onClick={() => {
                  setQ("");
                  inputRef.current?.focus();
                }}
                aria-label="Clear search"
                className="absolute right-1.5 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-muted hover:bg-ink/[0.06]"
              >
                <X size={15} />
              </button>
            )}
          </div>
          <button onClick={onClose} className="h-11 shrink-0 rounded-full px-3 text-[15px] font-medium transition-colors hover:bg-ink/[0.05]">
            Cancel
          </button>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="mx-auto max-w-2xl px-2 pb-[max(3rem,env(safe-area-inset-bottom))] pt-1">
          {!has ? (
            <>
              {all.length > 0 && (
                <Group title="Recent">
                  {all.slice(0, 6).map((it) => (
                    <Row key={`${it.kind}-${titleOf(it)}-${it.at}`} onOpen={openItem(it)} lead={<Thumb it={it} project={project} />} title={titleOf(it)} sub={metaOf(it)} />
                  ))}
                </Group>
              )}
              <p className="mx-auto max-w-sm px-4 pt-8 text-center text-[13px] leading-relaxed text-muted">
                Search titles, words inside your notes and PDFs, things Leo said, and your concepts and points.
              </p>
            </>
          ) : total === 0 ? (
            <div className="px-6 py-16 text-center">
              <p className="text-[15px] font-semibold">No results for “{dq}”</p>
              <p className="mt-1 text-[13px] text-muted">Try fewer words, or a word that appears inside a document.</p>
            </div>
          ) : (
            <>
              {library.length > 0 && (
                <Group title="Library" count={library.length}>
                  {library.map(({ it, snippet }) => (
                    <Row
                      key={`${it.kind}-${titleOf(it)}-${it.at}`}
                      onOpen={openItem(it)}
                      lead={<Thumb it={it} project={project} />}
                      title={<Highlight text={titleOf(it)} words={words} />}
                      sub={snippet ? <Highlight text={snippet} words={words} /> : metaOf(it)}
                    />
                  ))}
                </Group>
              )}
              {passages.length > 0 && (
                <Group title="Inside documents" count={passages.length}>
                  {passages.map(({ chunk }) => {
                    const f = fileById.get(chunk.sourceId);
                    return (
                      <Row
                        key={chunk.id}
                        onOpen={openPassage(chunk)}
                        lead={f ? <Thumb it={{ kind: "file", file: f, at: f.createdAt }} project={project} /> : <Tile icon={<FileText size={18} />} />}
                        title={<Highlight text={around(chunk.text, words)} words={words} />}
                        sub={`${chunk.sourceName.replace(/\.[a-z0-9]{1,5}$/i, "")}${chunk.page ? ` · page ${chunk.page}` : ""}`}
                      />
                    );
                  })}
                </Group>
              )}
              {chats.length > 0 && (
                <Group title="Chats with Leo" count={chats.length}>
                  {chats.map(({ m, text }) => (
                    <Row
                      key={m.id}
                      onOpen={openChat(m.threadId)}
                      lead={m.role === "assistant" ? <AgentAvatar size={40} frozenAt={0} look={project.avatar} /> : <Tile icon={<MessageCircle size={18} />} />}
                      title={<Highlight text={around(text, words)} words={words} />}
                      sub={`${m.role === "assistant" ? "Leo" : "You"} · ${threadTitle.get(m.threadId) ?? "Chat"} · ${timeAgo(m.createdAt)}`}
                    />
                  ))}
                </Group>
              )}
              {learning.length > 0 && (
                <Group title="Concepts and points" count={learning.length}>
                  {learning.map((x) =>
                    x.kind === "concept" ? (
                      <Row
                        key={x.c.id}
                        onOpen={openProgress}
                        lead={<Tile icon={<span className="h-3 w-3 rounded-full" style={{ background: STATUS_META[x.c.status].color }} />} />}
                        title={<Highlight text={x.c.name} words={words} />}
                        sub={`Concept · ${STATUS_META[x.c.status].label}`}
                      />
                    ) : (
                      <Row
                        key={x.p.id}
                        onOpen={openProgress}
                        lead={<Tile icon={<Flag size={17} />} />}
                        title={<Highlight text={x.p.text} words={words} />}
                        sub={`Point · ${POINT_META[x.p.kind].label}${x.p.done ? " · resolved" : ""}`}
                      />
                    )
                  )}
                </Group>
              )}
            </>
          )}
          {has && indexing > 0 && (
            <p className="px-4 pt-6 text-center text-[12px] text-muted">
              {indexing} {indexing === 1 ? "file is" : "files are"} still being indexed — their text will be searchable shortly.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Group({ title, count, children }: { title: string; count?: number; children: ReactNode }) {
  return (
    <section className="mt-4">
      <h3 className="flex items-baseline justify-between px-3 pb-1 text-[13px] font-semibold text-muted">
        <span>{title}</span>
        {count != null && <span className="font-normal tabular-nums">{count}</span>}
      </h3>
      <ul>{children}</ul>
    </section>
  );
}

function Row({ onOpen, lead, title, sub }: { onOpen: () => void; lead: ReactNode; title: ReactNode; sub?: ReactNode }) {
  return (
    <li>
      <button onClick={onOpen} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors hover:bg-ink/[0.04] active:bg-ink/[0.07]">
        <span className="shrink-0">{lead}</span>
        <span className="min-w-0 flex-1">
          <span className="line-clamp-2 text-[15px] leading-snug" dir="auto">
            {title}
          </span>
          {sub && (
            <span className="mt-0.5 line-clamp-2 block text-[13px] leading-snug text-muted" dir="auto">
              {sub}
            </span>
          )}
        </span>
      </button>
    </li>
  );
}

function Tile({ icon, style }: { icon: ReactNode; style?: React.CSSProperties }) {
  return (
    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ink/[0.06] text-muted" style={style}>
      {icon}
    </span>
  );
}

function Thumb({ it, project }: { it: LibItem; project: Project }) {
  if (it.kind === "note") return <Tile icon={<FileText size={18} />} />;
  if (it.kind === "sketch")
    return it.sketch.thumb ? <img src={it.sketch.thumb} alt="" className="h-10 w-10 rounded-xl bg-card object-contain ring-1 ring-line" /> : <Tile icon={<PenTool size={18} />} />;
  const f = it.file;
  if (f.kind === "audio") {
    const c = colorOf(project.color).hex;
    return <Tile icon={f.recorded ? <Mic size={18} /> : <Music size={18} />} style={{ background: `color-mix(in srgb, ${c} 14%, var(--card))`, color: c }} />;
  }
  if (f.kind === "text") return <Tile icon={<AlignLeft size={18} />} />;
  if (!f.thumb) return <Tile icon={f.kind === "video" ? <Film size={18} /> : f.kind === "image" ? <ImageIcon size={18} /> : <FileText size={18} />} />;
  return (
    <span className="relative block h-10 w-10 overflow-hidden rounded-xl bg-card ring-1 ring-line">
      <img src={f.thumb} alt="" className={`h-full w-full object-cover ${f.kind === "pdf" ? "object-top" : ""}`} />
      {f.kind === "video" && (
        <span className="absolute inset-0 flex items-center justify-center bg-[#000]/25 text-[#fff]">
          <Play size={13} fill="currentColor" />
        </span>
      )}
    </span>
  );
}
