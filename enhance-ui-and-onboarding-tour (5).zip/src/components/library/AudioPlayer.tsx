import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from "react";
import { Pause, Play, RotateCcw, RotateCw } from "lucide-react";
import type { LibFile } from "@/lib/db";
import { formatDuration } from "@/lib/media";

/** Neutral track for the unplayed part — derived from --ink, so it reads in light and dark. */
const TRACK = "color-mix(in srgb, var(--ink) 16%, transparent)";

/**
 * Waveform bars: the played part in `color`, the rest as a neutral track. Uses theme tokens,
 * never a hard-coded dark color (which used to vanish on the dark card while playing).
 */
export function Waveform({
  peaks,
  progress = 0,
  color = "var(--ink)",
  rest = TRACK,
  bars,
  className,
  onSeek,
  label = "Seek",
}: {
  peaks?: number[];
  progress?: number;
  color?: string;
  rest?: string;
  bars?: number;
  className?: string;
  onSeek?: (ratio: number) => void;
  label?: string;
}) {
  const data = useMemo(() => {
    if (peaks?.length) return peaks;
    const n = bars ?? 48;
    return Array.from({ length: n }, (_, i) => 0.25 + 0.5 * Math.abs(Math.sin(i * 0.7) * Math.cos(i * 0.23)));
  }, [peaks, bars]);
  const dragging = useRef(false);
  const ratioAt = (e: RPointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
  };
  const seekable = !!onSeek;
  return (
    <div
      className={`flex items-center gap-[2px] ${seekable ? "cursor-pointer touch-none" : ""} ${className ?? ""}`}
      role={seekable ? "slider" : undefined}
      aria-label={seekable ? label : undefined}
      aria-valuemin={seekable ? 0 : undefined}
      aria-valuemax={seekable ? 100 : undefined}
      aria-valuenow={seekable ? Math.round(progress * 100) : undefined}
      tabIndex={seekable ? 0 : undefined}
      onPointerDown={
        seekable
          ? (e) => {
              dragging.current = true;
              e.currentTarget.setPointerCapture(e.pointerId);
              onSeek(ratioAt(e));
            }
          : undefined
      }
      onPointerMove={seekable ? (e) => dragging.current && onSeek(ratioAt(e)) : undefined}
      onPointerUp={seekable ? () => (dragging.current = false) : undefined}
      onPointerCancel={seekable ? () => (dragging.current = false) : undefined}
      onKeyDown={
        seekable
          ? (e) => {
              if (e.key === "ArrowRight") onSeek(Math.min(1, progress + 0.05));
              if (e.key === "ArrowLeft") onSeek(Math.max(0, progress - 0.05));
            }
          : undefined
      }
    >
      {data.map((p, i) => (
        <div
          key={i}
          className="flex-1 rounded-full"
          style={{ height: `${Math.max(8, p * 100)}%`, background: (i + 0.5) / data.length <= progress ? color : rest }}
        />
      ))}
    </div>
  );
}

const RATES = [0.75, 1, 1.25, 1.5, 2];

export default function AudioPlayer({ file, accent }: { file: LibFile; accent?: string }) {
  const [url, setUrl] = useState("");
  // One address per file. The database returns a new Blob object whenever the file's record changes
  // (a rename, a finished transcript); a new address each time would restart what is playing.
  const contents = useRef(file.blob);
  contents.current = file.blob;
  useEffect(() => {
    const u = URL.createObjectURL(contents.current);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [file.id]);
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [t, setT] = useState(0);
  const [dur, setDur] = useState(file.duration ?? 0);
  const [rate, setRate] = useState(1);

  useEffect(() => {
    if (ref.current) ref.current.playbackRate = rate;
  }, [rate]);

  // Smooth progress while playing (timeupdate alone only fires ~4×/s).
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = 0;
    const tick = (now: number) => {
      if (now - last > 33) {
        last = now;
        const a = ref.current;
        if (a) setT(a.currentTime);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  const toggle = () => {
    const a = ref.current;
    if (!a) return;
    if (a.paused) void a.play();
    else a.pause();
  };
  const seek = (ratio: number) => {
    const a = ref.current;
    if (!a) return;
    const d = isFinite(a.duration) ? a.duration : dur;
    if (d) {
      a.currentTime = ratio * d;
      setT(a.currentTime);
    }
  };
  const skip = (s: number) => {
    const a = ref.current;
    if (!a) return;
    a.currentTime = Math.max(0, a.currentTime + s);
    setT(a.currentTime);
  };

  return (
    <div className="w-full">
      <audio
        ref={ref}
        src={url}
        preload="metadata"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
        onTimeUpdate={(e) => setT(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => isFinite(e.currentTarget.duration) && setDur(e.currentTarget.duration)}
        onDurationChange={(e) => isFinite(e.currentTarget.duration) && setDur(e.currentTarget.duration)}
      />
      <div className="w-full rounded-2xl bg-card p-5 ring-1 ring-line">
        <Waveform peaks={file.peaks} progress={dur ? Math.min(1, t / dur) : 0} color={accent ?? "var(--ink)"} className="h-28" onSeek={seek} label="Seek in recording" />
        <div className="mt-3 flex justify-between text-[12px] tabular-nums text-muted">
          <span>{formatDuration(t)}</span>
          <span>{formatDuration(dur)}</span>
        </div>
        <div className="mt-5 flex items-center justify-center gap-6">
          <button onClick={() => skip(-10)} className="flex h-11 w-11 items-center justify-center rounded-full text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink" aria-label="Back 10 seconds">
            <RotateCcw size={22} />
          </button>
          <button
            onClick={toggle}
            className="flex h-16 w-16 items-center justify-center rounded-full bg-ink text-white transition-transform active:scale-95"
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? <Pause size={26} fill="currentColor" /> : <Play size={26} fill="currentColor" className="ml-1" />}
          </button>
          <button onClick={() => skip(10)} className="flex h-11 w-11 items-center justify-center rounded-full text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink" aria-label="Forward 10 seconds">
            <RotateCw size={22} />
          </button>
        </div>
        <div className="mt-4 flex justify-center">
          <button
            onClick={() => setRate(RATES[(RATES.indexOf(rate) + 1) % RATES.length])}
            className="h-8 rounded-full bg-ink/[0.06] px-3 text-[12px] font-semibold tabular-nums transition-colors hover:bg-ink/[0.1]"
            aria-label={`Playback speed ${rate}×`}
          >
            {rate}×
          </button>
        </div>
      </div>
    </div>
  );
}
