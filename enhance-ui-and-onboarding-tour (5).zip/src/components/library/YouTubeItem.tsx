import { useEffect, useMemo, useRef, useState } from "react";
import { Captions, Check, ClipboardPaste, Copy, Loader2, RefreshCw, Search, TriangleAlert } from "lucide-react";
import { db, type LibFile, type Project } from "@/lib/db";
import { useApp } from "@/lib/store";
import { navigate, projectPath } from "@/lib/router";
import { clock, queueIndex, saveTranscript } from "@/lib/retrieval";
import { VideoError, addYoutubeVideo, linkRef, parsePastedTranscript, transcriptText } from "@/lib/youtube";
import YouTubePlayer, { type PlayerHandle } from "@/components/YouTubePlayer";
import { Button, Sheet, inputCls } from "@/components/ui";
import { cn } from "@/utils/cn";

/** Add a link to the library and say what happened. Resolves with a message when it could not be added. */
export async function addVideoToLibrary(projectId: string, link: string): Promise<string | null> {
  try {
    const { file, existing } = await addYoutubeVideo(projectId, link);
    useApp.getState().showToast(existing ? `"${file.name}" is already in your library` : `Added "${file.name}"`, {
      tone: existing ? "info" : "success",
      action: { label: "Open", onClick: () => navigate(projectPath(projectId, "library", file.id)) },
    });
    return null;
  } catch (e) {
    return e instanceof VideoError ? e.message : "The video couldn't be added. Check your connection and try again.";
  }
}

/** "YouTube link" in Add to library: paste a link and the video becomes a library item. */
export function AddYouTubeSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setValue("");
    setError("");
    setBusy(false);
  }, [open]);

  const add = async (link: string) => {
    if (busy) return;
    if (!linkRef(link)) return setError("That doesn't look like a YouTube video link.");
    setBusy(true);
    setError("");
    const problem = await addVideoToLibrary(project.id, link);
    setBusy(false);
    if (problem) setError(problem);
    else onClose();
  };

  const paste = async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) return setError("There's nothing to paste. Copy the video's link first.");
      setValue(text);
      // A pasted link is added straight away: paste is the whole gesture.
      if (linkRef(text)) void add(text);
      else setError("That doesn't look like a YouTube video link.");
    } catch {
      setError("Your browser didn't allow reading the clipboard. Paste the link into the box instead.");
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Add a YouTube video" description="Paste a link. The video is added to your library and plays here, without YouTube's interface.">
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          void add(value);
        }}
      >
        <div className="flex items-center gap-2">
          <input
            className={inputCls}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              setError("");
            }}
            onPaste={(e) => {
              const text = e.clipboardData.getData("text").trim();
              if (!linkRef(text)) return;
              e.preventDefault();
              setValue(text);
              void add(text);
            }}
            inputMode="url"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            enterKeyHint="done"
            placeholder="https://www.youtube.com/watch?v=…"
            aria-label="YouTube link"
            aria-invalid={!!error}
            disabled={busy}
          />
          <Button type="button" variant="soft" size="lg" className="shrink-0" onClick={() => void paste()} disabled={busy}>
            <ClipboardPaste size={16} /> Paste
          </Button>
        </div>
        {error && (
          <p role="alert" className="flex items-start gap-1.5 text-[13px] leading-snug text-danger-fg">
            <TriangleAlert size={14} className="mt-0.5 shrink-0" /> {error}
          </p>
        )}
        <Button type="submit" size="lg" className="w-full" disabled={busy || !value.trim()}>
          {busy ? (
            <>
              <Loader2 size={16} className="animate-spin" /> Adding…
            </>
          ) : (
            "Add to library"
          )}
        </Button>
        <p className="text-[13px] leading-relaxed text-muted">Leo gets the video's transcript, so he can answer questions about it and quiz you on it.</p>
      </form>
    </Sheet>
  );
}

/* ------------------------------------------------------------- transcript */

function sourceLabel(file: LibFile) {
  const t = file.transcript;
  if (!t) return "";
  if (t.source === "captions") return `From YouTube's captions${t.lang ? ` · ${t.lang}` : ""}${t.auto ? " · automatic" : ""}`;
  if (t.source === "gemini") return `Transcribed by Gemini${t.model ? ` · ${t.model}` : ""}`;
  return t.timed ? "Pasted by you" : "Pasted by you · no timestamps";
}

const sentence = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?)]$/.test(s) ? "" : ".") : "");

function TranscriptPanel({ file, second, onSeek }: { file: LibFile; second: number; onSeek: (t: number) => void }) {
  const t = file.transcript;
  const [query, setQuery] = useState("");
  const [pasting, setPasting] = useState(false);
  const [draft, setDraft] = useState("");
  const [copied, setCopied] = useState(false);
  const list = useRef<HTMLDivElement>(null);
  const segments = useMemo(() => t?.segments ?? [], [t]);
  const timed = !!t?.timed;
  const pending = file.indexed === "pending";
  const q = query.trim().toLowerCase();

  const active = useMemo(() => {
    if (!timed) return -1;
    let found = -1;
    for (let i = 0; i < segments.length && segments[i].t0 <= second + 0.5; i++) found = i;
    return found;
  }, [segments, second, timed]);
  const shown = useMemo(() => segments.map((s, i) => ({ s, i })).filter(({ s }) => !q || s.text.toLowerCase().includes(q)), [segments, q]);

  // Keep the line being spoken in view, unless the learner is reading or searching the list.
  useEffect(() => {
    const box = list.current;
    if (!box || active < 0 || q || box.matches(":hover")) return;
    const row = box.querySelector<HTMLElement>(`[data-line="${active}"]`);
    if (row) box.scrollTo({ top: Math.max(0, row.offsetTop - box.clientHeight / 2 + row.clientHeight / 2), behavior: "smooth" });
  }, [active, q]);

  const toast = useApp.getState().showToast;
  const savePasted = async () => {
    const parsed = parsePastedTranscript(draft, file.duration ?? 0);
    if (!parsed.segments.length) return toast("There's no text in that yet", { tone: "error" });
    await saveTranscript(file, { source: "pasted", timed: parsed.timed, segments: parsed.segments, at: Date.now() });
    setPasting(false);
    setDraft("");
    toast("Transcript saved. Leo can read it now.", { tone: "success" });
  };
  const fetchAgain = async () => {
    await db.files.update(file.id, { indexed: "pending", indexNote: undefined });
    queueIndex(file.id);
  };
  const copy = async () => {
    if (!t) return;
    try {
      await navigator.clipboard.writeText(transcriptText(t));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      toast("Couldn't copy. Select the text and copy it instead.", { tone: "error" });
    }
  };

  const small = "inline-flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[12px] font-medium text-muted transition-colors hover:bg-ink/[0.06] hover:text-ink";

  return (
    <section aria-label="Transcript" className="flex min-h-0 flex-col overflow-hidden rounded-2xl bg-card ring-1 ring-line">
      <header className="flex items-center gap-2 px-3.5 pb-1 pt-3">
        <Captions size={17} className="shrink-0 text-muted" />
        <h2 className="text-[15px] font-semibold">Transcript</h2>
        {segments.length > 0 && !pasting && (
          <button type="button" onClick={() => void copy()} className={cn(small, "ml-auto")}>
            {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Copied" : "Copy"}
          </button>
        )}
      </header>

      {pasting ? (
        <div className="space-y-2.5 px-3.5 pb-3.5 pt-1">
          <p className="text-[13px] leading-relaxed text-muted">On YouTube, open the video's description, choose “Show transcript”, select it all and copy. Timestamps are kept when they are there.</p>
          <textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={8}
            dir="auto"
            placeholder={"0:00\nWelcome to the lesson…\n0:12\nToday we look at…"}
            aria-label="Transcript text"
            className={cn(inputCls, "min-h-40 resize-y text-[15px] leading-relaxed")}
          />
          <div className="flex gap-2">
            <Button onClick={() => void savePasted()} disabled={!draft.trim()}>
              Save transcript
            </Button>
            <Button variant="ghost" onClick={() => setPasting(false)}>
              Cancel
            </Button>
          </div>
        </div>
      ) : pending ? (
        <div className="flex items-start gap-3 px-3.5 pb-4 pt-2" role="status">
          <Loader2 size={18} className="mt-0.5 shrink-0 animate-spin text-muted" />
          <div>
            <div className="text-[14px] font-medium">Getting the transcript…</div>
            <p className="mt-0.5 text-[13px] leading-relaxed text-muted">Looking for YouTube's captions first. If there are none, Gemini transcribes the video, which can take a few minutes for a long one. You can watch meanwhile.</p>
          </div>
        </div>
      ) : segments.length > 0 ? (
        <>
          <div className="px-3.5 text-[12px] text-muted">{sourceLabel(file)}</div>
          {t?.partial && <p className="mx-3.5 mt-2 rounded-xl bg-warn-bg px-3 py-2 text-[12.5px] leading-snug text-warn-fg">This transcript stops early: the video was too long to transcribe in one go.</p>}
          <div className="relative px-3.5 pb-1.5 pt-2.5">
            <Search size={14} className="pointer-events-none absolute left-6 top-1/2 -translate-y-[calc(50%-2px)] text-muted" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Escape" && query && (e.stopPropagation(), setQuery(""))}
              placeholder="Search the transcript"
              aria-label="Search the transcript"
              className="h-9 w-full rounded-full bg-ink/[0.05] pl-8 pr-3 text-[16px] outline-none ring-1 ring-transparent placeholder:text-muted/80 focus:ring-ink/20 sm:text-[14px]"
            />
          </div>
          <div ref={list} data-ctx-source={`video "${file.name}" transcript`} className="relative min-h-0 flex-1 overflow-y-auto overscroll-contain px-1.5 pb-2" style={{ maxHeight: "min(60dvh, 34rem)" }}>
            {shown.length === 0 && <p className="px-2.5 py-4 text-[13px] text-muted">Nothing in the transcript matches “{query.trim()}”.</p>}
            {shown.map(({ s, i }) =>
              timed ? (
                // The whole line jumps to that moment; the words stay selectable (select some and ask Leo).
                <div
                  key={i}
                  data-line={i}
                  data-active={i === active || undefined}
                  onClick={() => {
                    if (document.getSelection()?.isCollapsed !== false) onSeek(s.t0);
                  }}
                  className={cn("flex cursor-pointer gap-2.5 rounded-xl px-2 py-1.5 text-[14px] leading-relaxed transition-colors hover:bg-ink/[0.04]", i === active && "bg-ink/[0.07]")}
                >
                  <button type="button" aria-label={`Play from ${clock(s.t0)}`} className="h-6 w-11 shrink-0 rounded-md text-left text-[12px] font-semibold tabular-nums text-muted">
                    {clock(s.t0)}
                  </button>
                  <p dir="auto" className="min-w-0 flex-1">
                    {s.text}
                  </p>
                </div>
              ) : (
                <p key={i} dir="auto" className="px-2.5 py-1.5 text-[14px] leading-relaxed">
                  {s.text}
                </p>
              )
            )}
          </div>
          <div className="flex flex-wrap items-center gap-1 border-t border-line px-2 py-1.5">
            <button type="button" onClick={() => setPasting(true)} className={small}>
              <ClipboardPaste size={13} /> Replace with pasted text
            </button>
            <button type="button" onClick={() => void fetchAgain()} className={small}>
              <RefreshCw size={13} /> Fetch again
            </button>
          </div>
        </>
      ) : (
        <div className="px-3.5 pb-4 pt-1.5">
          <div className="text-[14px] font-medium">No transcript yet</div>
          <p className="mt-0.5 text-[13px] leading-relaxed text-muted">Leo can't read this video until it has one. {sentence(file.indexNote ?? "")}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={() => setPasting(true)}>
              <ClipboardPaste size={15} /> Paste a transcript
            </Button>
            <Button variant="soft" onClick={() => void fetchAgain()}>
              <RefreshCw size={15} /> Try again
            </Button>
          </div>
        </div>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ stage */

/** A YouTube item: the clean player, and beside (or under) it the transcript, which follows the video. */
export function YouTubeStage({ file }: { file: LibFile }) {
  const video = file.youtube;
  const player = useRef<PlayerHandle | null>(null);
  const position = useRef(0);
  const saved = useRef(0);
  const durationKnown = useRef(!!file.duration);
  const [second, setSecond] = useState(0);
  const setVideo = useApp((s) => s.setVideo);
  // Reopen where you stopped (or where the link pointed).
  const [resume] = useState(() => {
    const at = Number(localStorage.getItem("ytpos." + file.id));
    return at > 5 ? Math.floor(at) : (video?.start ?? 0);
  });

  // Tell Leo which video is open and where the learner is in it.
  useEffect(() => {
    position.current = resume;
    setVideo({ fileId: file.id, name: file.name, getTime: () => position.current });
    return () => {
      if (useApp.getState().video?.fileId === file.id) setVideo(null);
    };
  }, [file.id, file.name, resume, setVideo]);

  // A tapped citation ("Lecture 3, 12:40") jumps to that moment.
  useEffect(() => {
    const on = (e: Event) => {
      const d = (e as CustomEvent<{ fileId: string; t0?: number }>).detail;
      if (d?.fileId === file.id && typeof d.t0 === "number") player.current?.seekTo(d.t0);
    };
    window.addEventListener("harness:seek", on);
    return () => window.removeEventListener("harness:seek", on);
  }, [file.id]);

  if (!video) return null;

  const onProgress = (time: number, duration: number) => {
    position.current = time;
    const s = Math.floor(time);
    setSecond((prev) => (prev === s ? prev : s));
    // Finished videos start from the beginning next time; otherwise the place is saved every few seconds.
    const nearEnd = duration > 0 && time > duration - Math.min(10, duration * 0.1);
    if (nearEnd ? saved.current !== -1 : Math.abs(time - saved.current) >= 5) {
      saved.current = nearEnd ? -1 : time;
      localStorage.setItem("ytpos." + file.id, String(nearEnd ? 0 : s));
    }
    if (duration > 0 && !durationKnown.current) {
      durationKnown.current = true;
      void db.files.update(file.id, { duration: Math.round(duration) });
    }
  };

  return (
    <div className="@container">
      <div className="mx-auto grid max-w-6xl gap-4 sm:px-4 sm:pt-4 @4xl:grid-cols-[minmax(0,1fr)_23rem] @4xl:items-start">
        <div className="min-w-0">
          <YouTubePlayer key={video.id} id={video.id} start={resume} vertical={video.vertical} title={file.name} handle={player} onProgress={onProgress} />
          <p className="px-4 pt-3 text-[13px] leading-relaxed text-muted sm:px-1">
            Added {new Date(file.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}. Leo can't watch the video; he works from its transcript.
          </p>
        </div>
        <div className="min-w-0 px-3 sm:px-0">
          <TranscriptPanel
            file={file}
            second={second}
            onSeek={(t) => {
              position.current = t;
              setSecond(Math.floor(t));
              player.current?.seekTo(t);
            }}
          />
        </div>
      </div>
    </div>
  );
}
