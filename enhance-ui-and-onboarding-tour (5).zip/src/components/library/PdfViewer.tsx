import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Loader2, Minus, Plus, RotateCcw, StickyNote } from "lucide-react";
import type { PDFDocumentProxy } from "pdfjs-dist/legacy/build/pdf.mjs";
import { uid, type Highlight, type LibFile, type PageNote, type Stroke } from "@/lib/db";
import { closePdf, getPdfjs, openPdf, setPdfReaderActive } from "@/lib/media";
import { useApp } from "@/lib/store";
import { arabicFallback } from "@/lib/pdfAssets";
import { HIGHLIGHT_COLORS, PEN_COLORS, PEN_WIDTH, annotationSummary, highlightAt } from "@/lib/annotations";
import { isSheetOpen } from "@/components/ui";
import { AnnotationToolbar, HighlightLayer, HighlightMenu, InkLayer, PageNotes, SelectionMenu, marksFromRange, useAnnotations, type Mark, type Tool } from "./PdfAnnotations";

const TOUCH = typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches;
/** Phones: at most 2× and ~5 MP per page — sharp text, and safe for iOS's canvas memory limit. */
const MAX_DPR = TOUCH ? 2 : 3;
const MAX_CANVAS_PIXELS = TOUCH ? 5_000_000 : 16_000_000;
/** Pages are drawn when they are within this many viewports of the visible area; beyond that they are released. */
const PRELOAD = "120%";
/** Pages drawn at the same time. Keeps canvas memory flat on phones and big documents. */
const CONCURRENCY = TOUCH ? 1 : 2;
/** Space kept above a page when jumping to it (the tool pill floats there). */
const TOP_GAP = 72;
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 3;
const ZOOM_STEP = 0.25;

interface Job {
  priority: () => number;
  run: (signal: AbortSignal) => Promise<void>;
  ctrl: AbortController;
}

/**
 * Runs page renders with a small concurrency limit, nearest-to-the-reader first. A cancelled job
 * frees its slot immediately, so a stuck page can never block the pages after it (this was the
 * cause of "only page 1 renders").
 */
class RenderScheduler {
  private queue: Job[] = [];
  private running = 0;
  constructor(private readonly limit: number) {}

  schedule(priority: () => number, run: (signal: AbortSignal) => Promise<void>): () => void {
    const job: Job = { priority, run, ctrl: new AbortController() };
    this.queue.push(job);
    this.pump();
    return () => {
      const i = this.queue.indexOf(job);
      if (i >= 0) this.queue.splice(i, 1);
      job.ctrl.abort();
    };
  }

  private pump() {
    while (this.running < this.limit && this.queue.length > 0) {
      this.queue.sort((a, b) => a.priority() - b.priority());
      const job = this.queue.shift() as Job;
      this.running++;
      const aborted = new Promise<void>((resolve) => job.ctrl.signal.addEventListener("abort", () => resolve(), { once: true }));
      Promise.race([job.run(job.ctrl.signal), aborted])
        .catch(() => {
          /* each page reports its own failure */
        })
        .finally(() => {
          this.running--;
          this.pump();
        });
    }
  }
}

interface PageMarks {
  highlights: Highlight[];
  strokes: Stroke[];
  notes: PageNote[];
}
const NO_MARKS: PageMarks = { highlights: [], strokes: [], notes: [] };

/** The text the learner has selected in this viewer, and where it is on screen. */
interface Picked {
  marks: Mark[];
  text: string;
  box: { left: number; top: number; right: number; bottom: number };
}

interface PageActions {
  stroke: (page: number, points: number[]) => void;
  erase: (ids: string[]) => void;
  click: (page: number, x: number, y: number, clientX: number, clientY: number) => void;
  noteChange: (id: string, text: string) => void;
  noteRemove: (id: string, quiet?: boolean) => void;
}

/** The viewer the learner last touched: with two PDFs side by side, Undo goes to that one. */
let activeViewer = "";

const remembered = (key: string, allowed: readonly { hex: string }[]) => {
  const saved = localStorage.getItem(key);
  return allowed.some((c) => c.hex === saved) ? (saved as string) : allowed[0].hex;
};

/**
 * Continuous-scroll PDF reader with annotations. Only pages near the viewport are rendered
 * (IntersectionObserver), every page has a placeholder of the right height so scrolling works for
 * 500+ page files, and pages that scroll away are cancelled and released. `bar` renders the single
 * top bar and receives the page/zoom controls to place inside it.
 *
 * Highlights, pen strokes and page notes are saved with the PDF (see lib/annotations).
 */
export default function PdfViewer({ file, bar }: { file: LibFile; bar?: (controls: ReactNode) => ReactNode }) {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [err, setErr] = useState("");
  const [ratio, setRatio] = useState(1.294);
  const [fitWidth, setFitWidth] = useState(0);
  // Zoom is remembered per document, like the page.
  const [zoom, setZoom] = useState(() => {
    const z = Number(localStorage.getItem("pdfzoom." + file.id));
    return z >= ZOOM_MIN && z <= ZOOM_MAX ? z : 1;
  });
  const [current, setCurrent] = useState(1);
  const [draft, setDraft] = useState<string | null>(null);
  const [scroller, setScroller] = useState<HTMLDivElement | null>(null);
  const [scheduler] = useState(() => new RenderScheduler(CONCURRENCY));
  const pageEls = useRef<(HTMLDivElement | null)[]>([]);
  const currentRef = useRef(1);
  currentRef.current = current;
  const restored = useRef(false);
  const raf = useRef(0);
  const setPdf = useApp((s) => s.setPdf);
  const width = Math.max(0, Math.floor(fitWidth * zoom));

  // ----- annotations -----
  const { ann, ready, change, undo, redo, canUndo, canRedo } = useAnnotations(file);
  const [tool, setTool] = useState<Tool>("select");
  const [highlightColor, setHighlightColor] = useState(() => remembered("harness.pdf.highlight", HIGHLIGHT_COLORS));
  const [penColor, setPenColor] = useState(() => remembered("harness.pdf.pen", PEN_COLORS));
  const [picked, setPicked] = useState<Picked | null>(null);
  const [editing, setEditing] = useState<{ id: string; x: number; y: number } | null>(null);
  const [focusNote, setFocusNote] = useState<string | null>(null);
  const annRef = useRef(ann);
  annRef.current = ann;
  const toolRef = useRef(tool);
  toolRef.current = tool;
  const highlightRef = useRef(highlightColor);
  highlightRef.current = highlightColor;
  const penRef = useRef(penColor);
  penRef.current = penColor;
  /** True while a button in the selection menu is pressed, so the selection isn't treated as gone. */
  const menuPress = useRef(false);
  const rereadSelection = useRef<() => void>(() => {});

  // While reading, background indexing steps aside (it would load a second copy of the PDF).
  useEffect(() => {
    setPdfReaderActive(true);
    activeViewer = file.id;
    return () => setPdfReaderActive(false);
  }, [file.id]);

  useEffect(() => {
    let d: PDFDocumentProxy | null = null;
    let cancelled = false;
    restored.current = false;
    setErr("");
    openPdf(file.blob)
      .then(async (x) => {
        if (cancelled) return closePdf(x);
        d = x;
        try {
          const vp = (await x.getPage(1)).getViewport({ scale: 1 });
          if (!cancelled) setRatio(vp.height / vp.width);
        } catch {
          /* keep default ratio */
        }
        if (!cancelled) setDoc(x);
      })
      .catch((e) => {
        if (!cancelled) setErr(String(e?.message || e));
      });
    return () => {
      cancelled = true;
      closePdf(d);
      setDoc(null);
    };
  }, [file.id, file.blob]);

  useEffect(() => {
    if (!scroller) return;
    const ro = new ResizeObserver(() => setFitWidth(Math.max(0, Math.min(scroller.clientWidth - 24, 900))));
    ro.observe(scroller);
    return () => ro.disconnect();
  }, [scroller]);

  const register = useCallback((n: number, el: HTMLDivElement | null) => {
    pageEls.current[n - 1] = el;
  }, []);

  const scrollToPage = useCallback(
    (n: number, smooth = false) => {
      const el = pageEls.current[n - 1];
      const sc = scroller;
      if (!el || !sc) return;
      const top = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop;
      sc.scrollTo({ top: Math.max(0, top - TOP_GAP), behavior: smooth ? "smooth" : "auto" });
    },
    [scroller]
  );

  /** Current page = the last page whose top is above 35% of the visible area (binary search over page rects). */
  const measure = useCallback(() => {
    const sc = scroller;
    if (!sc) return;
    const probe = sc.getBoundingClientRect().top + sc.clientHeight * 0.35;
    const els = pageEls.current;
    let lo = 0;
    let hi = els.length - 1;
    let found = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const el = els[mid];
      if (!el) {
        lo = mid + 1;
        continue;
      }
      if (el.getBoundingClientRect().top <= probe) {
        found = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    const cur = found + 1;
    if (cur !== currentRef.current) setCurrent(cur);
  }, [scroller]);

  const schedule = useCallback(() => {
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0;
      measure();
    });
  }, [measure]);

  useEffect(() => {
    window.addEventListener("resize", schedule);
    return () => {
      window.removeEventListener("resize", schedule);
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [schedule]);

  // Reopen where you left off.
  useLayoutEffect(() => {
    if (!doc || width <= 0 || restored.current) return;
    restored.current = true;
    const saved = Math.min(doc.numPages, Math.max(1, Number(localStorage.getItem("pdfpage." + file.id)) || 1));
    if (saved > 1) {
      setCurrent(saved);
      requestAnimationFrame(() => scrollToPage(saved));
    }
  }, [doc, width, file.id, scrollToPage]);

  // A tapped citation ("book.pdf, p.12") jumps here even when this PDF is already open.
  useEffect(() => {
    const on = (e: Event) => {
      const d = (e as CustomEvent<{ fileId: string; page?: number }>).detail;
      if (!doc || d?.fileId !== file.id || !d.page) return;
      const p = Math.min(doc.numPages, Math.max(1, d.page));
      setCurrent(p);
      requestAnimationFrame(() => scrollToPage(p));
    };
    window.addEventListener("harness:seek", on);
    return () => window.removeEventListener("harness:seek", on);
  }, [doc, file.id, scrollToPage]);

  // Keep the current page in view when zooming.
  const prevWidth = useRef(width);
  useLayoutEffect(() => {
    if (prevWidth.current > 0 && prevWidth.current !== width) scrollToPage(currentRef.current);
    prevWidth.current = width;
  }, [width, scrollToPage]);

  useEffect(() => {
    localStorage.setItem("pdfpage." + file.id, String(current));
  }, [current, file.id]);
  useEffect(() => {
    localStorage.setItem("pdfzoom." + file.id, String(zoom));
  }, [zoom, file.id]);
  useEffect(() => {
    localStorage.setItem("harness.pdf.highlight", highlightColor);
    localStorage.setItem("harness.pdf.pen", penColor);
  }, [highlightColor, penColor]);

  // Share the page being read with Leo, with what the learner marked on it.
  useEffect(() => {
    if (!doc) return;
    let alive = true;
    const t = window.setTimeout(async () => {
      try {
        const tc = await (await doc.getPage(current)).getTextContent();
        const text = tc.items
          .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
          .join("")
          .replace(/[ \t]+/g, " ")
          .trim();
        const marks = annotationSummary(ann, current);
        if (alive) setPdf({ fileId: file.id, name: file.name, page: current, pages: doc.numPages, text: marks ? `${text}\n\n${marks}` : text });
      } catch {
        /* document closed while switching */
      }
    }, 200);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [doc, current, file.id, file.name, setPdf, ann]);
  // Only clear what this viewer shared: a second pane may be showing another PDF.
  useEffect(
    () => () => {
      if (useApp.getState().pdf?.fileId === file.id) setPdf(null);
    },
    [setPdf, file.id]
  );

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  // ----- highlighting -----
  const addHighlight = useCallback(
    (p: Picked, color: string) => {
      const at = Date.now();
      change((a) => ({ ...a, highlights: [...a.highlights, ...p.marks.map((m) => ({ id: uid(), page: m.page, color, rects: m.rects, text: p.text, at }))] }));
    },
    [change]
  );

  // Follow the text selection inside this viewer. With the Select tool a menu offers colors; with
  // the Highlight tool the selection is marked as soon as it is finished.
  useEffect(() => {
    if (!scroller) return;
    let down = false;
    let timer = 0;
    const read = () => {
      if (menuPress.current) return;
      const sel = document.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount) return setPicked(null);
      const range = sel.getRangeAt(0);
      if (!scroller.contains(range.commonAncestorContainer)) return setPicked(null);
      const marks = marksFromRange(range, scroller);
      if (!marks.length) return setPicked(null);
      const b = range.getBoundingClientRect();
      const next: Picked = { marks, text: sel.toString().replace(/\s+/g, " ").trim().slice(0, 600), box: { left: b.left, top: b.top, right: b.right, bottom: b.bottom } };
      if (toolRef.current === "highlight") {
        addHighlight(next, highlightRef.current);
        sel.removeAllRanges();
        setPicked(null);
      } else if (toolRef.current === "select") setPicked(next);
    };
    const later = (ms: number) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(read, ms);
    };
    rereadSelection.current = () => later(0);
    // Touch selections are adjusted with handles and never end with a pointer-up, so wait for them to settle.
    const onChange = () => {
      if (!down) later(toolRef.current === "highlight" ? 600 : 200);
    };
    const onDown = () => {
      down = true;
      setPicked(null);
    };
    const onUp = () => {
      if (!down) return;
      down = false;
      later(10);
    };
    document.addEventListener("selectionchange", onChange);
    scroller.addEventListener("pointerdown", onDown);
    document.addEventListener("pointerup", onUp);
    document.addEventListener("pointercancel", onUp);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener("selectionchange", onChange);
      scroller.removeEventListener("pointerdown", onDown);
      document.removeEventListener("pointerup", onUp);
      document.removeEventListener("pointercancel", onUp);
    };
  }, [scroller, addHighlight]);

  const clearSelection = () => {
    document.getSelection()?.removeAllRanges();
    setPicked(null);
  };

  // Undo / redo, and Esc back to selecting text. Only for the viewer the learner last used.
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (activeViewer !== file.id || isSheetOpen()) return;
      const el = document.activeElement as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) return;
      if ((e.metaKey || e.ctrlKey) && !e.altKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      } else if (e.key === "Escape" && (toolRef.current !== "select" || editing)) {
        // Handled here, so the same press doesn't also close the chat or leave fullscreen.
        e.preventDefault();
        e.stopPropagation();
        setTool("select");
        setEditing(null);
      }
    };
    window.addEventListener("keydown", on, true);
    return () => window.removeEventListener("keydown", on, true);
  }, [file.id, undo, redo, editing]);

  const actions = useMemo<PageActions>(
    () => ({
      stroke: (page, points) => change((a) => ({ ...a, strokes: [...a.strokes, { id: uid(), page, color: penRef.current, width: PEN_WIDTH, points }] })),
      erase: (ids) => change((a) => ({ ...a, strokes: a.strokes.filter((s) => !ids.includes(s.id)) })),
      click: (page, x, y, clientX, clientY) => {
        if (toolRef.current !== "select") return;
        const sel = document.getSelection();
        if (sel && !sel.isCollapsed) return;
        const hit = highlightAt(annRef.current.highlights.filter((h) => h.page === page), x, y);
        setEditing(hit ? { id: hit.id, x: clientX, y: clientY } : null);
      },
      noteChange: (id, text) => change((a) => ({ ...a, notes: a.notes.map((n) => (n.id === id ? { ...n, text: text.slice(0, 4000) } : n)) }), `note:${id}`),
      // An empty note that loses focus just goes away, without becoming its own undo step.
      noteRemove: (id, quiet) => change((a) => ({ ...a, notes: a.notes.filter((n) => n.id !== id) }), quiet ? `note:${id}` : ""),
    }),
    [change]
  );

  const addNote = () => {
    const id = uid();
    change((a) => ({ ...a, notes: [...a.notes, { id, page: currentRef.current, text: "", at: Date.now() }] }), `note:${id}`);
    setFocusNote(id);
  };

  const byPage = useMemo(() => {
    const map = new Map<number, PageMarks>();
    const at = (page: number) => {
      let entry = map.get(page);
      if (!entry) map.set(page, (entry = { highlights: [], strokes: [], notes: [] }));
      return entry;
    };
    for (const h of ann.highlights) at(h.page).highlights.push(h);
    for (const s of ann.strokes) at(s.page).strokes.push(s);
    for (const n of ann.notes) at(n.page).notes.push(n);
    return map;
  }, [ann]);

  const closeEditing = useCallback(() => setEditing(null), []);
  const edited = editing ? ann.highlights.find((h) => h.id === editing.id) : undefined;

  const numPages = doc?.numPages ?? file.pages ?? 0;
  const commitDraft = () => {
    const n = parseInt(draft ?? "", 10);
    if (n >= 1 && n <= numPages) {
      setCurrent(n);
      scrollToPage(n, true);
    }
    setDraft(null);
  };
  const zoomBy = (d: number) => setZoom((z) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round((z + d) / ZOOM_STEP) * ZOOM_STEP)));

  const controls = (
    <div className="flex shrink-0 items-center gap-0.5 rounded-full bg-ink/[0.05] p-0.5 text-[13px] tabular-nums">
      <button
        type="button"
        onClick={() => zoomBy(-ZOOM_STEP)}
        disabled={zoom <= ZOOM_MIN}
        aria-label="Zoom out"
        className="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-ink/[0.07] disabled:opacity-35 sm:h-8 sm:w-8"
      >
        <Minus size={16} />
      </button>
      <button
        type="button"
        onClick={() => setZoom(1)}
        aria-label="Reset zoom to 100%"
        title="Reset zoom to 100%"
        className="h-9 min-w-[52px] rounded-full px-1.5 font-medium transition-colors hover:bg-ink/[0.07] sm:h-8"
      >
        {Math.round(zoom * 100)}%
      </button>
      <button
        type="button"
        onClick={() => zoomBy(ZOOM_STEP)}
        disabled={zoom >= ZOOM_MAX}
        aria-label="Zoom in"
        className="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-ink/[0.07] disabled:opacity-35 sm:h-8 sm:w-8"
      >
        <Plus size={16} />
      </button>
      <span className="mx-1 h-4 w-px bg-line" aria-hidden />
      <label className="flex items-center gap-1 pl-1 pr-2">
        <input
          value={draft ?? String(current)}
          onChange={(e) => setDraft(e.target.value.replace(/\D/g, ""))}
          onFocus={(e) => {
            setDraft(String(current));
            e.currentTarget.select();
          }}
          onBlur={commitDraft}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          inputMode="numeric"
          aria-label="Go to page"
          className="h-9 w-12 rounded-full bg-ink/[0.06] text-center text-[16px] outline-none focus:bg-ink/[0.1] sm:h-8 sm:text-[13px]"
        />
        <span className="text-muted">/ {numPages || "…"}</span>
      </label>
    </div>
  );

  return (
    <div
      className="absolute inset-0 flex flex-col"
      onPointerDownCapture={() => {
        activeViewer = file.id;
      }}
    >
      {bar ? bar(controls) : <div className="flex shrink-0 justify-center border-b border-line bg-paper px-2 py-2">{controls}</div>}
      <div className="relative min-h-0 flex-1">
        <div
          ref={setScroller}
          onScroll={() => {
            schedule();
            if (editing) setEditing(null);
            // The selection menu follows the text it belongs to.
            if (picked) rereadSelection.current();
          }}
          data-pdf-scroller
          data-ctx-source={`PDF "${file.name}" p.${current}`}
          className="absolute inset-0 overflow-auto overscroll-contain bg-document"
        >
          {err ? (
            <p className="p-6 text-center text-sm text-danger-fg">Couldn&apos;t open this PDF: {err}</p>
          ) : !doc || width <= 0 ? (
            <div className="flex justify-center py-24">
              <Loader2 className="animate-spin text-muted" />
            </div>
          ) : (
            <div className="mx-auto flex w-max min-w-full flex-col items-center gap-3 px-3 pb-36 pt-16">
              {Array.from({ length: doc.numPages }, (_, i) => (
                <PdfPage
                  key={i + 1}
                  doc={doc}
                  num={i + 1}
                  width={width}
                  ratio={ratio}
                  root={scroller}
                  scheduler={scheduler}
                  currentRef={currentRef}
                  register={register}
                  marks={byPage.get(i + 1) ?? NO_MARKS}
                  tool={ready ? tool : "select"}
                  penColor={penColor}
                  noteWidth={Math.min(width, fitWidth)}
                  notesPinned={width > fitWidth}
                  focusNote={focusNote}
                  actions={actions}
                />
              ))}
            </div>
          )}
        </div>
        {doc && ready && !err && (
          <div className="pointer-events-none absolute inset-x-0 top-2 z-10 flex justify-center px-2">
            <AnnotationToolbar
              tool={tool}
              onTool={(t) => {
                setTool(t);
                setEditing(null);
                if (t !== "select") clearSelection();
              }}
              highlight={highlightColor}
              onHighlight={setHighlightColor}
              pen={penColor}
              onPen={setPenColor}
              page={current}
              onNote={addNote}
              canUndo={canUndo}
              canRedo={canRedo}
              onUndo={undo}
              onRedo={redo}
            />
          </div>
        )}
      </div>
      {picked && tool === "select" && (
        <SelectionMenu
          box={picked.box}
          floor={(scroller?.getBoundingClientRect().top ?? 0) + 60}
          last={highlightColor}
          press={menuPress}
          onPick={(hex) => {
            menuPress.current = false;
            setHighlightColor(hex);
            addHighlight(picked, hex);
            clearSelection();
          }}
          onAsk={() => {
            menuPress.current = false;
            setPicked(null);
            useApp.getState().setChatOpen(true);
          }}
        />
      )}
      {editing && edited && (
        <HighlightMenu
          x={editing.x}
          y={editing.y}
          color={edited.color}
          onColor={(hex) => {
            setHighlightColor(hex);
            change((a) => ({ ...a, highlights: a.highlights.map((h) => (h.id === edited.id ? { ...h, color: hex } : h)) }));
            setEditing(null);
          }}
          onRemove={() => {
            change((a) => ({ ...a, highlights: a.highlights.filter((h) => h.id !== edited.id) }));
            setEditing(null);
          }}
          onClose={closeEditing}
        />
      )}
    </div>
  );
}

type PageState = "idle" | "queued" | "rendering" | "rendered" | "error";

function PdfPage({
  doc,
  num,
  width,
  ratio,
  root,
  scheduler,
  currentRef,
  register,
  marks,
  tool,
  penColor,
  noteWidth,
  notesPinned,
  focusNote,
  actions,
}: {
  doc: PDFDocumentProxy;
  num: number;
  width: number;
  ratio: number;
  root: HTMLDivElement | null;
  scheduler: RenderScheduler;
  currentRef: { current: number };
  register: (n: number, el: HTMLDivElement | null) => void;
  marks: PageMarks;
  tool: Tool;
  penColor: string;
  noteWidth: number;
  notesPinned: boolean;
  focusNote: string | null;
  actions: PageActions;
}) {
  const box = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [ownRatio, setOwnRatio] = useState<number | null>(null);
  const [state, setState] = useState<PageState>("idle");
  const [attempt, setAttempt] = useState(0);
  /** Width the current bitmap was drawn at (0 = nothing drawn). */
  const drawnAt = useRef(0);

  useEffect(() => {
    register(num, box.current);
    return () => register(num, null);
  }, [num, register]);

  // Lazy: a page only becomes eligible to draw when it is near the reader.
  useEffect(() => {
    const el = box.current;
    if (!el || !root) return;
    const io = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { root, rootMargin: `${PRELOAD} 0px` });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);

  const release = useCallback(() => {
    const c = canvasRef.current;
    if (c) {
      c.width = 0;
      c.height = 0;
    }
    textRef.current?.replaceChildren();
    drawnAt.current = 0;
    setState("idle");
  }, []);

  // Far away: give the memory back.
  useEffect(() => {
    if (!visible) release();
  }, [visible, release]);

  // Zoom changed: the old bitmap is the wrong size.
  useEffect(() => {
    if (drawnAt.current !== 0 && drawnAt.current !== width) release();
  }, [width, release]);

  useEffect(() => {
    if (!visible || width <= 0 || drawnAt.current === width) return;
    setState((s) => (s === "rendered" ? s : "queued"));
    const cancel = scheduler.schedule(
      () => Math.abs(num - currentRef.current),
      async (signal) => {
        setState((s) => (s === "rendered" ? s : "rendering"));
        try {
          const page = await doc.getPage(num);
          if (signal.aborted) return;
          const base = page.getViewport({ scale: 1 });
          setOwnRatio(base.height / base.width);
          const scale = width / base.width;
          const vp = page.getViewport({ scale });
          const dpr =
            attempt > 0
              ? 1
              : Math.max(1, Math.min(window.devicePixelRatio || 1, MAX_DPR, Math.sqrt(MAX_CANVAS_PIXELS / (vp.width * vp.height))));
          const canvas = canvasRef.current;
          const raw = canvas?.getContext("2d");
          // Text in fonts the PDF doesn't embed falls back to a bundled Arabic face.
          const ctx = raw ? arabicFallback(raw) : null;
          if (!canvas || !ctx) throw new Error("Canvas unavailable (out of memory?)");
          canvas.width = Math.max(1, Math.floor(vp.width * dpr));
          canvas.height = Math.max(1, Math.floor(vp.height * dpr));
          canvas.style.width = `${Math.floor(vp.width)}px`;
          canvas.style.height = `${Math.floor(vp.height)}px`;
          const task = page.render({ canvasContext: ctx, canvas, viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
          const stop = () => task.cancel();
          signal.addEventListener("abort", stop, { once: true });
          try {
            await task.promise;
          } finally {
            signal.removeEventListener("abort", stop);
          }
          if (signal.aborted) return;
          drawnAt.current = width;
          setState("rendered");
          page.cleanup();

          // The text layer is best-effort: a failure here must never block the page image.
          try {
            const tc = await page.getTextContent();
            if (signal.aborted) return;
            const div = textRef.current;
            if (!div) return;
            div.replaceChildren();
            div.style.setProperty("--total-scale-factor", String(scale));
            const pdfjs = await getPdfjs();
            if (signal.aborted) return;
            const layer = new pdfjs.TextLayer({ textContentSource: tc, container: div, viewport: vp });
            const stopLayer = () => layer.cancel();
            signal.addEventListener("abort", stopLayer, { once: true });
            try {
              await layer.render();
            } finally {
              signal.removeEventListener("abort", stopLayer);
            }
          } catch {
            /* no selectable text on this page */
          }
        } catch (e) {
          if (signal.aborted) return;
          const msg = `${(e as Error)?.name ?? ""} ${(e as Error)?.message ?? ""}`;
          if (/cancel|abort/i.test(msg)) return;
          console.warn(`PDF page ${num} failed to render`, e);
          drawnAt.current = 0;
          // One automatic retry at 1× resolution, then show the error with a Retry button.
          if (attempt === 0) setAttempt(1);
          else setState("error");
        }
      }
    );
    return cancel;
  }, [visible, width, doc, num, scheduler, currentRef, attempt]);

  const pageRatio = ownRatio ?? ratio;
  const height = Math.round(width * pageRatio);
  const drawing = tool === "pen" || tool === "eraser";
  const noteCount = marks.notes.length;
  return (
    <div className="flex flex-col items-center">
      <div
        ref={box}
        data-page={num}
        data-state={state}
        onClick={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          actions.click(num, (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height, e.clientX, e.clientY);
        }}
        className="pdf-page relative shrink-0 overflow-hidden rounded-[4px] bg-[#fff] shadow-[0_1px_4px_rgba(0,0,0,0.14)]"
        style={{ width, height }}
      >
        <canvas ref={canvasRef} className="block" />
        {visible && marks.highlights.length > 0 && <HighlightLayer highlights={marks.highlights} />}
        <div ref={textRef} className="textLayer" />
        {visible && (drawing || marks.strokes.length > 0) && (
          <InkLayer
            strokes={marks.strokes}
            tool={tool}
            color={penColor}
            width={PEN_WIDTH}
            ratio={pageRatio}
            onStroke={(points) => actions.stroke(num, points)}
            onErase={actions.erase}
          />
        )}
        {noteCount > 0 && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              document.getElementById(`pdf-notes-${num}`)?.scrollIntoView({ block: "center", behavior: "smooth" });
            }}
            aria-label={`${noteCount} ${noteCount === 1 ? "note" : "notes"} on page ${num}: show`}
            title="Show this page's notes"
            className="absolute right-2 top-2 flex h-7 items-center gap-1 rounded-full bg-warn-bg px-2 text-[12px] font-semibold tabular-nums text-warn-fg shadow-sm ring-1 ring-[#000]/10"
          >
            <StickyNote size={13} /> {noteCount}
          </button>
        )}
        {state !== "rendered" && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 text-[13px] font-medium text-[#6e6e6e]">
            {state === "error" ? (
              <>
                <span>Couldn&apos;t show page {num}</span>
                <button
                  type="button"
                  onClick={() => {
                    drawnAt.current = 0;
                    setAttempt((a) => a + 1);
                  }}
                  className="pointer-events-auto inline-flex h-8 items-center gap-1.5 rounded-full bg-[#17171a] px-3.5 text-[12px] font-semibold text-[#fff]"
                >
                  <RotateCcw size={13} /> Retry
                </button>
              </>
            ) : (
              <span className="tabular-nums">{num}</span>
            )}
          </div>
        )}
      </div>
      {noteCount > 0 && <PageNotes notes={marks.notes} page={num} width={noteWidth} pinned={notesPinned} focusId={focusNote} onChange={actions.noteChange} onRemove={actions.noteRemove} />}
    </div>
  );
}
