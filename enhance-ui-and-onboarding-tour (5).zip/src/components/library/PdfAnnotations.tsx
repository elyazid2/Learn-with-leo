import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent, type ReactNode, type RefObject } from "react";
import { Eraser, Highlighter, MousePointer2, Pencil, Redo2, StickyNote, Trash2, Undo2 } from "lucide-react";
import type { Highlight, LibFile, PageNote, PdfAnnotations, Rect, Stroke } from "@/lib/db";
import { EMPTY_ANNOTATIONS, HIGHLIGHT_COLORS, MIN_STEP, PEN_COLORS, hitsStroke, loadAnnotations, mergeRects, roundPoints, saveAnnotations, strokePath } from "@/lib/annotations";
import { cn } from "@/utils/cn";

export type Tool = "select" | "highlight" | "pen" | "eraser";

/** The part of a text selection that falls on one page. */
export interface Mark {
  page: number;
  rects: Rect[];
}

/* ------------------------------------------------------------------ state */

/**
 * A PDF's annotations: loaded once, changed in memory, saved shortly after each change (and when
 * the viewer closes or the tab is hidden), with undo and redo.
 */
export function useAnnotations(file: Pick<LibFile, "id" | "projectId">) {
  const [ann, setAnn] = useState<PdfAnnotations>(EMPTY_ANNOTATIONS);
  const [ready, setReady] = useState(false);
  const [depth, setDepth] = useState({ undo: 0, redo: 0 });
  const live = useRef(ann);
  const loaded = useRef(false);
  const dirty = useRef(false);
  const timer = useRef<number | undefined>(undefined);
  const history = useRef<{ past: PdfAnnotations[]; future: PdfAnnotations[]; key: string }>({ past: [], future: [], key: "" });

  const flush = useCallback(() => {
    window.clearTimeout(timer.current);
    if (!dirty.current) return;
    dirty.current = false;
    void saveAnnotations(file.id, file.projectId, live.current).catch((e) => console.warn("annotations were not saved", e));
  }, [file.id, file.projectId]);

  useEffect(() => {
    let alive = true;
    void loadAnnotations(file.id).then((a) => {
      if (!alive) return;
      live.current = a;
      loaded.current = true;
      setAnn(a);
      setReady(true);
    });
    const onHide = () => flush();
    window.addEventListener("pagehide", onHide);
    document.addEventListener("visibilitychange", onHide);
    return () => {
      alive = false;
      window.removeEventListener("pagehide", onHide);
      document.removeEventListener("visibilitychange", onHide);
      flush();
    };
  }, [file.id, flush]);

  const commit = useCallback(
    (next: PdfAnnotations) => {
      live.current = next;
      dirty.current = true;
      setAnn(next);
      setDepth({ undo: history.current.past.length, redo: history.current.future.length });
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(flush, 400);
    },
    [flush]
  );

  /** Changes that share a `key` (typing in one note) count as a single step for undo. */
  const change = useCallback(
    (fn: (a: PdfAnnotations) => PdfAnnotations, key = "") => {
      // Nothing may be written before the saved annotations are in, or they would be overwritten.
      if (!loaded.current) return;
      const prev = live.current;
      const next = fn(prev);
      if (next === prev) return;
      const h = history.current;
      if (!(key && key === h.key)) {
        h.past.push(prev);
        if (h.past.length > 80) h.past.shift();
      }
      h.key = key;
      h.future = [];
      commit(next);
    },
    [commit]
  );

  const undo = useCallback(() => {
    const h = history.current;
    const prev = h.past.pop();
    if (!prev) return;
    h.future.push(live.current);
    h.key = "";
    commit(prev);
  }, [commit]);

  const redo = useCallback(() => {
    const h = history.current;
    const next = h.future.pop();
    if (!next) return;
    h.past.push(live.current);
    h.key = "";
    commit(next);
  }, [commit]);

  return { ann, ready, change, undo, redo, canUndo: depth.undo > 0, canRedo: depth.redo > 0 };
}

/* -------------------------------------------------------------- selection */

/** The boxes of a text selection, per page, as fractions of that page (one bar per line). */
export function marksFromRange(range: Range, root: HTMLElement): Mark[] {
  const pages = new Map<HTMLElement, DOMRect[]>();
  const top = range.commonAncestorContainer;
  const start = top.nodeType === Node.TEXT_NODE ? top.parentNode : top;
  if (!start) return [];
  const walker = document.createTreeWalker(start, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (!range.intersectsNode(node)) continue;
    const pageEl = node.parentElement?.closest(".textLayer")?.closest<HTMLElement>("[data-page]");
    if (!pageEl || !root.contains(pageEl)) continue;
    const part = document.createRange();
    part.selectNodeContents(node);
    if (node === range.startContainer) part.setStart(node, range.startOffset);
    if (node === range.endContainer) part.setEnd(node, range.endOffset);
    if (part.collapsed) continue;
    const list = pages.get(pageEl) ?? [];
    for (const r of part.getClientRects()) if (r.width > 0.5 && r.height > 0.5) list.push(r);
    pages.set(pageEl, list);
  }
  const out: Mark[] = [];
  for (const [el, rects] of pages) {
    const box = el.getBoundingClientRect();
    if (!rects.length || !box.width || !box.height) continue;
    const merged = mergeRects(
      rects.map((r): Rect => [(r.left - box.left) / box.width, (r.top - box.top) / box.height, r.width / box.width, r.height / box.height]),
      box.height / box.width
    );
    if (merged.length) out.push({ page: Number(el.dataset.page), rects: merged });
  }
  return out.sort((a, b) => a.page - b.page);
}

/* ---------------------------------------------------------------- toolbar */

function ToolButton({ label, active, disabled, onClick, children }: { label: string; active?: boolean; disabled?: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      title={label}
      aria-pressed={active}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-colors disabled:opacity-30",
        active ? "bg-ink text-white" : "text-ink/75 hover:bg-ink/[0.07] hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}

function Swatch({ hex, label, selected, onClick, size = 26 }: { hex: string; label: string; selected?: boolean; onClick: () => void; size?: number }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      aria-pressed={selected}
      className={cn("shrink-0 rounded-full ring-1 ring-inset ring-[#000]/10 transition-transform", selected ? "shadow-[0_0_0_2px_var(--elevated),0_0_0_4px_var(--ink)]" : "hover:scale-110")}
      style={{ width: size, height: size, background: hex }}
    />
  );
}

/** The floating tool pill: select, highlight, pen, eraser, page note, undo and redo. */
export function AnnotationToolbar({
  tool,
  onTool,
  highlight,
  onHighlight,
  pen,
  onPen,
  page,
  onNote,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
}: {
  tool: Tool;
  onTool: (t: Tool) => void;
  highlight: string;
  onHighlight: (hex: string) => void;
  pen: string;
  onPen: (hex: string) => void;
  page: number;
  onNote: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
}) {
  const colors = tool === "highlight" ? HIGHLIGHT_COLORS : tool === "pen" ? PEN_COLORS : null;
  const divider = <span className="mx-0.5 h-5 w-px shrink-0 bg-line" aria-hidden />;
  return (
    <div role="toolbar" aria-label="Annotation tools" className="pointer-events-auto flex max-w-full flex-col items-center rounded-2xl bg-elevated/95 p-1 shadow-[0_8px_28px_rgba(0,0,0,0.16)] ring-1 ring-line backdrop-blur">
      <div className="flex items-center gap-0.5">
        <ToolButton label="Select text" active={tool === "select"} onClick={() => onTool("select")}>
          <MousePointer2 size={17} />
        </ToolButton>
        <ToolButton label="Highlight: select text to mark it" active={tool === "highlight"} onClick={() => onTool(tool === "highlight" ? "select" : "highlight")}>
          <Highlighter size={17} />
        </ToolButton>
        <ToolButton label="Pen: draw on the page" active={tool === "pen"} onClick={() => onTool(tool === "pen" ? "select" : "pen")}>
          <Pencil size={16} />
        </ToolButton>
        <ToolButton label="Eraser: remove drawings" active={tool === "eraser"} onClick={() => onTool(tool === "eraser" ? "select" : "eraser")}>
          <Eraser size={17} />
        </ToolButton>
        {divider}
        <ToolButton label={`Add a note to page ${page}`} onClick={onNote}>
          <StickyNote size={17} />
        </ToolButton>
        {divider}
        <ToolButton label="Undo" disabled={!canUndo} onClick={onUndo}>
          <Undo2 size={17} />
        </ToolButton>
        <ToolButton label="Redo" disabled={!canRedo} onClick={onRedo}>
          <Redo2 size={17} />
        </ToolButton>
      </div>
      {colors && (
        <div className="flex items-center gap-2 px-1.5 pb-1 pt-1.5" role="group" aria-label={tool === "pen" ? "Pen color" : "Highlight color"}>
          {colors.map((c) => (
            <Swatch key={c.hex} hex={c.hex} label={c.label} selected={(tool === "pen" ? pen : highlight) === c.hex} onClick={() => (tool === "pen" ? onPen(c.hex) : onHighlight(c.hex))} />
          ))}
          <span className="pl-1 text-[12px] text-muted">{tool === "pen" ? "Draw on the page" : "Select text to highlight"}</span>
        </div>
      )}
    </div>
  );
}

/* ----------------------------------------------------------------- layers */

const pct = (n: number) => `${n * 100}%`;

/** Highlights sit between the page image and its text, so the text stays selectable. */
export const HighlightLayer = memo(function HighlightLayer({ highlights }: { highlights: Highlight[] }) {
  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden>
      {highlights.map((h) =>
        h.rects.map((r, i) => (
          <span
            key={`${h.id}:${i}`}
            data-highlight={h.id}
            className="absolute rounded-[2px]"
            style={{ left: pct(r[0]), top: pct(r[1]), width: pct(r[2]), height: pct(r[3]), background: h.color, mixBlendMode: "multiply" }}
          />
        ))
      )}
    </div>
  );
});

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

/**
 * Pen strokes, drawn straight on the page. With the pen or eraser active this layer takes the
 * pointer: one finger (or the mouse, or a stylus) draws, two fingers scroll the document.
 */
export function InkLayer({
  strokes,
  tool,
  color,
  width,
  ratio,
  onStroke,
  onErase,
}: {
  strokes: Stroke[];
  tool: Tool;
  color: string;
  /** Pen width as a fraction of the page width. */
  width: number;
  /** Page height / width. */
  ratio: number;
  onStroke: (points: number[]) => void;
  onErase: (ids: string[]) => void;
}) {
  const svg = useRef<SVGSVGElement>(null);
  const live = useRef<number[] | null>(null);
  const erasing = useRef(false);
  const hidden = useRef(new Set<string>());
  const fingers = useRef(new Map<number, { x: number; y: number }>());
  const panning = useRef(false);
  const [, redraw] = useState(0);
  const active = tool === "pen" || tool === "eraser";
  const H = 1000 * ratio;

  const at = (e: { clientX: number; clientY: number }) => {
    const r = svg.current!.getBoundingClientRect();
    return [clamp01((e.clientX - r.left) / r.width), clamp01((e.clientY - r.top) / r.height)] as const;
  };

  const eraseAt = (x: number, y: number) => {
    let hit = false;
    for (const s of strokes) {
      if (hidden.current.has(s.id) || !hitsStroke(s, x, y, ratio)) continue;
      hidden.current.add(s.id);
      hit = true;
    }
    if (hit) redraw((n) => n + 1);
  };

  /** End the stroke or the erasing in progress; `keep` is false when a second finger turned it into a scroll. */
  const finish = (keep: boolean) => {
    const points = live.current;
    live.current = null;
    if (points && keep) onStroke(roundPoints(points));
    if (erasing.current) {
      erasing.current = false;
      const ids = [...hidden.current];
      // The strokes stay hidden until the change arrives, so they don't flash back for a frame.
      if (ids.length && keep) onErase(ids);
      else hidden.current = new Set();
    }
    redraw((n) => n + 1);
  };

  // Erased strokes are gone from the list once the change lands.
  useEffect(() => {
    if (!erasing.current && hidden.current.size) hidden.current = new Set();
  }, [strokes]);

  const onDown = (e: RPointerEvent<SVGSVGElement>) => {
    if (!active || (e.pointerType === "mouse" && e.button !== 0)) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    if (e.pointerType === "touch") {
      fingers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (fingers.current.size >= 2) {
        panning.current = true;
        finish(false);
        return;
      }
    }
    e.preventDefault();
    const [x, y] = at(e);
    if (tool === "pen") live.current = [x, y];
    else {
      erasing.current = true;
      eraseAt(x, y);
    }
    redraw((n) => n + 1);
  };

  const onMove = (e: RPointerEvent<SVGSVGElement>) => {
    if (!active) return;
    if (e.pointerType === "touch" && panning.current) {
      const last = fingers.current.get(e.pointerId);
      const scroller = svg.current?.closest<HTMLElement>("[data-pdf-scroller]");
      if (last && scroller) {
        scroller.scrollTop -= (e.clientY - last.y) / fingers.current.size;
        scroller.scrollLeft -= (e.clientX - last.x) / fingers.current.size;
      }
      fingers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      return;
    }
    const points = live.current;
    if (points) {
      const batch = e.nativeEvent.getCoalescedEvents?.() ?? [];
      for (const ev of batch.length ? batch : [e.nativeEvent]) {
        const [x, y] = at(ev);
        if (Math.hypot(x - points[points.length - 2], (y - points[points.length - 1]) * ratio) >= MIN_STEP) points.push(x, y);
      }
      redraw((n) => n + 1);
    } else if (erasing.current) {
      const [x, y] = at(e);
      eraseAt(x, y);
    }
  };

  const onUp = (e: RPointerEvent<SVGSVGElement>) => {
    if (e.pointerType === "touch") {
      fingers.current.delete(e.pointerId);
      if (panning.current) {
        if (!fingers.current.size) panning.current = false;
        return;
      }
    }
    finish(e.type !== "pointercancel");
  };

  const drawn = useMemo(() => strokes.map((s) => ({ id: s.id, d: strokePath(s.points, 1000, H), color: s.color, width: s.width * 1000 })), [strokes, H]);
  const current = live.current;

  return (
    <svg
      ref={svg}
      viewBox={`0 0 1000 ${H}`}
      preserveAspectRatio="none"
      className="absolute inset-0 h-full w-full"
      style={{ pointerEvents: active ? "auto" : "none", touchAction: active ? "none" : undefined, cursor: tool === "pen" ? "crosshair" : tool === "eraser" ? "cell" : undefined }}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      data-ink
      aria-hidden
    >
      {drawn.map((s) =>
        hidden.current.has(s.id) ? null : <path key={s.id} data-stroke={s.id} d={s.d} stroke={s.color} strokeWidth={s.width} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      )}
      {current && <path d={strokePath(current, 1000, H)} stroke={color} strokeWidth={width * 1000} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
    </svg>
  );
}

/* ------------------------------------------------------------- page notes */

function NoteCard({ note, page, focus, onChange, onRemove }: { note: PageNote; page: number; focus: boolean; onChange: (id: string, text: string) => void; onRemove: (id: string, quiet?: boolean) => void }) {
  const field = useRef<HTMLTextAreaElement>(null);

  useLayoutEffect(() => {
    const el = field.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  }, [note.text]);

  useEffect(() => {
    if (!focus) return;
    field.current?.focus({ preventScroll: true });
    field.current?.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [focus]);

  return (
    <div className="rounded-xl bg-warn-bg p-3 ring-1 ring-line" data-note={note.id}>
      <div className="mb-1 flex items-center gap-1.5 text-[12px] font-medium text-warn-fg">
        <StickyNote size={13} />
        <span>Note · page {page}</span>
        <button
          type="button"
          onClick={() => onRemove(note.id)}
          aria-label={`Delete this note on page ${page}`}
          title="Delete note"
          className="-my-1 -mr-1 ml-auto flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-ink/[0.08]"
        >
          <Trash2 size={14} />
        </button>
      </div>
      <textarea
        ref={field}
        value={note.text}
        onChange={(e) => onChange(note.id, e.target.value)}
        onBlur={() => {
          if (!note.text.trim()) onRemove(note.id, true);
        }}
        rows={1}
        dir="auto"
        placeholder="Write a note for this page…"
        aria-label={`Note on page ${page}`}
        className="block w-full resize-none bg-transparent text-[16px] leading-relaxed text-ink outline-none placeholder:text-muted/70 sm:text-[15px]"
      />
    </div>
  );
}

/** A page's notes, attached directly under that page. */
export function PageNotes({
  notes,
  page,
  width,
  pinned,
  focusId,
  onChange,
  onRemove,
}: {
  notes: PageNote[];
  page: number;
  width: number;
  /** The page is wider than the viewer (zoomed in): keep the notes in view instead of centering them. */
  pinned: boolean;
  focusId: string | null;
  onChange: (id: string, text: string) => void;
  onRemove: (id: string, quiet?: boolean) => void;
}) {
  return (
    // Selections inside a note are the learner's own words, not PDF text to send to Leo.
    <div id={`pdf-notes-${page}`} data-no-capture role="group" aria-label={`Notes on page ${page}`} className={cn("mt-2 flex flex-col gap-2", pinned && "sticky left-3 self-start")} style={{ width }}>
      {notes.map((n) => (
        <NoteCard key={n.id} note={n} page={page} focus={n.id === focusId} onChange={onChange} onRemove={onRemove} />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ menus */

interface Box {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

const clamp = (n: number, lo: number, hi: number) => Math.min(Math.max(n, lo), Math.max(lo, hi));

/** Appears beside a text selection: pick a color to highlight it, or ask Leo about it. */
export function SelectionMenu({ box, last, press, floor = 8, onPick, onAsk }: { box: Box; last: string; press: RefObject<boolean>; /** Nothing is placed above this line (the tool pill is there). */ floor?: number; onPick: (hex: string) => void; onAsk: () => void }) {
  const W = 262;
  const H = 44;
  const coarse = typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches;
  const left = clamp((box.left + box.right) / 2 - W / 2, 8, window.innerWidth - W - 8);
  // Touch browsers put their own Copy / Select all bubble above the selection, so ours goes below it.
  const above = box.top - H - 10;
  const top = !coarse && above > floor ? above : clamp(box.bottom + (coarse ? 16 : 10), floor, window.innerHeight - H - 8);
  return (
    <div
      role="toolbar"
      aria-label="Highlight the selected text"
      data-pdf-menu
      className="fade-in fixed z-40 flex items-center gap-2 rounded-full bg-elevated py-1.5 pl-2.5 pr-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.2)] ring-1 ring-line"
      style={{ left, top, width: W, height: H }}
      // Keep the selection while a button here is pressed.
      onPointerDown={(e) => {
        e.preventDefault();
        press.current = true;
        window.addEventListener("pointerup", () => window.setTimeout(() => (press.current = false), 80), { once: true });
      }}
    >
      {HIGHLIGHT_COLORS.map((c) => (
        <Swatch key={c.hex} hex={c.hex} label={`Highlight ${c.label.toLowerCase()}`} selected={c.hex === last} onClick={() => onPick(c.hex)} />
      ))}
      <span className="h-5 w-px bg-line" aria-hidden />
      <button type="button" onClick={onAsk} className="h-8 flex-1 whitespace-nowrap rounded-full px-2.5 text-[13px] font-semibold transition-colors hover:bg-ink/[0.07]">
        Ask Leo
      </button>
    </div>
  );
}

/** Appears on a highlight that was clicked: change its color or remove it. */
export function HighlightMenu({ x, y, color, onColor, onRemove, onClose }: { x: number; y: number; color: string; onColor: (hex: string) => void; onRemove: () => void; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const W = 206;
  const H = 44;

  useEffect(() => {
    const away = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) onClose();
    };
    document.addEventListener("pointerdown", away);
    return () => document.removeEventListener("pointerdown", away);
  }, [onClose]);

  return (
    <div
      ref={ref}
      role="toolbar"
      aria-label="Highlight"
      data-pdf-menu
      className="fade-in fixed z-40 flex items-center gap-2 rounded-full bg-elevated py-1.5 pl-2.5 pr-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.2)] ring-1 ring-line"
      style={{ left: clamp(x - W / 2, 8, window.innerWidth - W - 8), top: clamp(y + 14, 8, window.innerHeight - H - 8), width: W, height: H }}
    >
      {HIGHLIGHT_COLORS.map((c) => (
        <Swatch key={c.hex} hex={c.hex} label={`Change to ${c.label.toLowerCase()}`} selected={c.hex === color} onClick={() => onColor(c.hex)} />
      ))}
      <span className="h-5 w-px bg-line" aria-hidden />
      <button type="button" onClick={onRemove} aria-label="Remove highlight" title="Remove highlight" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-danger-fg transition-colors hover:bg-danger-bg">
        <Trash2 size={15} />
      </button>
    </div>
  );
}
