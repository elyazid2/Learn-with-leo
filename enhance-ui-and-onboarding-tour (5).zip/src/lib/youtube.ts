import { db, uid, type LibFile, type Provider, type Transcript, type TranscriptSegment } from "./db";
import { youtubeRef, type YouTubeRef } from "./browser";
import { useSettings } from "./settings";
import { clock, parseClock, queueIndex } from "./retrieval";
import { groupSegments, parseTimestampedLines, spreadText } from "./transcribe";

/**
 * YouTube videos as library items. Nothing is downloaded: the item remembers the video, plays it
 * from YouTube in the app's own player, and keeps a transcript so Leo can work with what is said.
 *
 * The transcript is fetched once, when the video is added:
 *   1. YouTube's captions, when the video has them and YouTube lets this app read them.
 *   2. Otherwise Gemini listens to the video (it accepts YouTube links directly).
 *   3. Otherwise the learner can paste a transcript.
 */

export const watchUrl = (id: string, t = 0) => `https://www.youtube.com/watch?v=${id}${t > 0 ? `&t=${Math.floor(t)}s` : ""}`;
const posterUrl = (id: string) => `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;

/** The video a pasted or typed link points at, or null. */
export function linkRef(input: string): YouTubeRef | null {
  const value = input.trim();
  if (!value || /\s/.test(value)) return null;
  return youtubeRef(/^[a-z][a-z\d+.-]*:\/\//i.test(value) ? value : `https://${value}`);
}

/** A problem the learner can act on, in words meant for them. */
export class VideoError extends Error {}

async function lookup(id: string): Promise<{ title: string; author: string } | null> {
  let res: Response;
  try {
    res = await fetch(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(watchUrl(id))}`);
  } catch {
    return null; // offline, or the request was blocked: the video is still added, with a plain title
  }
  if (res.status === 401 || res.status === 403) throw new VideoError("This video is private, or its owner doesn't allow it to play outside YouTube.");
  if (res.status === 400 || res.status === 404) throw new VideoError("YouTube doesn't have a video at that link. Check it and try again.");
  if (!res.ok) return null;
  const j = (await res.json().catch(() => null)) as { title?: string; author_name?: string } | null;
  return j?.title ? { title: String(j.title).slice(0, 200), author: String(j.author_name ?? "").slice(0, 120) } : null;
}

/** The thumbnail as a small data URL (so the library works offline), or its address if that fails. */
async function poster(id: string): Promise<string> {
  try {
    const res = await fetch(posterUrl(id));
    if (res.ok) {
      const { imageToDataUrl } = await import("./media");
      const data = await imageToDataUrl(await res.blob(), 480);
      if (data) return data;
    }
  } catch {
    /* keep the address */
  }
  return posterUrl(id);
}

/** Add a YouTube video to a project's library. The same video is never added twice. */
export async function addYoutubeVideo(projectId: string, input: string): Promise<{ file: LibFile; existing: boolean }> {
  const ref = linkRef(input);
  if (!ref) throw new VideoError("That doesn't look like a YouTube video link.");
  const same = await db.files
    .where("projectId")
    .equals(projectId)
    .filter((f) => f.youtube?.id === ref.id)
    .first();
  if (same) return { file: same, existing: true };
  const [meta, thumb] = await Promise.all([lookup(ref.id), poster(ref.id)]);
  const now = Date.now();
  const file: LibFile = {
    id: uid(),
    projectId,
    name: meta?.title || "YouTube video",
    kind: "video",
    mime: "video/youtube",
    size: 0,
    blob: new Blob([], { type: "video/youtube" }),
    thumb,
    thumbVersion: 3,
    indexed: "pending",
    createdAt: now,
    youtube: { id: ref.id, ...(ref.start ? { start: ref.start } : {}), ...(ref.vertical ? { vertical: true } : {}), ...(meta?.author ? { author: meta.author } : {}) },
  };
  await db.files.add(file);
  await db.projects.update(projectId, { updatedAt: now });
  // The transcript is fetched in the background, through the same queue that indexes other files.
  queueIndex(file.id);
  return { file, existing: false };
}

/* ---------------------------------------------------------------- captions */

export type CaptionResult =
  | { ok: true; lang: string; auto: boolean; segments: TranscriptSegment[]; duration: number }
  | { ok: false; why: "none" | "blocked"; detail?: string; duration?: number };

/** YouTube's "json3" caption format → segments. */
export function captionSegments(body: string): TranscriptSegment[] {
  let j: { events?: { tStartMs?: number; dDurationMs?: number; segs?: { utf8?: string }[] }[] };
  try {
    j = JSON.parse(body);
  } catch {
    return [];
  }
  const out: TranscriptSegment[] = [];
  for (const e of Array.isArray(j?.events) ? j.events : []) {
    const text = (e.segs ?? [])
      .map((s) => s.utf8 ?? "")
      .join("")
      .replace(/\s+/g, " ")
      .trim();
    if (!text || typeof e.tStartMs !== "number") continue;
    const t0 = e.tStartMs / 1000;
    out.push({ t0, t1: t0 + Math.max(0, e.dDurationMs ?? 0) / 1000, text });
  }
  // Automatic captions overlap (a line stays up while the next appears): end each where the next begins.
  for (let i = 0; i + 1 < out.length; i++) if (out[i].t1 > out[i + 1].t0) out[i].t1 = out[i + 1].t0;
  return out;
}

/**
 * Runs inside a sandboxed frame. YouTube's player endpoint sends no cross-origin permission to a
 * normal website, but it does answer a page with an opaque origin, which is what a sandboxed frame
 * without "allow-same-origin" has. The request is sent as text/plain so the browser doesn't ask
 * permission first (YouTube rejects that question). The signed caption address in the answer has
 * to be fetched by the same browser, so that happens here too.
 */
const FRAME_SOURCE = `
const send = (m) => parent.postMessage(Object.assign({ nonce: NONCE }, m), "*");
(async () => {
  try {
    const r = await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
      method: "POST",
      credentials: "omit",
      headers: { "content-type": "text/plain" },
      body: JSON.stringify({ context: { client: { clientName: "ANDROID", clientVersion: "19.44.38", androidSdkVersion: 30, hl: "en" } }, videoId: VIDEO }),
    });
    if (!r.ok) return send({ error: "the player answered " + r.status });
    const j = await r.json();
    const duration = Number(j.videoDetails && j.videoDetails.lengthSeconds) || 0;
    const list = j.captions && j.captions.playerCaptionsTracklistRenderer && j.captions.playerCaptionsTracklistRenderer.captionTracks;
    const tracks = Array.isArray(list) ? list.filter((t) => t && typeof t.baseUrl === "string") : [];
    if (!tracks.length) return send({ none: true, duration, status: String((j.playabilityStatus && j.playabilityStatus.status) || "") });
    // Captions someone wrote, in the language that is spoken, beat automatic ones.
    const auto = tracks.find((t) => t.kind === "asr");
    const pick = (auto && tracks.find((t) => t.kind !== "asr" && t.languageCode === auto.languageCode)) || tracks.find((t) => t.kind !== "asr") || tracks[0];
    const url = new URL(pick.baseUrl);
    url.searchParams.set("fmt", "json3");
    const c = await fetch(url.href, { credentials: "omit" });
    if (!c.ok) return send({ error: "the captions answered " + c.status });
    send({ body: (await c.text()).slice(0, 6000000), lang: String(pick.languageCode || ""), auto: pick.kind === "asr", duration });
  } catch (e) {
    send({ error: String((e && e.message) || e) });
  }
})();
`;

/** Ask YouTube for a video's captions. Resolves (never rejects) with what happened. */
export function fetchCaptions(id: string, timeout = 15000): Promise<CaptionResult> {
  if (typeof document === "undefined") return Promise.resolve({ ok: false, why: "blocked", detail: "no page" });
  return new Promise((resolve) => {
    const nonce = uid();
    const frame = document.createElement("iframe");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.setAttribute("aria-hidden", "true");
    frame.tabIndex = -1;
    frame.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;border:0;visibility:hidden";
    const script = `const NONCE = ${JSON.stringify(nonce)}; const VIDEO = ${JSON.stringify(id)};${FRAME_SOURCE}`;
    frame.srcdoc = `<!doctype html><meta charset="utf-8"><scr${""}ipt>${script}</scr${""}ipt>`;
    let timer = 0;
    const done = (result: CaptionResult) => {
      window.clearTimeout(timer);
      window.removeEventListener("message", onMessage);
      frame.remove();
      resolve(result);
    };
    const onMessage = (e: MessageEvent) => {
      if (e.source !== frame.contentWindow) return;
      const d = e.data as { nonce?: string; error?: string; none?: boolean; body?: string; lang?: string; auto?: boolean; duration?: number } | null;
      if (!d || d.nonce !== nonce) return;
      const duration = typeof d.duration === "number" && d.duration > 0 ? d.duration : 0;
      if (d.none) return done({ ok: false, why: "none", duration });
      if (typeof d.body !== "string") return done({ ok: false, why: "blocked", detail: String(d.error ?? "no answer").slice(0, 160) });
      const segments = captionSegments(d.body);
      if (!segments.length) return done({ ok: false, why: "blocked", detail: "the captions came back empty", duration });
      done({ ok: true, lang: String(d.lang ?? "").slice(0, 12), auto: d.auto === true, segments, duration });
    };
    timer = window.setTimeout(() => done({ ok: false, why: "blocked", detail: "no answer in time" }), timeout);
    window.addEventListener("message", onMessage);
    document.body.appendChild(frame);
  });
}

/* ------------------------------------------------------------ transcription */

const GEMINI_PROMPT =
  "Transcribe everything that is said in this video, word for word, in the language it is spoken in. " +
  "Output only lines in the form [mm:ss] text (use [h:mm:ss] after the first hour), with timestamps measured from the start of the video, " +
  "starting a new line at least every 30 seconds. No commentary, no headings, no markdown. If nobody speaks, output nothing.";

/** The Gemini provider to transcribe with: the one chosen in Settings → Transcription, else any with a key. */
async function geminiProvider(): Promise<{ provider: Provider; model: string } | null> {
  const { transcriptionProviderId, transcriptionModel } = useSettings.getState();
  const all = await db.providers.toArray();
  const chosen = all.find((p) => p.id === transcriptionProviderId && p.type === "gemini" && p.apiKey);
  if (chosen) return { provider: chosen, model: transcriptionModel || chosen.defaultModel || "gemini-2.5-flash" };
  const any = all.find((p) => p.type === "gemini" && p.apiKey);
  if (!any) return null;
  // A fast model is plenty for transcription, and much cheaper on a long video.
  return { provider: any, model: any.models.find((m) => /flash/i.test(m) && !/image|tts|live/i.test(m)) || any.defaultModel || "gemini-2.5-flash" };
}

export async function transcribeWithGemini(provider: Provider, model: string, id: string, duration = 0): Promise<{ segments: TranscriptSegment[]; partial: boolean }> {
  const base = (provider.baseUrl || "https://generativelanguage.googleapis.com").replace(/\/+$/, "");
  const post = (lowResolution: boolean) =>
    fetch(`${base}/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": provider.apiKey },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ file_data: { file_uri: watchUrl(id) } }, { text: GEMINI_PROMPT }] }],
        // Only the sound matters here; low-resolution frames cost about a third as much.
        generationConfig: { temperature: 0, ...(lowResolution ? { mediaResolution: "MEDIA_RESOLUTION_LOW" } : {}) },
      }),
    });
  let res = await post(true);
  // A model that doesn't know the resolution setting answers 400: ask again without it.
  if (res.status === 400) res = await post(false);
  if (!res.ok) throw new Error(`Gemini answered ${res.status}: ${(await res.text()).replace(/\s+/g, " ").slice(0, 160)}`);
  const j = (await res.json()) as { candidates?: { finishReason?: string; content?: { parts?: { text?: string }[] } }[] };
  const first = j.candidates?.[0];
  const text = (first?.content?.parts ?? []).map((p) => p.text ?? "").join("");
  const rows = parseTimestampedLines(text, 0, 0).filter((s) => s.text.trim());
  const end = duration || (rows.length ? rows[rows.length - 1].t0 + 30 : 0);
  const segments = rows.map((s, i) => ({ t0: s.t0, t1: i + 1 < rows.length ? Math.max(s.t0, rows[i + 1].t0) : Math.max(s.t0, end), text: s.text.trim() }));
  return { segments, partial: first?.finishReason === "MAX_TOKENS" };
}

/** Lines of a comfortable reading length, each with its time span. */
const readable = (segments: TranscriptSegment[]) => groupSegments(segments, 240);

/** Get the transcript for a YouTube item: captions first, then transcription. Never throws. */
export async function loadYoutubeTranscript(file: Pick<LibFile, "youtube" | "duration">): Promise<{ transcript: Transcript; duration?: number } | { reason: string }> {
  const id = file.youtube?.id;
  if (!id) return { reason: "this is not a YouTube video" };
  const captions = await fetchCaptions(id);
  const known = file.duration || (captions.duration ?? 0);
  if (captions.ok) {
    return {
      transcript: { source: "captions", lang: captions.lang || undefined, auto: captions.auto || undefined, timed: true, segments: readable(captions.segments), at: Date.now() },
      duration: captions.duration || undefined,
    };
  }
  const why = captions.why === "none" ? "the video has no captions" : "YouTube didn't share the captions with this app";
  const gemini = await geminiProvider();
  if (!gemini) return { reason: `${why}, and transcribing a YouTube video needs a Gemini provider (Settings → AI providers)` };
  try {
    const out = await transcribeWithGemini(gemini.provider, gemini.model, id, known);
    if (!out.segments.length) return { reason: "no speech was found in this video" };
    return {
      transcript: { source: "gemini", model: gemini.model, timed: true, partial: out.partial || undefined, segments: readable(out.segments), at: Date.now() },
      duration: known || undefined,
    };
  } catch (e) {
    return { reason: `${why}, and Gemini couldn't transcribe it (${(e instanceof Error ? e.message : String(e)).slice(0, 160)})` };
  }
}

/* ------------------------------------------------------------------ pasted */

const STAMP = /^[[(]?((?:\d{1,2}:)?\d{1,2}:\d{2})(?:[.,]\d+)?[\])]?(?:\s*-->\s*\S+)?\s*[-–:]?\s*(.*)$/;

/**
 * A transcript the learner pasted: YouTube's own "Show transcript" text (a time on one line, the
 * words on the next), "[1:05] words" lines, subtitle files (SRT / VTT), or plain text with no times.
 */
export function parsePastedTranscript(raw: string, duration = 0): { segments: TranscriptSegment[]; timed: boolean } {
  const lines = raw
    .replace(/\r/g, "")
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !/^WEBVTT\b/i.test(l) && !/^\d+$/.test(l));
  if (!lines.length) return { segments: [], timed: false };
  const rows: { t: number; text: string }[] = [];
  let stamps = 0;
  for (const line of lines) {
    const m = STAMP.exec(line);
    if (m) {
      stamps++;
      rows.push({ t: parseClock(m[1]), text: m[2].trim() });
    } else if (rows.length) rows[rows.length - 1].text += `${rows[rows.length - 1].text ? " " : ""}${line}`;
    else rows.push({ t: 0, text: line });
  }
  const filled = rows.filter((r) => r.text);
  if (stamps >= 2 && stamps >= filled.length / 2) {
    const segments = filled.map((r, i) => ({ t0: r.t, t1: Math.max(r.t, filled[i + 1]?.t ?? r.t + 30), text: r.text }));
    return { segments: readable(segments), timed: true };
  }
  // No times: spread the text across the video, so reading a range of it still works.
  const text = lines.join(" ");
  const length = duration || Math.max(60, text.split(/\s+/).length / 2.5);
  return { segments: readable(spreadText(text, 0, length)), timed: false };
}

/* ------------------------------------------------------------------ for Leo */

/** The transcript as text, one "[m:ss] words" line per segment. */
export function transcriptText(t: Pick<Transcript, "segments" | "timed">): string {
  return t.segments.map((s) => (t.timed ? `[${clock(s.t0)}] ${s.text}` : s.text)).join("\n");
}

/**
 * What Leo is told about the video the learner has open: the whole transcript when it fits, else
 * the part around where they are and how to read the rest.
 */
export function videoContext(file: Pick<LibFile, "id" | "name" | "duration" | "transcript" | "indexed" | "indexNote" | "youtube">, at = 0, max = 10000): string {
  const where = `the learner is at ${clock(at)}${file.duration ? ` of ${clock(file.duration)}` : ""}`;
  const head = `## ${file.youtube ? "YouTube video" : "Video"} "${file.name}" (id=${file.id}) — ${where}`;
  const t = file.transcript;
  if (!t?.segments.length) {
    const why = file.indexed === "pending" ? " yet (it is still being fetched)" : file.indexNote ? ` (${file.indexNote})` : "";
    return `${head}\nThere is no transcript${why}. You cannot watch the video; ask the learner what it covers.\n\n`;
  }
  const lines = t.segments.map((s) => (t.timed ? `[${clock(s.t0)}] ${s.text}` : s.text));
  const note = t.timed ? "" : " (the times are estimates)";
  if (lines.reduce((n, l) => n + l.length + 1, 0) <= max) return `${head}\nFull transcript${note}:\n${lines.join("\n")}\n\n`;
  let i = t.segments.findIndex((s) => s.t1 > at - 90);
  if (i < 0) i = 0;
  const part: string[] = [];
  let used = 0;
  let j = i;
  for (; j < lines.length && (part.length === 0 || used + lines[j].length < max); j++) {
    part.push(lines[j]);
    used += lines[j].length + 1;
  }
  const rest = `{"type":"read","kind":"file","id":"${file.id}","from":"m:ss","to":"m:ss"}`;
  return `${head}\nTranscript from ${clock(t.segments[i].t0)} to ${clock(t.segments[j - 1].t1)}${note}. The video is longer; read other parts with ${rest}:\n${part.join("\n")}\n\n`;
}
