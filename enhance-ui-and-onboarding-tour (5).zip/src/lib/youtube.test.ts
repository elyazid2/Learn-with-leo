import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db, type LibFile } from "@/lib/db";
import { readLibraryFile } from "./ai/fileReader";
import { captionSegments, linkRef, parsePastedTranscript, transcriptText, videoContext } from "./youtube";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
beforeEach(() => fake.reset());

describe("YouTube links", () => {
  it("accepts the link shapes people paste, with or without https", () => {
    expect(linkRef("https://www.youtube.com/watch?v=aqz-KE-bpKQ")?.id).toBe("aqz-KE-bpKQ");
    expect(linkRef("youtu.be/aqz-KE-bpKQ?t=75")).toEqual({ id: "aqz-KE-bpKQ", start: 75, vertical: false });
    expect(linkRef("  https://youtube.com/shorts/aqz-KE-bpKQ  ")?.vertical).toBe(true);
  });

  it("rejects everything else", () => {
    for (const bad of ["", "photosynthesis explained", "https://vimeo.com/123456", "https://www.youtube.com/@Blender", "watch this https://youtu.be/aqz-KE-bpKQ"]) expect(linkRef(bad), bad).toBeNull();
  });
});

describe("YouTube captions", () => {
  it("reads caption events into timed lines and skips empty ones", () => {
    const body = JSON.stringify({
      events: [
        { tStartMs: 0, dDurationMs: 2500, segs: [{ utf8: "Hello " }, { utf8: "and welcome" }] },
        { tStartMs: 2500, dDurationMs: 1000, segs: [{ utf8: "\n" }] },
        { tStartMs: 3000, dDurationMs: 4000, segs: [{ utf8: "to the lesson" }] },
        { segs: [{ utf8: "no time" }] },
      ],
    });
    expect(captionSegments(body)).toEqual([
      { t0: 0, t1: 2.5, text: "Hello and welcome" },
      { t0: 3, t1: 7, text: "to the lesson" },
    ]);
  });

  it("ends an automatic caption where the next one begins", () => {
    const body = JSON.stringify({ events: [{ tStartMs: 0, dDurationMs: 6000, segs: [{ utf8: "one" }] }, { tStartMs: 2000, dDurationMs: 6000, segs: [{ utf8: "two" }] }] });
    expect(captionSegments(body).map((s) => s.t1)).toEqual([2, 8]);
  });

  it("treats anything that isn't caption data as no captions", () => {
    expect(captionSegments("<html>Sorry…</html>")).toEqual([]);
    expect(captionSegments("{}")).toEqual([]);
  });
});

describe("pasted transcripts", () => {
  it("reads YouTube's own Show transcript text (a time, then the words)", () => {
    const out = parsePastedTranscript("0:00\nwelcome back\n0:14\ntoday we look at cells\n1:02\nand how they divide");
    expect(out.timed).toBe(true);
    expect(out.segments[0]).toMatchObject({ t0: 0, text: "welcome back today we look at cells and how they divide" });
  });

  it("keeps lines apart when they are long enough to stand alone", () => {
    const long = "word ".repeat(40).trim();
    const out = parsePastedTranscript(`[00:05] ${long}\n[01:10] ${long}\n[1:02:03] ${long}`);
    expect(out.segments.map((s) => s.t0)).toEqual([5, 70, 3723]);
    expect(out.segments[0].t1).toBe(70);
  });

  it("reads subtitle files", () => {
    const srt = "1\n00:00:01,000 --> 00:00:04,000\nFirst line\n\n2\n00:00:04,500 --> 00:00:09,000\nSecond line";
    const out = parsePastedTranscript(srt);
    expect(out.timed).toBe(true);
    expect(out.segments[0].text).toBe("First line Second line");
    expect(out.segments[0].t0).toBe(1);
  });

  it("spreads plain text across the video so ranges of it can still be read", () => {
    const out = parsePastedTranscript("Cells are small. They divide. Mitosis has phases.", 300);
    expect(out.timed).toBe(false);
    expect(out.segments.length).toBeGreaterThan(0);
    expect(out.segments[out.segments.length - 1].t1).toBeCloseTo(300, 0);
    expect(parsePastedTranscript("   \n ").segments).toEqual([]);
  });
});

describe("what Leo is given about a video", () => {
  const file = (over: Partial<LibFile> = {}): LibFile =>
    ({ id: "v1", projectId: "p", name: "Cell division", kind: "video", mime: "video/youtube", size: 0, blob: null as never, createdAt: 1, youtube: { id: "aqz-KE-bpKQ" }, duration: 600, indexed: "done", ...over }) as LibFile;
  const segments = Array.from({ length: 40 }, (_, i) => ({ t0: i * 15, t1: i * 15 + 15, text: `line ${i} ${"words ".repeat(30).trim()}` }));

  it("attaches the whole transcript when it is short", () => {
    const text = videoContext(file({ transcript: { source: "captions", timed: true, segments: segments.slice(0, 3), at: 1 } }), 20);
    expect(text).toContain(`## YouTube video "Cell division" (id=v1) — the learner is at 0:20 of 10:00`);
    expect(text).toContain("Full transcript:\n[0:00] line 0");
    expect(text).toContain("[0:30] line 2");
  });

  it("attaches the part around where the learner is when it is long, and says how to read the rest", () => {
    const text = videoContext(file({ transcript: { source: "gemini", timed: true, segments, at: 1 } }), 300, 2000);
    expect(text).toContain("Transcript from 3:30 to");
    expect(text).toContain(`{"type":"read","kind":"file","id":"v1"`);
    expect(text).not.toContain("line 0 ");
    expect(text.length).toBeLessThan(2600);
  });

  it("says so when there is no transcript, with the reason", () => {
    expect(videoContext(file({ indexed: "none", indexNote: "the video has no captions" }), 0)).toContain("There is no transcript (the video has no captions). You cannot watch the video");
    expect(videoContext(file({ indexed: "pending" }), 0)).toContain("no transcript yet (it is still being fetched)");
  });

  it("writes timed transcripts with their times and untimed ones without", () => {
    expect(transcriptText({ timed: true, segments: segments.slice(0, 1) })).toMatch(/^\[0:00\] line 0/);
    expect(transcriptText({ timed: false, segments: [{ t0: 0, t1: 9, text: "plain" }] })).toBe("plain");
  });

  it("lets Leo read a YouTube item's transcript by time range, like any other video", async () => {
    await fake.files.add(file() as never);
    for (const [i, t0] of [0, 60, 120, 400].entries()) await fake.chunks.add({ id: `c${i}`, projectId: "p", sourceId: "v1", sourceKind: "file", sourceName: "Cell division", page: 0, text: `part ${i}`, t0, t1: t0 + 60 } as never);
    const all = await readLibraryFile("p", { id: "v1" });
    expect(all.ok).toBe(true);
    expect(all.text).toContain("[0:00–1:00] part 0");
    expect(all.text).toContain("[6:40–7:40] part 3");
    const later = await readLibraryFile("p", { id: "v1", from: "5:00" });
    expect(later.text).toContain("part 3");
    expect(later.text).not.toContain("part 0");
  });

  it("tells Leo why when a YouTube item has no transcript", async () => {
    await fake.files.add(file({ indexed: "none", indexNote: "the video has no captions, and transcribing a YouTube video needs a Gemini provider" }) as never);
    const out = await readLibraryFile("p", { id: "v1" });
    expect(out.ok).toBe(false);
    expect(out.label).toContain("no transcript (the video has no captions");
  });
});
