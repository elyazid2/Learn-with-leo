import { db, type Highlight, type PageNote, type PdfAnnotations, type Rect, type Stroke } from "./db";

/**
 * Annotations on a PDF: highlights, pen strokes and page notes.
 *
 * Everything is stored as fractions of the page (0..1), so marks stay in place at any zoom. They
 * live in their own table keyed by the file, not on the file record: saving a stroke must not
 * rewrite a 50 MB PDF.
 */

export const EMPTY_ANNOTATIONS: PdfAnnotations = { highlights: [], strokes: [], notes: [] };

export const HIGHLIGHT_COLORS = [
  { label: "Yellow", hex: "#ffe066" },
  { label: "Green", hex: "#a8e6a1" },
  { label: "Blue", hex: "#a5d4ff" },
  { label: "Pink", hex: "#ffc2d9" },
] as const;

export const PEN_COLORS = [
  { label: "Black", hex: "#17171a" },
  { label: "Red", hex: "#e03e3e" },
  { label: "Blue", hex: "#2f66e0" },
  { label: "Green", hex: "#16a072" },
] as const;

/** Pen width, eraser reach and the smallest step kept while drawing, as fractions of the page width. */
export const PEN_WIDTH = 0.003;
export const ERASER_RADIUS = 0.012;
export const MIN_STEP = 0.0015;

const round = (n: number) => Math.round(n * 1e4) / 1e4;
const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

/**
 * Turn the many small boxes of a text selection into one bar per line. `ratio` is the page's
 * height / width, so a gap across the page can be compared with a line's height.
 */
export function mergeRects(rects: Rect[], ratio = 1.3): Rect[] {
  const lines: Rect[][] = [];
  for (const r of [...rects].sort((a, b) => a[1] - b[1] || a[0] - b[0])) {
    if (!(r[2] > 0 && r[3] > 0)) continue;
    const line = lines.find((l) => {
      const f = l[0];
      const overlap = Math.min(f[1] + f[3], r[1] + r[3]) - Math.max(f[1], r[1]);
      return overlap > 0.5 * Math.min(f[3], r[3]);
    });
    if (line) line.push(r);
    else lines.push([r]);
  }
  const out: Rect[] = [];
  for (const line of lines) {
    line.sort((a, b) => a[0] - b[0]);
    let cur: Rect = [...line[0]];
    for (const r of line.slice(1)) {
      const gap = r[0] - (cur[0] + cur[2]);
      // Closer than about a character: the same run of text. Further apart: another column.
      if (gap <= Math.max(cur[3], r[3]) * ratio * 0.8) {
        const right = Math.max(cur[0] + cur[2], r[0] + r[2]);
        const top = Math.min(cur[1], r[1]);
        const bottom = Math.max(cur[1] + cur[3], r[1] + r[3]);
        cur = [cur[0], top, right - cur[0], bottom - top];
      } else {
        out.push(cur);
        cur = [...r];
      }
    }
    out.push(cur);
  }
  return out.map((r) => [round(clamp01(r[0])), round(clamp01(r[1])), round(r[2]), round(r[3])]);
}

/** The topmost highlight under a point (fractions of the page). */
export function highlightAt(highlights: Highlight[], x: number, y: number): Highlight | undefined {
  for (let i = highlights.length - 1; i >= 0; i--) {
    if (highlights[i].rects.some((r) => x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3])) return highlights[i];
  }
  return undefined;
}

/** A smooth SVG path through a stroke's points, in a W × H box. */
export function strokePath(points: number[], W: number, H: number): string {
  const n = Math.floor(points.length / 2);
  if (n < 1) return "";
  const X = (i: number) => Math.round(points[2 * i] * W * 10) / 10;
  const Y = (i: number) => Math.round(points[2 * i + 1] * H * 10) / 10;
  // A tap is a dot: a line too short to see, drawn with round ends.
  if (n === 1) return `M${X(0)} ${Y(0)}l0.01 0`;
  let d = `M${X(0)} ${Y(0)}`;
  for (let i = 1; i < n - 1; i++) {
    d += `Q${X(i)} ${Y(i)} ${Math.round((X(i) + X(i + 1)) * 5) / 10} ${Math.round((Y(i) + Y(i + 1)) * 5) / 10}`;
  }
  return `${d}L${X(n - 1)} ${Y(n - 1)}`;
}

/** Whether the eraser at (x, y) touches a stroke. Distances are measured in page widths. */
export function hitsStroke(stroke: Stroke, x: number, y: number, ratio: number, radius = ERASER_RADIUS): boolean {
  const reach = radius + stroke.width / 2;
  const p = stroke.points;
  const py = y * ratio;
  for (let i = 0; i + 1 < p.length; i += 2) {
    const j = i + 3 < p.length ? i + 2 : i;
    const ax = p[i];
    const ay = p[i + 1] * ratio;
    const dx = p[j] - ax;
    const dy = p[j + 1] * ratio - ay;
    const len2 = dx * dx + dy * dy;
    const t = len2 ? Math.max(0, Math.min(1, ((x - ax) * dx + (py - ay) * dy) / len2)) : 0;
    const cx = ax + t * dx;
    const cy = ay + t * dy;
    if ((x - cx) ** 2 + (py - cy) ** 2 <= reach * reach) return true;
  }
  return false;
}

export const roundPoints = (points: number[]) => points.map((n) => round(clamp01(n)));

const isNum = (v: unknown): v is number => typeof v === "number" && isFinite(v);
const isStr = (v: unknown): v is string => typeof v === "string";

/** Keep only well-formed annotations (saved rows and imported backups are not trusted blindly). */
export function normalizeAnnotations(raw: unknown): PdfAnnotations {
  const r = (raw ?? {}) as Partial<Record<keyof PdfAnnotations, unknown>>;
  const list = (v: unknown) => (Array.isArray(v) ? (v as Record<string, unknown>[]).filter((x) => x && typeof x === "object") : []);
  const page = (v: unknown) => isNum(v) && v >= 1;
  return {
    highlights: list(r.highlights)
      .filter((h) => isStr(h.id) && page(h.page) && isStr(h.color) && Array.isArray(h.rects))
      .map((h) => ({
        id: h.id as string,
        page: h.page as number,
        color: h.color as string,
        rects: (h.rects as unknown[]).filter((x): x is Rect => Array.isArray(x) && x.length === 4 && x.every(isNum)),
        text: isStr(h.text) ? h.text : "",
        at: isNum(h.at) ? h.at : 0,
      }))
      .filter((h) => h.rects.length > 0),
    strokes: list(r.strokes)
      .filter((s) => isStr(s.id) && page(s.page) && isStr(s.color) && Array.isArray(s.points) && (s.points as unknown[]).length >= 2 && (s.points as unknown[]).every(isNum))
      .map((s) => ({ id: s.id as string, page: s.page as number, color: s.color as string, width: isNum(s.width) ? s.width : PEN_WIDTH, points: s.points as number[] })),
    notes: list(r.notes)
      .filter((n) => isStr(n.id) && page(n.page) && isStr(n.text))
      .map((n) => ({ id: n.id as string, page: n.page as number, text: n.text as string, at: isNum(n.at) ? n.at : 0 })),
  };
}

export const countAnnotations = (a: PdfAnnotations) => a.highlights.length + a.strokes.length + a.notes.filter((n) => n.text.trim()).length;

export async function loadAnnotations(fileId: string): Promise<PdfAnnotations> {
  return normalizeAnnotations(await db.annotations.get(fileId));
}

export async function saveAnnotations(fileId: string, projectId: string, a: PdfAnnotations) {
  const notes: PageNote[] = a.notes.filter((n) => n.text.trim());
  if (!a.highlights.length && !a.strokes.length && !notes.length) await db.annotations.delete(fileId);
  else await db.annotations.put({ fileId, projectId, highlights: a.highlights, strokes: a.strokes, notes, updatedAt: Date.now() });
}

/** What the learner marked on a page, in words, so Leo can use it ("quiz me on what I highlighted"). */
export function annotationSummary(a: PdfAnnotations, page: number): string {
  const highlighted = [...new Set(a.highlights.filter((h) => h.page === page && h.text.trim()).map((h) => `- "${h.text.trim().slice(0, 300)}"`))].slice(0, 12);
  const notes = a.notes.filter((n) => n.page === page && n.text.trim()).map((n) => `- ${n.text.trim().slice(0, 500)}`).slice(0, 8);
  return [
    highlighted.length ? `[The learner highlighted on this page]\n${highlighted.join("\n")}` : "",
    notes.length ? `[The learner's notes on this page]\n${notes.join("\n")}` : "",
  ]
    .filter(Boolean)
    .join("\n\n");
}
