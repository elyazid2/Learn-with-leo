import { describe, expect, it } from "vitest";
import type { Highlight, Rect, Stroke } from "./db";
import { annotationSummary, hitsStroke, highlightAt, mergeRects, normalizeAnnotations, strokePath } from "./annotations";

describe("PDF highlights: turning a selection into bars", () => {
  it("merges the words of one line into a single bar", () => {
    const words: Rect[] = [
      [0.1, 0.2, 0.08, 0.02],
      [0.185, 0.2, 0.1, 0.02],
      [0.29, 0.201, 0.05, 0.019],
    ];
    expect(mergeRects(words, 1.4)).toEqual([[0.1, 0.2, 0.24, 0.02]]);
  });

  it("keeps separate lines separate, top to bottom", () => {
    const out = mergeRects(
      [
        [0.1, 0.25, 0.3, 0.02],
        [0.1, 0.2, 0.5, 0.02],
      ],
      1.4
    );
    expect(out.map((r) => r[1])).toEqual([0.2, 0.25]);
  });

  it("does not bridge the gap between two columns", () => {
    const out = mergeRects(
      [
        [0.1, 0.2, 0.3, 0.02],
        [0.6, 0.2, 0.3, 0.02],
      ],
      1.4
    );
    expect(out).toHaveLength(2);
  });

  it("drops empty boxes", () => {
    expect(mergeRects([[0.1, 0.2, 0, 0.02]])).toEqual([]);
  });
});

describe("PDF highlights: finding the one that was clicked", () => {
  const h = (id: string, rects: Rect[]): Highlight => ({ id, page: 1, color: "#ffe066", rects, text: "", at: 0 });
  const list = [h("a", [[0.1, 0.1, 0.5, 0.02]]), h("b", [[0.3, 0.1, 0.2, 0.02]])];

  it("returns the topmost highlight under the point", () => {
    expect(highlightAt(list, 0.35, 0.11)?.id).toBe("b");
    expect(highlightAt(list, 0.15, 0.11)?.id).toBe("a");
  });

  it("returns nothing for a click on plain text", () => {
    expect(highlightAt(list, 0.8, 0.5)).toBeUndefined();
  });
});

describe("PDF drawing", () => {
  const line: Stroke = { id: "s", page: 1, color: "#17171a", width: 0.003, points: [0.2, 0.2, 0.8, 0.2] };

  it("draws a tap as a dot and a stroke as a curve through its points", () => {
    expect(strokePath([0.5, 0.5], 1000, 1400)).toBe("M500 700l0.01 0");
    expect(strokePath([0.1, 0.1, 0.2, 0.2, 0.3, 0.1], 1000, 1000)).toBe("M100 100Q200 200 250 150L300 100");
    expect(strokePath([], 1000, 1000)).toBe("");
  });

  it("the eraser removes a stroke it touches anywhere along its length", () => {
    expect(hitsStroke(line, 0.5, 0.205, 1.4)).toBe(true);
    expect(hitsStroke(line, 0.2, 0.2, 1.4)).toBe(true);
  });

  it("the eraser leaves strokes it does not touch", () => {
    expect(hitsStroke(line, 0.5, 0.26, 1.4)).toBe(false);
    expect(hitsStroke(line, 0.9, 0.2, 1.4)).toBe(false);
  });

  it("a dot can be erased too", () => {
    expect(hitsStroke({ ...line, points: [0.5, 0.5] }, 0.505, 0.5, 1.4)).toBe(true);
  });
});

describe("PDF annotations: loading and telling Leo", () => {
  it("keeps well-formed annotations and drops anything else", () => {
    const out = normalizeAnnotations({
      highlights: [{ id: "h", page: 2, color: "#ffe066", rects: [[0.1, 0.1, 0.2, 0.02], ["x"]], text: "cells", at: 5 }, { id: "bad", page: 0, color: "x", rects: [] }, null],
      strokes: [{ id: "s", page: 1, color: "#17171a", points: [0.1, 0.2] }, { id: "odd", page: 1, color: "#000", points: ["a"] }],
      notes: [{ id: "n", page: 3, text: "revise this" }, { id: "n2", page: 3 }],
    });
    expect(out.highlights).toEqual([{ id: "h", page: 2, color: "#ffe066", rects: [[0.1, 0.1, 0.2, 0.02]], text: "cells", at: 5 }]);
    expect(out.strokes).toHaveLength(1);
    expect(out.strokes[0].width).toBeGreaterThan(0);
    expect(out.notes).toEqual([{ id: "n", page: 3, text: "revise this", at: 0 }]);
    expect(normalizeAnnotations(undefined)).toEqual({ highlights: [], strokes: [], notes: [] });
  });

  it("describes a page's highlights and notes for Leo, and nothing for an unmarked page", () => {
    const a = normalizeAnnotations({
      highlights: [{ id: "h", page: 2, color: "#ffe066", rects: [[0.1, 0.1, 0.2, 0.02]], text: "the powerhouse of the cell", at: 1 }],
      strokes: [],
      notes: [{ id: "n", page: 2, text: "ask about ATP" }, { id: "e", page: 2, text: "  " }],
    });
    expect(annotationSummary(a, 2)).toBe(`[The learner highlighted on this page]\n- "the powerhouse of the cell"\n\n[The learner's notes on this page]\n- ask about ATP`);
    expect(annotationSummary(a, 3)).toBe("");
  });
});
