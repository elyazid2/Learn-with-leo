import { create } from "zustand";
import type { AgentState } from "./avatar";

export interface AgentActivity {
  projectId: string | null;
  phase: Exclude<AgentState, "waiting">;
  at: number;
  reason?: "provider" | "error";
}

export interface NoteCtx {
  id: string;
  title: string;
  content: string;
}
export interface PdfCtx {
  fileId: string;
  name: string;
  page: number;
  pages: number;
  text: string;
}
export interface ImageCtx {
  fileId: string;
  name: string;
  getDataUrl: () => Promise<string | null>;
}
export interface SketchCtx {
  id: string;
  title: string;
  getDataUrl: () => Promise<string | null>;
}
/** The live Excalidraw instance of the sketch the learner has open, so actions can update it. */
export interface SketchApi {
  sketchId: string;
  updateScene: (scene: { elements: readonly unknown[] }) => void;
  /** Scroll and zoom so these elements are in view. */
  fit?: (elements: readonly unknown[]) => void;
  /** Save the canvas as it is now (scene and thumbnail). */
  save?: () => void;
}
/** The video the learner has open, so Leo can be given its transcript around where they are. */
export interface VideoCtx {
  fileId: string;
  name: string;
  getTime: () => number;
}
export interface SelectionCtx {
  text: string;
  source: string;
}
export interface BrowserCtx {
  url: string;
  title: string;
  text: string;
  selection?: string;
  capturedAt: number;
}


interface AppState {
  // Workspace context the AI can see
  note: NoteCtx | null;
  pdf: PdfCtx | null;
  image: ImageCtx | null;
  sketch: SketchCtx | null;
  sketchApi: SketchApi | null;
  setSketchApi: (a: SketchApi | null) => void;
  selection: SelectionCtx | null;
  setNote: (n: NoteCtx | null) => void;
  setPdf: (p: PdfCtx | null) => void;
  setImage: (i: ImageCtx | null) => void;
  setSketch: (s: SketchCtx | null) => void;
  video: VideoCtx | null;
  setVideo: (v: VideoCtx | null) => void;
  setSelection: (s: SelectionCtx | null) => void;
  browser: BrowserCtx | null;
  setBrowser: (b: BrowserCtx | null) => void;
  browserOpen: boolean;
  setBrowserOpen: (open: boolean) => void;
  browserUrl: string;
  setBrowserUrl: (url: string) => void;

  // Chat UI
  chatOpen: boolean;
  setChatOpen: (o: boolean) => void;
  addOpen: boolean;
  setAddOpen: (o: boolean) => void;
  activeThread: Record<string, string>; // projectId -> threadId
  setActiveThread: (projectId: string, threadId: string) => void;
  streaming: { threadId: string; content: string } | null;
  setStreaming: (s: { threadId: string; content: string } | null) => void;
  abort: AbortController | null;
  setAbort: (a: AbortController | null) => void;
  agent: AgentActivity;
  waitingProjectId: string | null;
  setAgentActivity: (phase: AgentActivity["phase"], projectId: string | null, reason?: AgentActivity["reason"]) => void;
  setAgentWaiting: (projectId: string | null) => void;

  toast: Toast | null;
  showToast: (text: string, opts?: ToastOptions) => void;
  dismissToast: () => void;

  /** Keyboard shortcut help sheet. */
  shortcutsOpen: boolean;
  setShortcutsOpen: (o: boolean) => void;
  /** Bumped by the global ⌘K shortcut; screens that own a search UI listen for it. */
  searchRequest: number;
  requestSearch: () => void;
}

export type ToastTone = "info" | "success" | "error";
export interface ToastOptions {
  tone?: ToastTone;
  /** Optional inline action, e.g. Undo or Retry. */
  action?: { label: string; onClick: () => void };
  duration?: number;
}
export interface Toast extends ToastOptions {
  id: number;
  text: string;
}

const savedActive = (() => {
  try {
    return JSON.parse(localStorage.getItem("harness.activeThread") || "{}");
  } catch {
    return {};
  }
})();

export const useApp = create<AppState>((set, get) => ({
  note: null,
  pdf: null,
  image: null,
  sketch: null,
  selection: null,
  browser: null,
  setBrowser: (browser) => set({ browser }),
  browserOpen: false,
  setBrowserOpen: (browserOpen) => set({ browserOpen }),
  browserUrl: "",
  setBrowserUrl: (browserUrl) => set({ browserUrl }),
  setNote: (note) => set({ note }),
  setPdf: (pdf) => set({ pdf }),
  setImage: (image) => set({ image }),
  setSketch: (sketch) => set({ sketch }),
  video: null,
  setVideo: (video) => set({ video }),
  sketchApi: null,
  setSketchApi: (sketchApi) => set({ sketchApi }),
  setSelection: (selection) => set({ selection }),

  chatOpen: false,
  setChatOpen: (chatOpen) => set({ chatOpen }),
  addOpen: false,
  setAddOpen: (addOpen) => set({ addOpen }),
  activeThread: savedActive,
  setActiveThread: (projectId, threadId) => {
    const activeThread = { ...get().activeThread, [projectId]: threadId };
    localStorage.setItem("harness.activeThread", JSON.stringify(activeThread));
    set({ activeThread });
  },
  streaming: null,
  setStreaming: (streaming) => set({ streaming }),
  abort: null,
  setAbort: (abort) => set({ abort }),
  agent: { projectId: null, phase: "idle", at: Date.now() },
  waitingProjectId: null,
  setAgentActivity: (phase, projectId, reason) => set({ agent: { phase, projectId, reason, at: Date.now() } }),
  setAgentWaiting: (waitingProjectId) => set({ waitingProjectId }),

  toast: null,
  showToast: (text, opts = {}) => {
    const id = Date.now() + Math.random();
    // Errors and actionable toasts stay a little longer so they can be read and used.
    const tone: ToastTone = opts.tone ?? (/^(couldn'?t|could not|can'?t|cannot|chat error|error)\b|\b(failed|denied)\b/i.test(text) ? "error" : "info");
    const duration = opts.duration ?? (opts.action ? 5200 : tone === "error" ? 4200 : 2600);
    set({ toast: { id, text, ...opts, tone } });
    setTimeout(() => {
      if (get().toast?.id === id) set({ toast: null });
    }, duration);
  },
  dismissToast: () => set({ toast: null }),

  shortcutsOpen: false,
  setShortcutsOpen: (shortcutsOpen) => set({ shortcutsOpen }),
  searchRequest: 0,
  requestSearch: () => set({ searchRequest: get().searchRequest + 1 }),
}));
