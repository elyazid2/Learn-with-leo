/**
 * Fact-check of Leo's core: what the prompt promises about making and editing files, checked
 * against what the parser, validator and executor really do. Each test names the promise.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});
vi.mock("@/lib/retrieval", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/retrieval")>();
  return { ...actual, indexNote: vi.fn(async () => {}) };
});

import { db, type CitationRef, type Message, type Note } from "@/lib/db";
import { useSettings } from "@/lib/settings";
import { buildHistory, resolvePending } from "@/lib/chat";
import { ACTION_TYPES, applyApprovedAction, executeActions, extractActions, noteBlock, noteTarget, noteViewIn, parseSegments, type Action } from "./actions";
import { publicUrlProblem } from "./publicUrl";

const fake = db as unknown as ReturnType<typeof import("../../test/fakeDb").createFakeDb>;
const P = "proj";
const T = "thread";
let clock = 1000;

const note = (over: Partial<Note> = {}): Note => ({ id: "n1", projectId: P, title: "Cells", content: "Cells have a membrane.", author: "user", createdAt: 1, updatedAt: 1, ...over });

async function addMsg(m: Partial<Message> & Pick<Message, "role" | "content">) {
  const id = `m${++clock}`;
  await db.messages.add({ id, threadId: T, projectId: P, createdAt: ++clock, ...m });
  return id;
}
const results = (body: string) => addMsg({ role: "user", hidden: true, content: `<action_results>\n${body}\n</action_results>` });
/** Leo read the note in this thread, exactly as the executor reports a read. */
const readNote = (n: Note) => results(noteBlock("Note", n));
const run = (a: Action, citations?: CitationRef[]) => executeActions(P, T, [a], { citations });
const parse = (json: string) => parseSegments("```action\n" + json + "\n```");
const thread = async () => (await db.messages.where("threadId").equals(T).sortBy("createdAt")) as Message[];

beforeEach(() => {
  fake.reset();
  useSettings.setState({ alwaysApprove: true });
});

describe("replace never runs on a note Leo has not fully and currently seen", () => {
  const long = `## Intro\n${"alpha beta gamma. ".repeat(900)}\n\n## Sources\n- book.pdf, p.3`;

  it("a clipped read is recognised even when the note contains markdown headings", () => {
    // Legacy read format: the truncation mark sits at the end, after the note's own `##` headings.
    const body = `# Cells\n\n## Membrane\nText\n\n## Sources\n- book.pdf, p.3\n…[truncated]`;
    const view = noteViewIn([{ role: "user", content: `<action_results>\n## Note "Cells" (id=n1)\n${body}\n</action_results>` }], "n1");
    expect(view).toMatchObject({ seen: true, clipped: true });
  });

  it("Leo cannot replace a long note after reading only its first part", async () => {
    expect(long.length).toBeGreaterThan(12000);
    await db.notes.add(note({ author: "ai", lastEditedBy: "ai", content: long }));
    const read = await run({ type: "read", kind: "note", id: "n1" });
    await results(read.read.join("\n"));
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "short" });
    expect(r.results[0].ok).toBe(false);
    expect(r.results[0].label).toMatch(/part of it/);
    expect((await db.notes.get("n1"))!.content).toBe(long);
    // Append and patch stay available: they cannot drop the unseen tail.
    expect((await run({ type: "note", id: "n1", title: "", content: "More." })).results[0].ok).toBe(true);
  });

  it("a long note is read in parts, and each part says exactly how to continue", async () => {
    await db.notes.add(note({ content: long }));
    const first = (await run({ type: "read", kind: "note", id: "n1" })).read[0];
    expect(first.split("\n")[0]).toBe(`## Note "Cells" (id=n1) — partial view: characters 1–12000 of ${long.length}`);
    expect(first).toContain(`{"type":"read","kind":"note","id":"n1","from":"12000"}`);
    const next = extractActions('```action\n{"type":"read","kind":"note","id":"n1","from":12000}\n```');
    const second = (await executeActions(P, T, next)).read[0];
    expect(second.split("\n")[0]).toBe(`## Note "Cells" (id=n1) — partial view: characters 12001–${long.length} of ${long.length}`);
    expect(second.endsWith("- book.pdf, p.3")).toBe(true);
    // A short note is still one plain block.
    await db.notes.add(note({ id: "n2", title: "Short", content: "tiny" }));
    expect((await run({ type: "read", kind: "note", id: "n2" })).read[0]).toBe('## Note "Short" (id=n2)\ntiny');
  });

  it("refuses when the learner changed the note after Leo read it", async () => {
    const n = note({ author: "ai", lastEditedBy: "ai", content: "Leo's draft." });
    await db.notes.add(n);
    await readNote(n);
    await db.notes.update("n1", { content: "Leo's draft.\n\nMy own addition.", lastEditedBy: "user", updatedAt: 5000 });
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "Rewritten from the old copy" });
    expect(r.results[0].ok).toBe(false);
    expect(r.results[0].label).toMatch(/read it again/);
    expect((await db.notes.get("n1"))!.content).toContain("My own addition.");
    // After a fresh read the same replace goes through.
    await readNote((await db.notes.get("n1"))!);
    expect((await run({ type: "note", id: "n1", title: "", mode: "replace", content: "Rewritten from the new copy" })).results[0].ok).toBe(true);
  });

  it("refuses when Leo's copy was collapsed out of the context by a later step", async () => {
    const n = note({ content: "Mine, word for word." });
    await db.notes.add(n);
    await addMsg({ role: "user", content: "tidy my note" });
    await readNote(n);
    await addMsg({ role: "assistant", content: "Let me check something else." });
    await results('## Search "x"\nNo matching passages.');
    // The premise, checked against the real history builder: the model no longer has the text.
    expect(buildHistory(await thread()).map((m) => m.content).join("\n")).not.toContain("Mine, word for word.");
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "New" });
    expect(r.results[0].ok).toBe(false);
    expect(r.results[0].label).toMatch(/read it again/);
    expect(r.pending).toEqual([]);
    expect((await db.notes.get("n1"))!.content).toBe("Mine, word for word.");
  });

  it("still lets Leo rewrite a note it wrote itself on a later turn", async () => {
    const n = note({ author: "ai", lastEditedBy: "ai", content: "Leo's own text." });
    await db.notes.add(n);
    await readNote(n);
    await addMsg({ role: "assistant", content: "Done." });
    await addMsg({ role: "user", content: "make it shorter" });
    expect((await run({ type: "note", id: "n1", title: "", mode: "replace", content: "Shorter." })).results[0].ok).toBe(true);
  });

  it("refuses an empty replace instead of blanking the note", async () => {
    const n = note({ author: "ai", lastEditedBy: "ai" });
    await db.notes.add(n);
    await readNote(n);
    const r = await run({ type: "note", id: "n1", title: "", mode: "replace", content: "  " });
    expect(r.results[0].ok).toBe(false);
    expect((await db.notes.get("n1"))!.content).toBe("Cells have a membrane.");
  });
});

describe("a note's Sources are the sources of the reply that wrote it", () => {
  const earlier: CitationRef[] = [{ label: "S1", fileId: "fA", name: "old.pdf", page: 1 }];
  const now: CitationRef[] = [{ label: "S1", fileId: "fB", name: "new.pdf", page: 7 }];
  beforeEach(async () => {
    await db.files.add({ id: "fA", projectId: P, name: "old.pdf", kind: "pdf" } as never);
    await db.files.add({ id: "fB", projectId: P, name: "new.pdf", kind: "pdf" } as never);
    // An earlier turn's reply was grounded in old.pdf.
    await addMsg({ role: "assistant", content: "Earlier answer [S1]", citations: earlier });
  });

  it("[S#] in a new note resolves against this turn's passages, not an earlier turn's", async () => {
    await run({ type: "note", title: "Summary", content: "Key idea [S1]." }, now);
    const n = (await db.notes.toArray())[0];
    expect(n.sources).toEqual([{ fileId: "fB", page: 7 }]);
    expect(n.content).toContain("- new.pdf, p.7");
    expect(n.content).not.toContain("old.pdf");
  });

  it("a note approved later keeps the sources of the reply that proposed it", async () => {
    useSettings.setState({ alwaysApprove: false });
    const r = await run({ type: "note", title: "Summary", content: "Key idea [S1]." }, now);
    expect(r.pending).toHaveLength(1);
    expect(await db.notes.toArray()).toHaveLength(0);
    const id = await addMsg({ role: "assistant", content: "Proposed.", citations: now, pending: r.pending });
    // Another turn, grounded elsewhere, happens before the learner presses Apply.
    await addMsg({ role: "assistant", content: "Later answer [S1]", citations: earlier });
    await resolvePending(id, r.pending[0].id, true);
    const n = (await db.notes.toArray())[0];
    expect(n.sources).toEqual([{ fileId: "fB", page: 7 }]);
    expect((await db.messages.get(id))!.pending![0].status).toBe("applied");
  });

  it("sources Leo passes are kept as numbers and unknown files are dropped", async () => {
    const [a] = extractActions('```action\n{"type":"note","title":"T","content":"x","sources":[{"fileId":"fB","page":"12","t0":"abc"},{"fileId":"nope","page":2}]}\n```');
    expect(a).toMatchObject({ sources: [{ fileId: "fB", page: 12 }, { fileId: "nope", page: 2 }] });
    await run(a);
    expect((await db.notes.toArray())[0].sources).toEqual([{ fileId: "fB", page: 12 }]);
  });
});

describe("notes Leo makes follow the same rules as notes the learner makes", () => {
  it("a new note gets a link-safe title", async () => {
    const r = await run({ type: "note", title: "C# basics: [intro] / part 1", content: "x" });
    const n = (await db.notes.toArray())[0];
    expect(n.title).toBe("C- basics - -intro- - part 1");
    expect(r.results[0].label).toBe("Created note · C- basics - -intro- - part 1");
    // The common case reads well: a colon becomes a spaced dash.
    await run({ type: "note", title: "Cell biology: key ideas", content: "x" });
    expect((await db.notes.toArray()).map((x) => x.title)).toContain("Cell biology - key ideas");
  });

  it("writing the same title again reuses the note instead of duplicating it", async () => {
    await run({ type: "note", title: "Cells: an overview", content: "v1" });
    const again = await run({ type: "note", title: "cells: an overview", content: "v2" });
    const all = await db.notes.toArray();
    expect(all).toHaveLength(1);
    expect(all[0].content).toBe("v2");
    expect(all[0].versions!.map((v) => v.content)).toEqual(["v1"]);
    expect(again.results[0].label).toMatch(/^Updated note/);
  });

  it("the same title in another folder is a different note", async () => {
    await run({ type: "note", title: "Summary", folder: "Biology", content: "bio" });
    await run({ type: "note", title: "Summary", folder: "Chemistry", content: "chem" });
    const all = await db.notes.toArray();
    expect(all.map((n) => `${n.folder}/${n.title}: ${n.content}`).sort()).toEqual(["Biology/Summary: bio", "Chemistry/Summary: chem"]);
  });

  it("the approval preview says when 'creating' a note will change an existing one", async () => {
    useSettings.setState({ alwaysApprove: false });
    await db.notes.add(note({ id: "n1", title: "Summary", author: "ai", lastEditedBy: "ai", content: "old" }));
    await db.notes.add(note({ id: "n2", title: "Plan", content: "mine" }));
    expect((await run({ type: "note", title: "Summary", content: "new" })).pending[0].label).toBe("Rewrite Leo's note “Summary”");
    expect((await run({ type: "note", title: "plan", content: "extra" })).pending[0].label).toBe("Add to your note “Plan”");
    expect((await run({ type: "note", title: "Brand new", content: "x" })).pending[0].label).toBe("Create note “Brand new”");
  });

  it("the approval preview looks up the very note the executor will change", async () => {
    await db.notes.add(note({ id: "n1", title: "Summary", author: "ai", lastEditedBy: "ai", content: "old" }));
    expect((await noteTarget(P, { type: "note", title: "summary", content: "new" }))?.id).toBe("n1");
    expect(await noteTarget(P, { type: "note", title: "Summary", folder: "Biology", content: "new" })).toBeUndefined();
    expect(await noteTarget(P, { type: "note", title: "Something else", content: "new" })).toBeUndefined();
    expect((await noteTarget(P, { type: "note", id: "n1", title: "", content: "x" }))?.id).toBe("n1");
    expect(await noteTarget("another-project", { type: "note", id: "n1", title: "", content: "x" })).toBeUndefined();
  });

  it("repeating a note's current title in an edit is not a rename", async () => {
    // A title stored before titles were cleaned; Leo sends it back exactly as listed.
    const a = note({ title: "Cells: an overview", author: "ai", lastEditedBy: "ai" });
    await db.notes.add(a);
    await readNote(a);
    const r = await run({ type: "note", id: "n1", title: "Cells: an overview", content: "More." });
    expect(r.results[0].label).toBe("Appended to note · Cells: an overview");
    expect((await db.notes.get("n1"))!.title).toBe("Cells: an overview");
  });

  it("renaming through an edit keeps [[wikilinks]] in other notes pointing at the note", async () => {
    const a = note({ author: "ai", lastEditedBy: "ai" });
    await db.notes.add(a);
    await db.notes.add(note({ id: "n2", title: "Index", content: "See [[Cells]] and [[Cells|the cell note]]." }));
    await readNote(a);
    const r = await run({ type: "note", id: "n1", title: "Cell biology", content: "More." });
    expect(r.results[0]).toMatchObject({ ok: true, label: "Appended to note · Cell biology (renamed from “Cells”)" });
    expect((await db.notes.get("n1"))!.title).toBe("Cell biology");
    expect((await db.notes.get("n2"))!.content).toBe("See [[Cell biology]] and [[Cell biology|the cell note]].");
    // The earlier name is in History, so the rename can be undone.
    expect((await db.notes.get("n1"))!.versions![0].title).toBe("Cells");
  });

  it("organize → rename rewrites links and never duplicates a title in the folder", async () => {
    await db.notes.add(note());
    await db.notes.add(note({ id: "n2", title: "Index", content: "See [[Cells]]." }));
    await db.notes.add(note({ id: "n3", title: "Tissues", content: "…" }));
    const r = await applyApprovedAction(P, { type: "organize", ops: [{ op: "rename", kind: "note", id: "n1", name: "Tissues" }] });
    expect(r.ok).toBe(true);
    expect((await db.notes.get("n1"))!.title).toBe("Tissues 2");
    expect((await db.notes.get("n2"))!.content).toBe("See [[Tissues 2]].");
  });

  it("organize → move keeps titles unique in the destination folder", async () => {
    await db.notes.add(note({ id: "n1", title: "Summary" }));
    await db.notes.add(note({ id: "n2", title: "Summary", folder: "Biology" }));
    await applyApprovedAction(P, { type: "organize", ops: [{ op: "move", kind: "note", id: "n1", folder: "Biology" }] });
    expect(await db.notes.get("n1")).toMatchObject({ folder: "Biology", title: "Summary 2" });
  });
});

describe("the validator enforces what the prompt documents", () => {
  const invalid = (json: string, why?: RegExp) => expect(parse(json)[0]).toMatchObject({ kind: "invalid", ...(why ? { reason: expect.stringMatching(why) } : {}) });
  const valid = (json: string) => expect(parse(json)[0]).toMatchObject({ kind: "action" });

  it("map status and placement level", () => {
    invalid('{"type":"map","concept":"Osmosis","status":"amazing"}', /new, learning, shaky or solid/);
    expect(extractActions('```action\n{"type":"map","concept":"Osmosis","status":"Not started"}\n```')[0]).toMatchObject({ status: "new" });
    valid('{"type":"map","concept":"Osmosis"}');
    invalid('{"type":"set_level","level":"Guru"}', /Beginner, Novice, Intermediate, Advanced, Expert/);
    expect(extractActions('```action\n{"type":"set_level","level":"upper-intermediate"}\n```')[0]).toMatchObject({ level: "Intermediate" });
  });

  it("memory needs what each op really uses", () => {
    invalid('{"type":"memory","op":"update","text":"x"}', /id/);
    invalid('{"type":"memory","op":"delete"}', /id/);
    invalid('{"type":"memory","op":"save","text":"x"}', /kind/);
    invalid('{"type":"memory","op":"save","kind":"goal"}', /text/);
    valid('{"type":"memory","op":"save","kind":"goal","text":"Pass the exam"}');
    valid('{"type":"memory","op":"update","id":"m1","text":"Pass the exam in June"}');
  });

  it("quizzes need a real choice and notes need something to write", () => {
    invalid('{"type":"quiz","question":"q","options":["only"],"answer":0}', /2–8/);
    invalid('{"type":"note","title":"T","content":"   "}', /empty/);
    valid('{"type":"note","id":"n1","mode":"patch","patches":[{"find":"a","replace":""}]}');
  });

  it("Leo opens public web pages only", () => {
    for (const url of ["http://192.168.1.1/admin", "https://localhost:3000", "http://127.0.0.1:11434/api", "http://2130706433/", "http://[::1]/", "https://router.local/", "https://intranet/wiki", "https://user:pw@example.com/", "javascript:alert(1)", "file:///etc/passwd", "not a url"]) {
      expect(publicUrlProblem(url), url).not.toBeNull();
      invalid(JSON.stringify({ type: "browser", url }), /public/);
    }
    for (const url of ["https://en.wikipedia.org/wiki/Osmosis", "http://example.com/page", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "https://8.8.8.8/"]) {
      expect(publicUrlProblem(url), url).toBeNull();
      valid(JSON.stringify({ type: "browser", url }));
    }
  });

  it("the scratchpad is gone from organize", () => {
    invalid('{"type":"organize","ops":[{"op":"move","kind":"scratch","id":"s1"}]}', /note or project/);
  });
});

describe("the prompt describes the tools that exist", () => {
  it("documents exactly the action types the validator accepts", async () => {
    const { TOOL_DOCS } = await import("./prompt");
    const documented = new Set([...TOOL_DOCS.matchAll(/\{"type":"([a-z_]+)"/g)].map((m) => m[1]));
    expect([...documented].sort()).toEqual([...ACTION_TYPES].sort());
    for (const t of ACTION_TYPES) expect(parse(`{"type":"${t}"}`)[0], t).not.toMatchObject({ reason: expect.stringMatching(/unknown action type/) });
  });

  it("never shows Leo the removed scratchpad, and says whether changes wait for approval", async () => {
    const { buildSystemPrompt } = await import("./prompt");
    await db.projects.add({ id: P, name: "Biology", tag: "", color: "ink", createdAt: 1, updatedAt: 1, placement: { status: "pending" }, scratchpad: "legacy scratch text" } as never);
    const project = (await db.projects.get(P))!;
    useSettings.setState({ alwaysApprove: false });
    const gated = await buildSystemPrompt(project, "ask");
    expect(gated).not.toMatch(/scratch/i);
    expect(gated).toMatch(/Approval: ON/);
    useSettings.setState({ alwaysApprove: true });
    expect(await buildSystemPrompt(project, "ask")).toMatch(/Approval: OFF/);
  });
});
