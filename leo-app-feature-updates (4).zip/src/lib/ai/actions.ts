import {
  db,
  uid,
  type ActionResult,
  type Concept,
  type ConceptStatus,
  type MemoryKind,
  type PointKind,
} from "../db";
import { useApp } from "../store";
// On-demand guides for Leo, bundled as raw strings so they work client-side. The markdown file is
// the Excalidraw MCP's read_me text, kept verbatim.
import excalidrawGuide from "./guides/excalidraw-readme.md";

const GUIDES: Record<string, string> = { excalidraw: excalidrawGuide };
import {
  isAvatarColor,
  isAvatarExpression,
  isAvatarShape,
  normalizeAvatarLook,
  type AvatarLook,
} from "../avatar";

/** One shape Leo may ask for. In a `sketch` action `from`/`to` are element indices; in an
 * `edit_sketch` "add" op they may also name an existing element ref such as "s3". */
export interface SketchElementSpec {
  type: "rectangle" | "ellipse" | "diamond" | "arrow" | "text";
  x: number;
  y: number;
  width?: number;
  height?: number;
  text?: string;
  color?: string;
  from?: number | string;
  to?: number | string;
}

/** A single change to an existing sketch. */
export interface SketchOp {
  op: "add" | "update" | "delete";
  /** Element ref from the sketch listing, e.g. "s3". */
  ref?: string;
  element?: SketchElementSpec;
}

export type Action =
  | { type: "ask"; question: string; options: string[] }
  | {
      type: "quiz";
      question: string;
      options: string[];
      answer: number;
      explanation?: string;
      concept?: string;
    }
  | { type: "set_level"; level: string; summary?: string; startingPoint?: string }
  | { type: "map"; concept: string; status?: ConceptStatus; parent?: string; note?: string }
  | { type: "point"; kind: PointKind; text: string }
  | { type: "resolve_point"; text: string }
  | { type: "set_avatar"; shape?: AvatarLook["shape"]; color?: AvatarLook["color"]; expression?: AvatarLook["expression"] }
  /** Grade an open-ended (typed) answer so it counts toward the map and review schedule. */
  | { type: "assess"; concept: string; correct: boolean; note?: string }
  | { type: "note"; id?: string; title: string; content: string; mode?: "append" | "replace" }
  | { type: "read"; kind: "note" | "sketch" | "guide"; id: string }
  | { type: "edit_sketch"; id: string; ops: SketchOp[] }
  | { type: "sketch"; title: string; elements: SketchElementSpec[] }
  | { type: "browser"; url: string }
  | { type: "memory"; op: "save" | "update" | "delete"; id?: string; scope?: "global" | "project"; kind?: MemoryKind; text?: string };

export type Segment =
  | { kind: "text"; text: string }
  | { kind: "action"; action: Action; index: number }
  /** A block the model emitted that we could not parse/validate. Shown to the learner and fed back to the model. */
  | { kind: "invalid"; raw: string; reason: string }
  | { kind: "pending"; hint?: string };

const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.length <= 8 && v.every((o) => typeof o === "string");

const BLOCK_RE = /```action[^\n]*\n([\s\S]*?)```/g;

function parseBody(body: string): { actions: Action[]; invalid: { raw: string; reason: string }[] } {
  const clean = body.trim();
  const out: unknown[] = [];
  const invalid: { raw: string; reason: string }[] = [];
  try {
    const j = JSON.parse(clean);
    if (Array.isArray(j)) out.push(...j);
    else out.push(j);
  } catch {
    for (const line of clean.split("\n")) {
      const l = line.trim().replace(/,$/, "");
      if (!l) continue;
      try {
        out.push(JSON.parse(l));
      } catch {
        invalid.push({ raw: l.slice(0, 200), reason: "not valid JSON" });
      }
    }
  }
  const actions: Action[] = [];
  for (const o of out) {
    if (isAction(o)) actions.push(o);
    else invalid.push({ raw: JSON.stringify(o).slice(0, 200), reason: `unknown or malformed action "${(o as { type?: string })?.type ?? "?"}"` });
  }
  return { actions, invalid };
}

/**
 * A shape spec Leo sent. `count` bounds numeric from/to indices when they refer to a sibling.
 * `partial` allows x/y to be omitted, for an update that only changes some fields.
 */
function isSketchElementSpec(v: Record<string, unknown>, count?: number, partial = false): boolean {
  const indexOk = (x: unknown) =>
    typeof x !== "number" || (Number.isInteger(x) && x >= 0 && (count === undefined || x < count));
  const coord = (x: unknown) => partial || (typeof x === "number" && Number.isFinite(x) && Math.abs(x) <= 2000);
  return (
    ["rectangle", "ellipse", "diamond", "arrow", "text"].includes(v.type as string) &&
    coord(v.x) &&
    coord(v.y) &&
    (v.width === undefined || (typeof v.width === "number" && v.width >= 0 && v.width <= 1200)) &&
    (v.height === undefined || (typeof v.height === "number" && v.height >= 0 && v.height <= 900)) &&
    (v.text === undefined || (typeof v.text === "string" && v.text.length <= 300)) &&
    (v.color === undefined || (typeof v.color === "string" && /^#[0-9a-f]{6}$/i.test(v.color))) &&
    (v.from === undefined || typeof v.from === "number" || typeof v.from === "string") &&
    (v.to === undefined || typeof v.to === "number" || typeof v.to === "string") &&
    indexOk(v.from) &&
    indexOk(v.to)
  );
}

function isAction(a: unknown): a is Action {
  if (!a || typeof a !== "object") return false;
  const o = a as Record<string, unknown>;
  switch (o.type) {
    case "ask":
      return typeof o.question === "string" && isStringArray(o.options);
    case "quiz":
      return (
        typeof o.question === "string" &&
        isStringArray(o.options) &&
        typeof o.answer === "number" &&
        Number.isInteger(o.answer) &&
        o.answer >= 0 &&
        o.answer < (o.options as string[]).length
      );
    case "assess":
      return typeof o.concept === "string" && typeof o.correct === "boolean";
    case "set_level":
      return typeof o.level === "string";
    case "map":
      return typeof o.concept === "string";
    case "point":
      return typeof o.text === "string" && ["careful", "confused", "next"].includes(o.kind as string);
    case "resolve_point":
      return typeof o.text === "string";
    case "set_avatar":
      return (
        (o.shape === undefined || isAvatarShape(o.shape)) &&
        (o.color === undefined || isAvatarColor(o.color)) &&
        (o.expression === undefined || isAvatarExpression(o.expression)) &&
        (o.shape !== undefined || o.color !== undefined || o.expression !== undefined)
      );
    case "note":
      return (
        typeof o.content === "string" &&
        typeof (o.title ?? "") === "string" &&
        (o.id === undefined || typeof o.id === "string") &&
        (o.mode === undefined || ["append", "replace"].includes(o.mode as string))
      );
    case "read":
      return (o.kind === "note" || o.kind === "sketch" || o.kind === "guide") && typeof o.id === "string" && !!o.id && o.id.length <= 64;
    case "edit_sketch":
      return (
        typeof o.id === "string" &&
        !!o.id &&
        Array.isArray(o.ops) &&
        o.ops.length > 0 &&
        o.ops.length <= 40 &&
        o.ops.every((p: unknown) => {
          if (!p || typeof p !== "object") return false;
          const v = p as Record<string, unknown>;
          if (v.ref !== undefined && !(typeof v.ref === "string" && /^s\d{1,4}$/.test(v.ref))) return false;
          if (v.op === "add") return !!v.element && typeof v.element === "object" && isSketchElementSpec(v.element as Record<string, unknown>);
          if (v.op === "update")
            return typeof v.ref === "string" && (v.element === undefined || isSketchElementSpec(v.element as Record<string, unknown>, undefined, true));
          if (v.op === "delete") return typeof v.ref === "string";
          return false;
        })
      );
    case "sketch":
      return (
        typeof o.title === "string" &&
        Array.isArray(o.elements) &&
        o.elements.length > 0 &&
        o.elements.length <= 40 &&
        o.elements.every((e: unknown) => !!e && typeof e === "object" && isSketchElementSpec(e as Record<string, unknown>, (o.elements as unknown[]).length))
      );
    case "browser":
      return typeof o.url === "string" && o.url.length <= 2048;
    case "memory":
      return (
        ["save", "update", "delete"].includes(o.op as string) &&
        (o.scope === undefined || ["global", "project"].includes(o.scope as string)) &&
        (o.kind === undefined || ["level", "goal", "preference", "strength", "weakness", "fact"].includes(o.kind as string)) &&
        (o.text === undefined || (typeof o.text === "string" && o.text.length <= 500)) &&
        (o.id === undefined || typeof o.id === "string")
      );
    default:
      return false;
  }
}

/** What Leo is doing, read from the part of an action block that has streamed so far. */
export function actionHint(partial: string): string {
  const type = /"type"\s*:\s*"([a-z_]+)"/.exec(partial)?.[1];
  if (!type) return "Working\u2026";
  const field = (name: string) => {
    const m = new RegExp(`"${name}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(partial);
    return m?.[1];
  };
  switch (type) {
    case "sketch": {
      const title = field("title")?.trim();
      return title ? `Drawing \u201c${title}\u201d\u2026` : "Drawing a sketch\u2026";
    }
    case "edit_sketch":
      return "Editing the sketch\u2026";
    case "note":
      return /"mode"\s*:\s*"append"/.test(partial) ? "Adding to a note\u2026" : "Writing a note\u2026";
    case "read": {
      const kind = field("kind");
      if (kind === "guide") return "Reading the Excalidraw guide\u2026";
      if (kind === "sketch") return "Reading a sketch\u2026";
      if (kind === "note") return "Reading a note\u2026";
      return "Reading\u2026";
    }
    case "browser":
      return "Opening the browser\u2026";
    case "memory":
      return "Saving a memory\u2026";
    case "set_level":
    case "map":
    case "assess":
    case "point":
    case "resolve_point":
      return "Updating your learning map\u2026";
    case "ask":
    case "quiz":
      return "Preparing a question\u2026";
    case "set_avatar":
      return "Updating Leo\u2019s look\u2026";
    default:
      return "Working\u2026";
  }
}

/** The descriptive label for the action currently streaming, if a block is still open. */
export function progressHint(content: string): string | null {
  const segs = parseSegments(content, true);
  for (let i = segs.length - 1; i >= 0; i--) {
    const s = segs[i];
    if (s.kind === "pending") return s.hint ?? null;
  }
  return null;
}

export function parseSegments(content: string, streaming = false): Segment[] {
  // Safety net: some models print a single action object with no fence. A message that is exactly
  // one valid action is treated as that action.
  const bare = content.trim();
  if (!content.includes("```") && bare.startsWith("{") && bare.endsWith("}")) {
    try {
      const one: unknown = JSON.parse(bare);
      if (isAction(one)) return [{ kind: "action", action: one, index: 0 }];
    } catch {
      /* still streaming, or not JSON at all */
    }
  }
  const segs: Segment[] = [];
  let last = 0;
  let idx = 0;
  let m: RegExpExecArray | null;
  BLOCK_RE.lastIndex = 0;
  while ((m = BLOCK_RE.exec(content))) {
    const before = content.slice(last, m.index);
    if (before.trim()) segs.push({ kind: "text", text: before });
    const { actions, invalid } = parseBody(m[1]);
    for (const a of actions) segs.push({ kind: "action", action: a, index: idx++ });
    for (const inv of invalid) segs.push({ kind: "invalid", ...inv });
    last = m.index + m[0].length;
  }
  let rest = content.slice(last);
  const open = rest.indexOf("```action");
  if (open >= 0) {
    const before = rest.slice(0, open);
    if (before.trim()) segs.push({ kind: "text", text: before });
    if (streaming) segs.push({ kind: "pending", hint: actionHint(rest.slice(open)) });
    else segs.push({ kind: "invalid", raw: rest.slice(open, open + 200), reason: "action block was cut off" });
  } else {
    if (streaming) rest = rest.replace(/`{1,3}[a-z]{0,6}$/, "");
    if (rest.trim()) segs.push({ kind: "text", text: rest });
  }
  return segs;
}

export function extractActions(content: string): Action[] {
  return parseSegments(content)
    .filter((s): s is Extract<Segment, { kind: "action" }> => s.kind === "action")
    .map((s) => s.action);
}

/** Problems the model should hear about on its next turn. */
export function invalidActionFeedback(content: string): string | null {
  const bad = parseSegments(content).filter((s): s is Extract<Segment, { kind: "invalid" }> => s.kind === "invalid");
  if (!bad.length) return null;
  return `Note: ${bad.length} of your action blocks could not be executed (${bad.map((b) => b.reason).join("; ")}). Re-emit them as valid JSON if they still matter.`;
}

/** Strip action blocks for plain-text uses (thread titles, history summaries). */
export function stripActions(content: string) {
  return content.replace(BLOCK_RE, "").trim();
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

export async function findConcept(projectId: string, name: string) {
  const all = await db.concepts.where("projectId").equals(projectId).toArray();
  return all.find((c) => norm(c.name) === norm(name));
}

export async function upsertConcept(
  projectId: string,
  name: string,
  patch: Partial<Pick<Concept, "status" | "note">> = {},
  parentName?: string
): Promise<Concept> {
  const now = Date.now();
  let parentId: string | undefined;
  if (parentName && norm(parentName) !== norm(name)) {
    const parent = await upsertConcept(projectId, parentName);
    parentId = parent.id;
  }
  const existing = await findConcept(projectId, name);
  if (existing) {
    const upd: Partial<Concept> = { updatedAt: now };
    if (patch.status) upd.status = patch.status;
    if (patch.note) upd.note = patch.note;
    if (parentId && parentId !== existing.id) upd.parentId = parentId;
    await db.concepts.update(existing.id, upd);
    return { ...existing, ...upd };
  }
  const c: Concept = {
    id: uid(),
    projectId,
    name: name.trim().slice(0, 80),
    parentId,
    status: patch.status ?? "new",
    note: patch.note,
    correct: 0,
    attempts: 0,
    createdAt: now,
    updatedAt: now,
  };
  await db.concepts.add(c);
  return c;
}

const DAY = 86_400_000;

/** Record one graded outcome: stats, recent window, status and a simple spaced-review schedule. */
export async function recordQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await upsertConcept(projectId, conceptName);
  const fresh = (await db.concepts.get(c.id))!;
  let status = fresh.status;
  if (correct && status === "new") status = "learning";
  if (!correct && status === "solid") status = "shaky";
  const recent = [...(fresh.recent ?? []), correct ? 1 : 0].slice(-10);
  // Two consecutive correct answers on a learning concept earn "solid".
  if (correct && status === "learning" && recent.length >= 2 && recent.slice(-2).every((r) => r === 1)) status = "solid";
  const prev = fresh.interval ?? 0;
  const interval = correct ? Math.min(60, prev === 0 ? 1 : Math.round(prev * 2.2 * 10) / 10) : 0.5;
  const now = Date.now();
  await db.concepts.update(c.id, {
    attempts: fresh.attempts + 1,
    correct: fresh.correct + (correct ? 1 : 0),
    recent,
    status,
    interval,
    lastReviewed: now,
    nextReview: now + interval * DAY,
    updatedAt: now,
  });
}

/** Undo one graded outcome (learner disputed the answer key). */
export async function revertQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await findConcept(projectId, conceptName);
  if (!c || c.attempts === 0) return;
  const recent = [...(c.recent ?? [])];
  const idx = recent.lastIndexOf(correct ? 1 : 0);
  if (idx >= 0) recent.splice(idx, 1);
  await db.concepts.update(c.id, {
    attempts: c.attempts - 1,
    correct: Math.max(0, c.correct - (correct ? 1 : 0)),
    recent,
    updatedAt: Date.now(),
  });
}

export async function addPoint(projectId: string, kind: PointKind, text: string, author: "user" | "ai") {
  const t = text.trim();
  if (!t) return false;
  const existing = await db.points.where("projectId").equals(projectId).toArray();
  if (existing.some((p) => !p.done && norm(p.text) === norm(t))) return false;
  await db.points.add({ id: uid(), projectId, kind, text: t, author, done: false, createdAt: Date.now() });
  return true;
}

/* ------------------------------------------------------------- sketch refs */

interface SketchEl {
  id: string;
  type: string;
  x: number;
  y: number;
  width: number;
  height: number;
  isDeleted?: boolean;
  version?: number;
  versionNonce?: number;
  text?: string;
  backgroundColor?: string;
  strokeColor?: string;
  /** Set for the text element a shape or arrow uses as its label. */
  containerId?: string;
  customData?: Record<string, unknown> | null;
  startBinding?: { elementId?: string } | null;
  endBinding?: { elementId?: string } | null;
}

const refOf = (e: SketchEl) => (typeof e.customData?.ref === "string" ? (e.customData.ref as string) : null);

/** Give every live element the next free ref (s1, s2, …). Mutates customData in place. */
function assignRefs(elements: SketchEl[]): Map<string, string> {
  const live = elements.filter((e) => !e.isDeleted);
  const used = new Set(live.map(refOf).filter((r): r is string => !!r));
  const byId = new Map<string, string>();
  let n = 1;
  for (const e of live) {
    let ref = refOf(e);
    if (!ref) {
      while (used.has(`s${n}`)) n++;
      ref = `s${n}`;
      used.add(ref);
      e.customData = { ...(e.customData ?? {}), ref };
    }
    byId.set(e.id, ref);
  }
  return byId;
}

/** Excalidraw needs a new version + nonce before it will repaint a mutated element. */
function bump(e: SketchEl) {
  e.version = (e.version ?? 1) + 1;
  e.versionNonce = Math.floor(Math.random() * 2 ** 31);
}

const r1 = (n: number) => Math.round(Number.isFinite(n) ? n : 0);

const isShape = (t: string) => t === "rectangle" || t === "ellipse" || t === "diamond";

/**
 * The Excalidraw skeleton for one shape spec, carrying its ref in customData. `idFor` resolves
 * an arrow's from/to (an element index in a `sketch`, or an existing ref in an `edit_sketch` add)
 * to the id the arrow should bind to.
 */
function skeletonOf(
  e: SketchElementSpec,
  ref: string,
  idFor: (from: number | string | undefined) => string | undefined,
  id?: string
) {
  if (e.type === "text") return { type: "text", x: e.x, y: e.y, text: e.text || "", customData: { ref } };
  if (e.type === "arrow") {
    const start = idFor(e.from);
    const end = idFor(e.to);
    return {
      type: "arrow",
      x: e.x,
      y: e.y,
      width: e.width ?? 100,
      height: e.height ?? 0,
      customData: { ref },
      ...(start ? { start: { id: start } } : {}),
      ...(end ? { end: { id: end } } : {}),
    };
  }
  return {
    ...(id ? { id } : {}),
    type: e.type,
    x: e.x,
    y: e.y,
    width: e.width ?? 140,
    height: e.height ?? 72,
    strokeColor: "#17171a",
    backgroundColor: e.color ?? "#e3ecfe",
    fillStyle: "solid",
    strokeWidth: 2,
    roughness: 0,
    customData: { ref },
    ...(e.text ? { label: { text: e.text } } : {}),
  };
}

/**
 * One line per element with its stable ref, e.g. `s3 rectangle 100 40 140 72 #e3ecfe "Label"`
 * and `s7 arrow s3→s4`. Refs live in element.customData.ref and are assigned in element order
 * when missing, so they stay stable between reads and edits.
 */
export function describeSketch(scene: string): string {
  let elements: SketchEl[] = [];
  try {
    elements = (JSON.parse(scene || "{}").elements ?? []) as SketchEl[];
  } catch {
    return "(this sketch could not be read)";
  }
  if (!Array.isArray(elements) || !elements.length) return "(empty sketch)";
  const byId = assignRefs(elements);
  const labelOf = new Map<string, string>();
  for (const e of elements) if (e.containerId && typeof e.text === "string") labelOf.set(e.containerId, e.text);
  const lines = elements
    .filter((e) => !e.isDeleted)
    .map((e) => {
      const ref = byId.get(e.id) ?? "?";
      const label = e.type === "text" ? e.text : labelOf.get(e.id);
      if (e.type === "arrow" || e.type === "line") {
        const from = e.startBinding?.elementId ? byId.get(e.startBinding.elementId) : undefined;
        const to = e.endBinding?.elementId ? byId.get(e.endBinding.elementId) : undefined;
        const ends = from && to ? `${from}→${to}` : `${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}`;
        return `${ref} arrow ${ends}${label ? ` "${label}"` : ""}`;
      }
      const fill = e.backgroundColor && e.backgroundColor !== "transparent" ? ` ${e.backgroundColor}` : "";
      return `${ref} ${e.type} ${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}${fill}${label ? ` "${label}"` : ""}`;
    });
  return lines.length ? lines.join("\n") : "(empty sketch)";
}

/** What a turn's actions produced: chips for the learner, plus material for the model's next step. */
export interface ExecutionReport {
  results: ActionResult[];
  /** One entry per `read`: the item's contents, fed back to the model as <action_results>. */
  read: string[];
}

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n)}\n…[truncated]` : s);

export async function executeActions(
  projectId: string,
  threadId: string,
  actions: Action[]
): Promise<ExecutionReport> {
  const results: ActionResult[] = [];
  const read: string[] = [];
  for (const a of actions) {
    try {
      switch (a.type) {
        case "set_level": {
          // Gate: placement needs evidence. Count answered ask/quiz cards in this thread.
          const project = await db.projects.get(projectId);
          if (project?.placement.status !== "done") {
            const msgs = await db.messages.where("threadId").equals(threadId).toArray();
            const answered = msgs.reduce((n, m) => n + Object.keys(m.answers ?? {}).length, 0);
            if (answered < 3) {
              results.push({ type: a.type, label: `Level not set yet — only ${answered} answered question(s); ask at least 3`, ok: false });
              break;
            }
          }
          await db.projects.update(projectId, {
            placement: {
              status: "done",
              level: a.level,
              summary: a.summary,
              startingPoint: a.startingPoint,
              at: Date.now(),
            },
            updatedAt: Date.now(),
          });
          await db.threads.update(threadId, { mode: "ask" });
          results.push({ type: a.type, label: `Level set: ${a.level}`, ok: true });
          break;
        }
        case "map": {
          const status = (["new", "learning", "shaky", "solid"] as const).includes(a.status as ConceptStatus)
            ? a.status
            : undefined;
          await upsertConcept(projectId, a.concept, { status, note: a.note }, a.parent);
          results.push({
            type: a.type,
            label: `${a.concept}${status ? ` → ${status}` : ""}`,
            ok: true,
          });
          break;
        }
        case "point": {
          const ok = await addPoint(projectId, a.kind, a.text, "ai");
          if (ok) results.push({ type: a.type, label: a.text, ok: true });
          break;
        }
        case "resolve_point": {
          const pts = await db.points.where("projectId").equals(projectId).toArray();
          const target = pts.find((p) => !p.done && norm(p.text) === norm(a.text));
          if (target) {
            await db.points.update(target.id, { done: true, resolvedBy: "ai" });
            results.push({ type: a.type, label: target.text, ok: true });
          } else {
            results.push({ type: a.type, label: `No open point matches “${a.text}” exactly`, ok: false });
          }
          break;
        }
        case "assess": {
          await recordQuizResult(projectId, a.concept, a.correct);
          if (a.note) await upsertConcept(projectId, a.concept, { note: a.note });
          results.push({ type: a.type, label: `${a.concept}: ${a.correct ? "correct" : "needs work"}`, ok: true });
          break;
        }
        case "set_avatar": {
          const project = await db.projects.get(projectId);
          if (!project) break;
          const current = normalizeAvatarLook(project.avatar);
          const look = normalizeAvatarLook({ ...current, ...a }, current);
          await db.projects.update(projectId, { avatar: look, updatedAt: Date.now() });
          results.push({ type: a.type, label: `${look.shape} · ${look.color} · ${look.expression}`, ok: true });
          break;
        }
        case "note": {
          const now = Date.now();
          if (a.id) {
            const existing = await db.notes.get(a.id);
            if (!existing || existing.projectId !== projectId) {
              results.push({ type: a.type, label: "Note not found in this project", ok: false });
              break;
            }
            const mode = a.mode ?? "replace";
            const content =
              mode === "append"
                ? `${existing.content.trimEnd()}${existing.content.trim() ? "\n\n" : ""}${a.content}`
                : a.content;
            await db.notes.update(a.id, {
              title: a.title?.trim() || existing.title,
              content,
              // Keep what was there so a replace can be undone.
              previousContent: mode === "replace" ? existing.content : existing.previousContent,
              author: "ai",
              updatedAt: now,
            });
            const updated = await db.notes.get(a.id);
            if (updated) {
              const { indexNote } = await import("../retrieval");
              await indexNote(updated);
            }
            results.push({ type: a.type, label: `${mode === "append" ? "Appended to" : "Updated"} note · ${a.title || existing.title}`, ok: true });
          } else {
            const id = uid();
            await db.notes.add({ id, projectId, title: a.title?.trim() || "Leo's note", content: a.content, author: "ai", createdAt: now, updatedAt: now });
            const created = await db.notes.get(id);
            if (created) {
              const { indexNote } = await import("../retrieval");
              await indexNote(created);
            }
            results.push({ type: a.type, label: `Created note · ${a.title || "Leo's note"}`, ok: true });
          }
          break;
        }
        case "read": {
          if (a.kind === "guide") {
            const guide = GUIDES[a.id];
            if (!guide) {
              results.push({ type: a.type, label: `No guide called "${a.id}" — the only guide is "excalidraw"`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read guide · ${a.id}`, ok: true });
            // The full text, unclipped: it rides the same <action_results> path notes and sketches use.
            read.push(`## Guide "${a.id}"\n${guide}`);
            break;
          }
          if (a.kind === "note") {
            const n = await db.notes.get(a.id);
            if (!n || n.projectId !== projectId) {
              results.push({ type: a.type, label: `Note ${a.id} not found in this project`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read note · ${n.title}`, ok: true });
            read.push(`## Note "${n.title}" (id=${n.id})\n${clip(n.content, 12000) || "(empty)"}`);
          } else {
            const s = await db.sketches.get(a.id);
            if (!s || s.projectId !== projectId) {
              results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read sketch · ${s.title}`, ok: true });
            read.push(`## Sketch "${s.title}" (id=${s.id}) — one line per element: ref type x y w h fill "label"\n${describeSketch(s.scene)}`);
          }
          break;
        }
        case "edit_sketch": {
          const existing = await db.sketches.get(a.id);
          if (!existing || existing.projectId !== projectId) {
            results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
            break;
          }
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          let parsed: { elements?: unknown; appState?: unknown; files?: unknown } = {};
          try {
            parsed = JSON.parse(existing.scene || "{}");
          } catch {
            parsed = {};
          }
          const elements = (Array.isArray(parsed.elements) ? parsed.elements : []) as SketchEl[];
          const byId = assignRefs(elements);
          const byRef = new Map<string, SketchEl>();
          for (const e of elements) if (!e.isDeleted) {
            const r = byId.get(e.id);
            if (r) byRef.set(r, e);
          }
          const freeRef = () => {
            let n = byRef.size + 1;
            while (byRef.has(`s${n}`)) n++;
            return `s${n}`;
          };
          const problems: string[] = [];
          let added = 0;
          let updated = 0;
          let deleted = 0;
          for (const op of a.ops) {
            const target = op.ref ? byRef.get(op.ref) : undefined;
            if (op.ref && !target) {
              problems.push(`no element ${op.ref}`);
              continue;
            }
            if (op.op === "add") {
              const spec = op.element;
              if (!spec) {
                problems.push("add needs an element");
                continue;
              }
              const ref = freeRef();
              const made = convertToExcalidrawElements(
                [skeletonOf(spec, ref, (f) => (typeof f === "string" ? byRef.get(f)?.id : undefined)) as never],
                { regenerateIds: true }
              )[0] as SketchEl | undefined;
              if (!made) {
                problems.push(`could not add a ${spec.type}`);
                continue;
              }
              elements.push(made);
              byRef.set(ref, made);
              added++;
            } else if (op.op === "update" && target) {
              const spec = op.element;
              if (spec) {
                if (typeof spec.x === "number") target.x = spec.x;
                if (typeof spec.y === "number") target.y = spec.y;
                if (typeof spec.width === "number") target.width = spec.width;
                if (typeof spec.height === "number") target.height = spec.height;
                if (typeof spec.color === "string") {
                  if (target.type === "rectangle" || target.type === "ellipse" || target.type === "diamond") target.backgroundColor = spec.color;
                  else target.strokeColor = spec.color;
                }
                if (typeof spec.text === "string") {
                  if (target.type === "text") target.text = spec.text;
                  else {
                    const label = elements.find((e) => e.containerId === target.id && !e.isDeleted);
                    if (label) {
                      label.text = spec.text;
                      bump(label);
                    } else problems.push(`${op.ref} has no label to change`);
                  }
                }
              }
              bump(target);
              updated++;
            } else if (op.op === "delete" && target) {
              target.isDeleted = true;
              bump(target);
              const label = elements.find((e) => e.containerId === target.id);
              if (label) {
                label.isDeleted = true;
                bump(label);
              }
              for (const e of elements) if (e.startBinding?.elementId === target.id || e.endBinding?.elementId === target.id) bump(e);
              deleted++;
            }
          }
          const scene = serializeAsJSON(elements as never, (parsed.appState ?? { viewBackgroundColor: "#ffffff" }) as never, (parsed.files ?? {}) as never, "local");
          await db.sketches.update(a.id, { scene, updatedAt: Date.now() });
          const api = useApp.getState().sketchApi;
          if (api && api.sketchId === a.id) api.updateScene({ elements });
          results.push({
            type: a.type,
            label: `Sketch · ${added} added, ${updated} updated, ${deleted} deleted${problems.length ? ` — ${problems.join("; ")}` : ""}`,
            ok: problems.length === 0,
          });
          break;
        }
        case "sketch": {
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          const skeleton = a.elements.map((e, i) =>
            skeletonOf(
              e,
              `s${i + 1}`,
              (f) => {
                const t = typeof f === "number" ? a.elements[f] : undefined;
                return t && (t.type === "rectangle" || t.type === "ellipse" || t.type === "diamond") ? `shape-${f}` : undefined;
              },
              e.type === "rectangle" || e.type === "ellipse" || e.type === "diamond" ? `shape-${i}` : undefined
            )
          );
          const elements = convertToExcalidrawElements(skeleton as never, { regenerateIds: true });
          const scene = serializeAsJSON(elements, { viewBackgroundColor: "#ffffff", gridSize: 20 } as never, {} as never, "local");
          const now = Date.now();
          const id = uid();
          await db.sketches.add({ id, projectId, title: a.title.trim() || "Leo's sketch", scene, createdAt: now, updatedAt: now });
          results.push({ type: a.type, label: `Created sketch · ${a.title || "Untitled"}`, ok: true });
          break;
        }
        case "browser": {
          let url: URL;
          try {
            url = new URL(a.url);
          } catch {
            throw new Error("Invalid URL");
          }
          if (!["http:", "https:"].includes(url.protocol)) throw new Error("Leo can only open http and https pages");
          useApp.getState().setBrowserUrl(url.href);
          useApp.getState().setBrowserOpen(true);
          useApp.getState().setChatOpen(false);
          results.push({ type: a.type, label: `Opened browser · ${url.hostname}`, ok: true });
          break;
        }
        case "memory": {
          if (a.op === "delete") {
            if (!a.id) throw new Error("Memory delete needs an id");
            const existing = await db.memories.get(a.id);
            if (existing && (existing.projectId === projectId || existing.projectId === "*")) await db.memories.delete(a.id);
            results.push({ type: a.type, label: existing ? "Forgot that memory" : "Memory not found", ok: !!existing });
            break;
          }
          if (!a.text?.trim() || !a.kind) throw new Error("Memory save needs a kind and text");
          const scopeId = a.scope === "project" ? projectId : "*";
          const now = Date.now();
          if (a.op === "update" && a.id) {
            const existing = await db.memories.get(a.id);
            if (!existing || (existing.projectId !== projectId && existing.projectId !== "*")) throw new Error("Memory not found");
            await db.memories.update(a.id, { projectId: scopeId, kind: a.kind, text: a.text.trim(), updatedAt: now });
            results.push({ type: a.type, label: `Updated memory · ${a.kind}`, ok: true });
          } else {
            const all = await db.memories.where("projectId").equals(scopeId).toArray();
            const duplicate = all.find((m) => m.kind === a.kind && norm(m.text) === norm(a.text!));
            if (duplicate) {
              await db.memories.update(duplicate.id, { text: a.text.trim(), updatedAt: now });
              results.push({ type: a.type, label: `Updated memory · ${a.kind}`, ok: true });
            } else {
              await db.memories.add({ id: uid(), projectId: scopeId, kind: a.kind, text: a.text.trim(), createdAt: now, updatedAt: now });
              results.push({ type: a.type, label: `Remembered · ${a.kind}`, ok: true });
            }
          }
          break;
        }
        default:
          break;
      }
    } catch (e) {
      results.push({ type: a.type, label: String(e), ok: false });
    }
  }
  return { results, read };
}
