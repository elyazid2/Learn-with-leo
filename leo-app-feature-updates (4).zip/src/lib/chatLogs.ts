import { db, type Message, type Thread } from "./db";

/**
 * Chat logs export: exactly what the model saw and did — visible and hidden messages,
 * raw content (action blocks included), apiContent, action results, answers and context tags.
 * Images and audio are replaced with a placeholder, and provider settings/API keys never appear.
 */

const IMAGE_PLACEHOLDER = "[image omitted]";
const AUDIO_PLACEHOLDER = "[audio omitted]";

/** Defensive: strip any inline base64 data URL that made it into a text field. */
function scrub(text: string) {
  return text.replace(/data:[a-z0-9.+-]+\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]+/gi, "[base64 data omitted]");
}

export interface ChatLogMessage {
  role: Message["role"];
  createdAt: number;
  hidden: boolean;
  error: boolean;
  partial: boolean;
  content: string;
  apiContent?: string;
  actionResults?: Message["actionResults"];
  answers?: Message["answers"];
  context?: Message["context"];
  images?: string[];
  audios?: string[];
}

export interface ChatLogThread {
  id: string;
  title: string;
  mode: Thread["mode"];
  providerId?: string;
  model?: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatLogMessage[];
}

export interface ChatLogsFile {
  app: "harness";
  kind: "chat-logs";
  exportedAt: number;
  scope: "last" | "all";
  threads: ChatLogThread[];
}

function messageLog(m: Message): ChatLogMessage {
  return {
    role: m.role,
    createdAt: m.createdAt,
    hidden: !!m.hidden,
    error: !!m.error,
    partial: !!m.partial,
    content: scrub(m.content),
    ...(m.apiContent !== undefined ? { apiContent: scrub(m.apiContent) } : {}),
    ...(m.actionResults ? { actionResults: m.actionResults } : {}),
    ...(m.answers ? { answers: m.answers } : {}),
    ...(m.context ? { context: m.context } : {}),
    ...(m.images?.length ? { images: m.images.map(() => IMAGE_PLACEHOLDER) } : {}),
    ...(m.audios?.length ? { audios: m.audios.map(() => AUDIO_PLACEHOLDER) } : {}),
  };
}

/** "last" is the most recently updated conversation; "all" is every thread, newest first. */
export async function buildChatLogs(scope: "last" | "all"): Promise<ChatLogsFile> {
  const threads = await db.threads.orderBy("updatedAt").toArray();
  const chosen = scope === "last" ? threads.slice(-1) : threads.slice().reverse();
  const out: ChatLogThread[] = [];
  for (const t of chosen) {
    const messages = await db.messages.where("threadId").equals(t.id).sortBy("createdAt");
    out.push({
      id: t.id,
      title: t.title,
      mode: t.mode,
      providerId: t.providerId,
      model: t.model,
      createdAt: t.createdAt,
      updatedAt: t.updatedAt,
      messages: messages.map(messageLog),
    });
  }
  return { app: "harness", kind: "chat-logs", exportedAt: Date.now(), scope, threads: out };
}

export const chatLogsFilename = () => `harness-chat-logs-${new Date().toISOString().slice(0, 10)}.json`;
