import { useState } from "react";
import { Download } from "lucide-react";
import { download } from "@/lib/backup";
import { buildChatLogs, chatLogsFilename } from "@/lib/chatLogs";
import { useApp } from "@/lib/store";
import { Button, Field, Segmented } from "@/components/ui";

/**
 * Chat logs for debugging Leo: exactly what the model saw and did, including hidden action
 * results and guide text. Images/audio become placeholders; API keys and provider settings
 * are never part of this export.
 */
export default function ChatLogsSection() {
  const showToast = useApp((s) => s.showToast);
  const [scope, setScope] = useState<"last" | "all">("last");
  const [busy, setBusy] = useState(false);

  const doExport = async () => {
    setBusy(true);
    try {
      const data = await buildChatLogs(scope);
      if (!data.threads.length) {
        showToast("No chats to export yet");
        return;
      }
      download(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }), chatLogsFilename());
      showToast(`Exported ${data.threads.length} chat${data.threads.length === 1 ? "" : "s"}`);
    } catch (e) {
      showToast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="mt-10">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">Chat logs</h2>
      <div className="space-y-3 rounded-2xl bg-card p-4 ring-1 ring-line">
        <p className="text-[13px] leading-relaxed text-muted">
          Every message in order, including hidden action results and guide text — exactly what the model saw and did. Images and audio are replaced with a
          placeholder; API keys and provider settings are never included.
        </p>
        <Field label="Which chats">
          <Segmented<"last" | "all">
            className="flex w-full [&>button]:flex-1 [&>button]:py-2"
            value={scope}
            onChange={setScope}
            options={[
              { value: "last", label: "Last chat" },
              { value: "all", label: "All chats" },
            ]}
          />
        </Field>
        <Button variant="soft" onClick={() => void doExport()} disabled={busy}>
          <Download size={15} /> Export chat logs
        </Button>
      </div>
    </section>
  );
}
