#!/usr/bin/env bash
# Build Learn with Leo with its own, unchanged toolchain (leo/package.json → vite build → one
# self-contained index.html) and publish the result for the Next.js shell to serve at "/".
set -euo pipefail
cd "$(dirname "$0")/../leo"
[ -d node_modules ] || npm install --no-audit --no-fund
npm run build
mkdir -p ../leo-dist
cp dist/index.html ../leo-dist/index.html
echo "leo-dist/index.html updated ($(du -h ../leo-dist/index.html | cut -f1))"
