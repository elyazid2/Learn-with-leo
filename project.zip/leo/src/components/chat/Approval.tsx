import { useEffect, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { AlertTriangle, Check, FolderTree, Pencil, Trash2, Wrench, X } from "lucide-react";
import { db, type Message, type Note, type PendingAction } from "@/lib/db";
import { applyPatches, noteTarget, type Action } from "@/lib/ai/actions";
import { describeOrganize } from "@/lib/organize";
import { resolvePending } from "@/lib/chat";
import { TOOL_META } from "@/lib/tools";
import { cn } from "@/utils/cn";

type NoteAction = Extract<Action, { type: "note" }>;

/** Lines that appear on only one side, so the preview can mark what changed. */
function changedLines(a: string, b: string) {
  const left = new Set(a.split("\n"));
  const right = new Set(b.split("\n"));
  return { removed: (l: string) => !right.has(l) && l.trim() !== "", added: (l: string) => !left.has(l) && l.trim() !== "" };
}

function TextColumn({ label, text, mark, tone, empty = "(empty — new note)" }: { label: string; text: string; mark: (l: string) => boolean; tone: "old" | "new"; empty?: string }) {
  return (
    <div className="min-w-0">
      <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">{label}</div>
      <div className="max-h-64 overflow-auto rounded-xl bg-card p-2 font-mono text-[12px] leading-relaxed ring-1 ring-line" dir="auto">
        {text ? (
          text.split("\n").map((l, i) => (
            <div
              key={i}
              className={cn(
                "whitespace-pre-wrap break-words px-1",
                mark(l) && (tone === "old" ? "bg-danger-bg text-danger-fg line-through decoration-danger-fg/40" : "bg-[#16a07222] text-ink")
              )}
            >
              {l || "\u00a0"}
            </div>
          ))
        ) : (
          <div className="px-1 italic text-muted">{empty}</div>
        )}
      </div>
    </div>
  );
}

/**
 * Old vs new for a proposed note change, with optional editing before accepting. `existing` is the
 * note Apply will change, found the same way the executor finds it: so a "create" that reuses a
 * note of the same title shows that note's text as Old, not an empty page.
 */
function NotePreview({ action, existing, editable, draft, onDraft }: { action: NoteAction; existing: Note | null | undefined; editable: boolean; draft: string | null; onDraft: (v: string | null) => void }) {
  const before = existing?.content ?? "";
  const proposed = useMemo(() => {
    const written = action.content ?? "";
    if (!existing) return written;
    // Reusing a same-title note: Leo's own note is rewritten, the learner's gets the new text added.
    if (!action.id) return existing.author === "ai" ? written : `${before.trimEnd()}\n\n${written}`;
    const mode = action.mode ?? "append";
    if (mode === "append") return `${before.trimEnd()}${before.trim() ? "\n\n" : ""}${written}`;
    if (mode === "patch") {
      const r = applyPatches(before, action.patches ?? []);
      return "error" in r ? null : r.content;
    }
    return written;
  }, [action, existing, before]);
  if (existing === undefined) return <div className="h-16 animate-pulse rounded-xl bg-ink/[0.04]" />;
  if (proposed === null) return <p className="text-[12px]">This edit no longer matches the note (it changed since Leo read it). Dismiss it and ask Leo again.</p>;
  const after = draft ?? proposed;
  const marks = changedLines(before, after);
  return (
    <div className="space-y-2">
      <div className="grid gap-2 sm:grid-cols-2">
        <TextColumn label={existing ? "Old" : "Old (none)"} text={before} mark={marks.removed} tone="old" empty={existing ? "(empty)" : undefined} />
        {editable && draft !== null ? (
          <div className="min-w-0">
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">New (editing)</div>
            <textarea
              value={draft}
              onChange={(e) => onDraft(e.target.value)}
              rows={10}
              dir="auto"
              aria-label="Edit the proposed note text"
              className="h-64 w-full resize-y rounded-xl bg-card p-2 font-mono text-[12px] leading-relaxed text-ink outline-none ring-1 ring-ink/25 focus:ring-ink/50"
            />
          </div>
        ) : (
          <TextColumn label="New" text={after} mark={marks.added} tone="new" />
        )}
      </div>
      {editable && (
        <button
          type="button"
          onClick={() => onDraft(draft === null ? proposed : null)}
          className="inline-flex items-center gap-1 rounded-full bg-card px-2.5 py-1 text-[11px] font-medium text-ink ring-1 ring-line hover:bg-ink/5"
        >
          <Pencil size={11} /> {draft === null ? "Edit before accepting" : "Discard my edits"}
        </button>
      )}
    </div>
  );
}

function OrganizePreview({ projectId, action }: { projectId: string; action: Extract<Action, { type: "organize" }> }) {
  const [lines, setLines] = useState<string[] | null>(null);
  useEffect(() => {
    let live = true;
    describeOrganize(projectId, action.ops).then((l) => live && setLines(l));
    return () => {
      live = false;
    };
  }, [projectId, action]);
  return (
    <ul className="space-y-1 rounded-xl bg-card p-2.5 text-[12.5px] text-ink ring-1 ring-line">
      {(lines ?? action.ops.map(() => "…")).map((l, i) => (
        <li key={i} className="flex gap-2">
          <FolderTree size={13} className="mt-0.5 shrink-0 text-muted" />
          <span className="min-w-0 break-words">{l}</span>
        </li>
      ))}
    </ul>
  );
}

function ToolPreview({ action }: { action: Extract<Action, { type: "add_tool" }> }) {
  return (
    <div className="rounded-xl bg-card p-2.5 text-[12.5px] text-ink ring-1 ring-line">
      <div className="flex items-center gap-2 font-medium">
        <Wrench size={13} className="text-muted" /> {action.title?.trim() || TOOL_META[action.tool].title}
        <span className="font-normal text-muted">· {TOOL_META[action.tool].desc}</span>
      </div>
      {!!action.items?.length && <div className="mt-1 text-muted">{action.items.length} checklist items: {action.items.slice(0, 4).join(", ")}{action.items.length > 4 ? "…" : ""}</div>}
      {!!action.cards?.length && <div className="mt-1 text-muted">{action.cards.length} flash cards</div>}
    </div>
  );
}

function DeletePreview({ action }: { action: Extract<Action, { type: "delete" }> }) {
  const item = useLiveQuery(async () => {
    if (action.kind === "note") return db.notes.get(action.id);
    if (action.kind === "sketch") return db.sketches.get(action.id);
    if (action.kind === "file") return db.files.get(action.id);
    return db.tools.get(action.id);
  }, [action.kind, action.id]);
  const title = item ? ("title" in item ? item.title : item.name) : action.id;
  return (
    <div className="rounded-xl bg-card p-2.5 text-[12.5px] text-ink ring-1 ring-line">
      <div className="flex items-center gap-2 font-medium">
        <Trash2 size={13} className="text-danger-fg" /> Move {action.kind} “{title || "Untitled"}” to Trash
      </div>
      <div className="mt-0.5 text-[11.5px] text-muted">Moves to this project&apos;s Trash bin — you can restore it or delete it for good from there.</div>
    </div>
  );
}

function ApprovalCard({ message, p, disabled }: { message: Message; p: PendingAction; disabled: boolean }) {
  const action = p.action as unknown as Action;
  const [draft, setDraft] = useState<string | null>(null);
  const status: Record<PendingAction["status"], string> = { pending: "", applied: "Approved", dismissed: "Denied", failed: "Failed" };
  const open = p.status === "pending";
  // The note this proposal will change (undefined while loading, null when it makes a new one).
  const target = useLiveQuery(async () => (action.type === "note" ? ((await noteTarget(message.projectId, action)) ?? null) : null), [message.projectId, p.id]);

  const approve = () => {
    let override: Action | undefined;
    if (action.type === "note" && draft !== null) {
      // The learner's own version is applied exactly as written, to the note the preview showed.
      override = target ? { type: "note", id: target.id, title: action.id ? action.title : "", content: draft, mode: "replace" } : { ...action, content: draft };
    }
    void resolvePending(message.id, p.id, true, override);
  };

  return (
    <div className={cn("rounded-2xl px-3 py-2.5 text-[12px] ring-1 ring-black/5", open ? "bg-warn-bg text-warn-fg" : "bg-ink/[0.035] text-muted")}>
      <div className="flex flex-wrap items-center gap-2">
        <AlertTriangle size={12} className="shrink-0" />
        <span className="min-w-0 flex-1 break-words font-medium">
          {p.label}
          {open ? "?" : ""}
        </span>
        {!open && (
          <span className="shrink-0 text-[11px] opacity-80" title={p.result}>
            {status[p.status]}
          </span>
        )}
      </div>
      {open && (
        <div className="mt-2 space-y-2">
          {action.type === "note" && <NotePreview action={action} existing={target} editable draft={draft} onDraft={setDraft} />}
          {action.type === "organize" && <OrganizePreview projectId={message.projectId} action={action} />}
          {action.type === "add_tool" && <ToolPreview action={action} />}
          {action.type === "delete" && <DeletePreview action={action} />}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={approve}
              disabled={disabled}
              className="flex items-center gap-1 rounded-full bg-ink px-3 py-1.5 text-[12px] font-semibold text-white hover:opacity-90 disabled:opacity-50"
            >
              <Check size={12} /> {draft !== null ? "Accept my version" : "Approve"}
            </button>
            <button
              onClick={() => void resolvePending(message.id, p.id, false)}
              disabled={disabled}
              className="flex items-center gap-1 rounded-full bg-card px-3 py-1.5 text-[12px] font-medium text-ink ring-1 ring-line hover:bg-ink/5 disabled:opacity-50"
            >
              <X size={12} /> Deny
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/** Changes Leo proposed that wait for the learner: a preview, then Approve / Deny. */
export function PendingActions({ message, disabled }: { message: Message; disabled: boolean }) {
  const items = message.pending ?? [];
  if (!items.length) return null;
  return (
    <div className="my-1.5 space-y-1.5">
      {items.map((p) => (
        <ApprovalCard key={p.id} message={message} p={p} disabled={disabled} />
      ))}
    </div>
  );
}
