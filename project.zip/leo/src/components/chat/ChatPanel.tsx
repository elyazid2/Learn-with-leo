import { trashItem } from "@/lib/trash";
import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowDown, ArrowRight, ArrowUp, Check, Brain, ChevronDown, ClipboardCheck, Compass, GripHorizontal, PenLine, History, Maximize2, MessageCircle, Mic, PanelBottom, PanelLeft, PanelRight, Paperclip, PictureInPicture2, Square, SquarePen, Trash2, X } from "lucide-react";
import { db, type ContextTag, type Message, type Project, type Provider, type Thread, type ThinkingLevel } from "@/lib/db";
import ProviderLogo, { providerDisplayName } from "@/components/ProviderLogo";
import { THINKING_LEVELS, rememberThinking, thinkingOption } from "@/lib/ai/thinking";
import { useApp } from "@/lib/store";
import { createThread, getDefaultModel, getOrCreateActiveThread, isBusy, sendMessage, startPlacement, stopStreaming } from "@/lib/chat";
import ErrorBoundary from "@/components/ErrorBoundary";
import { useShallow } from "zustand/react/shallow";
import { modelLabel } from "@/lib/models";
import { Sheet, isSheetOpen } from "@/components/ui";
import { navigate } from "@/lib/router";
import { timeAgo } from "@/lib/media";
import { ChatMessage, CtxIcon, StreamingMessage } from "./ChatMessage";
import MentionPicker, { type Mention } from "./MentionPicker";
import { ExplainSheet } from "@/components/ExplainThenNow";
import { audioSegment, blobToDataUrl, formatClock, imageToDataUrl, pdfPageText } from "@/lib/media";
import { listenOnce, speechSupported } from "@/lib/speech";
import { MicButton } from "@/components/stt/Dictation";
import { cn } from "@/utils/cn";
import AgentAvatar from "@/components/AgentAvatar";
import { normalizeAvatarLook, type AgentState, type AvatarLook } from "@/lib/avatar";
import { useAgentState } from "@/lib/useAgentState";
import { noteBlock, parseSegments } from "@/lib/ai/actions";
import { useSettings, confirmDeletion } from "@/lib/settings";
import { NARROW, useLayout, type ChatDock } from "@/lib/layout";
import LiveActivity from "./LiveActivity";
import { usePresence } from "@/lib/motion";
import { ResizeGrip, useFloatFrame, useViewport } from "@/components/FloatingWindow";

/** Fullscreen chat keeps a comfortable reading width in the middle of the screen. */
const WIDE_PAD = "max(1rem, calc((100% - 46rem) / 2))";
const isTouch = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
/** Height of the chat header (grip + avatar row). */
const CHAT_HEADER_H = 70;

const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n) + "\n…[truncated]" : s);

/** Leo's chat: one conversation per thread, no modes — Leo works out what you want from each message. */
export default function ChatPanel({ project, placement = "float" }: { project: Project; placement?: "float" | "inline" | "full" | "hidden" }) {
  const open = useApp((s) => s.chatOpen);
  const setOpen = useApp((s) => s.setChatOpen);
  const streaming = useApp((s) => s.streaming);
  const activeId = useApp((s) => s.activeThread[project.id]);
  const vp = useViewport();

  // ----- position and size: the same floating frame as every tool window -----
  // "inline" is docked beside or below the work, "full" covers the screen, "hidden" keeps the chat alive out of sight.
  const max = placement === "full";
  const inline = placement === "inline";
  const floating = placement === "float";
  const frame = useFloatFrame("harness.panel", {
    vp,
    initial: (v) => {
      const small = v.w < 640;
      const w = small ? v.w - 16 : 400;
      const h = Math.min(small ? Math.round(v.h * 0.8) : 640, v.h - 16);
      return { x: v.w - w - 16, y: v.h - h - 16, w, h };
    },
    minW: 320,
    minH: 280,
    headerH: CHAT_HEADER_H,
    enabled: floating,
  });

  // ----- data -----
  const thread = useLiveQuery(() => (activeId ? db.threads.get(activeId) : undefined), [activeId]);
  const messages = useLiveQuery(
    (): Promise<Message[]> => (activeId ? db.messages.where("threadId").equals(activeId).sortBy("createdAt") : Promise.resolve([])),
    [activeId]
  );
  const providers = useLiveQuery(() => db.providers.toArray(), []);
  const [showHistory, setShowHistory] = useState(false);
  const [modelPickerOpen, setModelPickerOpen] = useState(false);
  const [thinkingOpen, setThinkingOpen] = useState(false);
  const [explainOpen, setExplainOpen] = useState(false);
  const defaultModel = useLiveQuery(() => getDefaultModel(), []);
  const activeProvider = providers?.find((p) => p.id === (thread?.providerId ?? defaultModel?.providerId))
    ?? providers?.find((p) => p.models.includes(thread?.model ?? defaultModel?.model ?? ""))
    ?? providers?.find((p) => p.models.length > 0);
  const agentState = useAgentState(project.id);
  const developerMode = useSettings((s) => s.developerMode);
  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);
  const setAgentWaiting = useApp((s) => s.setAgentWaiting);

  useEffect(() => {
    if (open && !activeId) void getOrCreateActiveThread(project.id, "ask");
  }, [open, activeId, project.id]);

  useEffect(() => {
    const history = messages ?? [];
    const lastAssistant = [...history].reverse().find((m) => m.role === "assistant" && !m.error);
    const hasNewerUser = lastAssistant && history.some((m) => m.role === "user" && m.createdAt > lastAssistant.createdAt);
    const quizOpen =
      !!lastAssistant &&
      !hasNewerUser &&
      parseSegments(lastAssistant.content).some((segment) => segment.kind === "action" && segment.action.type === "quiz" && lastAssistant.answers?.[segment.index] === undefined);
    setAgentWaiting(quizOpen ? project.id : null);
    return () => {
      if (useApp.getState().waitingProjectId === project.id) setAgentWaiting(null);
    };
  }, [messages, project.id, setAgentWaiting]);

  // ----- scroll -----
  const scroller = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  // The composer floats over the conversation; the list reserves its measured height underneath.
  const [composerH, setComposerH] = useState(96);
  const [awayFromBottom, setAwayFromBottom] = useState(false);
  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [messages, streaming?.content, open, composerH]);
  const jumpToLatest = () => {
    const el = scroller.current;
    if (!el) return;
    stick.current = true;
    setAwayFromBottom(false);
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  };
  // Switching threads always starts at the latest message.
  useEffect(() => {
    stick.current = true;
    setAwayFromBottom(false);
  }, [activeId]);

  // Esc closes Leo when focus is in the panel (or nowhere in particular) and no dialog is on top.
  useEffect(() => {
    if (!open) return;
    const on = (e: KeyboardEvent) => {
      if (e.key !== "Escape" || e.defaultPrevented || isSheetOpen()) return;
      const el = document.activeElement as HTMLElement | null;
      if (el && el !== document.body && !el.closest("[data-chat-panel]")) return;
      if (showHistory) setShowHistory(false);
      else setOpen(false);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [open, showHistory, setOpen]);

  // The floating panel stays mounted for a moment after closing, so it can settle back into the dock.
  const presence = usePresence(open && placement !== "hidden");

  // A fullscreen chat is only for the moment: once Leo has closed, the next time he opens he is the standard floating window.
  const wasMounted = useRef(false);
  useEffect(() => {
    if (wasMounted.current && !presence.mounted && !open) useLayout.getState().endFullscreen();
    wasMounted.current = presence.mounted;
  }, [presence.mounted, open]);
  // Leo's window can't be minimized any more: a chat that was left minimized by an older version opens in full.
  const expandFrame = frame.expand;
  useEffect(() => {
    if (open && frame.minimized) expandFrame();
  }, [open, frame.minimized, expandFrame]);

  if (!presence.mounted) return null;

  const busy = !!streaming;
  const visible = (messages ?? []).filter((m) => !m.hidden);
  const showStream = streaming && streaming.threadId === activeId;
  const needsProvider = !developerMode && providers && providers.length === 0;

  const newChat = async () => {
    setShowHistory(false);
    if (thread && visible.length === 0 && thread.mode !== "placement") return;
    await createThread(project.id, "ask");
  };

  return (
    <div
      data-chat-panel
      aria-hidden={presence.closing || undefined}
      onAnimationEnd={(e) => {
        if (presence.closing && e.target === e.currentTarget) presence.end();
      }}
      className={cn(
        "flex flex-col overflow-hidden bg-paper",
        inline ? "h-full w-full" : cn(presence.closing ? "panel-out" : "panel-in", "fixed z-50 shadow-[0_20px_60px_rgba(0,0,0,0.20)] ring-1 ring-black/10"),
        placement === "float" && "rounded-2xl"
      )}
      style={inline ? undefined : max ? { left: 0, top: vp.top, width: vp.w, height: vp.h } : frame.style}
    >
      <div className={cn("@container relative z-20 shrink-0 border-b border-line bg-card/85 backdrop-blur", max && "pt-[env(safe-area-inset-top)]")}>
        <div className={cn("touch-none", floating && "cursor-grab select-none active:cursor-grabbing")} {...(floating ? frame.moveHandlers : {})}>
          <div className={cn("flex justify-center pt-1.5", placement !== "float" && "invisible h-1.5")}>
            <GripHorizontal size={16} className="text-muted/60" />
          </div>
          <div className="flex items-center gap-1 px-3 pb-1.5 @[22rem]:gap-2.5 @lg:pb-2.5">
            <AgentAvatar state={agentState} look={look} size={36} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="display text-[17px] leading-tight">Leo</span>
                <ModelChip className="hidden @lg:block" developerMode={developerMode} provider={activeProvider} label={activeModelLabel(thread, providers ?? [], defaultModel)} onOpen={() => setModelPickerOpen(true)} />
              </div>
              <StatusLine busy={busy} state={agentState} topic={project.name} />
            </div>
            <ThinkingButton level={thread?.thinking} onClick={() => setThinkingOpen(true)} active={thinkingOpen} />
            <HeaderBtn onClick={() => setShowHistory((s) => !s)} label={showHistory ? "Back to chat" : "Chat history"} active={showHistory}>
              <History size={17} />
            </HeaderBtn>
            <HeaderBtn onClick={() => void newChat()} label="New chat">
              <SquarePen size={17} />
            </HeaderBtn>
            <DockMenu narrow={vp.w < NARROW} />
            <HeaderBtn onClick={() => setOpen(false)} label="Close">
              <X size={18} />
            </HeaderBtn>
          </div>
          <ModelChip className="flex pb-2.5 pl-[58px] pr-3 @lg:hidden" developerMode={developerMode} provider={activeProvider} label={activeModelLabel(thread, providers ?? [], defaultModel)} onOpen={() => setModelPickerOpen(true)} />
        </div>
      </div>

      <div className="relative flex min-h-0 flex-1 flex-col" style={{ "--composer-h": `${composerH}px` } as CSSProperties}>
      {showHistory ? (
        <HistoryList projectId={project.id} activeId={activeId} onPick={() => setShowHistory(false)} />
      ) : (
        <div
          ref={scroller}
          onScroll={(e) => {
            const el = e.currentTarget;
            stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
            const away = el.scrollHeight - el.scrollTop - el.clientHeight > 240;
            if (away !== awayFromBottom) setAwayFromBottom(away);
          }}
          className="min-h-0 flex-1 space-y-4 overflow-y-auto px-4 pb-[var(--composer-h)] pt-4"
          style={max ? { paddingInline: WIDE_PAD } : undefined}
        >
          {needsProvider ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <AgentAvatar state="blocked" look={look} size={58} />
              <p className="mt-3 display text-[22px]">Connect a model for Leo</p>
              <p className="mt-1 max-w-[270px] text-[13px] leading-relaxed text-muted">
                Leo runs on your own AI provider — OpenAI, Anthropic, Gemini, OpenRouter or a local model.
              </p>
              <button onClick={() => navigate("settings")} className="mt-4 h-10 rounded-full bg-ink px-5 text-sm font-semibold text-white">
                Open settings
              </button>
            </div>
          ) : visible.length === 0 && !showStream ? (
            <EmptyChat project={project} state={agentState} look={look} onExplain={() => setExplainOpen(true)} onSend={(t) => thread && void sendMessage({ threadId: thread.id, text: t })} />
          ) : (
            visible.map((m, i) => (
              <ErrorBoundary key={m.id} scope="message" inline>
                <ChatMessage message={m} disabled={busy} look={look} isLatest={i === visible.length - 1} />
              </ErrorBoundary>
            ))
          )}
          {showStream && <StreamingMessage content={streaming!.content} state={agentState} look={look} />}
          {busy && <LiveActivity projectId={project.id} />}
        </div>
      )}
      {!showHistory && awayFromBottom && (
        <button
          onClick={jumpToLatest}
          style={{ bottom: Math.max(12, composerH - 18) }}
          className="rise absolute left-1/2 z-20 flex h-9 -translate-x-1/2 items-center gap-1.5 rounded-full bg-elevated px-3.5 text-[13px] font-medium shadow-[0_6px_20px_rgba(0,0,0,0.16)] ring-1 ring-line transition-colors hover:bg-card"
        >
          <ArrowDown size={14} /> {busy ? "Leo is replying" : "Latest"}
        </button>
      )}

      <Composer project={project} thread={thread} busy={busy} onHeight={setComposerH} wide={max} onExplain={() => setExplainOpen(true)} />
      </div>
      {floating && <ResizeGrip handlers={frame.resizeHandlers} />}
      <ModelPickerSheet open={modelPickerOpen} onClose={() => setModelPickerOpen(false)} thread={thread} providers={providers ?? []} />
      <ThinkingSheet open={thinkingOpen} onClose={() => setThinkingOpen(false)} thread={thread} />
      <ExplainSheet project={project} open={explainOpen} onClose={() => setExplainOpen(false)} />
    </div>
  );
}

/** One quiet line under Leo's name: what he is doing right now, or the topic when he is idle. */
function StatusLine({ busy, state, topic }: { busy: boolean; state: AgentState; topic: string }) {
  const text = busy ? (state === "working" ? "Working on it" : state === "speaking" ? "Replying" : "Thinking") : state === "waiting" ? "Waiting for your answer" : state === "listening" ? "Listening" : topic;
  const live = busy || state === "listening";
  return (
    <div className="mt-0.5 flex h-4 items-center gap-1.5 text-[11.5px] leading-4 text-muted" aria-live="polite">
      {live && <span className="typing-dots" aria-hidden><i /><i /><i /></span>}
      <span key={text} className="status-swap truncate">{text}</span>
    </div>
  );
}

/** Brain button in the chat header; shows the chat's thinking level once it isn't "Auto". */
function ThinkingButton({ level, onClick, active }: { level?: ThinkingLevel; onClick: () => void; active: boolean }) {
  const opt = thinkingOption(level);
  return (
    <button
      onClick={onClick}
      aria-label={`Thinking level: ${opt.label}`}
      title={`Thinking: ${opt.label}`}
      aria-pressed={active}
      className={cn(
        "relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors",
        active || opt.bars > 0 ? "bg-ink/[0.08] text-ink" : "text-ink/70 hover:bg-ink/[0.05] hover:text-ink"
      )}
    >
      <Brain size={17} />
      {opt.bars > 0 && (
        <span aria-hidden className="absolute -bottom-0.5 left-1/2 flex -translate-x-1/2 items-end gap-px">
          {[1, 2, 3, 4].map((i) => (
            <i key={i} className={cn("block w-[3px] rounded-full", i <= opt.bars ? "bg-ink" : "bg-ink/20")} style={{ height: 2 + i * 1.5 }} />
          ))}
        </span>
      )}
    </button>
  );
}

/** Pick how hard Leo thinks for this chat. New chats start at the level you used last. */
function ThinkingSheet({ open, onClose, thread }: { open: boolean; onClose: () => void; thread?: Thread }) {
  const current = thread?.thinking ?? "auto";
  const choose = async (level: ThinkingLevel) => {
    if (!thread) return;
    await db.threads.update(thread.id, { thinking: level });
    rememberThinking(level);
    onClose();
  };
  return (
    <Sheet open={open} onClose={onClose} title="Thinking level">
      <p className="-mt-2 mb-3 text-[13px] text-muted">
        How much reasoning Leo does before replying. Higher levels are slower but better on hard problems. Models that can't reason ignore it.
      </p>
      <div className="space-y-0.5">
        {THINKING_LEVELS.map((o) => {
          const selected = current === o.value;
          return (
            <button
              key={o.value}
              onClick={() => void choose(o.value)}
              aria-pressed={selected}
              className={cn("flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-ink/[0.04]", selected && "bg-ink/[0.06]")}
            >
              <span aria-hidden className="flex h-5 w-6 shrink-0 items-end justify-center gap-[2px]">
                {[1, 2, 3, 4].map((i) => (
                  <i key={i} className={cn("block w-[4px] rounded-full", i <= o.bars ? "bg-ink" : "bg-ink/15")} style={{ height: 5 + i * 3 }} />
                ))}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[14px] font-semibold">{o.label}</span>
                <span className="block text-[12px] text-muted">{o.hint}</span>
              </span>
              {selected && <Check size={16} className="shrink-0" />}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}

function HeaderBtn({ onClick, label, active, children }: { onClick: () => void; label: string; active?: boolean; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      aria-pressed={active}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors",
        active ? "bg-ink/[0.08] text-ink" : "text-ink/70 hover:bg-ink/[0.05] hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}

function activeModelLabel(
  thread: Thread | undefined,
  providers: { id: string; name: string; models: string[] }[],
  fallback: { providerId: string; model: string } | null | undefined
) {
  if (thread?.model) return modelLabel(thread.model);
  if (fallback?.model) return modelLabel(fallback.model);
  const any = providers.flatMap((p) => p.models)[0];
  return any ? modelLabel(any) : "Choose model";
}

/**
 * The model this chat uses, as a chip that opens the picker. It sits beside Leo's name when the
 * header is wide enough to show it; a narrow header (the floating chat, a phone) gives it a row of
 * its own instead of squeezing it down to a letter. `className` sets when it shows.
 */
function ModelChip({ developerMode, provider, label, onOpen, className }: { developerMode: boolean; provider?: Provider; label: string; onOpen: () => void; className?: string }) {
  return (
    <div className={cn("min-w-0", className)}>
      {developerMode ? (
        <span className="block truncate rounded-full bg-ink/[0.06] px-2.5 py-0.5 text-[12px] font-medium text-muted">Developer mock</span>
      ) : (
        <button
          type="button"
          onClick={onOpen}
          className="flex min-w-0 max-w-full items-center gap-1 rounded-full bg-ink/[0.06] py-0.5 pl-2.5 pr-1.5 text-left text-[12px] font-medium text-ink/80 transition-colors hover:bg-ink/[0.1] active:scale-[0.98]"
          aria-label="Choose model for this chat"
          title={`Model: ${label}`}
        >
          {provider && <ProviderLogo provider={provider} size={21} className="!rounded-md !bg-transparent !ring-0" />}
          <span className="truncate">{label}</span>
          <ChevronDown size={12} className="shrink-0" />
        </button>
      )}
    </div>
  );
}

function PickerLogo({ provider, selected = false, size = 36 }: { provider?: Provider; selected?: boolean; size?: number }) {
  if (provider) return <ProviderLogo provider={provider} size={size} selected={selected} />;
  return (
    <span className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-[13px] font-bold text-muted">
      L
      {selected && <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-ink text-white ring-2 ring-card" aria-hidden><Check size={10} strokeWidth={3} /></span>}
    </span>
  );
}

function ModelPickerSheet({
  open,
  onClose,
  thread,
  providers,
}: {
  open: boolean;
  onClose: () => void;
  thread?: Thread;
  providers: Provider[];
}) {
  const savedDefault = useLiveQuery(() => getDefaultModel(), [providers]);
  const currentProvider = thread?.providerId ?? savedDefault?.providerId;
  const currentModel = thread?.model ?? savedDefault?.model;
  const defaultProvider = providers.find((p) => p.id === savedDefault?.providerId) ?? providers.find((p) => p.models.length > 0);
  const usingDefault = !!savedDefault && currentProvider === savedDefault.providerId && currentModel === savedDefault.model;
  const choose = async (providerId: string | undefined, model: string | undefined) => {
    if (!thread) return;
    await db.threads.update(thread.id, { providerId, model });
    onClose();
  };
  return (
    <Sheet open={open} onClose={onClose} title="Choose model">
      <p className="-mt-2 mb-3 text-[13px] text-muted">Only models enabled in Settings appear here.</p>
      <div className="max-h-[62dvh] space-y-4 overflow-y-auto">
        <section>
          <h3 className="mb-1 px-1 text-[12px] font-semibold text-muted">Default for new chats</h3>
          <button
            onClick={() => void choose(undefined, undefined)}
            className={cn(
              "flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-colors",
              !thread?.providerId ? "bg-ink/[0.06] ring-1 ring-ink/15" : "hover:bg-ink/[0.04]"
            )}
          >
            <PickerLogo provider={defaultProvider} selected={usingDefault} />
            <span className="min-w-0 flex-1">
              <span className="block text-[14px] font-semibold">{savedDefault ? modelLabel(savedDefault.model) : "No default model"}</span>
              <span className="block truncate text-[12px] text-muted">
                {defaultProvider ? providerDisplayName(defaultProvider.name) : "Set a default in Settings"}
              </span>
            </span>
            {usingDefault && <span className="rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">Using</span>}
          </button>
        </section>
        {providers.map((p) => (
          <section key={p.id}>
            <h3 className="mb-1 px-1 text-[12px] font-semibold text-muted">{providerDisplayName(p.name)}</h3>
            {p.models.length ? (
              <div className="space-y-0.5">
                {p.models.map((m) => {
                  const selected = currentProvider === p.id && currentModel === m;
                  return (
                    <button
                      key={m}
                      onClick={() => void choose(p.id, m)}
                      aria-pressed={selected}
                      className={cn("flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors", selected ? "bg-ink/[0.06]" : "hover:bg-ink/[0.04]")}
                    >
                      <PickerLogo provider={p} selected={selected} size={32} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[14px] font-semibold">{modelLabel(m)}</span>
                        <span className="block truncate text-[11px] text-muted">{m}</span>
                      </span>
                      {selected && <span className="text-[11px] font-medium text-muted">This chat</span>}
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="px-2 py-2 text-[12px] text-muted">No enabled models — enable some in Settings.</p>
            )}
          </section>
        ))}
      </div>
      <button onClick={() => { onClose(); navigate("settings"); }} className="mt-3 w-full rounded-full bg-ink/[0.05] py-2.5 text-[13px] font-medium hover:bg-ink/[0.08]">
        Manage enabled models in Settings
      </button>
    </Sheet>
  );
}

function dayBucket(t: number) {
  const d = new Date(t);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diff = (today.getTime() - new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()) / 86400000;
  if (diff <= 0) return "Today";
  if (diff < 2) return "Yesterday";
  if (diff < 7) return "This week";
  if (diff < 31) return "This month";
  return "Older";
}

function HistoryList({ projectId, activeId, onPick }: { projectId: string; activeId?: string; onPick: () => void }) {
  const threads = useLiveQuery(() => db.threads.where("projectId").equals(projectId).reverse().sortBy("updatedAt"), [projectId]);
  const setActive = useApp((s) => s.setActiveThread);
  const [q, setQ] = useState("");
  const remove = async (t: Thread) => {
    if (!(await confirmDeletion(`Move “${t.title}” and its messages to this project's Trash?`, { title: "Delete chat?" }))) return;
    await trashItem("thread", t.id);
    if (t.id === activeId) {
      const rest = (threads ?? []).filter((x) => x.id !== t.id);
      if (rest[0]) setActive(projectId, rest[0].id);
      else await createThread(projectId, "ask");
    }
  };
  const query = q.trim().toLowerCase();
  const list = (threads ?? []).filter((t) => !t.deletedAt && (!query || t.title.toLowerCase().includes(query)));
  const groups: { label: string; items: Thread[] }[] = [];
  for (const t of list) {
    const label = dayBucket(t.updatedAt);
    const g = groups[groups.length - 1];
    if (g && g.label === label) g.items.push(t);
    else groups.push({ label, items: [t] });
  }
  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-2 pb-[var(--composer-h)]">
      <div className="flex items-center justify-between gap-2 px-2 pb-2 pt-1">
        <h3 className="text-[13px] font-semibold text-muted">Your chats with Leo</h3>
        <span className="text-[12px] tabular-nums text-muted">{threads?.filter((t) => !t.deletedAt).length ?? 0}</span>
      </div>
      {(threads?.length ?? 0) > 5 && (
        <div className="px-1 pb-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Find a chat"
            aria-label="Find a chat"
            className="h-9 w-full rounded-full bg-ink/[0.05] px-3.5 text-[14px] outline-none placeholder:text-muted/80 focus:ring-1 focus:ring-ink/15"
          />
        </div>
      )}
      {threads && list.length === 0 && (
        <p className="px-3 py-8 text-center text-[13px] text-muted">{query ? `No chats match "${q}".` : "No chats yet — say hi to Leo."}</p>
      )}
      {groups.map((g) => (
        <div key={g.label} className="mb-1.5">
          <div className="px-2 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide text-muted/80">{g.label}</div>
          {g.items.map((t) => (
            <div key={t.id} className={cn("group flex items-center gap-2 rounded-xl px-2 py-2", t.id === activeId ? "bg-ink/[0.06]" : "hover:bg-ink/[0.03]")}>
              <button
                className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                aria-current={t.id === activeId ? "true" : undefined}
                onClick={() => {
                  setActive(projectId, t.id);
                  onPick();
                }}
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-card text-muted ring-1 ring-line">
                  {t.mode === "placement" ? <Compass size={15} /> : <MessageCircle size={15} />}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[14px] font-medium">{t.title}</span>
                  <span className="block text-[12px] text-muted">
                    {t.mode === "placement" ? "Placement · " : ""}
                    {timeAgo(t.updatedAt)}
                  </span>
                </span>
              </button>
              <button
                onClick={() => void remove(t)}
                className="flex h-9 w-9 items-center justify-center rounded-full text-muted transition-opacity hover:bg-danger-bg hover:text-danger-fg sm:opacity-0 sm:focus-visible:opacity-100 sm:group-hover:opacity-100"
                aria-label={`Delete chat ${t.title}`}
              >
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function EmptyChat({ project, state, look, onSend, onExplain }: { project: Project; state: AgentState; look: AvatarLook; onSend: (t: string) => void; onExplain: () => void }) {
  const { note, selection, pdf, image, sketch } = useApp(useShallow((s) => ({ note: s.note, selection: s.selection, pdf: s.pdf, image: s.image, sketch: s.sketch })));
  const suggestions: string[] = [];
  if (selection) suggestions.push("Explain the selected text simply");
  if (note) suggestions.push("Review my note — what's wrong or missing?");
  if (pdf) suggestions.push("Summarize this page and quiz me on it");
  if (image) suggestions.push("Explain what's in this picture");
  if (sketch) suggestions.push("Give feedback on my sketch");
  suggestions.push("Teach me something new", "Quiz me", "What should I learn next?");

  return (
    <div className="stagger flex h-full flex-col justify-end">
      <div className="mb-4">
        <AgentAvatar state={state} look={look} size={56} />
        <h3 className="mt-3 display text-[22px] leading-tight">Hi, I'm Leo</h3>
        <p className="mt-1 max-w-[36ch] text-[14px] leading-relaxed text-muted">
          Ask me anything about {project.name}. I can teach you, quiz you, and keep your progress up to date.
        </p>
      </div>
      {project.placement.status !== "done" && (
        <button
          onClick={() => void startPlacement(project.id)}
          className="mb-2.5 flex w-full items-center gap-3 rounded-2xl bg-card p-3.5 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.03]"
        >
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-ink/[0.06]">
            <Compass size={17} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[14px] font-semibold">Find my starting point</span>
            <span className="block text-[12px] text-muted">A few quick questions to set your level</span>
          </span>
          <ArrowRight size={16} className="shrink-0 text-muted" />
        </button>
      )}
      <div className="flex flex-wrap gap-1.5">
        {suggestions.slice(0, 6).map((s) => (
          <button key={s} onClick={() => onSend(s)} className="rounded-full bg-card px-3 py-1.5 text-left text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.04]">
            {s}
          </button>
        ))}
        <button onClick={onExplain} className="flex items-center gap-1.5 rounded-full bg-card px-3 py-1.5 text-left text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.04]">
          <PenLine size={13} className="text-muted" /> How would you explain it?
        </button>
      </div>
    </div>
  );
}

type CtxKey = "note" | "selection" | "pdf" | "image" | "sketch" | "video" | "browser";

function Composer({ project, thread, busy, onHeight, wide, onExplain }: { project: Project; thread?: Thread; busy: boolean; onHeight: (h: number) => void; wide?: boolean; onExplain: () => void }) {
  const { note, selection, pdf, image, sketch, video, browser, setSelection } = useApp(
    useShallow((s) => ({ note: s.note, selection: s.selection, pdf: s.pdf, image: s.image, sketch: s.sketch, video: s.video, browser: s.browser, setSelection: s.setSelection }))
  );
  const [text, setText] = useState("");
  const sending = useRef(false);
  const shareMediaByDefault = useSettings((s) => s.shareMediaByDefault);
  const enterToSend = useSettings((s) => s.enterToSend);
  const [off, setOff] = useState<Record<CtxKey, boolean>>({ note: false, selection: false, pdf: false, image: !shareMediaByDefault, sketch: !shareMediaByDefault, video: false, browser: false });
  const [mentions, setMentions] = useState<Mention[]>([]);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [listening, setListening] = useState(false);
  const [focused, setFocused] = useState(false);
  const showDictation = useSettings((s) => s.showDictation);
  const whisperMic = useSettings((s) => !!s.whisperUrl.trim() || s.demoTranscription);
  const hintId = useId();
  const showHint = focused && !text && !pickerOpen;
  const ta = useRef<HTMLTextAreaElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);

  // Report the floating composer's height (it grows with chips and multi-line text) to the panel.
  useLayoutEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    const report = () => onHeight(el.offsetHeight);
    report();
    const ro = new ResizeObserver(report);
    ro.observe(el);
    return () => ro.disconnect();
  }, [onHeight]);

  useEffect(() => {
    if (selection) setOff((o) => ({ ...o, selection: false }));
  }, [selection]);

  // On a computer, opening Leo ("/", the shortcut or the dock) puts the cursor in the message box.
  // Touch devices are left alone so the keyboard doesn't jump up uninvited.
  useEffect(() => {
    if (!isTouch) ta.current?.focus({ preventScroll: true });
  }, []);

  useLayoutEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 140) + "px";
  }, [text]);

  const onTextChange = (value: string) => {
    setText(value);
    const caret = ta.current?.selectionStart ?? value.length;
    const upto = value.slice(0, caret);
    const match = /(^|\s)@([^\s@]{0,40})$/.exec(upto);
    if (match) {
      setMentionQuery(match[2]);
      setPickerOpen(true);
    } else if (pickerOpen) setPickerOpen(false);
  };

  const addMention = (m: Mention) => {
    // "How would you explain it?" opens its own sheet; it is never attached to a message.
    if (m.kind === "explain") {
      setText((v) => v.replace(/(^|\s)@([^\s@]{0,40})$/, (_full, pre: string) => pre.trimEnd()).trimStart());
      setPickerOpen(false);
      setMentionQuery("");
      onExplain();
      return;
    }
    setMentions((list) => [...list.filter((x) => x.key !== m.key), m]);
    setText((v) => v.replace(/(^|\s)@([^\s@]{0,40})$/, (full, pre: string) => (full.endsWith("@") ? pre : pre + " ")).trimStart());
    setPickerOpen(false);
    setMentionQuery("");
    ta.current?.focus();
  };

  const dictation = async () => {
    if (!speechSupported()) return useApp.getState().showToast("Dictation isn't available in this browser");
    setListening(true);
    useApp.getState().setAgentActivity("listening", project.id);
    const transcript = await listenOnce();
    setListening(false);
    useApp.getState().setAgentActivity("idle", project.id);
    if (transcript) onTextChange(`${text}${text ? " " : ""}${transcript}`);
  };

  const chips: { key: CtxKey; label: string; active: boolean }[] = [];
  if (selection) chips.push({ key: "selection", label: `“${selection.text.slice(0, 40)}${selection.text.length > 40 ? "…" : ""}”`, active: !off.selection });
  if (note) chips.push({ key: "note", label: note.title, active: !off.note });
  if (pdf) chips.push({ key: "pdf", label: `${pdf.name.replace(/\.pdf$/i, "")} · p.${pdf.page}`, active: !off.pdf });
  if (image) chips.push({ key: "image", label: image.name, active: !off.image });
  if (sketch) chips.push({ key: "sketch", label: sketch.title, active: !off.sketch });
  if (video) chips.push({ key: "video", label: video.title, active: !off.video });
  if (browser) chips.push({ key: "browser", label: browser.title || browser.url, active: !off.browser });

  const practice = mentions.some((m) => m.kind === "practice");
  const send = useCallback(async () => {
    const material = mentions.filter((m) => m.kind !== "practice");
    const wantsTest = material.length !== mentions.length;
    // "@Practice test" alone is a complete request.
    const msg = text.trim() || (wantsTest ? `Build me a practice test${material.length ? ` from ${material.map((m) => m.name.replace(/\.[a-z0-9]{1,5}$/i, "")).join(", ")}` : ""}` : "");
    if (!msg || busy || sending.current || isBusy()) return;
    sending.current = true;
    setText("");
    const snapshotSelection = selection;
    try {
      const t = thread ?? (await getOrCreateActiveThread(project.id, "ask"));
      const tags: ContextTag[] = [];
      let ctx = "";
      const images: string[] = [];
      const audios: { data: string; mime: string; name: string }[] = [];
      for (const m of material) {
        if (m.kind === "note" && m.noteId) {
          const n = await db.notes.get(m.noteId);
          if (!n) continue;
          tags.push({ kind: "note", label: n.title });
          ctx += `${noteBlock("Referenced note:", n)}\n\n`;
          continue;
        }
        if (m.kind === "sketch" && m.sketchId) {
          const s = await db.sketches.get(m.sketchId);
          if (!s) continue;
          tags.push({ kind: "sketch", label: s.title });
          try {
            const { exportToBlob } = await import("@excalidraw/excalidraw");
            const scene = JSON.parse(s.scene || "{}") as { elements?: unknown[]; appState?: Record<string, unknown>; files?: Record<string, unknown> };
            const blob = await exportToBlob({
              elements: (scene.elements ?? []) as never,
              appState: { ...(scene.appState ?? {}), exportBackground: true, viewBackgroundColor: "#ffffff" } as never,
              files: (scene.files ?? {}) as never,
              maxWidthOrHeight: 1280,
              mimeType: "image/png",
            });
            images.push(await blobToDataUrl(blob));
          } catch {
            /* the drawing could not be rendered — the reference still reaches Leo */
          }
          ctx += `## Referenced sketch: "${s.title}" (id=${s.id}; drawing attached)\n\n`;
          continue;
        }
        const file = m.fileId ? await db.files.get(m.fileId) : undefined;
        if (!file) continue;
        if (m.kind === "pdf" && m.page) {
          const pageText = await pdfPageText(file.blob, m.page).catch(() => "");
          tags.push({ kind: "pdf", label: `${file.name} · p.${m.page}` });
          ctx += `## PDF \"${file.name}\" — exactly page ${m.page} of ${m.pages ?? file.pages ?? "?"} (extracted text)\n${clip(pageText, 9000) || "(no extractable text on this page — it may be scanned)"}\n\n`;
        } else if (m.kind === "audio") {
          const start = m.start ?? 0;
          const end = m.end ?? (start + 30);
          const seg = await audioSegment(file.blob, start, end);
          tags.push({ kind: "audio", label: `${file.name} · ${formatClock(start)}–${formatClock(end)}` });
          ctx += `## Audio segment: \"${file.name}\" from ${formatClock(start)} to ${formatClock(end)} (${Math.round(end - start)}s). ${seg ? "The clip is attached; listen to it directly." : "The clip could not be decoded; ask the learner what it says."}\n\n`;
          if (seg) audios.push({ data: seg.dataUrl, mime: "audio/wav", name: `${file.name} ${formatClock(start)}-${formatClock(end)}` });
        } else if (m.kind === "image") {
          const data = await imageToDataUrl(file.blob, 1280);
          if (data) { images.push(data); tags.push({ kind: "image", label: file.name }); ctx += `## Referenced image: \"${file.name}\" (exactly the file the learner mentioned)\n\n`; }
        } else if (m.kind === "text") {
          const content = await file.blob.text().catch(() => "");
          tags.push({ kind: "text", label: file.name });
          ctx += `## Referenced text file: \"${file.name}\"\n${clip(content, 9000)}\n\n`;
        } else if (m.kind === "video") {
          tags.push({ kind: "video", label: file.name });
          if (file.youtubeId) {
            const { transcriptExcerpt } = await import("@/lib/youtube");
            const transcript = transcriptExcerpt(file, 9000);
            ctx += transcript
              ? `## YouTube video: \"${file.name}\"${file.channel ? ` by ${file.channel}` : ""}${file.youtubeUrl ? ` (${file.youtubeUrl})` : ""}. You cannot watch the video; teach and quiz from this transcript, and cite moments like [3:12].\n${transcript}\n\n`
              : `## YouTube video: \"${file.name}\". Its transcript is not available yet, so you cannot quiz on the video's content; the learner can add a transcript on the video page.\n\n`;
          } else {
            ctx += `## Referenced video: \"${file.name}\"${file.duration ? ` (${Math.round(file.duration)}s)` : ""}. You cannot watch it; ask the learner to describe or share a frame.\n\n`;
          }
        }
      }
      if (wantsTest) {
        tags.push({ kind: "practice", label: "Practice test" });
        ctx += `## Practice test requested\nThe learner chose "Practice test" from the @ menu. Build a timed practice test now and emit it as a single practice_test action. ${
          material.length
            ? `Base every question on the material referenced above (${material.map((m) => `"${m.name}"`).join(", ")}); do not pull questions from elsewhere.`
            : "No material was mentioned, so search and read the most relevant library material first (exams, books, video transcripts), then build the test from it."
        } Mix multiple-choice and open questions.\n\n`;
      }
      if (selection && !off.selection) {
        tags.push({ kind: "selection", label: selection.text.slice(0, 40) });
        ctx += `## Selected text (from ${selection.source})\n${clip(selection.text, 6000)}\n\n`;
      }
      if (note && !off.note) {
        tags.push({ kind: "note", label: note.title });
        ctx += `${noteBlock("Current note:", note)}\n\n`;
      }
      if (pdf && !off.pdf) {
        tags.push({ kind: "pdf", label: `${pdf.name} p.${pdf.page}` });
        ctx += `## PDF "${pdf.name}" — page ${pdf.page} of ${pdf.pages} (extracted text)\n${clip(pdf.text, 8000) || "(no extractable text — may be a scanned page)"}\n\n`;
      }
      if (image && !off.image) {
        const d = await image.getDataUrl();
        if (d) {
          images.push(d);
          tags.push({ kind: "image", label: image.name });
          ctx += `## Attached image: "${image.name}" (from the library)\n\n`;
        }
      }
      if (sketch && !off.sketch) {
        const d = await sketch.getDataUrl();
        if (d) {
          images.push(d);
          tags.push({ kind: "sketch", label: sketch.title });
          ctx += `## Attached sketch: "${sketch.title}" (id=${sketch.id}; the learner's sketchboard drawing)\n\n`;
        }
      }
      if (video && !off.video) {
        tags.push({ kind: "video", label: video.title });
        ctx += `## Video the learner is watching: "${video.title}"\n${video.text || "(no transcript is available for this video yet)"}\n\n`;
      }
      if (browser && !off.browser) {
        tags.push({ kind: "browser", label: browser.title || browser.url });
        ctx += `## Browser page: ${browser.title} (${browser.url})\n${clip(browser.selection || browser.text, 12000)}\n\n`;
      }
      if (snapshotSelection && !off.selection) setSelection(null);
      const ok = await sendMessage({
        threadId: t.id,
        text: msg,
        apiContent: ctx ? `<workspace_context>\n${ctx.trim()}\n</workspace_context>\n\n${msg}` : undefined,
        context: tags,
        images,
        audios,
      });
      if (ok) setMentions([]);
      else setText(msg);
    } catch (e) {
      setText(msg);
      useApp.getState().showToast(`Couldn't send: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      sending.current = false;
    }
  }, [text, busy, thread, project.id, selection, note, pdf, image, sketch, video, browser, off, setSelection, mentions]);

  return (
    <div
      ref={rootRef}
      className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-paper via-paper/90 to-transparent px-3 pb-[max(12px,env(safe-area-inset-bottom))] pt-7"
      style={wide ? { paddingInline: WIDE_PAD } : undefined}
    >
      {chips.length > 0 && (
        <div className="no-scrollbar pointer-events-auto mb-2 flex gap-1.5 overflow-x-auto px-1">
          {chips.map((c) => (
            <span
              key={c.key}
              className={cn(
                "flex shrink-0 items-center gap-1 rounded-full py-1 pl-2.5 pr-1 text-[12px] font-medium transition-colors",
                c.active ? "bg-ink text-white" : "border border-dashed border-ink/25 text-muted"
              )}
            >
              <button
                onClick={() => setOff((o) => ({ ...o, [c.key]: !o[c.key] }))}
                className="flex max-w-[190px] items-center gap-1"
                title={c.active ? "Shared with Leo — tap to exclude" : "Tap to share with Leo"}
              >
                <CtxIcon kind={c.key} />
                <span className="truncate">{c.label}</span>
              </button>
              {c.key === "selection" ? (
                <button onClick={() => setSelection(null)} className="rounded-full p-0.5 opacity-70 hover:opacity-100" aria-label="Clear selection">
                  <X size={12} />
                </button>
              ) : (
                <span className="w-1" />
              )}
            </span>
          ))}
        </div>
      )}
      {mentions.length > 0 && (
        <div className="pointer-events-auto mb-2 flex flex-wrap gap-1.5 px-1">
          {mentions.map((m) => (
            <span key={m.key} className="flex items-center gap-1.5 rounded-full bg-ink py-1 pl-2.5 pr-1 text-[12px] font-medium text-white">
              {m.kind === "practice" ? <ClipboardCheck size={11} /> : <Paperclip size={11} />}
              <span className="max-w-[210px] truncate">
                {m.kind === "note" || m.kind === "sketch" || m.kind === "practice" ? m.name : m.name.replace(/\.[a-z0-9]{1,5}$/i, "")}
                {m.kind === "pdf" ? ` · p.${m.page}` : m.kind === "audio" ? ` · ${formatClock(m.start ?? 0)}–${formatClock(m.end ?? 0)}` : ""}
              </span>
              <button onClick={() => setMentions((list) => list.filter((x) => x.key !== m.key))} aria-label={`Remove ${m.name}`} className="rounded-full p-0.5 opacity-70 hover:opacity-100">
                <X size={11} />
              </button>
            </span>
          ))}
        </div>
      )}
      <div
        className={cn(
          "pointer-events-auto relative flex min-h-[52px] items-center gap-1 rounded-[26px] bg-elevated p-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.13)] ring-1 ring-line transition-[box-shadow,transform] duration-200",
          focused && "-translate-y-px shadow-[0_14px_36px_rgba(0,0,0,0.18)] ring-ink/25"
        )}
      >
        <MentionPicker project={project} open={pickerOpen} query={mentionQuery} onClose={() => setPickerOpen(false)} onPick={addMention} />
        <textarea
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          ref={ta}
          rows={1}
          value={text}
          onChange={(e) => onTextChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Escape" && pickerOpen) {
              e.preventDefault();
              setPickerOpen(false);
              return;
            }
            if (pickerOpen && (e.key === "Enter" || e.key === "ArrowDown" || e.key === "ArrowUp")) return;
            if (e.key === "Enter" && !e.shiftKey && !isTouch && enterToSend) {
              e.preventDefault();
              void send();
            }
          }}
          placeholder={busy ? "Leo is replying…" : practice ? "Anything to focus on? (optional)" : "Message Leo…"}
          aria-label="Message Leo"
          aria-describedby={showHint ? hintId : undefined}
          dir="auto"
          className="max-h-[140px] min-h-[40px] flex-1 resize-none bg-transparent py-2 pl-3 pr-1 text-[16px] leading-snug outline-none placeholder:text-muted/80"
        />
        {whisperMic ? (
          <MicButton context="Leo chat" confirmLabel="Put in message" onConfirm={(t) => setText((v) => (v.trim() ? `${v.trimEnd()} ${t}` : t))} />
        ) : showDictation && (
          <button
            onClick={() => void dictation()}
            className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors", listening ? "bg-danger-fg text-white" : "text-ink/70 hover:bg-ink/[0.08] hover:text-ink")}
            aria-label={listening ? "Stop dictation" : "Dictate"}
            aria-pressed={listening}
          >
            <Mic size={17} />
          </button>
        )}
        {busy ? (
          <button onClick={stopStreaming} className="stop-ring pop flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-white transition-transform active:scale-90" aria-label="Stop">
            <Square size={13} fill="currentColor" />
          </button>
        ) : (
          <button
            onClick={() => void send()}
            disabled={!text.trim() && !practice}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-white transition-[opacity,transform] duration-200 ease-[var(--ease-spring)] enabled:hover:scale-105 enabled:active:scale-90 disabled:scale-90 disabled:opacity-25"
            aria-label="Send"
          >
            <ArrowUp size={18} strokeWidth={2.5} />
          </button>
        )}
      </div>
      {showHint && (
        <p id={hintId} className="fade-in px-4 pt-1.5 text-[11px] leading-none text-muted">
          <span className="font-semibold text-ink/70">@</span> mention a file, start a practice test or explain it · <span className="font-semibold text-ink/70">Shift+Enter</span> for a new line
        </p>
      )}
    </div>
  );
}

const DOCKS: { id: ChatDock; label: string; icon: ReactNode; wideOnly?: boolean }[] = [
  { id: "float", label: "Floating", icon: <PictureInPicture2 size={15} /> },
  { id: "right", label: "Dock right", icon: <PanelRight size={15} />, wideOnly: true },
  { id: "left", label: "Dock left", icon: <PanelLeft size={15} />, wideOnly: true },
  { id: "bottom", label: "Dock below", icon: <PanelBottom size={15} /> },
  { id: "full", label: "Fullscreen", icon: <Maximize2 size={15} /> },
];

/** Where the chat sits: floating, docked beside or below the work, or fullscreen. */
function DockMenu({ narrow }: { narrow: boolean }) {
  const dock = useLayout((s) => s.tempDock ?? s.chatDock);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const away = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    const key = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.stopPropagation();
      setOpen(false);
    };
    document.addEventListener("pointerdown", away);
    document.addEventListener("keydown", key, true);
    return () => {
      document.removeEventListener("pointerdown", away);
      document.removeEventListener("keydown", key, true);
    };
  }, [open]);
  // Phones have no room for a side column, so a side dock shows as "below" there.
  const current = narrow && (dock === "left" || dock === "right") ? "bottom" : dock;
  return (
    <div ref={ref} className="relative shrink-0">
      <HeaderBtn onClick={() => setOpen((o) => !o)} label="Chat position" active={open}>
        <PanelRight size={16} />
      </HeaderBtn>
      {open && (
        <div role="menu" aria-label="Chat position" className="absolute right-0 top-full z-30 mt-1 w-44 rounded-2xl bg-elevated p-1 shadow-[0_16px_40px_rgba(0,0,0,0.2)] ring-1 ring-line">
          {DOCKS.filter((d) => !(narrow && d.wideOnly)).map((d) => (
            <button
              key={d.id}
              type="button"
              role="menuitemradio"
              aria-checked={current === d.id}
              onClick={() => {
                useLayout.getState().setChatDock(d.id);
                setOpen(false);
              }}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-[13px] font-medium transition-colors",
                current === d.id ? "bg-ink/[0.07] text-ink" : "text-ink/80 hover:bg-ink/[0.04]"
              )}
            >
              <span className="text-muted">{d.icon}</span>
              {d.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
