import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { History, Pin, Trash2 } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { confirmDeletion } from "@/lib/settings";
import { useWindows, type FloatWin } from "@/lib/windows";
import { trashItem } from "@/lib/trash";
import { setPinned } from "@/lib/pins";
import ItemHistorySheet from "@/components/library/ItemHistorySheet";
import { FloatingWindow, WinBtn } from "@/components/FloatingWindow";
import { ToolBody, TOOL_ICON, TOOL_SIZE } from "@/components/tools/Tools";

/** Every floating window of a project: the library tools the learner has open. */
export default function ProjectWindows({ project }: { project: Project }) {
  const wins = useWindows((s) => s.wins);
  const tools = useLiveQuery(() => db.tools.where("projectId").equals(project.id).toArray(), [project.id]);
  const [historyToolId, setHistoryToolId] = useState<string | null>(null);
  const mine = wins.filter((w) => w.projectId === project.id);
  const order = mine.map((w) => w.id);

  // A tool removed from the library takes its window with it.
  useEffect(() => {
    if (!tools) return;
    for (const w of wins) if (w.projectId === project.id && !tools.some((t) => t.id === w.toolId && !t.deletedAt)) useWindows.getState().close(w.id);
  }, [tools, wins, project.id]);

  const focus = (id: string) => useWindows.getState().focus(id);
  const close = (id: string) => useWindows.getState().close(id);
  // Rendered in a stable order so focusing a window never remounts or moves another; stacking comes from z.
  const stable = [...mine].sort((a, b) => a.id.localeCompare(b.id));

  return (
    <>
      {stable.map((w: FloatWin) => {
        const z = 41 + Math.min(order.indexOf(w.id), 8);
        const tool = tools?.find((t) => t.id === w.toolId);
        if (!tool || tool.deletedAt) return null;
        const remove = async () => {
          if (!(await confirmDeletion(`“${tool.title}” and what it saved will go to the Trash.`, { title: "Remove tool?", confirmLabel: "Remove" }))) return;
          close(w.id);
          await trashItem("tool", tool.id);
        };
        return (
          <FloatingWindow
            key={w.id}
            storageKey={`tool:${tool.id}`}
            label={tool.title}
            title={tool.title}
            icon={TOOL_ICON[tool.kind](15)}
            size={TOOL_SIZE[tool.kind]}
            minSize={{ w: 260, h: 220 }}
            index={order.indexOf(w.id)}
            z={z}
            onFocus={() => focus(w.id)}
            onClose={() => close(w.id)}
            actions={
              <>
                <WinBtn onClick={() => void setPinned("tool", tool.id, !tool.pinned)} label={tool.pinned ? "Unpin from Leo's context" : "Pin for Leo"} className={tool.pinned ? "bg-ink text-on-ink hover:bg-ink/90" : ""}>
                  <Pin size={13} fill={tool.pinned ? "currentColor" : "none"} />
                </WinBtn>
                <WinBtn onClick={() => setHistoryToolId(tool.id)} label="Version history">
                  <History size={14} />
                </WinBtn>
                <WinBtn onClick={() => void remove()} label="Remove tool" className="hover:bg-danger-bg hover:text-danger-fg">
                  <Trash2 size={14} />
                </WinBtn>
              </>
            }
          >
            <ToolBody tool={tool} />
          </FloatingWindow>
        );
      })}
      {historyToolId && <ItemHistorySheet kind="tool" id={historyToolId} open={!!historyToolId} onClose={() => setHistoryToolId(null)} />}
    </>
  );
}
