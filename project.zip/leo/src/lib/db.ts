import Dexie, { type Table } from "dexie";
import type { AvatarLook } from "./avatar";

export type PlacementStatus = "pending" | "in_progress" | "done";

/** "icon" is a minimal line icon by name (see lib/projectIcon). "emoji" is kept so older projects and backups still load. */
export type ProjectIcon = { kind: "icon"; name: string } | { kind: "emoji"; emoji: string } | { kind: "image"; src: string };

export interface Project {
  id: string;
  name: string;
  tag: string;
  color: string;
  avatar?: AvatarLook;
  /** Emoji or uploaded image/logo shown instead of a letter. */
  icon?: ProjectIcon;
  /** One home-screen folder, never a nested note folder. Missing means home. */
  folderId?: string;
  createdAt: number;
  updatedAt: number;
  /** "Explain it like I would" — written at the start, compared later on request only. */
  explanation?: ProjectExplanation;
  /** @deprecated The scratchpad was removed. rescueScratchpad() moves old text into a note and deletes this field. */
  scratchpad?: string;
  placement: {
    status: PlacementStatus;
    level?: string;
    summary?: string;
    startingPoint?: string;
    at?: number;
  };
}

export interface ExplanationEntry {
  text: string;
  at: number;
}

export interface ProjectExplanation {
  /** How the learner explained the topic at the start. */
  before?: ExplanationEntry;
  /** The latest explanation written for a comparison. */
  after?: ExplanationEntry;
}

/**
 * @deprecated A thought from the removed cross-project scratchpad. The `scratch` table stays in the
 * schema so existing databases and older backups still open; rescueScratchpad() turns its rows into
 * notes and leaves it empty.
 */
export interface ScratchItem {
  id: string;
  text: string;
  createdAt: number;
  updatedAt: number;
}

export type ToolKind = "clock" | "calculator" | "converter" | "checklist" | "flashcards";

/** A small built-in tool that lives in a project's library. It only runs once it has been added. */
export interface ToolItem {
  id: string;
  projectId: string;
  kind: ToolKind;
  title: string;
  /** Tool-specific saved state (timers, checklist items, flash cards…). */
  state: Record<string, unknown>;
  tags?: string[];
  /** Metadata snapshots from Leo's approved edits. */
  versions?: ItemMetadataVersion[];
  /** Pinned: always in Leo's context for this project. */
  pinned?: boolean;
  /** Soft-deleted: in the project's Trash until restored or deleted for good. */
  deletedAt?: number;
  createdAt: number;
  updatedAt: number;
}

export interface TestQuestion {
  q: string;
  /** Multiple choice when present; otherwise an open (typed) answer. */
  options?: string[];
  answer?: number;
  modelAnswer?: string;
  concept?: string;
  points?: number;
}

export interface TestAttempt {
  answers: (number | string | null)[];
  startedAt: number;
  finishedAt: number;
  /** Auto-graded multiple-choice score. */
  correct: number;
  graded: number;
  timedOut: boolean;
}

/** A timed practice test Leo built from library material. */
export interface PracticeTest {
  id: string;
  projectId: string;
  title: string;
  /** Project Trash; omitted for active tests. */
  deletedAt?: number;
  minutes: number;
  source?: string;
  questions: TestQuestion[];
  attempts: TestAttempt[];
  createdAt: number;
}

export interface ProjectFolder {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
}

export type FileKind = "pdf" | "image" | "audio" | "video" | "text";

export interface LibFile {
  id: string;
  projectId: string;
  name: string;
  kind: FileKind;
  mime: string;
  size: number;
  blob: Blob;
  thumb?: string;
  peaks?: number[];
  duration?: number;
  pages?: number;
  recorded?: boolean;
  /** Text indexing for grounding: pending → done | none (no extractable text) | failed */
  indexed?: "pending" | "done" | "none" | "failed";
  /** PDF pages with no extractable text (scans, figures): Leo sees them as images when it reads them. */
  visualPages?: number[];
  /** Why indexing produced nothing, shown to Leo (e.g. "transcription off"). */
  indexNote?: string;
  /** 2+ = poster frame captured after a real seek (older uploads could be black). */
  thumbVersion?: number;
  /** "youtube" items stream from YouTube; uploaded files carry their own blob. */
  source?: "upload" | "youtube";
  tags?: string[];
  /** Metadata snapshots from Leo's approved edits (the original Blob is not duplicated). */
  versions?: ItemMetadataVersion[];
  /** Pinned: always in Leo's context for this project. */
  pinned?: boolean;
  /** Soft-deleted: in the project's Trash until restored or deleted for good. */
  deletedAt?: number;
  /** The YouTube video id, when this item is a link rather than a file. */
  youtubeId?: string;
  /** The page the video was added from (watch, youtu.be, shorts…). */
  youtubeUrl?: string;
  channel?: string;
  /** The video's transcript, with timestamps, so Leo can teach and quiz from it. */
  transcript?: TranscriptSegment[];
  transcriptSource?: "captions" | "pasted" | "audio";
  transcriptState?: "fetching" | "done" | "unavailable" | "failed";
  /** Plain-language reason a transcript isn't there, shown on the video page. */
  transcriptNote?: string;
  createdAt: number;
}

/** One span of speech with its start and end in seconds from the start of a video. */
export interface TranscriptSegment {
  t0: number;
  t1: number;
  text: string;
}

/**
 * Annotations belong to one PDF page and are saved with the document, in page-relative units
 * (0..1 of the page's width and height), so they stay in place at any zoom or pane width.
 */
export interface PdfRect {
  x: number;
  y: number;
  w: number;
  h: number;
}
export interface PdfPoint {
  x: number;
  y: number;
}
export type PdfAnnotation =
  | { id: string; projectId: string; fileId: string; page: number; kind: "highlight"; color: string; rects: PdfRect[]; text: string; createdAt: number; updatedAt: number }
  | { id: string; projectId: string; fileId: string; page: number; kind: "ink"; color: string; width: number; points: PdfPoint[]; createdAt: number; updatedAt: number }
  | { id: string; projectId: string; fileId: string; page: number; kind: "note"; text: string; createdAt: number; updatedAt: number };

/** A folder in a project's notes tree. Folders also exist implicitly through their notes. */
export interface Folder {
  id: string;
  projectId: string;
  /** Full path, e.g. "Biology/Cells". */
  path: string;
  createdAt: number;
}

export interface Note {
  /** Labels added by the learner or (with approval) by Leo. */
  tags?: string[];
  /** Pinned: always in Leo's context for this project. */
  pinned?: boolean;
  /** Soft-deleted: in the project's Trash until restored or deleted for good. */
  deletedAt?: number;
  /** Direct links to other items (a PDF page, a video timestamp, a sketch, another note). */
  links?: ItemLink[];
  /** Folder path inside the project (e.g. "Biology/Cells"). Empty or missing = root. */
  folder?: string;
  id: string;
  projectId: string;
  title: string;
  content: string;
  /** Legacy: the text before Leo's last "replace". Superseded by `versions`; still offered as a restore point. */
  previousContent?: string;
  /** Who created the note. Never changed by later edits. */
  author?: "user" | "ai";
  /** Who changed the content last (Leo's edits set "ai"; the editor sets "user"). */
  lastEditedBy?: "user" | "ai";
  /** Passages an AI note was grounded in (file page or media timestamp). */
  sources?: SourceRef[];
  /** Up to NOTE_VERSION_LIMIT earlier versions, oldest first, newest last. Pushed before each of Leo's edits. */
  versions?: NoteVersion[];
  createdAt: number;
  updatedAt: number;
}

/** A direct link from a note to another item (or a spot inside it). */
export interface ItemLink {
  id: string;
  targetKind: "note" | "sketch" | "file";
  targetId: string;
  /** PDF page (1-based) when the target is a PDF. */
  page?: number;
  /** Start second when the target is audio/video. */
  t0?: number;
  label?: string;
}

export interface SketchVersion {
  scene: string;
  title?: string;
  tags?: string[];
  at: number;
  replacedBy: "user" | "ai";
}

/** Small snapshots for file / tool metadata; files never duplicate their Blob. */
export interface ItemMetadataVersion {
  name: string;
  tags?: string[];
  state?: Record<string, unknown>;
  at: number;
  replacedBy: "user" | "ai";
}

export const SKETCH_VERSION_LIMIT = 10;

export interface NoteVersion {
  title: string;
  content: string;
  folder?: string;
  tags?: string[];
  links?: ItemLink[];
  at: number;
  /** Who made the edit that replaced this version. */
  replacedBy: "user" | "ai";
}

export const NOTE_VERSION_LIMIT = 10;

export interface Sketch {
  tags?: string[];
  /** Pinned: always in Leo's context for this project. */
  pinned?: boolean;
  /** Soft-deleted: in the project's Trash until restored or deleted for good. */
  deletedAt?: number;
  /** Earlier scenes, saved before each of Leo's edits (newest last). */
  versions?: SketchVersion[];
  id: string;
  projectId: string;
  title: string;
  scene: string;
  thumb?: string;
  thumbLight?: string;
  thumbDark?: string;
  /** Fingerprint of the scene these previews were rendered from. */
  thumbScene?: string;
  thumbVersion?: number;
  createdAt: number;
  updatedAt: number;
}

export type ChatMode = "placement" | "teach" | "test" | "ask";

export interface Thread {
  id: string;
  projectId: string;
  /** Project Trash; messages remain with the thread for restoration. */
  deletedAt?: number;
  title: string;
  mode: ChatMode;
  providerId?: string;
  model?: string;
  /** How hard the model should think for this chat. Missing = "auto" (the provider's own default). */
  thinking?: ThinkingLevel;
  createdAt: number;
  updatedAt: number;
}

/** "auto" sends nothing; the rest map to each API's reasoning setting (see lib/ai/thinking.ts). */
export type ThinkingLevel = "auto" | "low" | "medium" | "high" | "xhigh";

export interface ActionResult {
  type: string;
  label: string;
  ok: boolean;
}

/**
 * An action Leo proposed that needs the learner's OK before it runs (replacing a learner's note,
 * deleting a memory). Stored on the assistant message; the chat shows Apply / Dismiss.
 */
export interface PendingAction {
  id: string;
  /** The validated action as Leo emitted it (JSON-serializable). */
  action: { type: string } & Record<string, unknown>;
  label: string;
  status: "pending" | "applied" | "dismissed" | "failed";
  /** Outcome text once applied/failed. */
  result?: string;
}

export interface ContextTag {
  kind: string;
  label: string;
}

/**
 * What one assistant turn was sent and what came back, for the chat-log export. Stored on the message
 * (Dexie indexes nothing here, so no schema version bump is needed). Never includes an API key.
 */
export interface TurnMeta {
  model?: string;
  /** Provider display name, e.g. "OpenRouter". */
  provider?: string;
  providerType?: string;
  baseUrl?: string;
  /** max_tokens actually sent, or "not sent" when the request carried none. */
  maxTokens?: number | "not sent";
  /** Why the stream ended, in the provider's own wording. */
  finishReason?: string;
  /** Characters received. */
  chars?: number;
  durationMs?: number;
  error?: string;
  /** The system prompt sent on this turn. Reported once per thread in the export. */
  systemPrompt?: string;
}

export interface Message {
  id: string;
  threadId: string;
  projectId: string;
  role: "user" | "assistant";
  content: string;
  /** Content actually sent to the model, if different from the displayed content */
  apiContent?: string;
  hidden?: boolean;
  context?: ContextTag[];
  images?: string[];
  /** Audio clips attached from an @mention (for providers that support audio input). */
  audios?: string[];
  actionResults?: ActionResult[];
  /** [S1]… labels of the SOURCES this reply was given, so citations become tappable. */
  citations?: CitationRef[];
  /** Proposed actions waiting for the learner's Apply / Dismiss. */
  pending?: PendingAction[];
  answers?: Record<number, number>;
  /** Quiz indices the learner disputed (stats were reverted). */
  disputed?: number[];
  error?: boolean;
  /** Stream ended early (error/abort). Actions were NOT executed. */
  partial?: boolean;
  /** The model hit its output limit (finishReason length / max_tokens / MAX_TOKENS). Shown as a note; never written into `content`. */
  truncated?: boolean;
  /** The last step of the turn still wanted to read or retry: the chat offers a Continue chip. */
  continuable?: boolean;
  /** Provider/stream details for this assistant turn, for the chat-log export. */
  turn?: TurnMeta;
  createdAt: number;
}

export type ConceptStatus = "new" | "learning" | "shaky" | "solid";

export interface Concept {
  id: string;
  projectId: string;
  deletedAt?: number;
  name: string;
  parentId?: string;
  status: ConceptStatus;
  note?: string;
  correct: number;
  attempts: number;
  /** Last 10 graded outcomes, newest last (1 = correct). Drives recent accuracy. */
  recent?: number[];
  /** Spaced review: interval in days and the next due timestamp. */
  interval?: number;
  nextReview?: number;
  lastReviewed?: number;
  createdAt: number;
  updatedAt: number;
}

export type PointKind = "careful" | "confused" | "next";

export interface Point {
  id: string;
  projectId: string;
  deletedAt?: number;
  kind: PointKind;
  text: string;
  author: "user" | "ai";
  done: boolean;
  resolvedBy?: "user" | "ai";
  createdAt: number;
}

/** A searchable slice of a library file or note, used for grounding and search. */
export interface Chunk {
  id: string;
  projectId: string;
  sourceId: string;
  sourceKind: "file" | "note";
  sourceName: string;
  /** 1-based page for PDFs; 0 for notes/text. */
  page: number;
  text: string;
  /** Audio/video transcript chunks: start and end in seconds. */
  t0?: number;
  t1?: number;
  /** "ai" = written by Leo (its own notes); ranked lower so Leo doesn't cite itself. */
  author?: "user" | "ai";
}

/** Where a grounded passage came from: a file page or a media timestamp. */
export interface SourceRef {
  fileId: string;
  page?: number;
  t0?: number;
}

/** A citation Leo used in a reply ([S1] → its passage), so the chip can open the exact spot. */
export interface CitationRef {
  label: string;
  fileId?: string;
  noteId?: string;
  name: string;
  page?: number;
  t0?: number;
}

/** A persisted quiz question, reviewed on a spaced schedule without an LLM call. */
export interface Card {
  id: string;
  projectId: string;
  question: string;
  options: string[];
  answer: number;
  explanation?: string;
  concept: string;
  source?: string;
  /** Spaced review: interval in days, next due timestamp, review count. */
  interval: number;
  nextReview: number;
  reps: number;
  lapses: number;
  createdAt: number;
  updatedAt: number;
}

export type ProviderType = "openai" | "anthropic" | "gemini";

/** Special connection kinds that need more than a base URL and a key. */
export type ProviderKind = "chatgpt-oauth";

export interface Provider {
  id: string;
  name: string;
  type: ProviderType;
  baseUrl: string;
  apiKey: string;
  /** Models discovered from the provider; only `models` below are enabled for chat. */
  catalogModels?: string[];
  models: string[];
  defaultModel: string;
  /** Request timeout in seconds (default 120). */
  timeout?: number;
  /** Max output tokens where the API requires it (Anthropic). */
  maxTokens?: number;
  /** "chatgpt-oauth": the local openai-oauth endpoint. No API key; requests go through the local CORS proxy. */
  kind?: ProviderKind;
  /** Local Node.js CORS proxy that fronts `baseUrl` for the browser (kind "chatgpt-oauth"). Empty = call baseUrl directly. */
  proxyUrl?: string;
  createdAt: number;
}

export type MemoryKind = "level" | "goal" | "preference" | "strength" | "weakness" | "fact";

/** Long-term learner memory. projectId="*" means applies across all learning projects. */
export interface Memory {
  id: string;
  projectId: string;
  deletedAt?: number;
  kind: MemoryKind;
  text: string;
  createdAt: number;
  updatedAt: number;
}

export interface KV {
  key: string;
  value: unknown;
}

class HarnessDB extends Dexie {
  projects!: Table<Project, string>;
  projectFolders!: Table<ProjectFolder, string>;
  files!: Table<LibFile, string>;
  notes!: Table<Note, string>;
  folders!: Table<Folder, string>;
  sketches!: Table<Sketch, string>;
  threads!: Table<Thread, string>;
  messages!: Table<Message, string>;
  concepts!: Table<Concept, string>;
  points!: Table<Point, string>;
  providers!: Table<Provider, string>;
  memories!: Table<Memory, string>;
  chunks!: Table<Chunk, string>;
  cards!: Table<Card, string>;
  /** Page highlights, pen strokes and page notes for PDFs. */
  pdfAnnotations!: Table<PdfAnnotation, string>;
  scratch!: Table<ScratchItem, string>;
  tools!: Table<ToolItem, string>;
  tests!: Table<PracticeTest, string>;
  kv!: Table<KV, string>;

  constructor() {
    super("harness");
    // Migration habit: never edit an existing version block. Add a new
    // this.version(n) with only the changed stores, plus .upgrade() for data.
    this.version(1).stores({
      projects: "id, updatedAt",
      files: "id, projectId, createdAt",
      notes: "id, projectId, updatedAt",
      sketches: "id, projectId, updatedAt",
      threads: "id, projectId, updatedAt",
      messages: "id, threadId, projectId, createdAt",
      concepts: "id, projectId",
      points: "id, projectId",
      providers: "id",
      kv: "key",
    });
    this.version(2)
      .stores({
        chunks: "id, projectId, sourceId",
        concepts: "id, projectId, nextReview",
      })
      .upgrade(async (tx) => {
        await tx.table("concepts").toCollection().modify((c: Concept) => {
          c.recent ??= [];
          c.interval ??= 0;
        });
        await tx.table("files").toCollection().modify((f: LibFile) => {
          if (!f.indexed) f.indexed = f.kind === "pdf" ? "pending" : "none";
        });
      });
    this.version(3)
      .stores({
        memories: "id, projectId, kind, updatedAt",
      })
      .upgrade(async (tx) => {
        // Before the catalog/enabled split, every stored model was enabled.
        await tx.table("providers").toCollection().modify((p: Provider) => {
          p.catalogModels ??= [...p.models];
        });
      });
    this.version(4).stores({
      folders: "id, projectId",
    });
    this.version(5).stores({
      cards: "id, projectId, nextReview",
    });
    this.version(6).stores({
      files: "id, projectId, createdAt, youtubeId",
      pdfAnnotations: "id, fileId, projectId, page, updatedAt",
    });
    this.version(7).stores({
      projects: "id, updatedAt, folderId",
      projectFolders: "id, name, updatedAt",
    });
    this.version(8).stores({
      scratch: "id, updatedAt",
      tools: "id, projectId, updatedAt",
      tests: "id, projectId, createdAt",
    });
  }
}

export const SCHEMA_VERSION = 8;

export const db = new HarnessDB();

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 9);

export async function touchProject(projectId: string) {
  await db.projects.update(projectId, { updatedAt: Date.now() });
}

export async function deleteProject(projectId: string) {
  await db.transaction(
    "rw",
    [db.projects, db.folders, db.files, db.notes, db.sketches, db.threads, db.messages, db.concepts, db.points, db.chunks, db.memories, db.cards, db.pdfAnnotations, db.tools, db.tests],
    async () => {
      await db.tools.where("projectId").equals(projectId).delete();
      await db.tests.where("projectId").equals(projectId).delete();
      await db.chunks.where("projectId").equals(projectId).delete();
      await db.cards.where("projectId").equals(projectId).delete();
      await db.pdfAnnotations.where("projectId").equals(projectId).delete();
      await db.memories.where("projectId").equals(projectId).delete();
      await db.files.where("projectId").equals(projectId).delete();
      await db.folders.where("projectId").equals(projectId).delete();
      await db.notes.where("projectId").equals(projectId).delete();
      await db.sketches.where("projectId").equals(projectId).delete();
      await db.threads.where("projectId").equals(projectId).delete();
      await db.messages.where("projectId").equals(projectId).delete();
      await db.concepts.where("projectId").equals(projectId).delete();
      await db.points.where("projectId").equals(projectId).delete();
      await db.projects.delete(projectId);
    }
  );
}

export async function getKV<T>(key: string, fallback: T): Promise<T> {
  const row = await db.kv.get(key);
  return (row?.value as T) ?? fallback;
}

export async function setKV(key: string, value: unknown) {
  await db.kv.put({ key, value });
}

export const PROJECT_COLORS: Record<string, { hex: string; soft: string; name: string }> = {
  ink: { hex: "#17171a", soft: "#e9e8e3", name: "Ink" },
  blue: { hex: "#2f66e0", soft: "#e3ecfe", name: "Blue" },
  green: { hex: "#16a072", soft: "#dcf3ea", name: "Green" },
  amber: { hex: "#e08a12", soft: "#fcefd9", name: "Amber" },
  rose: { hex: "#d2354e", soft: "#fde3e7", name: "Rose" },
  violet: { hex: "#7352e8", soft: "#ece7fe", name: "Violet" },
  teal: { hex: "#0e9bb0", soft: "#d9f2f5", name: "Teal" },
  orange: { hex: "#ef6a2c", soft: "#fde6da", name: "Orange" },
};

export const colorOf = (key: string) => PROJECT_COLORS[key] ?? PROJECT_COLORS.ink;

export const STATUS_META: Record<ConceptStatus, { label: string; color: string; desc: string }> = {
  new: { label: "Not started", color: "var(--status-new)", desc: "Not yet covered" },
  learning: { label: "Learning", color: "#3b82f6", desc: "Being taught" },
  shaky: { label: "Shaky", color: "#e5940c", desc: "Mistakes or gaps" },
  solid: { label: "Solid", color: "#16a372", desc: "Demonstrated" },
};

export const POINT_META: Record<PointKind, { label: string; short: string; color: string; soft: string }> = {
  careful: { label: "Be careful about", short: "Careful", color: "#e0920f", soft: "#fdf1dc" },
  confused: { label: "Not understood yet", short: "Unclear", color: "#e5485e", soft: "#fde4e8" },
  next: { label: "Learn next", short: "Next", color: "#3b74f0", soft: "#e3ecfe" },
};
