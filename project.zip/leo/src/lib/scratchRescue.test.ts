import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});
vi.mock("@/lib/retrieval", () => ({ indexNote: vi.fn(async () => {}) }));

import { db, type Project } from "@/lib/db";
import { rescueScratchpad, SCRATCH_PROJECT_NAME } from "./scratchRescue";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const project = (id: string, over: Record<string, unknown> = {}) =>
  ({ id, name: `Project ${id}`, tag: "", color: "ink", createdAt: 1, updatedAt: 1, placement: { status: "pending" }, ...over }) as unknown as Project;
const thought = (id: string, text: string, at: number) => ({ id, text, createdAt: at, updatedAt: at });

beforeEach(() => fake.reset());

describe("the scratchpad was removed, what was written in it was not", () => {
  it("does nothing when there is nothing to rescue", async () => {
    await db.projects.add(project("a"));
    expect(await rescueScratchpad()).toEqual({ projectNotes: 0, thoughts: 0 });
    expect(await db.notes.toArray()).toEqual([]);
    expect(await db.projects.toArray()).toHaveLength(1);
  });

  it("a project's scratchpad text becomes a note in that project", async () => {
    await db.projects.add(project("a", { scratchpad: "remember: ask about osmosis\nsecond line" }));
    await db.projects.add(project("b", { scratchpad: "   " }));
    await db.projects.add(project("c"));
    expect(await rescueScratchpad()).toEqual({ projectNotes: 1, thoughts: 0 });
    const notes = await db.notes.toArray();
    expect(notes).toHaveLength(1);
    expect(notes[0]).toMatchObject({ projectId: "a", title: "Scratchpad", content: "remember: ask about osmosis\nsecond line", author: "user" });
    // The legacy field is cleared everywhere, including the blank one.
    for (const p of await db.projects.toArray()) expect("scratchpad" in p).toBe(false);
  });

  it("does not overwrite a note that is already called Scratchpad", async () => {
    await db.projects.add(project("a", { scratchpad: "new text" }));
    await db.notes.add({ id: "x", projectId: "a", title: "Scratchpad", content: "the learner's own note", createdAt: 1, updatedAt: 1 });
    await rescueScratchpad();
    const notes = await db.notes.toArray();
    expect(notes.map((n) => n.title).sort()).toEqual(["Scratchpad", "Scratchpad 2"]);
    expect(notes.find((n) => n.id === "x")!.content).toBe("the learner's own note");
  });

  it("cross-project thoughts become notes in a Scratchpad project, and the old table is emptied", async () => {
    await db.projects.add(project("a"));
    await fake.scratch.add(thought("s2", "Second thought: compare mitosis / meiosis?\nmore detail", 200));
    await fake.scratch.add(thought("s1", "First thought", 100));
    await fake.scratch.add(thought("s3", "   ", 300));
    const r = await rescueScratchpad();
    expect(r).toMatchObject({ projectNotes: 0, thoughts: 2 });
    const home = (await db.projects.toArray()).find((p) => p.name === SCRATCH_PROJECT_NAME)!;
    expect(home).toBeTruthy();
    expect(r.projectId).toBe(home.id);
    const notes = (await db.notes.toArray()).sort((x, y) => x.createdAt - y.createdAt);
    expect(notes.map((n) => [n.projectId, n.title, n.createdAt])).toEqual([
      [home.id, "First thought", 100],
      [home.id, "Second thought - compare mitosis - meiosis", 200],
    ]);
    expect(notes[1].content).toBe("Second thought: compare mitosis / meiosis?\nmore detail");
    expect(await fake.scratch.toArray()).toEqual([]);
  });

  it("is idempotent, and reuses the Scratchpad project when older data arrives later (a backup import)", async () => {
    await fake.scratch.add(thought("s1", "First thought", 100));
    const first = await rescueScratchpad();
    expect(await rescueScratchpad()).toEqual({ projectNotes: 0, thoughts: 0 });
    await fake.scratch.add(thought("s9", "First thought", 900));
    const again = await rescueScratchpad();
    expect(again.projectId).toBe(first.projectId);
    expect((await db.projects.toArray()).filter((p) => p.name === SCRATCH_PROJECT_NAME)).toHaveLength(1);
    expect((await db.notes.toArray()).map((n) => n.title).sort()).toEqual(["First thought", "First thought 2"]);
  });
});
