import { create } from "zustand";
import { persist } from "zustand/middleware";

/** A floating window opened over a project: a library tool. */
export interface FloatWin {
  /** Stable id: `tool:<toolId>`. */
  id: string;
  kind: "tool";
  projectId: string;
  toolId?: string;
}

interface WindowsState {
  /** Open windows; the last one is on top. */
  wins: FloatWin[];
  open: (w: FloatWin) => void;
  close: (id: string) => void;
  focus: (id: string) => void;
  toggle: (w: FloatWin) => void;
}

export const toolWinId = (toolId: string) => `tool:${toolId}`;

/** Only tool windows are restored. A list saved by an older build may still hold the removed scratchpad window. */
export function restorableWindows(saved: unknown): FloatWin[] {
  const wins = (saved as { wins?: unknown } | null | undefined)?.wins;
  if (!Array.isArray(wins)) return [];
  return wins.filter((w): w is FloatWin => !!w && typeof w === "object" && (w as FloatWin).kind === "tool" && typeof (w as FloatWin).toolId === "string" && typeof (w as FloatWin).id === "string");
}

export const useWindows = create<WindowsState>()(
  persist(
    (set, get) => ({
      wins: [],
      open: (w) => set({ wins: [...get().wins.filter((x) => x.id !== w.id), w] }),
      close: (id) => set({ wins: get().wins.filter((x) => x.id !== id) }),
      focus: (id) => {
        const wins = get().wins;
        const w = wins.find((x) => x.id === id);
        if (!w || wins[wins.length - 1]?.id === id) return;
        set({ wins: [...wins.filter((x) => x.id !== id), w] });
      },
      toggle: (w) => (get().wins.some((x) => x.id === w.id) ? get().close(w.id) : get().open(w)),
    }),
    {
      name: "harness.windows",
      partialize: (s) => ({ wins: s.wins }),
      merge: (saved, current) => ({ ...current, wins: restorableWindows(saved) }),
    }
  )
);

/** Open a library tool as a floating window (never as a full page). */
export const openToolWindow = (projectId: string, toolId: string) => useWindows.getState().open({ id: toolWinId(toolId), kind: "tool", projectId, toolId });
