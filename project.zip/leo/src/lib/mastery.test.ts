import { describe, expect, it } from "vitest";
import { leafConcepts } from "./mastery";
import { readableTitle } from "./notes";

describe("mastery counts the leaves of the knowledge map", () => {
  it("leaves out concepts that only group others", () => {
    const c = (id: string, parentId?: string) => ({ id, parentId });
    const map = [c("structure"), c("organelles", "structure"), c("membrane", "structure"), c("transport"), c("osmosis", "transport"), c("alone")];
    expect(leafConcepts(map).map((x) => x.id)).toEqual(["organelles", "membrane", "osmosis", "alone"]);
    expect(leafConcepts([])).toEqual([]);
  });
});

describe("a sentence becomes a file name that still reads well", () => {
  it("turns a colon into a spaced dash and drops a trailing question mark", () => {
    expect(readableTitle("Cell biology: key ideas")).toBe("Cell biology - key ideas");
    expect(readableTitle("What is osmosis?")).toBe("What is osmosis");
    expect(readableTitle("Meeting at 10:30")).toBe("Meeting at 10-30");
    expect(readableTitle("  Plain title  ")).toBe("Plain title");
    // Already a file name: unchanged, so comparing titles is stable.
    expect(readableTitle(readableTitle("Cells: an overview"))).toBe("Cells - an overview");
  });
});
