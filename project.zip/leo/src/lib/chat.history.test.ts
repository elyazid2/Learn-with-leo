import { describe, expect, it } from "vitest";
import type { Message } from "./db";
import { buildHistory, collapseActionResults, CONTINUE_RESULTS, CUT_OFF_NOTICE, resultsMessage, stepNotice } from "./chat";
import { fullResultIndexes } from "./ai/context";

let t = 0;
const msg = (m: Partial<Message> & Pick<Message, "role" | "content">): Message => ({
  id: `m${++t}`,
  threadId: "th",
  projectId: "p",
  createdAt: t,
  ...m,
});

const CONTEXT = `<workspace_context>\n## PDF "bio.pdf" — page 4 of 9 (extracted text)\nMitochondria are the powerhouse…\n## Current note: "Cells" (id=n1)\nCell notes\n</workspace_context>\n\nExplain page 4 and add it to my note`;

/** A learner turn followed by two agent-loop steps (read → results → read → results). */
function loopThread(): Message[] {
  return [
    msg({ role: "user", content: "Hi" }),
    msg({ role: "assistant", content: "Hello!" }),
    msg({ role: "user", content: "Explain page 4 and add it to my note", apiContent: CONTEXT }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"note","id":"n2"}\n```' }),
    msg({ role: "user", hidden: true, content: '<action_results>\n## Note "Old" (id=n2)\nFIRST READ BODY\n</action_results>' }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"guide","id":"excalidraw"}\n```' }),
    msg({ role: "user", hidden: true, content: '<action_results>\n## Guide "excalidraw"\nGUIDE TEXT\n</action_results>' }),
    msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"sketch","id":"s1"}\n```' }),
    msg({ role: "user", hidden: true, content: "<action_results>\n## Sketch \"Flow\" (id=s1)\ns1 rectangle 0 0 10 10\n- FAILED note: x\n</action_results>" }),
  ];
}

describe("buildHistory (regression #2)", () => {
  it("keeps the learner's context on steps ≥ 2 instead of collapsing it to a placeholder", () => {
    const h = buildHistory(loopThread());
    const learner = h.find((m) => m.content.includes("Explain page 4"))!;
    expect(learner.content).toBe(CONTEXT);
    expect(learner.content).not.toContain("[workspace context was attached");
  });

  it("keeps EVERY <action_results> of the current learner turn in full (nothing collapses mid-turn)", () => {
    const h = buildHistory(loopThread());
    const results = h.filter((m) => m.content.startsWith("<action_results>"));
    expect(results).toHaveLength(3);
    expect(results[0].content).toContain("FIRST READ BODY");
    expect(results[1].content).toContain("GUIDE TEXT");
    expect(results[2].content).toContain("s1 rectangle 0 0 10 10");
    expect(results[2].content).toContain("- FAILED note: x");
  });

  it("collapses results of EARLIER learner turns to their headings, keeping the guide and FAILED lines", () => {
    const thread = [
      ...loopThread(),
      msg({ role: "assistant", content: "All done." }),
      msg({ role: "user", content: "Thanks, now another thing" }),
      msg({ role: "assistant", hidden: true, content: '```action\n{"type":"read","kind":"note","id":"n9"}\n```' }),
      msg({ role: "user", hidden: true, content: '<action_results>\n## Note "New" (id=n9)\nNEW TURN BODY\n</action_results>' }),
    ];
    const results = buildHistory(thread).filter((m) => m.content.startsWith("<action_results>"));
    expect(results).toHaveLength(4);
    expect(results[0].content).toContain('## Note "Old" (id=n2)');
    expect(results[0].content).not.toContain("FIRST READ BODY");
    expect(results[1].content).toContain("GUIDE TEXT");
    expect(results[2].content).not.toContain("s1 rectangle 0 0 10 10");
    expect(results[2].content).toContain("- FAILED note: x");
    expect(results[3].content).toContain("NEW TURN BODY");
  });

  it("caps the current turn's results at ~24k characters, the oldest collapsing first", () => {
    const big = (tag: string) => `<action_results>\n## Note "${tag}" (id=${tag})\n${tag.repeat(1)}${"x".repeat(9_000)}\n</action_results>`;
    const thread = [
      msg({ role: "user", content: "Read all of these", apiContent: "CTX" }),
      ...["A", "B", "C", "D"].flatMap((t) => [msg({ role: "assistant", hidden: true, content: "reading" }), msg({ role: "user", hidden: true, content: big(t) })]),
    ];
    const results = buildHistory(thread).filter((m) => m.content.startsWith("<action_results>"));
    // Newest two (≈18k) fit; the third would pass 24k, so it and the oldest collapse.
    expect(results.map((r) => r.content.length > 5000)).toEqual([false, false, true, true]);
    expect(results[0].content).toContain("[contents omitted");
    expect(fullResultIndexes([{ role: "user", content: "hi" }, { role: "user", hidden: true, content: big("Z") }]).size).toBe(1);
  });

  it("always keeps the newest result in full, even when it alone is over the cap", () => {
    const huge = `<action_results>\n## Note "H" (id=h)\n${"y".repeat(30_000)}\n</action_results>`;
    const thread = [msg({ role: "user", content: "go" }), msg({ role: "assistant", hidden: true, content: "r" }), msg({ role: "user", hidden: true, content: huge })];
    expect(buildHistory(thread)[2].content.length).toBeGreaterThan(30_000);
  });

  it("collapses older turns' apiContent and uses visible text for the first step", () => {
    const thread = loopThread().slice(0, 3);
    thread[0] = { ...thread[0], apiContent: "<workspace_context>\nold\n</workspace_context>\n\nHi" };
    const h = buildHistory(thread);
    expect(h[0].content).toBe("Hi\n[workspace context was attached to this message when it was sent]");
    expect(h[2].content).toBe(CONTEXT);
  });

  it("attaches invalid-action feedback to the newest user-role message", () => {
    const thread = [
      msg({ role: "user", content: "Make a note", apiContent: "CTX\n\nMake a note" }),
      msg({ role: "assistant", hidden: true, content: '```action\n{"type":"note"}\n```' }),
      msg({ role: "user", hidden: true, content: "<action_results>\n- FAILED note: bad\n</action_results>" }),
    ];
    const h = buildHistory(thread);
    expect(h[0].content).toBe("CTX\n\nMake a note");
    expect(h[2].content).toContain("could not be executed");
  });

  it("collapseActionResults keeps headings and FAILED lines", () => {
    const out = collapseActionResults('<action_results>\n## Note "A" (id=1)\nbody\nmore\n- FAILED read: nope\n</action_results>');
    expect(out).toContain('## Note "A" (id=1)');
    expect(out).not.toContain("body");
    expect(out.startsWith("<action_results>\n")).toBe(true);
    expect(out.endsWith("\n</action_results>")).toBe(true);
  });
});

describe("step notices in <action_results>", () => {
  it("every results message says which step the model is on", () => {
    expect(stepNotice(2)).toBe("You are on step 2 of 6.");
    expect(resultsMessage({ step: 3, read: ["## Note \"A\" (id=1)\nbody"], failed: ["- FAILED read: nope"] })).toMatch(/^<action_results>\nYou are on step 3 of 6\./);
  });

  it("on the final step it says to answer now, with no more reads", () => {
    const m = resultsMessage({ step: 6, read: [], failed: [] });
    expect(m).toContain("step 6 of 6");
    expect(m).toMatch(/answer now, no more reads/);
  });

  it("tells Leo when his reply was cut off, and keeps FAILED lines last so they survive a collapse", () => {
    const m = resultsMessage({ step: 2, read: ["## Search \"x\"\nhits"], advisory: ['## Layout check — sketch "S" (id=1)\n- s1 overlaps s2'], failed: ["- FAILED note: bad"], cutOff: true });
    expect(m).toContain(CUT_OFF_NOTICE);
    const collapsed = collapseActionResults(m);
    expect(collapsed).toContain("You are on step 2 of 6.");
    expect(collapsed).toContain(CUT_OFF_NOTICE);
    expect(collapsed).toContain("- FAILED note: bad");
    expect(collapsed).not.toContain("hits");
  });

  it("Continue is an <action_results> message with a fresh step 1, so it belongs to the same learner turn", () => {
    expect(CONTINUE_RESULTS.startsWith("<action_results>")).toBe(true);
    expect(CONTINUE_RESULTS).toContain("step 1 of 6");
  });
});
