import { describe, expect, it } from "vitest";
import { parseSegments } from "./actions";
import {
  applyPatch,
  assignRefs,
  cameraView,
  describeSketch,
  finishPlanned,
  fitShape,
  labelColor,
  lintScene,
  normColor,
  overviewCamera,
  planSketch,
  prepareSketchElements,
  rerouteBoundArrows,
  routeArrow,
  sketchElementProblem,
  type SketchEl,
  type SketchElementSpec,
} from "./sketchSpec";

const parse = (elements: unknown[], extra: Record<string, unknown> = {}) => parseSegments("```action\n" + JSON.stringify({ type: "sketch", title: "T", elements, ...extra }) + "\n```");
const sketchOf = (segs: ReturnType<typeof parse>) => {
  const s = segs[0];
  if (s.kind !== "action" || s.action.type !== "sketch") throw new Error(`not a sketch: ${JSON.stringify(s)}`);
  return s.action;
};

describe("native Excalidraw properties survive normalization", () => {
  it("keeps stroke, fill, opacity, roughness, widths, dashes, fonts, corners and arrowheads", () => {
    const a = sketchOf(
      parse([
        { type: "rectangle", id: "a", x: 0, y: 0, text: "A", strokeColor: "#4a9eed", backgroundColor: "transparent", fillStyle: "hachure", strokeWidth: 4, strokeStyle: "dashed", roughness: 2, opacity: 30, fontSize: 24, fontFamily: "code", textAlign: "left", rounded: false },
        { type: "arrow", from: "a", to: 0, endArrowhead: "triangle", startArrowhead: null, route: "elbow", fromSide: "bottom" },
      ])
    );
    expect(a.elements[0]).toMatchObject({ strokeColor: "#4a9eed", backgroundColor: "transparent", fillStyle: "hachure", strokeWidth: 4, strokeStyle: "dashed", roughness: 2, opacity: 30, fontSize: 24, fontFamily: "code", textAlign: "left", rounded: false });
    expect(a.elements[1]).toMatchObject({ from: 0, to: 0, endArrowhead: "triangle", startArrowhead: null, route: "elbow", fromSide: "bottom" });
  });

  it("translates guide-style spellings instead of dropping them", () => {
    const a = sketchOf(
      parse([
        { type: "rectangle", id: "b1", x: 10, y: 10, width: 200, height: 80, roundness: { type: 3 }, backgroundColor: "#a5d8ff", label: { text: "Start", fontSize: 20 } },
        { type: "rectangle", id: "b2", x: 400, y: 10, width: 200, height: 80, roundness: null },
        { type: "arrow", id: "a1", x: 210, y: 50, points: [[0, 0], [190, 0]], startBinding: { elementId: "b1", fixedPoint: [1, 0.5] }, endBinding: { elementId: "b2", fixedPoint: [0, 0.5] }, elbowed: true },
      ])
    );
    expect(a.elements[0]).toMatchObject({ text: "Start", fontSize: 20, rounded: true, backgroundColor: "#a5d8ff" });
    expect(a.elements[1]).toMatchObject({ rounded: false });
    expect(a.elements[2]).toMatchObject({ from: 0, to: 1, fromSide: "right", toSide: "left", route: "elbow", points: [[0, 0], [190, 0]] });
  });

  it("maps colour names and short hex to #rrggbb, and rejects nonsense with a reason", () => {
    expect(normColor("Red")).toBe("#ef4444");
    expect(normColor("#abc")).toBe("#aabbcc");
    expect(normColor("#11223344")).toBe("#112233");
    expect(normColor("none")).toBe("transparent");
    const seg = parse([{ type: "rectangle", x: 0, y: 0, color: "not-a-colour" }])[0];
    expect(seg).toMatchObject({ kind: "invalid", reason: expect.stringContaining("color must be a #rrggbb") });
  });
});

describe("cameraUpdate, delete and ids", () => {
  it("turns cameraUpdate into camera cues and keeps element indices clean", () => {
    const a = sketchOf(
      parse([
        { type: "cameraUpdate", x: 0, y: 0, width: 400, height: 300 },
        { type: "rectangle", id: "r", x: 0, y: 0, text: "R" },
        { type: "cameraUpdate", x: 100, y: 0, width: 800, height: 600 },
        { type: "ellipse", id: "e", x: 300, y: 0, text: "E" },
        { type: "arrow", from: "r", to: "e" },
      ])
    );
    expect(a.elements).toHaveLength(3);
    expect(a.cameras).toEqual([
      { at: 0, x: 0, y: 0, width: 400, height: 300 },
      { at: 1, x: 100, y: 0, width: 800, height: 600 },
    ]);
    expect(a.elements[2]).toMatchObject({ from: 0, to: 1 });
  });

  it("completes a camera at 4:3 and ignores an unusable one", () => {
    const { cameras } = prepareSketchElements([{ type: "cameraUpdate", x: 0, y: 0, width: 800 }, { type: "cameraUpdate", x: "left" }, { type: "text", x: 0, y: 0, text: "t" }]);
    expect(cameras).toEqual([{ at: 0, x: 0, y: 0, width: 800, height: 600 }]);
  });

  it("applies a delete entry to earlier elements by id", () => {
    const a = sketchOf(parse([{ type: "rectangle", id: "x", x: 0, y: 0 }, { type: "rectangle", id: "y", x: 200, y: 0 }, { type: "delete", ids: "x" }]));
    expect(a.elements).toHaveLength(1);
    expect(a.elements[0]).toMatchObject({ x: 200 });
  });

  it("names an arrow target that matches no id, instead of silently leaving the arrow loose", () => {
    const seg = parse([{ type: "rectangle", id: "a", x: 0, y: 0 }, { type: "arrow", from: "a", to: "ghost" }])[0];
    expect(seg).toMatchObject({ kind: "invalid", reason: expect.stringContaining('"to" is "ghost"') });
  });

  it("lets an arrow between two shapes omit its coordinates, but not a free one", () => {
    expect(parse([{ type: "rectangle", id: "a", x: 0, y: 0 }, { type: "rectangle", id: "b", x: 300, y: 0 }, { type: "arrow", from: "a", to: "b" }])[0].kind).toBe("action");
    expect(parse([{ type: "arrow" }])[0]).toMatchObject({ kind: "invalid", reason: expect.stringContaining("x is required") });
  });

  it("validates the new fields with messages that say what is allowed", () => {
    const bad = (el: Record<string, unknown>) => sketchElementProblem({ type: "rectangle", x: 0, y: 0, ...el }, 0, 1);
    expect(bad({ opacity: 140 })).toMatch(/opacity must be a number from 0 to 100/);
    expect(bad({ roughness: 3 })).toMatch(/roughness must be 0/);
    expect(bad({ fillStyle: "dots" })).toMatch(/fillStyle must be/);
    expect(bad({ points: [[0, 0]] })).toMatch(/points must be/);
    expect(bad({ endArrowhead: "spear" })).toMatch(/endArrowhead must be/);
    expect(sketchElementProblem({ type: "freedraw", x: 0, y: 0 }, 0, 1)).toMatch(/freedraw needs "points"/);
    expect(bad({ strokeColor: "#112233", opacity: 50, rounded: true })).toBeNull();
  });
});

describe("sizing and routing", () => {
  it("grows a shape to fit its label and never shrinks one", () => {
    const small = fitShape("rectangle", "A fairly long label that needs a few lines to be readable", 18, 140, 60);
    expect(small.width).toBeGreaterThanOrEqual(140);
    expect(small.height).toBeGreaterThan(60);
    expect(fitShape("rectangle", "Hi", 18, 300, 200)).toEqual({ width: 300, height: 200 });
    // An ellipse/diamond needs more room than a rectangle for the same text.
    expect(fitShape("diamond", "Does it hold?", 18).width).toBeGreaterThan(fitShape("rectangle", "Does it hold?", 18).width);
  });

  it("routes an arrow between the facing sides of two shapes, with a small gap", () => {
    const a = { x: 0, y: 0, width: 100, height: 60 };
    const b = { x: 300, y: 0, width: 100, height: 60 };
    const r = routeArrow(a, b);
    expect([r.fromSide, r.toSide]).toEqual(["right", "left"]);
    expect(r.x).toBe(104);
    expect(r.y).toBe(30);
    expect(r.points[1][0]).toBe(300 - 4 - 104);
    expect(routeArrow({ ...b, y: 200 }, { ...a, y: 0 }).fromSide).toBe("top");
  });

  it("elbow and curve routes have a bend; an elbow collapses to a straight line when aligned", () => {
    const a = { x: 0, y: 0, width: 100, height: 60 };
    const b = { x: 300, y: 200, width: 100, height: 60 };
    expect(routeArrow(a, b, { route: "elbow" }).points).toHaveLength(4);
    expect(routeArrow(a, { ...b, y: 0 }, { route: "elbow" }).points).toHaveLength(2);
    expect(routeArrow(a, b, { route: "curve" }).points).toHaveLength(3);
    expect(routeArrow(a, b, { fromSide: "bottom", toSide: "left", route: "elbow" }).points).toHaveLength(3);
  });

  it("an elbow between two bottoms loops out below both shapes instead of cutting across", () => {
    const a = { x: 0, y: 0, width: 100, height: 60 };
    const b = { x: 300, y: 0, width: 100, height: 60 };
    const r = routeArrow(a, b, { route: "elbow", fromSide: "bottom", toSide: "bottom" });
    const lowest = Math.max(...r.points.map((p) => p[1]));
    expect(lowest).toBeGreaterThan(30);
    expect(r.points).toHaveLength(4);
  });

  it("plans a sketch: arrows get routes and bindings from the shapes' real boxes; styles reach the skeleton", () => {
    const specs: SketchElementSpec[] = [
      { type: "rectangle", id: "a", x: 0, y: 0, width: 160, height: 80, text: "A", color: "#a5d8ff", strokeColor: "#4a9eed", opacity: 80, fillStyle: "cross-hatch", strokeWidth: 4, roughness: 1, fontSize: 22 },
      { type: "ellipse", x: 360, y: 0, width: 160, height: 80, text: "B" },
      { type: "arrow", from: 0, to: 1, text: "go", strokeStyle: "dashed", endArrowhead: "triangle" },
      { type: "text", x: 200, y: 200, text: "Title", anchor: "center", fontSize: 28, fontFamily: "hand" },
    ];
    const planned = planSketch(specs);
    const [a, , arrow, text] = planned;
    expect(a.skeleton).toMatchObject({ type: "rectangle", backgroundColor: "#a5d8ff", strokeColor: "#4a9eed", opacity: 80, fillStyle: "cross-hatch", strokeWidth: 4, roughness: 1, roundness: { type: 3 }, label: { text: "A", fontSize: 22 } });
    expect(arrow.skeleton).toMatchObject({ type: "arrow", strokeStyle: "dashed", endArrowhead: "triangle", x: 164, y: 40, label: { text: "go" } });
    expect(arrow.bind.start?.key).toBe("s1");
    expect(arrow.bind.end?.key).toBe("s2");
    expect(text.skeleton).toMatchObject({ type: "text", fontSize: 28, fontFamily: 5 });
    expect(text.centerAt).toEqual({ x: 200, y: 200 });
  });

  it("finishPlanned binds arrows to shapes on both sides and centres anchored text", () => {
    const planned = planSketch([
      { type: "rectangle", id: "a", x: 0, y: 0, text: "A" },
      { type: "rectangle", id: "b", x: 400, y: 0, text: "B" },
      { type: "arrow", from: "a", to: "b" },
      { type: "text", x: 100, y: 100, text: "T", anchor: "center" },
    ].map((e) => (e.type === "arrow" ? { ...e, from: 0, to: 1 } : e)) as SketchElementSpec[]);
    const mk = (id: string, ref: string, extra: Partial<SketchEl> = {}): SketchEl => ({ id, type: "rectangle", x: 0, y: 0, width: 10, height: 10, customData: { ref }, boundElements: [{ id: `${id}-label`, type: "text" }], ...extra });
    const byRef = new Map<string, SketchEl>([
      ["s1", mk("A", "s1")],
      ["s2", mk("B", "s2")],
      ["s3", mk("arrow", "s3", { type: "arrow", boundElements: null })],
      ["s4", mk("T", "s4", { type: "text", width: 40, height: 20, boundElements: null })],
    ]);
    finishPlanned(planned, byRef);
    expect(byRef.get("s3")!.startBinding).toMatchObject({ elementId: "A", gap: 4 });
    expect(byRef.get("s3")!.endBinding).toMatchObject({ elementId: "B" });
    expect(byRef.get("s1")!.boundElements).toContainEqual({ id: "arrow", type: "arrow" });
    expect(byRef.get("s2")!.boundElements).toContainEqual({ id: "arrow", type: "arrow" });
    expect(byRef.get("s4")).toMatchObject({ x: 80, y: 90 });
  });

  it("builds a complete freedraw element and offsets a line's points to start at 0,0", () => {
    const [free, line] = planSketch([
      { type: "freedraw", x: 10, y: 10, points: [[0, 0], [10, 5], [25, 0]], strokeColor: "#ef4444", strokeWidth: 4 },
      { type: "line", x: 0, y: 0, points: [[5, 5], [55, 5]], strokeStyle: "dotted" },
    ]);
    expect(free.skeleton).toMatchObject({ type: "freedraw", strokeColor: "#ef4444", strokeWidth: 4, simulatePressure: true, width: 25, height: 5, isDeleted: false });
    expect((free.skeleton.points as number[][])[0]).toEqual([0, 0]);
    expect(line.skeleton).toMatchObject({ type: "line", x: 5, y: 5, points: [[0, 0], [50, 0]], endArrowhead: null, strokeStyle: "dotted" });
  });

  it("picks a readable label colour on dark fills", () => {
    expect(labelColor("#1e3a5f", "#1e1e1e")).toBe("#f8f9fa");
    expect(labelColor("#a5d8ff", "#1e1e1e")).toBe("#1e1e1e");
    expect(labelColor("#a5d8ff", "#4a9eed")).toBe("#1e1e1e"); // a mid-blue outline is not used for text on a pale fill
    expect(labelColor("#1e3a5f", "#1e1e1e", 30)).toBe("#1e1e1e");
  });
});

const el = (id: string, type: string, x: number, y: number, w: number, h: number, extra: Partial<SketchEl> = {}): SketchEl => ({ id, type, x, y, width: w, height: h, version: 1, ...extra });

describe("editing keeps native properties and arrows attached", () => {
  it("update changes style, text and size, and moves labels with their shape's font", () => {
    const box = el("b", "rectangle", 0, 0, 100, 60, { backgroundColor: "#e3ecfe", strokeColor: "#1e1e1e" });
    const label = el("l", "text", 10, 10, 40, 20, { containerId: "b", text: "Old", fontSize: 18 });
    const out = applyPatch(box, { backgroundColor: "#1e3a5f", opacity: 90, strokeStyle: "dashed", fillStyle: "zigzag", roughness: 1, strokeWidth: 4, rounded: true, fontSize: 24, text: "A much longer replacement label for this box" }, [label], "s1");
    expect(box).toMatchObject({ backgroundColor: "#1e3a5f", opacity: 90, strokeStyle: "dashed", fillStyle: "zigzag", roughness: 1, strokeWidth: 4, roundness: { type: 3 } });
    expect(label).toMatchObject({ fontSize: 24, text: "A much longer replacement label for this box", originalText: "A much longer replacement label for this box", strokeColor: "#f8f9fa" });
    expect(box.height).toBeGreaterThan(60); // grew to fit
    expect(out.moved).toBe(true);
  });

  it("moving a shape re-routes the arrows attached to it", () => {
    const a = el("a", "rectangle", 0, 0, 100, 60);
    const b = el("b", "rectangle", 300, 0, 100, 60);
    const arrow = el("ar", "arrow", 104, 30, 192, 0, { points: [[0, 0], [192, 0]], startBinding: { elementId: "a" }, endBinding: { elementId: "b" } });
    applyPatch(b, { x: 300, y: 300 }, [], "s2");
    expect(rerouteBoundArrows([a, b, arrow], new Set(["b"]))).toBe(1);
    expect(arrow.points!.length).toBe(2);
    expect(arrow.height).toBeGreaterThan(100);
    expect(arrow.version).toBeGreaterThan(1);
    // Nothing moved → nothing re-routed.
    expect(rerouteBoundArrows([a, b, arrow], new Set(["zzz"]))).toBe(0);
  });

  it("changes an arrow's heads and points through update", () => {
    const arrow = el("ar", "arrow", 0, 0, 100, 0, { points: [[0, 0], [100, 0]], endArrowhead: "arrow" });
    applyPatch(arrow, { endArrowhead: null, startArrowhead: "dot", points: [[10, 10], [60, 10], [60, 80]], strokeColor: "#ef4444" }, [], "s1");
    expect(arrow).toMatchObject({ endArrowhead: null, startArrowhead: "dot", strokeColor: "#ef4444", x: 10, y: 10, width: 50, height: 70 });
    expect(arrow.points).toEqual([[0, 0], [50, 0], [50, 70]]);
  });
});

describe("the listing and the lint", () => {
  const scene = (elements: SketchEl[]) => JSON.stringify({ elements });

  it("lists style next to what was always listed, and attached arrows as s3→s4", () => {
    const elements = [
      el("a", "rectangle", 10, 20, 140, 72, { backgroundColor: "#e3ecfe", strokeColor: "#ef4444", strokeStyle: "dashed", opacity: 40 }),
      el("al", "text", 0, 0, 10, 10, { containerId: "a", text: "Start", fontSize: 24 }),
      el("b", "ellipse", 300, 20, 140, 72, { backgroundColor: "transparent" }),
      el("ar", "arrow", 150, 50, 150, 0, { startBinding: { elementId: "a" }, endBinding: { elementId: "b" } }),
    ];
    const lines = describeSketch(scene(elements)).split("\n");
    expect(lines[0]).toBe('s1 rectangle 10 20 140 72 #e3ecfe [stroke #ef4444, dashed, opacity 40, font 24] "Start"');
    // A label is part of its shape, so it is not listed on its own (its ref number is skipped).
    expect(lines[1]).toBe("s3 ellipse 300 20 140 72 transparent");
    expect(lines[2]).toBe("s4 arrow s1→s3");
  });

  it("reports overlaps and arrows through shapes, but not zone panels or contained shapes", () => {
    const base = [
      el("zone", "rectangle", 0, 0, 600, 300),
      el("in", "rectangle", 40, 40, 140, 70),
      el("a", "rectangle", 700, 0, 140, 70),
      el("b", "rectangle", 760, 30, 140, 70),
      el("far1", "rectangle", 0, 500, 100, 60),
      el("wall", "rectangle", 300, 480, 40, 100),
      el("far2", "rectangle", 500, 500, 100, 60),
      el("arrow", "arrow", 104, 530, 396, 0, { points: [[0, 0], [396, 0]], startBinding: { elementId: "far1" }, endBinding: { elementId: "far2" } }),
    ];
    const notes = lintScene(base);
    expect(notes.some((n) => n.includes("s3") && n.includes("s4") && n.includes("overlaps"))).toBe(true);
    expect(notes.some((n) => n.includes("passes through"))).toBe(true);
    expect(notes.filter((n) => n.includes("s1") || n.includes("s2"))).toEqual([]);
  });
});

describe("camera maths", () => {
  it("centres the requested area using Excalidraw's (x + scroll) * zoom mapping", () => {
    const v = cameraView({ width: 800, height: 600 }, { x: 100, y: 50, width: 400, height: 300 });
    expect(v.zoom).toBe(2);
    // The left edge of the rect lands at screen x = (100 + scrollX) * zoom = 0 for an exact-fit rect.
    expect((100 + v.scrollX) * v.zoom).toBeCloseTo(0);
    expect((50 + v.scrollY) * v.zoom).toBeCloseTo(0);
    // A wider area than the viewport ratio is letterboxed, still centred.
    const w = cameraView({ width: 800, height: 600 }, { x: 0, y: 0, width: 800, height: 300 });
    expect(w.zoom).toBe(1);
    expect(w.scrollY * w.zoom).toBeCloseTo(150);
  });

  it("frames content in a 4:3 overview with padding", () => {
    const cam = overviewCamera([el("a", "rectangle", 0, 0, 400, 100), el("b", "rectangle", 500, 200, 100, 100)])!;
    expect(cam.width / cam.height).toBeCloseTo(4 / 3);
    expect(cam.x).toBeLessThan(0);
    expect(cam.x + cam.width).toBeGreaterThan(600);
    expect(overviewCamera([])).toBeNull();
  });
});

describe("refs", () => {
  it("assigns stable refs in element order", () => {
    const els = [el("a", "rectangle", 0, 0, 1, 1, { customData: { ref: "s3" } }), el("b", "ellipse", 0, 0, 1, 1)];
    expect([...assignRefs(els).values()]).toEqual(["s3", "s1"]);
  });
});
