/**
 * Leo's drawing schema — the one place that says what a sketch element may contain.
 *
 * The model writes plain JSON elements (a superset of what the Excalidraw guide shows). This module
 *   1. normalizes them (guide-style `label`, `roundness`, `startBinding`… become this schema, and
 *      nothing native is thrown away),
 *   2. validates them with messages the model can act on,
 *   3. plans them: sizes shapes to their text, routes arrows between shapes, centres text,
 *   4. lints the finished scene for overlaps, and
 *   5. edits existing scenes (style changes, moves that keep arrows attached).
 *
 * Everything here is pure data in, data out — no Excalidraw import — so it is unit-tested directly.
 * lib/ai/actions.ts hands the planned skeletons to Excalidraw's convertToExcalidrawElements.
 */

/* ------------------------------------------------------------------ schema */

export const ELEMENT_TYPES = ["rectangle", "ellipse", "diamond", "arrow", "line", "text", "freedraw"] as const;
export const ELEMENT_TYPE_LIST = "rectangle, ellipse, diamond, arrow, line, text or freedraw";
export const SHAPE_TYPES = ["rectangle", "ellipse", "diamond"] as const;
export const FILL_STYLES = ["solid", "hachure", "cross-hatch", "zigzag"] as const;
export const STROKE_STYLES = ["solid", "dashed", "dotted"] as const;
export const ARROWHEADS = ["arrow", "bar", "dot", "circle", "circle_outline", "triangle", "triangle_outline", "diamond", "diamond_outline"] as const;
export const SIDES = ["top", "right", "bottom", "left"] as const;
export const ROUTES = ["straight", "elbow", "curve"] as const;
export const TEXT_ALIGNS = ["left", "center", "right"] as const;
export const FONT_FAMILIES = { hand: 5, normal: 2, code: 3 } as const;

export type Side = (typeof SIDES)[number];
export type Route = (typeof ROUTES)[number];
export type Arrowhead = (typeof ARROWHEADS)[number];

export interface CameraRect {
  x: number;
  y: number;
  width: number;
  height: number;
}
/** A camera move placed in a sketch's element list: it happens before element number `at` is drawn. */
export interface SketchCamera extends CameraRect {
  at: number;
}

/**
 * One element Leo may draw. In a `sketch`, from/to are element ids (or indices); in an `edit_sketch`
 * "add" op they may also name an existing element ref such as "s3". Every style field is native
 * Excalidraw and optional; `color` is the short form (a shape's fill, or a text/line's stroke).
 */
export interface SketchElementSpec {
  type: (typeof ELEMENT_TYPES)[number];
  /** Name for arrows to point at (`"from":"b1"`). Only meaningful inside one `sketch`. */
  id?: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  text?: string;
  color?: string;
  strokeColor?: string;
  backgroundColor?: string;
  fillStyle?: (typeof FILL_STYLES)[number];
  strokeWidth?: number;
  strokeStyle?: (typeof STROKE_STYLES)[number];
  roughness?: number;
  opacity?: number;
  fontSize?: number;
  fontFamily?: keyof typeof FONT_FAMILIES | number;
  textAlign?: (typeof TEXT_ALIGNS)[number];
  /** Rounded corners (shapes) or a smooth curve (arrows, lines). Rectangles are rounded unless false. */
  rounded?: boolean;
  /** Text only: x,y is the CENTRE of the text instead of its top-left corner. */
  anchor?: "center";
  from?: number | string;
  to?: number | string;
  fromSide?: Side | "auto";
  toSide?: Side | "auto";
  route?: Route;
  /** arrow/line/freedraw: [dx,dy] offsets from x,y (first point is the start). */
  points?: [number, number][];
  startArrowhead?: Arrowhead | null;
  endArrowhead?: Arrowhead | null;
}

/** A single change to an existing sketch. */
export interface SketchOp {
  op: "add" | "update" | "delete" | "camera";
  /** Element ref from the sketch listing, e.g. "s3". */
  ref?: string;
  /** Complete for "add"; for "update" only the fields to change are present. */
  element?: SketchElementSpec;
  /** For "camera": where to look. */
  camera?: CameraRect;
}

/** Excalidraw elements as stored in a scene (only the fields this module reads or writes). */
export interface SketchEl {
  id: string;
  type: string;
  x: number;
  y: number;
  width: number;
  height: number;
  angle?: number;
  isDeleted?: boolean;
  version?: number;
  versionNonce?: number;
  text?: string;
  originalText?: string;
  fontSize?: number;
  fontFamily?: number;
  textAlign?: string;
  backgroundColor?: string;
  strokeColor?: string;
  fillStyle?: string;
  strokeWidth?: number;
  strokeStyle?: string;
  roughness?: number;
  opacity?: number;
  roundness?: { type: number } | null;
  points?: [number, number][];
  startArrowhead?: string | null;
  endArrowhead?: string | null;
  /** Set for the text element a shape or arrow uses as its label. */
  containerId?: string | null;
  boundElements?: { id: string; type: string }[] | null;
  customData?: Record<string, unknown> | null;
  startBinding?: { elementId?: string; focus?: number; gap?: number } | null;
  endBinding?: { elementId?: string; focus?: number; gap?: number } | null;
}

/** The fields an `update` op may change; everything else about the element is left alone. */
export const STYLE_KEYS = ["strokeColor", "backgroundColor", "fillStyle", "strokeWidth", "strokeStyle", "roughness", "opacity", "fontSize", "fontFamily", "textAlign", "rounded", "startArrowhead", "endArrowhead", "points"] as const;

/** Largest numbers a sketch may use. Wide enough for zone panels and camera tours, small enough to catch typos. */
export const LIMITS = { coord: 3000, shapeW: 2400, shapeH: 1800, arrowW: 2400, arrowH: 1800, text: 300, elements: 60, ops: 60, cameras: 12, points: 300 } as const;

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
const numeric = (v: unknown) => (typeof v === "number" ? v : typeof v === "string" && v.trim() ? Number(v) : NaN);
const isShapeType = (t: unknown) => t === "rectangle" || t === "ellipse" || t === "diamond";
const isLinearType = (t: unknown) => t === "arrow" || t === "line";

/* ------------------------------------------------------------------ colours */

/** Names models reach for when they forget the hex rule, mapped to the app's palette. */
const NAMED_COLORS: Record<string, string> = {
  black: "#1e1e1e", white: "#ffffff", gray: "#868e96", grey: "#868e96", red: "#ef4444", green: "#22c55e", blue: "#4a9eed",
  orange: "#f59e0b", amber: "#f59e0b", yellow: "#facc15", purple: "#8b5cf6", violet: "#8b5cf6", pink: "#ec4899", teal: "#0ca678",
  cyan: "#06b6d4", lime: "#84cc16", brown: "#a0674b",
};
const HEX6 = /^#[0-9a-f]{6}$/i;

/** "#abc" → "#aabbcc", "#rrggbbaa" → "#rrggbb", "red" → palette hex. Anything else is returned unchanged so validation can name it. */
export function normColor(v: unknown): unknown {
  if (typeof v !== "string") return v;
  const s = v.trim().toLowerCase();
  if (s === "transparent" || s === "none") return "transparent";
  if (/^#[0-9a-f]{3}$/.test(s)) return `#${s[1]}${s[1]}${s[2]}${s[2]}${s[3]}${s[3]}`;
  if (/^#[0-9a-f]{8}$/.test(s)) return s.slice(0, 7);
  if (HEX6.test(s)) return s;
  return NAMED_COLORS[s] ?? v;
}
export const isColor = (v: unknown): v is string => typeof v === "string" && (v === "transparent" || HEX6.test(v));

/** Relative luminance 0..1 of a #rrggbb colour. */
function luminance(hex: string): number {
  const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}

/** Text colour that stays readable on a fill: light on dark fills, the stroke (or near-black) otherwise. */
export function labelColor(fill: string | undefined, stroke: string | undefined, opacity = 100): string {
  // Only a really dark outline colour is reused for text; mid-tones (blue, green…) read poorly on pastel fills.
  const base = stroke && stroke !== "transparent" && HEX6.test(stroke) && luminance(stroke) < 0.15 ? stroke : "#1e1e1e";
  if (!fill || fill === "transparent" || !HEX6.test(fill) || opacity < 60) return base;
  return luminance(fill) < 0.22 ? "#f8f9fa" : base;
}

/* ------------------------------------------------------------- normalization */

const SIDE_OF_FIXED_POINT = (p: unknown): Side | undefined => {
  if (!Array.isArray(p) || p.length < 2) return undefined;
  const [fx, fy] = [Number(p[0]), Number(p[1])];
  if (!Number.isFinite(fx) || !Number.isFinite(fy)) return undefined;
  if (Math.abs(fx - 0.5) >= Math.abs(fy - 0.5)) return fx >= 0.5 ? "right" : "left";
  return fy >= 0.5 ? "bottom" : "top";
};

const lower = (v: unknown) => (typeof v === "string" ? v.trim().toLowerCase() : v);
const num = (v: unknown) => (typeof v === "string" ? (Number.isNaN(numeric(v)) ? v : numeric(v)) : v);

/**
 * Reduce one element — in this app's format or copied from the Excalidraw guide — to the schema
 * above. Guide-style extras are translated, not dropped: `label` → text/fontSize, `roundness` →
 * rounded, `startBinding` → from/fromSide, `elbowed` → route. Values that are wrong (not numbers,
 * bad type…) are kept so validation can name them. `resolveRef` turns an element id or original
 * index into the spec's from/to value.
 */
export function normalizeSketchElement(raw: unknown, resolveRef: (v: unknown) => unknown): unknown {
  if (!isRecord(raw)) return raw;
  const e = raw;
  const out: Record<string, unknown> = {};
  if (e.type !== undefined) out.type = lower(e.type);
  for (const k of ["x", "y", "width", "height"] as const) if (e[k] !== undefined && e[k] !== null) out[k] = num(e[k]);

  const label = isRecord(e.label) ? e.label : undefined;
  if (typeof e.text === "string") out.text = e.text;
  else if (label && typeof label.text === "string") out.text = label.text;
  else if (e.text !== undefined && e.text !== null) out.text = e.text;

  if (e.color !== undefined && e.color !== null) out.color = normColor(e.color);
  if (e.strokeColor !== undefined && e.strokeColor !== null) out.strokeColor = normColor(e.strokeColor);
  if (e.backgroundColor !== undefined && e.backgroundColor !== null) out.backgroundColor = normColor(e.backgroundColor);

  for (const k of ["fillStyle", "strokeStyle", "textAlign"] as const) {
    const v = e[k] ?? (k === "textAlign" ? label?.textAlign : undefined);
    if (v !== undefined && v !== null) out[k] = lower(v);
  }
  for (const k of ["strokeWidth", "roughness", "opacity"] as const) if (e[k] !== undefined && e[k] !== null) out[k] = num(e[k]);
  const fontSize = e.fontSize ?? label?.fontSize;
  if (fontSize !== undefined && fontSize !== null) out.fontSize = num(fontSize);
  const fontFamily = e.fontFamily ?? label?.fontFamily;
  if (fontFamily !== undefined && fontFamily !== null) out.fontFamily = typeof fontFamily === "string" ? (Number.isNaN(numeric(fontFamily)) ? lower(fontFamily) : numeric(fontFamily)) : fontFamily;

  if (typeof e.rounded === "boolean") out.rounded = e.rounded;
  else if (e.roundness === null) out.rounded = false;
  else if (e.roundness !== undefined) out.rounded = true;

  if (e.anchor !== undefined && e.anchor !== null) out.anchor = lower(e.anchor);
  if (Array.isArray(e.points)) out.points = e.points;
  for (const k of ["startArrowhead", "endArrowhead"] as const) {
    if (e[k] === null) out[k] = null;
    else if (e[k] !== undefined) out[k] = lower(e[k]);
  }

  const startBinding = isRecord(e.startBinding) ? e.startBinding : undefined;
  const endBinding = isRecord(e.endBinding) ? e.endBinding : undefined;
  const from = e.from !== undefined && e.from !== null ? e.from : startBinding?.elementId;
  const to = e.to !== undefined && e.to !== null ? e.to : endBinding?.elementId;
  const f = resolveRef(from);
  if (f !== undefined) out.from = f;
  const t = resolveRef(to);
  if (t !== undefined) out.to = t;
  if (e.fromSide !== undefined && e.fromSide !== null) out.fromSide = lower(e.fromSide);
  else if (startBinding) {
    const s = SIDE_OF_FIXED_POINT(startBinding.fixedPoint);
    if (s) out.fromSide = s;
  }
  if (e.toSide !== undefined && e.toSide !== null) out.toSide = lower(e.toSide);
  else if (endBinding) {
    const s = SIDE_OF_FIXED_POINT(endBinding.fixedPoint);
    if (s) out.toSide = s;
  }

  const route = lower(e.route ?? e.arrowType);
  if (route === "round") out.route = "curve";
  else if (route === "sharp") out.route = "straight";
  else if (route !== undefined && route !== null) out.route = route;
  else if (e.elbowed === true) out.route = "elbow";
  return out;
}

/** Guide-only entries that steer the viewport or remove things; they are never drawn as elements. */
const PSEUDO_ELEMENT_TYPES = new Set(["cameraUpdate", "delete", "restoreCheckpoint"]);
export const isPseudoElement = (v: unknown) => isRecord(v) && PSEUDO_ELEMENT_TYPES.has(v.type as string);

/** A `cameraUpdate` entry as a rect, completing a missing size at 4:3. Null when it cannot be made sense of. */
export function cameraOf(raw: unknown): CameraRect | null {
  if (!isRecord(raw)) return null;
  const x = numeric(raw.x);
  const y = numeric(raw.y);
  let w = numeric(raw.width);
  let h = numeric(raw.height);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  if (!(w > 0) && h > 0) w = (h * 4) / 3;
  if (!(h > 0) && w > 0) h = (w * 3) / 4;
  if (!(w > 0) || !(h > 0)) return null;
  const c = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
  return { x: c(x, -LIMITS.coord, LIMITS.coord), y: c(y, -LIMITS.coord, LIMITS.coord), width: c(w, 100, 6000), height: c(h, 75, 4500) };
}

/**
 * Elements of a `sketch` action: pseudo-elements are taken out, the rest normalized, and arrows kept
 * attached — numeric from/to are re-based after the removal, and element ids resolve to indices.
 *   cameraUpdate → `cameras` (applied while the sketch is drawn)
 *   delete       → removes earlier elements by id
 *   restoreCheckpoint → ignored (there are no checkpoints)
 */
export function prepareSketchElements(raw: unknown[]): { elements: unknown[]; cameras: SketchCamera[] } {
  const removed = new Set<number>();
  const idAt = new Map<string, number>();
  const cameraAt: { index: number; rect: CameraRect }[] = [];
  raw.forEach((e, i) => {
    if (!isRecord(e)) return;
    if (e.type === "delete") {
      const ids = Array.isArray(e.ids) ? e.ids.map(String) : typeof e.ids === "string" ? e.ids.split(",").map((s) => s.trim()) : [];
      for (const id of ids) {
        const at = idAt.get(id);
        if (at !== undefined) {
          removed.add(at);
          idAt.delete(id);
        }
      }
      return;
    }
    if (isPseudoElement(e)) return;
    if (typeof e.id === "string" && !idAt.has(e.id)) idAt.set(e.id, i);
  });
  const kept: number[] = [];
  const newIndex = new Map<number, number>();
  raw.forEach((e, i) => {
    if (isPseudoElement(e) || removed.has(i)) {
      const rect = isRecord(e) && e.type === "cameraUpdate" ? cameraOf(e) : null;
      if (rect) cameraAt.push({ index: kept.length, rect });
      return;
    }
    newIndex.set(i, kept.length);
    kept.push(i);
  });
  const ids = new Map<string, number>();
  for (const [orig, ni] of newIndex) {
    const el = raw[orig];
    if (isRecord(el) && typeof el.id === "string" && !ids.has(el.id)) ids.set(el.id, ni);
  }
  const resolveRef = (v: unknown): unknown => {
    if (typeof v === "number") return Number.isInteger(v) && v >= 0 && v < raw.length ? (newIndex.has(v) ? newIndex.get(v) : v) : v;
    if (typeof v === "string") {
      if (ids.has(v)) return ids.get(v);
      // "s3" is the ref a sketch's third element gets once drawn.
      const ref = /^s(\d{1,3})$/.exec(v);
      if (ref && Number(ref[1]) >= 1 && Number(ref[1]) <= kept.length) return Number(ref[1]) - 1;
      return v;
    }
    return v === null ? undefined : v;
  };
  return {
    elements: kept.map((i) => normalizeSketchElement(raw[i], resolveRef)),
    cameras: cameraAt.slice(0, LIMITS.cameras).map((c) => ({ at: c.index, ...c.rect })),
  };
}

/** Ops of an `edit_sketch` action: a `cameraUpdate` entry becomes a camera op; the rest is normalized. */
export function prepareSketchOps(raw: unknown[]): unknown[] {
  const ops: unknown[] = [];
  for (const op of raw) {
    if (!isRecord(op)) {
      ops.push(op);
      continue;
    }
    if (op.type === "cameraUpdate" || (isRecord(op.element) && op.element.type === "cameraUpdate")) {
      const rect = cameraOf(op.type === "cameraUpdate" ? op : op.element);
      if (rect) ops.push({ op: "camera", camera: rect });
      continue;
    }
    if (isPseudoElement(op) || isPseudoElement(op.element)) continue;
    const out: Record<string, unknown> = {};
    if (op.op !== undefined) out.op = lower(op.op);
    if (op.ref !== undefined) out.ref = op.ref;
    if (op.op === "camera") {
      const rect = cameraOf(op.camera ?? op);
      out.camera = rect ?? op.camera;
    }
    if (op.element !== undefined && op.element !== null) out.element = normalizeSketchElement(op.element, (v) => (v === null ? undefined : v));
    ops.push(out);
  }
  return ops;
}

/* ---------------------------------------------------------------- validation */

const show = (v: unknown) => {
  const s = JSON.stringify(v) ?? String(v);
  return s.length > 40 ? `${s.slice(0, 40)}…` : s;
};

/** "element 3 (rectangle “Start”)" — enough for the learner and the model to find the culprit. */
function describeElement(v: Record<string, unknown>, i: number) {
  const text = typeof v.text === "string" ? v.text.trim() : "";
  const label = text ? ` \u201c${text.length > 24 ? `${text.slice(0, 24)}\u2026` : text}\u201d` : "";
  return `element ${i + 1}${typeof v.type === "string" ? ` (${v.type}${label})` : ""}`;
}

const inRange = (x: unknown, min: number, max: number) => typeof x === "number" && Number.isFinite(x) && x >= min && x <= max;
const oneOf = <T extends readonly string[]>(list: T, v: unknown): v is T[number] => typeof v === "string" && (list as readonly string[]).includes(v);

/**
 * Why one element spec is unusable, or null when it is fine. `count` bounds numeric from/to indices
 * when they refer to a sibling; `partial` allows fields to be omitted (an update changes only some).
 */
export function sketchElementProblem(raw: unknown, i: number, count?: number, partial = false): string | null {
  if (!isRecord(raw)) return `element ${i + 1} is ${show(raw)}, not an object`;
  const v = raw;
  const who = describeElement(v, i);
  if (!(partial && v.type === undefined) && !oneOf(ELEMENT_TYPES, v.type)) return `${who}: unknown type ${show(v.type ?? null)} — use ${ELEMENT_TYPE_LIST}`;
  const linear = isLinearType(v.type) || v.type === "freedraw" || (partial && v.type === undefined);
  const sketchArrow = count !== undefined && isLinearType(v.type) && v.from !== undefined && v.to !== undefined;
  for (const k of ["x", "y"] as const) {
    if (v[k] === undefined) {
      // An arrow between two named shapes is placed by the app, so it needs no coordinates.
      if (!partial && !sketchArrow && !(v.type === "arrow" && v.from !== undefined && v.to !== undefined)) return `${who}: ${k} is required`;
    } else if (!inRange(v[k], -LIMITS.coord, LIMITS.coord)) return `${who}: ${k} must be a number between -${LIMITS.coord} and ${LIMITS.coord} (got ${show(v[k])})`;
  }
  if (v.width !== undefined && !inRange(v.width, linear ? -LIMITS.arrowW : 0, linear ? LIMITS.arrowW : LIMITS.shapeW))
    return `${who}: width must be a number between ${linear ? -LIMITS.arrowW : 0} and ${linear ? LIMITS.arrowW : LIMITS.shapeW} (got ${show(v.width)})`;
  if (v.height !== undefined && !inRange(v.height, linear ? -LIMITS.arrowH : 0, linear ? LIMITS.arrowH : LIMITS.shapeH))
    return `${who}: height must be a number between ${linear ? -LIMITS.arrowH : 0} and ${linear ? LIMITS.arrowH : LIMITS.shapeH} (got ${show(v.height)})`;
  if (v.text !== undefined && typeof v.text !== "string") return `${who}: text must be a string (got ${show(v.text)})`;
  if (typeof v.text === "string" && v.text.length > LIMITS.text) return `${who}: text is ${v.text.length} characters; the limit is ${LIMITS.text}`;
  if (v.type === "text" && !partial && !(typeof v.text === "string" && v.text.trim())) return `${who}: a text element needs its "text"`;
  for (const k of ["color", "strokeColor", "backgroundColor"] as const)
    if (v[k] !== undefined && !isColor(v[k])) return `${who}: ${k} must be a #rrggbb hex value or "transparent" (got ${show(v[k])})`;
  if (v.fillStyle !== undefined && !oneOf(FILL_STYLES, v.fillStyle)) return `${who}: fillStyle must be ${FILL_STYLES.join(", ")} (got ${show(v.fillStyle)})`;
  if (v.strokeStyle !== undefined && !oneOf(STROKE_STYLES, v.strokeStyle)) return `${who}: strokeStyle must be ${STROKE_STYLES.join(", ")} (got ${show(v.strokeStyle)})`;
  if (v.textAlign !== undefined && !oneOf(TEXT_ALIGNS, v.textAlign)) return `${who}: textAlign must be left, center or right (got ${show(v.textAlign)})`;
  if (v.strokeWidth !== undefined && !inRange(v.strokeWidth, 0, 16)) return `${who}: strokeWidth must be a number from 0 to 16 (got ${show(v.strokeWidth)})`;
  if (v.roughness !== undefined && !(typeof v.roughness === "number" && [0, 1, 2].includes(v.roughness))) return `${who}: roughness must be 0 (clean), 1 (sketchy) or 2 (very sketchy) (got ${show(v.roughness)})`;
  if (v.opacity !== undefined && !inRange(v.opacity, 0, 100)) return `${who}: opacity must be a number from 0 to 100 (got ${show(v.opacity)})`;
  if (v.fontSize !== undefined && !inRange(v.fontSize, 8, 120)) return `${who}: fontSize must be a number from 8 to 120 (got ${show(v.fontSize)})`;
  if (v.fontFamily !== undefined && !(oneOf(Object.keys(FONT_FAMILIES) as unknown as readonly string[], v.fontFamily) || [1, 2, 3, 5, 6, 7, 8, 9].includes(v.fontFamily as number)))
    return `${who}: fontFamily must be "hand", "normal" or "code" (got ${show(v.fontFamily)})`;
  if (v.rounded !== undefined && typeof v.rounded !== "boolean") return `${who}: rounded must be true or false (got ${show(v.rounded)})`;
  if (v.anchor !== undefined && v.anchor !== "center") return `${who}: anchor must be "center" (got ${show(v.anchor)})`;
  if (v.route !== undefined && !oneOf(ROUTES, v.route)) return `${who}: route must be ${ROUTES.join(", ")} (got ${show(v.route)})`;
  for (const k of ["fromSide", "toSide"] as const) if (v[k] !== undefined && !(v[k] === "auto" || oneOf(SIDES, v[k]))) return `${who}: ${k} must be top, right, bottom, left or auto (got ${show(v[k])})`;
  for (const k of ["startArrowhead", "endArrowhead"] as const) if (v[k] !== undefined && v[k] !== null && !oneOf(ARROWHEADS, v[k])) return `${who}: ${k} must be null or one of ${ARROWHEADS.join(", ")} (got ${show(v[k])})`;
  if (v.points !== undefined) {
    const p = v.points;
    const ok = Array.isArray(p) && p.length >= 2 && p.length <= LIMITS.points && p.every((q) => Array.isArray(q) && q.length >= 2 && inRange(q[0], -LIMITS.coord * 2, LIMITS.coord * 2) && inRange(q[1], -LIMITS.coord * 2, LIMITS.coord * 2));
    if (!ok) return `${who}: points must be 2–${LIMITS.points} pairs like [[0,0],[120,40]] (offsets from x,y)`;
  }
  if (v.type === "freedraw" && !partial && v.points === undefined) return `${who}: freedraw needs "points" like [[0,0],[10,4],[22,9]]`;
  for (const k of ["from", "to"] as const) {
    const x = v[k];
    if (x === undefined) continue;
    if (typeof x === "number") {
      if (!Number.isInteger(x) || x < 0 || (count !== undefined && x >= count)) return `${who}: "${k}" must be the id or index of another element${count !== undefined ? ` (0–${count - 1})` : ""} (got ${show(x)})`;
    } else if (typeof x === "string") {
      // In a sketch every id is already resolved to an index, so a string left over names nothing.
      if (count !== undefined) return `${who}: "${k}" is ${show(x)}, which is not the id of any element in this sketch — give the target shape an "id" and use it`;
    } else return `${who}: "${k}" must be an element id or ref (got ${show(x)})`;
  }
  return null;
}

/** Why an op of an `edit_sketch` action is unusable, or null. */
export function sketchOpProblem(raw: unknown, i: number): string | null {
  if (!isRecord(raw)) return `op ${i + 1} is ${show(raw)}, not an object`;
  const v = raw;
  const who = `op ${i + 1}${typeof v.op === "string" ? ` (${v.op}${typeof v.ref === "string" ? ` ${v.ref}` : ""})` : ""}`;
  if (v.ref !== undefined && !(typeof v.ref === "string" && /^s\d{1,4}$/.test(v.ref))) return `${who}: ref must be an element ref from the listing such as "s3" (got ${show(v.ref)})`;
  if (v.op === "add") {
    if (!isRecord(v.element)) return `${who}: add needs an "element" to draw`;
    const p = sketchElementProblem(v.element, 0, undefined, false);
    return p ? `${who}: ${p.replace(/^element 1/, "element")}` : null;
  }
  if (v.op === "update") {
    if (typeof v.ref !== "string") return `${who}: update needs the "ref" of the element to change`;
    if (v.element === undefined) return null;
    const p = sketchElementProblem(v.element, 0, undefined, true);
    return p ? `${who}: ${p.replace(/^element 1/, "element")}` : null;
  }
  if (v.op === "delete") return typeof v.ref === "string" ? null : `${who}: delete needs the "ref" of the element to remove`;
  if (v.op === "camera") return isRecord(v.camera) && cameraOf(v.camera) ? null : `${who}: camera needs {"x","y","width","height"} (the scene area to look at)`;
  return `${who}: unknown op ${show(v.op ?? null)} — use add, update, delete or camera`;
}

/** Why the cameras of a sketch are unusable (they are lenient: bad entries were already dropped). */
export function camerasProblem(cameras: unknown): string | null {
  if (cameras === undefined) return null;
  if (!Array.isArray(cameras) || cameras.length > LIMITS.cameras) return `a sketch may carry at most ${LIMITS.cameras} cameraUpdate entries`;
  return null;
}

/* ------------------------------------------------------- sizing and routing */

export interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
  type?: string;
}

const r2 = (n: number) => Math.round(n * 100) / 100;
export const fontFamilyOf = (f: SketchElementSpec["fontFamily"]): number | undefined => (typeof f === "string" ? FONT_FAMILIES[f] : f);
const CHAR_W = 0.55;
const LINE_H = 1.25;

/** Rough pixel size of a text block: good enough to size containers and centre labels. */
export function estimateText(text: string, fontSize: number) {
  const lines = (text || " ").split("\n");
  const widest = Math.max(...lines.map((l) => l.length));
  return { width: widest * fontSize * CHAR_W, height: lines.length * fontSize * LINE_H, lines: lines.length };
}

const SHAPE_K: Record<string, { w: number; h: number }> = { rectangle: { w: 1, h: 1 }, ellipse: { w: 1.42, h: 1.3 }, diamond: { w: 1.9, h: 1.8 } };

/** The size a labelled shape needs so its text fits. Never smaller than what the model asked for. */
export function fitShape(type: string, text: string | undefined, fontSize: number, width?: number, height?: number): { width: number; height: number } {
  const kk = SHAPE_K[type] ?? SHAPE_K.rectangle;
  const k = kk.w;
  if (!text) return { width: width ?? 160, height: height ?? 80 };
  const lines = text.split("\n");
  const oneLine = estimateText(text, fontSize).width;
  const word = Math.max(...text.split(/\s+/).map((w) => w.length)) * fontSize * CHAR_W;
  let W = width ?? Math.min(340, Math.max(140, oneLine * k + 40));
  if ((W - 40) / k < word) W = Math.min(LIMITS.shapeW, word * k + 40);
  const inner = Math.max(40, (W - 40) / k);
  const wrapped = lines.reduce((n, l) => n + Math.max(1, Math.ceil((l.length * fontSize * CHAR_W) / inner)), 0);
  const needH = wrapped * fontSize * LINE_H * kk.h + 28;
  return { width: Math.round(W), height: Math.round(Math.max(height ?? 70, needH)) };
}

const centerOf = (b: Box) => ({ x: b.x + b.width / 2, y: b.y + b.height / 2 });
const GAP = 4;

function sidePoint(b: Box, side: Side, gap = GAP) {
  const c = centerOf(b);
  if (side === "right") return { x: b.x + b.width + gap, y: c.y };
  if (side === "left") return { x: b.x - gap, y: c.y };
  if (side === "top") return { x: c.x, y: b.y - gap };
  return { x: c.x, y: b.y + b.height + gap };
}
const OPPOSITE: Record<Side, Side> = { top: "bottom", bottom: "top", left: "right", right: "left" };

/** The sides two boxes should be joined at: the ones that face each other along the dominant axis. */
export function facingSides(a: Box, b: Box): [Side, Side] {
  const ca = centerOf(a);
  const cb = centerOf(b);
  const dx = cb.x - ca.x;
  const dy = cb.y - ca.y;
  const horizontal = Math.abs(dx) / (a.width / 2 + b.width / 2 || 1) >= Math.abs(dy) / (a.height / 2 + b.height / 2 || 1);
  const from: Side = horizontal ? (dx >= 0 ? "right" : "left") : dy >= 0 ? "bottom" : "top";
  return [from, OPPOSITE[from]];
}

export interface ArrowRoute {
  x: number;
  y: number;
  points: [number, number][];
  width: number;
  height: number;
  fromSide: Side;
  toSide: Side;
}

/** A path from box a to box b that leaves and enters at the middle of a side, straight, elbowed or curved. */
export function routeArrow(a: Box, b: Box, opts: { fromSide?: Side | "auto"; toSide?: Side | "auto"; route?: Route } = {}): ArrowRoute {
  const [autoFrom, autoTo] = facingSides(a, b);
  const fromSide = opts.fromSide && opts.fromSide !== "auto" ? opts.fromSide : autoFrom;
  const toSide = opts.toSide && opts.toSide !== "auto" ? opts.toSide : autoTo;
  const s = sidePoint(a, fromSide);
  const e = sidePoint(b, toSide);
  const dx = e.x - s.x;
  const dy = e.y - s.y;
  const hz = (side: Side) => side === "left" || side === "right";
  let pts: [number, number][] = [[0, 0], [dx, dy]];
  const route = opts.route ?? "straight";
  if (route === "elbow" && fromSide === toSide) {
    // Both ends on the same side: loop out and back in (a U), instead of cutting across the shapes.
    const out = 44;
    if (fromSide === "bottom") pts = [[0, 0], [0, Math.max(0, dy) + out], [dx, Math.max(0, dy) + out], [dx, dy]];
    else if (fromSide === "top") pts = [[0, 0], [0, Math.min(0, dy) - out], [dx, Math.min(0, dy) - out], [dx, dy]];
    else if (fromSide === "right") pts = [[0, 0], [Math.max(0, dx) + out, 0], [Math.max(0, dx) + out, dy], [dx, dy]];
    else pts = [[0, 0], [Math.min(0, dx) - out, 0], [Math.min(0, dx) - out, dy], [dx, dy]];
  } else if (route === "elbow" && dx !== 0 && dy !== 0) {
    if (hz(fromSide) && hz(toSide)) pts = [[0, 0], [dx / 2, 0], [dx / 2, dy], [dx, dy]];
    else if (!hz(fromSide) && !hz(toSide)) pts = [[0, 0], [0, dy / 2], [dx, dy / 2], [dx, dy]];
    else if (hz(fromSide)) pts = [[0, 0], [dx, 0], [dx, dy]];
    else pts = [[0, 0], [0, dy], [dx, dy]];
  } else if (route === "curve") {
    const len = Math.hypot(dx, dy) || 1;
    const bend = Math.min(60, len * 0.2);
    pts = [[0, 0], [dx / 2 + (-dy / len) * bend, dy / 2 + (dx / len) * bend], [dx, dy]];
  }
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return {
    x: r2(s.x),
    y: r2(s.y),
    points: pts.map((p) => [r2(p[0]), r2(p[1])] as [number, number]),
    width: r2(Math.max(...xs) - Math.min(...xs)),
    height: r2(Math.max(...ys) - Math.min(...ys)),
    fromSide,
    toSide,
  };
}

/* ------------------------------------------------------------------ planning */

/** What the planner needs to know about a shape an arrow points at. */
export interface Target {
  /** Stable key the caller resolves after conversion (a ref such as "s3"). */
  key: string;
  box: Box;
}

/** One element ready for convertToExcalidrawElements, plus what must be fixed up once it exists. */
export interface Planned {
  ref: string;
  skeleton: Record<string, unknown>;
  /** Target keys an arrow is bound to (done after conversion, so existing elements work too). */
  bind: { start?: Target; end?: Target };
  /** Text to centre on a point once its real size is known. */
  centerAt?: { x: number; y: number };
  /** Resolved geometry of a shape, for later arrows. */
  box?: Box;
}

const DEFAULT_STROKE = "#1e1e1e";
const DEFAULT_FILL = "#e3ecfe";

function strokeProps(e: SketchElementSpec, defaults: { stroke: string; roughness?: number }) {
  return {
    strokeColor: e.strokeColor ?? (e.type === "text" || isLinearType(e.type) || e.type === "freedraw" ? e.color : undefined) ?? defaults.stroke,
    strokeWidth: e.strokeWidth ?? 2,
    strokeStyle: e.strokeStyle ?? "solid",
    roughness: e.roughness ?? defaults.roughness ?? 0,
    opacity: e.opacity ?? 100,
  };
}

const clampFont = (n: number | undefined, fallback: number) => Math.max(12, n ?? fallback);

/** The final size of a shape spec (labels grow the box; nothing shrinks). */
export function shapeBox(e: SketchElementSpec): Box {
  const fs = clampFont(e.fontSize, 18);
  const size = fitShape(e.type, e.text, fs, e.width, e.height);
  return { x: e.x ?? 0, y: e.y ?? 0, width: size.width, height: size.height, type: e.type };
}

/** Plan one element. `targetOf` resolves an arrow's from/to (an index in a sketch, a ref in an edit). */
export function planElement(e: SketchElementSpec, ref: string, targetOf: (v: number | string | undefined) => Target | undefined, box?: Box): Planned {
  const customData = { ref };
  if (e.type === "text") {
    const fontSize = clampFont(e.fontSize, 20);
    const strokeColor = e.strokeColor ?? e.color ?? DEFAULT_STROKE;
    const x = e.x ?? 0;
    const y = e.y ?? 0;
    return {
      ref,
      bind: {},
      skeleton: {
        type: "text",
        x,
        y,
        text: e.text ?? "",
        fontSize,
        ...(fontFamilyOf(e.fontFamily) ? { fontFamily: fontFamilyOf(e.fontFamily) } : {}),
        ...(e.textAlign ? { textAlign: e.textAlign } : {}),
        strokeColor,
        opacity: e.opacity ?? 100,
        customData,
      },
      ...(e.anchor === "center" ? { centerAt: { x, y } } : {}),
    };
  }

  if (e.type === "freedraw") {
    const pts = (e.points ?? [[0, 0], [1, 1]]).map((p) => [p[0] - e.points![0][0], p[1] - e.points![0][1]] as [number, number]);
    const xs = pts.map((p) => p[0]);
    const ys = pts.map((p) => p[1]);
    const st = strokeProps(e, { stroke: DEFAULT_STROKE, roughness: 0 });
    return {
      ref,
      bind: {},
      // freedraw skips the converter's defaults, so every field of a real element is written here.
      skeleton: {
        type: "freedraw",
        id: `free-${ref}`,
        x: (e.x ?? 0) + e.points![0][0],
        y: (e.y ?? 0) + e.points![0][1],
        width: Math.max(...xs) - Math.min(...xs),
        height: Math.max(...ys) - Math.min(...ys),
        angle: 0,
        ...st,
        backgroundColor: e.backgroundColor ?? "transparent",
        fillStyle: e.fillStyle ?? "solid",
        groupIds: [],
        frameId: null,
        index: null,
        roundness: null,
        seed: Math.floor(Math.random() * 2 ** 31),
        version: 1,
        versionNonce: Math.floor(Math.random() * 2 ** 31),
        isDeleted: false,
        boundElements: null,
        updated: Date.now(),
        link: null,
        locked: false,
        points: pts,
        pressures: [],
        simulatePressure: true,
        lastCommittedPoint: null,
        customData,
      },
    };
  }

  if (isLinearType(e.type)) {
    const start = e.type === "arrow" ? targetOf(e.from) : undefined;
    const end = e.type === "arrow" ? targetOf(e.to) : undefined;
    const st = strokeProps(e, { stroke: DEFAULT_STROKE });
    const curve = e.rounded === true || e.route === "curve";
    let x = e.x ?? 0;
    let y = e.y ?? 0;
    let points: [number, number][];
    if (e.points) {
      points = e.points.map((p) => [p[0] - e.points![0][0], p[1] - e.points![0][1]] as [number, number]);
      x += e.points[0][0];
      y += e.points[0][1];
    } else if (start && end && start.key !== end.key) {
      const r = routeArrow(start.box, end.box, { fromSide: e.fromSide, toSide: e.toSide, route: e.route ?? (e.rounded === true ? "curve" : "straight") });
      x = r.x;
      y = r.y;
      points = r.points;
    } else {
      const w = e.width ?? 100;
      const h = e.height ?? 0;
      points = e.route === "elbow" && w !== 0 && h !== 0 ? [[0, 0], [w / 2, 0], [w / 2, h], [w, h]] : [[0, 0], [w, h]];
    }
    const xs = points.map((p) => p[0]);
    const ys = points.map((p) => p[1]);
    return {
      ref,
      bind: { ...(start ? { start } : {}), ...(end ? { end } : {}) },
      skeleton: {
        type: e.type,
        x,
        y,
        width: Math.max(...xs) - Math.min(...xs),
        height: Math.max(...ys) - Math.min(...ys),
        points,
        ...st,
        roundness: curve ? { type: 2 } : null,
        ...(e.type === "arrow"
          ? {
              startArrowhead: e.startArrowhead === undefined ? null : e.startArrowhead,
              endArrowhead: e.endArrowhead === undefined ? "arrow" : e.endArrowhead,
            }
          : { startArrowhead: null, endArrowhead: null }),
        customData,
        ...(e.type === "arrow" && e.text
          ? { label: { text: e.text, fontSize: clampFont(e.fontSize, 16), ...(fontFamilyOf(e.fontFamily) ? { fontFamily: fontFamilyOf(e.fontFamily) } : {}), strokeColor: labelColor(undefined, st.strokeColor) } }
          : {}),
      },
    };
  }

  // Shapes.
  const b = box ?? shapeBox(e);
  const fill = e.backgroundColor ?? e.color ?? DEFAULT_FILL;
  const st = strokeProps(e, { stroke: DEFAULT_STROKE });
  const rounded = e.rounded ?? e.type === "rectangle";
  return {
    ref,
    bind: {},
    box: b,
    skeleton: {
      type: e.type,
      x: b.x,
      y: b.y,
      width: b.width,
      height: b.height,
      ...st,
      backgroundColor: fill,
      fillStyle: e.fillStyle ?? "solid",
      roundness: rounded ? { type: 3 } : null,
      customData,
      ...(e.text
        ? {
            label: {
              text: e.text,
              fontSize: clampFont(e.fontSize, 18),
              ...(fontFamilyOf(e.fontFamily) ? { fontFamily: fontFamilyOf(e.fontFamily) } : {}),
              ...(e.textAlign ? { textAlign: e.textAlign } : {}),
              strokeColor: labelColor(fill, st.strokeColor, st.opacity),
            },
          }
        : {}),
    },
  };
}

/** Plan every element of a `sketch`. Arrows refer to shapes by index; shapes are sized first. */
export function planSketch(specs: SketchElementSpec[]): Planned[] {
  const boxes = specs.map((s) => (isShapeType(s.type) ? shapeBox(s) : undefined));
  const targetAt = (v: number | string | undefined): Target | undefined => {
    if (typeof v !== "number") return undefined;
    const box = boxes[v];
    return box ? { key: `s${v + 1}`, box } : undefined;
  };
  return specs.map((s, i) => planElement(s, `s${i + 1}`, targetAt, boxes[i]));
}

/**
 * After convertToExcalidrawElements: attach arrows to their shapes (binding data on both sides) and
 * centre anchored text. `byRef` maps refs to elements, converted or already in the scene.
 */
export function finishPlanned(planned: Planned[], byRef: Map<string, SketchEl>) {
  for (const p of planned) {
    const el = byRef.get(p.ref);
    if (!el) continue;
    if (p.centerAt) {
      el.x = r2(p.centerAt.x - el.width / 2);
      el.y = r2(p.centerAt.y - el.height / 2);
    }
    const bind = (target: Target | undefined, which: "startBinding" | "endBinding") => {
      const shape = target && byRef.get(target.key);
      if (!shape) return;
      el[which] = { elementId: shape.id, focus: 0, gap: GAP };
      const list = shape.boundElements ?? [];
      if (!list.some((b) => b.id === el.id)) shape.boundElements = [...list, { id: el.id, type: "arrow" }];
    };
    bind(p.bind.start, "startBinding");
    bind(p.bind.end, "endBinding");
  }
}

/* -------------------------------------------------------------- refs & edits */

export const refOf = (e: SketchEl) => (typeof e.customData?.ref === "string" ? (e.customData.ref as string) : null);

/** Give every live element the next free ref (s1, s2, …). Mutates customData in place. */
export function assignRefs(elements: SketchEl[]): Map<string, string> {
  const live = elements.filter((e) => !e.isDeleted);
  const used = new Set(live.map(refOf).filter((r): r is string => !!r));
  const byId = new Map<string, string>();
  let n = 1;
  for (const e of live) {
    let ref = refOf(e);
    if (!ref) {
      while (used.has(`s${n}`)) n++;
      ref = `s${n}`;
      used.add(ref);
      e.customData = { ...(e.customData ?? {}), ref };
    }
    byId.set(e.id, ref);
  }
  return byId;
}

/** Excalidraw needs a new version + nonce before it will repaint a mutated element. */
export function bump(e: SketchEl) {
  e.version = (e.version ?? 1) + 1;
  e.versionNonce = Math.floor(Math.random() * 2 ** 31);
}

const boxOfEl = (e: SketchEl): Box => ({ x: e.x, y: e.y, width: e.width, height: e.height, type: e.type });

/** Set a text element's text and give it a size that roughly matches, so selection boxes stay sane. */
function setText(el: SketchEl, text: string) {
  const fs = el.fontSize ?? 20;
  const m = estimateText(text, fs);
  el.text = text;
  el.originalText = text;
  if (!el.containerId) {
    el.width = Math.round(m.width);
    el.height = Math.round(m.height);
  }
  bump(el);
}

export interface PatchResult {
  problems: string[];
  /** Ids of shapes that moved or resized, so arrows attached to them can follow. */
  moved: boolean;
}

/**
 * Apply an `update` op's fields to an element. Position/size, colours, fill, stroke, opacity,
 * roughness, fonts, corners, arrowheads, points and text are all changeable; only the fields
 * present change. `labels` are the bound text elements of the target (a shape's or arrow's label).
 */
export function applyPatch(target: SketchEl, spec: Partial<SketchElementSpec>, labels: SketchEl[], refName: string): PatchResult {
  const problems: string[] = [];
  let moved = false;
  const shape = isShapeType(target.type);
  const linear = isLinearType(target.type);
  const isText = target.type === "text";
  if (typeof spec.x === "number" || typeof spec.y === "number" || typeof spec.width === "number" || typeof spec.height === "number") moved = true;
  if (typeof spec.x === "number") target.x = spec.x;
  if (typeof spec.y === "number") target.y = spec.y;
  if (typeof spec.width === "number" && !linear) target.width = Math.abs(spec.width);
  if (typeof spec.height === "number" && !linear) target.height = Math.abs(spec.height);
  if (linear && (typeof spec.width === "number" || typeof spec.height === "number") && !spec.points) {
    const pts = target.points ?? [[0, 0], [target.width, target.height]];
    const last = pts[pts.length - 1];
    const sx = typeof spec.width === "number" && last[0] !== 0 ? spec.width / last[0] : 1;
    const sy = typeof spec.height === "number" && last[1] !== 0 ? spec.height / last[1] : 1;
    target.points = pts.map((p) => [p[0] * sx, p[1] * sy] as [number, number]);
    target.width = Math.abs(typeof spec.width === "number" ? spec.width : target.width);
    target.height = Math.abs(typeof spec.height === "number" ? spec.height : target.height);
  }
  if (spec.points && (linear || target.type === "freedraw")) {
    const p0 = spec.points[0];
    target.points = spec.points.map((p) => [p[0] - p0[0], p[1] - p0[1]] as [number, number]);
    target.x += p0[0];
    target.y += p0[1];
    target.width = Math.max(...target.points.map((p) => p[0])) - Math.min(...target.points.map((p) => p[0]));
    target.height = Math.max(...target.points.map((p) => p[1])) - Math.min(...target.points.map((p) => p[1]));
    moved = true;
  }
  // "color" is the short form: a shape's fill, otherwise the stroke.
  if (typeof spec.color === "string") {
    if (shape) target.backgroundColor = spec.color;
    else target.strokeColor = spec.color;
  }
  if (typeof spec.backgroundColor === "string") target.backgroundColor = spec.backgroundColor;
  if (typeof spec.strokeColor === "string") target.strokeColor = spec.strokeColor;
  if (typeof spec.fillStyle === "string") target.fillStyle = spec.fillStyle;
  if (typeof spec.strokeStyle === "string") target.strokeStyle = spec.strokeStyle;
  if (typeof spec.strokeWidth === "number") target.strokeWidth = spec.strokeWidth;
  if (typeof spec.roughness === "number") target.roughness = spec.roughness;
  if (typeof spec.opacity === "number") target.opacity = spec.opacity;
  if (typeof spec.rounded === "boolean") target.roundness = spec.rounded ? { type: shape ? 3 : 2 } : null;
  if (linear && target.type === "arrow") {
    if (spec.startArrowhead !== undefined) target.startArrowhead = spec.startArrowhead;
    if (spec.endArrowhead !== undefined) target.endArrowhead = spec.endArrowhead;
  }
  const fontBits = (el: SketchEl) => {
    if (typeof spec.fontSize === "number") el.fontSize = Math.max(12, spec.fontSize);
    const ff = fontFamilyOf(spec.fontFamily);
    if (ff) el.fontFamily = ff;
    if (typeof spec.textAlign === "string") el.textAlign = spec.textAlign;
    if (typeof spec.fontSize === "number" || ff || spec.textAlign) bump(el);
  };
  if (isText) fontBits(target);
  else for (const l of labels) fontBits(l);
  // A label that was on a dark fill stays readable when the fill changes.
  if (!isText && shape && (spec.color || spec.backgroundColor)) {
    for (const l of labels) {
      l.strokeColor = labelColor(target.backgroundColor, target.strokeColor, target.opacity ?? 100);
      bump(l);
    }
  } else if (!isText && typeof spec.strokeColor === "string" && labels.length && !shape) {
    for (const l of labels) {
      l.strokeColor = spec.strokeColor;
      bump(l);
    }
  }
  if (typeof spec.text === "string") {
    if (isText) setText(target, spec.text);
    else {
      const label = labels[0];
      if (label) {
        setText(label, spec.text);
        // A longer label may need a bigger shape.
        if (shape) {
          const fit = fitShape(target.type, spec.text, label.fontSize ?? 18, target.width, target.height);
          if (fit.width > target.width || fit.height > target.height) {
            target.width = fit.width;
            target.height = fit.height;
            moved = true;
          }
        }
      } else problems.push(`${refName} has no label to change`);
    }
  }
  if (isText && typeof spec.anchor === "string") {
    /* anchoring only matters when a text is first placed */
  }
  bump(target);
  return { problems, moved };
}

const axisAligned = (pts: [number, number][]) => pts.every((p, i) => i === 0 || p[0] === pts[i - 1][0] || p[1] === pts[i - 1][1]);

/**
 * Arrows attached at both ends follow their shapes: after a move or resize their path is routed
 * again between the same two shapes (elbowed arrows stay elbowed). Returns how many were moved.
 */
export function rerouteBoundArrows(elements: SketchEl[], changedIds: Set<string>): number {
  const live = new Map(elements.filter((e) => !e.isDeleted).map((e) => [e.id, e] as const));
  let n = 0;
  for (const a of elements) {
    if (a.isDeleted || a.type !== "arrow") continue;
    const s = a.startBinding?.elementId ? live.get(a.startBinding.elementId) : undefined;
    const e = a.endBinding?.elementId ? live.get(a.endBinding.elementId) : undefined;
    if (!s || !e || s.id === e.id) continue;
    if (!changedIds.has(s.id) && !changedIds.has(e.id)) continue;
    const pts = a.points ?? [];
    const route: Route = pts.length === 3 || pts.length === 4 ? (axisAligned(pts) ? "elbow" : "curve") : "straight";
    const r = routeArrow(boxOfEl(s), boxOfEl(e), { route: pts.length > 2 ? route : "straight" });
    a.x = r.x;
    a.y = r.y;
    a.points = r.points;
    a.width = r.width;
    a.height = r.height;
    bump(a);
    // Its label follows the arrow's new midpoint.
    for (const l of elements) if (l.containerId === a.id && !l.isDeleted) bump(l);
    n++;
  }
  return n;
}

/* ---------------------------------------------------------------- the listing */

const r1 = (n: number) => Math.round(Number.isFinite(n) ? n : 0);

/**
 * One line per element with its stable ref, e.g. `s3 rectangle 100 40 140 72 fill #e3ecfe "Label"`
 * and `s7 arrow s3→s4`. Non-default styling is appended (stroke, dashed, font size, opacity…) so
 * Leo can match and adjust what is there. Refs live in element.customData.ref.
 */
export function describeSketch(scene: string): string {
  let elements: SketchEl[] = [];
  try {
    elements = (JSON.parse(scene || "{}").elements ?? []) as SketchEl[];
  } catch {
    return "(this sketch could not be read)";
  }
  if (!Array.isArray(elements) || !elements.length) return "(empty sketch)";
  const byId = assignRefs(elements);
  const labelOf = new Map<string, string>();
  const labelEl = new Map<string, SketchEl>();
  for (const e of elements) {
    if (e.containerId && typeof e.text === "string" && !e.isDeleted) {
      labelOf.set(e.containerId, e.text);
      labelEl.set(e.containerId, e);
    }
  }
  const style = (e: SketchEl, label?: SketchEl) => {
    const bits: string[] = [];
    if (e.strokeColor && e.strokeColor !== "#1e1e1e" && e.strokeColor !== "#17171a") bits.push(`stroke ${e.strokeColor}`);
    if (e.strokeStyle && e.strokeStyle !== "solid") bits.push(e.strokeStyle);
    if (e.strokeWidth && e.strokeWidth !== 2) bits.push(`w${e.strokeWidth}`);
    if (e.fillStyle && e.fillStyle !== "solid" && e.backgroundColor && e.backgroundColor !== "transparent") bits.push(e.fillStyle);
    if (typeof e.opacity === "number" && e.opacity !== 100) bits.push(`opacity ${e.opacity}`);
    if (e.roughness && e.type !== "text") bits.push(`rough ${e.roughness}`);
    const fs = e.type === "text" ? e.fontSize : label?.fontSize;
    const usual = e.type === "text" ? 20 : e.type === "arrow" || e.type === "line" ? 16 : 18;
    if (fs && fs !== usual) bits.push(`font ${fs}`);
    return bits.length ? ` [${bits.join(", ")}]` : "";
  };
  const lines = elements
    .filter((e) => !e.isDeleted && !e.containerId)
    .map((e) => {
      const ref = byId.get(e.id) ?? "?";
      const label = e.type === "text" ? e.text : labelOf.get(e.id);
      const text = label ? ` "${label.replace(/\s*\n\s*/g, " / ")}"` : "";
      if (e.type === "arrow" || e.type === "line") {
        const from = e.startBinding?.elementId ? byId.get(e.startBinding.elementId) : undefined;
        const to = e.endBinding?.elementId ? byId.get(e.endBinding.elementId) : undefined;
        const ends = from && to ? `${from}→${to}` : `${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}`;
        return `${ref} ${e.type} ${ends}${style(e, labelEl.get(e.id))}${text}`;
      }
      if (e.type === "freedraw") return `${ref} freedraw ${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}${style(e)}`;
      const fill = e.backgroundColor && e.backgroundColor !== "transparent" ? ` ${e.backgroundColor}` : e.type === "text" ? "" : " transparent";
      return `${ref} ${e.type} ${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}${fill}${style(e, labelEl.get(e.id))}${text}`;
    });
  return lines.length ? lines.join("\n") : "(empty sketch)";
}

/* ----------------------------------------------------------------- the lint */

const overlapArea = (a: Box, b: Box) => Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
const contains = (outer: Box, inner: Box, slack = 6) => inner.x >= outer.x - slack && inner.y >= outer.y - slack && inner.x + inner.width <= outer.x + outer.width + slack && inner.y + inner.height <= outer.y + outer.height + slack;

function segmentHitsBox(p: [number, number], q: [number, number], b: Box): boolean {
  // Liang–Barsky against the box shrunk a little, so grazing an edge is not a hit.
  const m = 6;
  const [xmin, xmax, ymin, ymax] = [b.x + m, b.x + b.width - m, b.y + m, b.y + b.height - m];
  if (xmax <= xmin || ymax <= ymin) return false;
  const dx = q[0] - p[0];
  const dy = q[1] - p[1];
  let t0 = 0;
  let t1 = 1;
  for (const [pp, qq] of [[-dx, p[0] - xmin], [dx, xmax - p[0]], [-dy, p[1] - ymin], [dy, ymax - p[1]]] as [number, number][]) {
    if (pp === 0) {
      if (qq < 0) return false;
    } else {
      const t = qq / pp;
      if (pp < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
      if (t0 > t1) return false;
    }
  }
  return true;
}

/**
 * Composition problems in a finished scene, as short lines Leo can act on: shapes or text that
 * overlap without one containing the other, and arrows that cut through a shape they do not join.
 * Panels that contain other shapes (zones) are fine and never reported.
 */
export function lintScene(elements: SketchEl[], limit = 6): string[] {
  const live = elements.filter((e) => !e.isDeleted);
  const byId = new Map(live.map((e) => [e.id, e] as const));
  const refs = assignRefs(elements);
  const name = (e: SketchEl) => {
    const label = e.type === "text" ? e.text : live.find((l) => l.containerId === e.id)?.text;
    return `${refs.get(e.id) ?? "?"}${label ? ` “${label.replace(/\s+/g, " ").slice(0, 24)}”` : ` ${e.type}`}`;
  };
  const solid = live.filter((e) => !e.containerId && (isShapeType(e.type) || e.type === "text"));
  const notes: string[] = [];
  for (let i = 0; i < solid.length; i++) {
    for (let j = i + 1; j < solid.length; j++) {
      const a = solid[i];
      const b = solid[j];
      if (a.type === "text" && b.type === "text" ? false : contains(boxOfEl(a), boxOfEl(b)) || contains(boxOfEl(b), boxOfEl(a))) continue;
      const area = overlapArea(boxOfEl(a), boxOfEl(b));
      const small = Math.min(a.width * a.height, b.width * b.height) || 1;
      if (area / small > (a.type === "text" || b.type === "text" ? 0.08 : 0.12)) notes.push(`${name(a)} overlaps ${name(b)}`);
    }
  }
  for (const a of live) {
    if (a.type !== "arrow" || !a.points || a.points.length < 2) continue;
    const joined = new Set([a.startBinding?.elementId, a.endBinding?.elementId]);
    const path = a.points.map((p) => [a.x + p[0], a.y + p[1]] as [number, number]);
    for (const s of live) {
      if (!isShapeType(s.type) || s.containerId || joined.has(s.id) || !byId.has(s.id)) continue;
      // A panel the arrow starts and ends inside is a zone, not an obstacle.
      const inside = (pt: [number, number]) => pt[0] >= s.x && pt[0] <= s.x + s.width && pt[1] >= s.y && pt[1] <= s.y + s.height;
      if (inside(path[0]) && inside(path[path.length - 1])) continue;
      if (path.slice(1).some((pt, k) => segmentHitsBox(path[k], pt, boxOfEl(s)))) notes.push(`arrow ${name(a)} passes through ${name(s)}`);
    }
  }
  return [...new Set(notes)].slice(0, limit);
}

/* ------------------------------------------------------------------- camera */

/**
 * The scroll and zoom that show `rect` (scene coordinates) centred in a viewport of the given pixel
 * size. Excalidraw maps scene x to screen as (x + scrollX) * zoom.
 */
export function cameraView(viewport: { width: number; height: number }, rect: CameraRect, maxZoom = 3): { zoom: number; scrollX: number; scrollY: number } {
  const zoom = Math.min(maxZoom, Math.max(0.1, Math.min(viewport.width / rect.width, viewport.height / rect.height)));
  return {
    zoom,
    scrollX: -rect.x + (viewport.width / zoom - rect.width) / 2,
    scrollY: -rect.y + (viewport.height / zoom - rect.height) / 2,
  };
}

/** The 4:3 camera that frames a set of elements with some padding — the final overview shot. */
export function overviewCamera(elements: readonly { x: number; y: number; width: number; height: number; isDeleted?: boolean }[], pad = 48): CameraRect | null {
  const live = elements.filter((e) => !e.isDeleted);
  if (!live.length) return null;
  const x0 = Math.min(...live.map((e) => Math.min(e.x, e.x + e.width)));
  const y0 = Math.min(...live.map((e) => Math.min(e.y, e.y + e.height)));
  const x1 = Math.max(...live.map((e) => Math.max(e.x, e.x + e.width)));
  const y1 = Math.max(...live.map((e) => Math.max(e.y, e.y + e.height)));
  let w = x1 - x0 + pad * 2;
  let h = y1 - y0 + pad * 2;
  if (w / h < 4 / 3) w = (h * 4) / 3;
  else h = (w * 3) / 4;
  return { x: (x0 + x1) / 2 - w / 2, y: (y0 + y1) / 2 - h / 2, width: w, height: h };
}
