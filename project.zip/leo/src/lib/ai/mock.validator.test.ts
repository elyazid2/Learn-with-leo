/**
 * The developer mock tutor is how people try the app without an API key, and it goes through the
 * same parser and validator as a real model. Every scripted reply must therefore stay valid when
 * the validator gets stricter.
 */
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import type { ChatMode, Project } from "@/lib/db";
import { streamMockChat } from "./mock";
import { parseSegments, type Segment } from "./actions";

const project = { id: "p", name: "Cell biology", tag: "biology", color: "green", createdAt: 1, updatedAt: 1, placement: { status: "pending" } } as Project;

// The mock streams with real pauses between chunks; fake timers run them instantly.
beforeAll(() => {
  vi.useFakeTimers();
});
afterAll(() => {
  vi.useRealTimers();
});

async function reply(text: string, mode: ChatMode = "ask"): Promise<Segment[]> {
  let out = "";
  let finished = false;
  const run = (async () => {
    for await (const chunk of streamMockChat(project, mode, [{ role: "user", content: text }], { delay: 0, behavior: "auto" }, new AbortController().signal)) out += chunk;
  })().finally(() => {
    finished = true;
  });
  while (!finished) await vi.advanceTimersByTimeAsync(500);
  await run;
  return parseSegments(out);
}
const types = (segs: Segment[]) => segs.flatMap((s) => (s.kind === "action" ? [s.action.type] : []));
const problems = (segs: Segment[]) => segs.flatMap((s) => (s.kind === "invalid" ? [s.reason] : []));

describe("the mock tutor's replies pass the validator", () => {
  const cases: [prompt: string, expects: string | null, mode?: ChatMode][] = [
    ["write a note about osmosis", "note"],
    ["draw a diagram of the cell cycle", null],
    ["look it up on Wikipedia", "browser"],
    ["quiz me", "quiz"],
    ["teach me the next thing", null],
    ["give me a practice test", "practice_test"],
    ["organize my notes", "organize"],
    ["add a pomodoro timer", "add_tool"],
    ["change your avatar color", "set_avatar"],
    ["hello there", null],
    ["Start the placement. Ask me your first question.", null, "placement"],
  ];
  for (const [prompt, expects, mode] of cases) {
    it(`"${prompt}"${expects ? ` → ${expects}` : ""}`, async () => {
      const segs = await reply(prompt, mode);
      expect(problems(segs)).toEqual([]);
      if (expects) expect(types(segs)).toContain(expects);
    });
  }
});
