# Drawing guide — how to write sketches in Harness

This guide describes exactly what the `sketch` and `edit_sketch` actions accept. Everything here runs; nothing here needs another tool. You have read it now — do not read it again in this chat.

A sketch is a JSON action. Its `elements` array lists what to draw, in the order it should appear on the learner's screen (the sketch is drawn live, one element at a time).

```action
{"type":"sketch","title":"Short title","elements":[ ... ]}
```

## 1. Elements

| type | what | placement |
|---|---|---|
| `rectangle` `ellipse` `diamond` | a shape; `text` is a label centred inside | `x`,`y` = top-left corner; `width`,`height` optional |
| `text` | a title or note on its own | `x`,`y` = top-left, or add `"anchor":"center"` and `x`,`y` is its centre |
| `arrow` | a connector, with an arrowhead at the end | between shapes: `from` + `to` (nothing else needed). Free: `x`,`y` + `points` or `width`,`height` |
| `line` | like an arrow with no heads | `x`,`y` + `points` or `width`,`height` |
| `freedraw` | a hand-drawn stroke (curve, underline, simple icon) | `x`,`y` + `points` |

- Give every shape you will connect an `"id"` (any short string, e.g. `"in"`). Then `"from":"in","to":"proc"` joins them. The app draws the arrow between the facing sides of the two shapes and attaches it, so it stays connected when the learner moves a shape. Do not compute arrow coordinates yourself. (`from`/`to` also accept an element's index in the array, 0-based.)
- `points` are `[dx,dy]` offsets from `x`,`y`, starting at `[0,0]`: `[[0,0],[120,0],[120,80]]` is an L-shaped path.
- An arrow's `text` is its label — keep it to 1–3 words.
- The app enlarges a shape if its text would not fit, but it never shrinks one. Plan for the final size.

## 2. Style — every field is optional

| field | values | notes |
|---|---|---|
| `color` | `#rrggbb` | short form: the fill of a shape, the stroke of text/arrows/lines |
| `backgroundColor` | `#rrggbb` or `"transparent"` | fill |
| `strokeColor` | `#rrggbb` or `"transparent"` | outline / text colour |
| `fillStyle` | `solid` `hachure` `cross-hatch` `zigzag` | default `solid` |
| `strokeWidth` | 1, 2 (default), 4 | |
| `strokeStyle` | `solid` `dashed` `dotted` | dashed = optional / returns / boundaries |
| `roughness` | 0 clean (default), 1 sketchy, 2 very sketchy | keep 0 for maths and technical figures |
| `opacity` | 0–100 | use 25–40 for big background panels |
| `fontSize` | 14–48 | see sizes below |
| `fontFamily` | `hand` `normal` `code` | |
| `textAlign` | `left` `center` `right` | |
| `rounded` | `true` / `false` | rounded corners; rectangles are rounded unless `false`. On arrows/lines: a smooth curve |
| `route` | `straight` (default) `elbow` `curve` | arrows between shapes |
| `fromSide` `toSide` | `top` `right` `bottom` `left` | force which side an arrow leaves / enters (default: the sides that face each other) |
| `startArrowhead` `endArrowhead` | `null` `arrow` `bar` `dot` `triangle` `diamond` (+ `_outline` variants) | `endArrowhead` defaults to `arrow`; use `null` for a plain line |

Guide-style spellings are accepted too and translated: `label:{text,fontSize}`, `roundness:{type:3}`, `startBinding`/`endBinding` with `elementId` and `fixedPoint`, `elbowed:true`, `arrowType`. Colour names like `"red"` map to the palette; always prefer hex.

## 3. Camera — `cameraUpdate`

A `cameraUpdate` entry in `elements` is not drawn. It moves the learner's view before the elements after it appear:

`{"type":"cameraUpdate","x":0,"y":0,"width":800,"height":600}`

- `x`,`y` = top-left of the area to show (scene coordinates); `width`,`height` = its size. Use 4:3 sizes: 400×300 (close-up), 600×450, 800×600 (standard), 1200×900 (large overview).
- Start with a camera on the first group, move it as you draw the next group, and the app ends on a full overview of everything automatically — you do not need a final camera.
- Cameras do not count in element indices. Cap: 12.
- For a diagram that fits in 900×600, one camera (or none) is enough. Use several only for big or step-by-step diagrams.

`{"type":"delete","ids":"a,b"}` entries remove earlier elements by `id` (no animation). Checkpoints (`restoreCheckpoint`) do not exist here; to change a saved sketch later, use `edit_sketch`.

## 4. Progressive drawing

Elements appear in array order. Order them the way you would explain it: title → first shape → its arrow → next shape → … Background panels first (so they sit behind), decorations last. Labelled shapes appear with their text.

## 5. Layout rules (readability)

- Plan a grid before you write coordinates. The default view is about 900×600; a 4:3 camera lets you go bigger.
- Standard box: 180×80 with `fontSize` 18. Gap between neighbouring shapes: at least 60 px horizontally and 50 px vertically — arrows and their labels need that room.
- Flow left→right or top→bottom. Align shapes on shared x or y values (columns at x = 60, 300, 540, 780; rows at y = 120, 260, 400).
- Title: a `text` at `fontSize` 28, centred over the diagram with `"anchor":"center"` (x = middle of the diagram, y ≈ 30).
- Font sizes: titles 24–28, labels 16–20, annotations 14. Never below 14. 3–15 shapes beat 40 tiny ones.
- Text over a fill must contrast: dark text on pastel fills (the app picks light text on dark fills for labels). Never light grey on white: minimum text colour `#757575`.
- Do not stack elements closer than their own height. Standalone text must not touch shapes or arrows.
- To group things, draw a large rounded rectangle first (`opacity` 30, a zone fill, `strokeStyle` `dashed`) and place the members inside it with 20 px+ padding; give it a small `text` title as a separate `text` element at its top-left.
- Use at most 4–5 colours, with the same meaning each time. No emoji (they do not render).
- After you create a sketch, the app may send a "Layout check" listing overlaps. Fix them with `edit_sketch` (update `x`/`y`; arrows follow) or leave them if harmless.

## 6. Palette

Strokes / accents: blue `#4a9eed`, amber `#f59e0b`, green `#22c55e`, red `#ef4444`, purple `#8b5cf6`, pink `#ec4899`, cyan `#06b6d4`, lime `#84cc16`. Dark text variants for coloured text on light fills: `#15803d`, `#2563eb`, `#b45309`, `#b91c1c`.

Fills (pastel): light blue `#a5d8ff` (input, sources) · light green `#b2f2bb` (success, output) · light orange `#ffd8a8` (warning, external) · light purple `#d0bfff` (processing) · light red `#ffc9c9` (error, critical) · light yellow `#fff3bf` (notes, decisions) · light teal `#c3fae8` (storage, data) · light pink `#eebefa` (metrics).

Zones (use with `opacity` 30): blue `#dbe4ff`, purple `#e5dbff`, green `#d3f9d8`.

Defaults when you omit a field: shapes get a pale blue fill `#e3ecfe`, near-black outline, `strokeWidth` 2, `roughness` 0; labels are centred in their shape.

## 7. Example — process with a decision

```action
{"type":"sketch","title":"Study loop","elements":[
 {"type":"cameraUpdate","x":0,"y":0,"width":800,"height":600},
 {"type":"text","x":400,"y":30,"anchor":"center","text":"The study loop","fontSize":28},
 {"type":"rectangle","id":"learn","x":60,"y":100,"width":180,"height":80,"text":"Learn a chunk","color":"#a5d8ff","strokeColor":"#4a9eed"},
 {"type":"rectangle","id":"test","x":310,"y":100,"width":180,"height":80,"text":"Test yourself","color":"#fff3bf","strokeColor":"#f59e0b"},
 {"type":"arrow","from":"learn","to":"test","text":"then"},
 {"type":"diamond","id":"ok","x":560,"y":80,"width":200,"height":120,"text":"Got it?","color":"#d0bfff","strokeColor":"#8b5cf6"},
 {"type":"arrow","from":"test","to":"ok"},
 {"type":"rectangle","id":"next","x":560,"y":300,"width":200,"height":80,"text":"Next chunk","color":"#b2f2bb","strokeColor":"#22c55e"},
 {"type":"arrow","from":"ok","to":"next","text":"yes"},
 {"type":"rectangle","id":"redo","x":310,"y":300,"width":180,"height":80,"text":"Review the gap","color":"#ffc9c9","strokeColor":"#ef4444"},
 {"type":"arrow","from":"ok","to":"redo","text":"no","route":"elbow","fromSide":"bottom","toSide":"right","strokeStyle":"dashed"},
 {"type":"arrow","from":"redo","to":"test","route":"elbow","fromSide":"top","toSide":"bottom","strokeStyle":"dashed"}
]}
```

## 8. Editing later — `edit_sketch`

Read the sketch first (`read` with `kind":"sketch"`): you get one line per element with its ref (`s1`, `s2`, …), position, size, fill, non-default style and label; attached arrows read `s3→s4`. Then send small ops:

- `{"op":"add","element":{...}}` — any element above; an arrow may use refs — `{"type":"arrow","from":"s3","to":"s4"}` — or the `id` of an element added earlier in the same edit (give the new shape an `id`).
- `{"op":"update","ref":"s3","element":{...}}` — only the fields to change: `x` `y` `width` `height` `text` `color` `backgroundColor` `strokeColor` `fillStyle` `strokeWidth` `strokeStyle` `roughness` `opacity` `fontSize` `fontFamily` `textAlign` `rounded` `startArrowhead` `endArrowhead` `points`. Moving or resizing a shape re-routes the arrows attached to it.
- `{"op":"delete","ref":"s3"}` — also removes its label and detaches its arrows.
- `{"op":"camera","camera":{"x":0,"y":0,"width":800,"height":600}}` — look somewhere while the edits are painted.

Make the smallest change that does the job; do not redraw a sketch the learner may have edited.
