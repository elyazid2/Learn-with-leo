import {
  db,
  uid,
  type ActionResult,
  type CitationRef,
  type Concept,
  type ConceptStatus,
  type MemoryKind,
  type Message,
  type Note,
  type PendingAction,
  type PointKind,
  type SourceRef,
} from "../db";
import { versionsWithCurrent } from "../noteVersions";
import { trashItem } from "../trash";
import { SKETCH_VERSION_LIMIT } from "../db";
import { stage } from "../live";
import { useApp } from "../store";
import { useSettings } from "../settings";
import { applyOrganize, organizeProblem, type OrganizeOp } from "../organize";
import { createTool, isToolKind, TOOL_KINDS } from "../tools";
import { cleanFolder as cleanNoteFolder, readableTitle, renameNote, uniqueTitle } from "../notes";
import { publicUrlProblem } from "./publicUrl";
import {
  LIMITS,
  applyPatch,
  assignRefs,
  bump,
  camerasProblem,
  describeSketch,
  finishPlanned,
  lintScene,
  planElement,
  planSketch,
  prepareSketchElements,
  prepareSketchOps,
  rerouteBoundArrows,
  shapeBox,
  sketchElementProblem,
  sketchOpProblem,
  type CameraRect,
  type SketchCamera,
  type SketchEl,
  type SketchElementSpec,
  type SketchOp,
  type Target,
} from "./sketchSpec";
import { isStopped } from "../turn";
import { fullResultIndexes } from "./context";
export type { SketchElementSpec, SketchOp, CameraRect, SketchCamera };
export { describeSketch };
// On-demand guides for Leo, bundled as raw strings so they work client-side. The markdown file is
// the drawing guide: it documents exactly what the sketch / edit_sketch actions accept (no external tool).
import excalidrawGuide from "./guides/excalidraw-readme.md?raw";

const GUIDES: Record<string, string> = { excalidraw: excalidrawGuide };
import {
  isAvatarColor,
  isAvatarExpression,
  isAvatarShape,
  normalizeAvatarLook,
  type AvatarLook,
} from "../avatar";

export type Action =
  | { type: "ask"; question: string; options: string[] }
  | {
      type: "quiz";
      question: string;
      options: string[];
      answer: number;
      explanation?: string;
      concept?: string;
      /** Where the question comes from, e.g. "book.pdf, p.12" — stored on the review card. */
      source?: string;
    }
  | { type: "set_level"; level: string; summary?: string; startingPoint?: string }
  | { type: "map"; concept: string; status?: ConceptStatus; parent?: string; note?: string }
  | { type: "point"; kind: PointKind; text: string }
  | { type: "resolve_point"; text: string }
  | { type: "set_avatar"; shape?: AvatarLook["shape"]; color?: AvatarLook["color"]; expression?: AvatarLook["expression"] }
  /** Grade an open-ended (typed) answer so it counts toward the map and review schedule. */
  | { type: "assess"; concept: string; correct: boolean; note?: string }
  /** Without an id: create. With an id: "append" (default), "patch" (exact find/replace edits) or "replace". */
  | {
      type: "note";
      id?: string;
      title: string;
      content: string;
      mode?: NoteMode;
      patches?: NotePatch[];
      /** New notes only: folder path such as "Biology/Cells". */
      folder?: string;
      /** Passages the note is grounded in. */
      sources?: SourceRef[];
    }
  | { type: "read"; kind: "note" | "sketch" | "guide"; id: string; /** Notes only: character offset to continue a long note from. */ from?: string }
  /** Read a library file: PDF pages, an audio/video time range, or a text range (paginated). */
  | { type: "read"; kind: "file"; id: string; pages?: string; from?: string; to?: string }
  /** Search the library (files, notes or both); returns the top passages. */
  | { type: "search"; query: string; scope?: "all" | "files" | "notes" }
  | { type: "edit_sketch"; id: string; ops: SketchOp[] }
  | { type: "sketch"; title: string; elements: SketchElementSpec[]; /** Camera moves from cameraUpdate entries; `at` = how many elements are drawn before the move. */ cameras?: SketchCamera[] }
  | { type: "browser"; url: string }
  | { type: "memory"; op: "save" | "update" | "delete"; id?: string; scope?: "global" | "project"; kind?: MemoryKind; text?: string }
  /** Create folders, move, rename and tag items. Always shown as a preview for the learner's approval. */
  | { type: "organize"; ops: OrganizeOp[]; reason?: string }
  /** Add a built-in tool (clock, calculator, converter, checklist, flash cards) to the library. */
  | { type: "add_tool"; tool: import("../db").ToolKind; title?: string; items?: string[]; cards?: { front: string; back: string }[] }
  /** A timed practice test built from library material; the learner starts it from the chat. */
  | { type: "practice_test"; title: string; minutes: number; source?: string; questions: PracticeQuestionSpec[] }
  /** Delete a library item. Always waits for the learner's approval; the item goes to the Trash, not away for good. */
  | { type: "delete"; kind: "note" | "sketch" | "file" | "tool"; id: string };

export interface PracticeQuestionSpec {
  q: string;
  options?: string[];
  answer?: number;
  model_answer?: string;
  concept?: string;
}

/** Leo's organizing and note changes wait for a preview unless Settings → "Always approve" is on. */
export const approvalRequired = () => !useSettings.getState().alwaysApprove;

/** Every action type the validator knows. A test checks the prompt's tool list against this. */
export const ACTION_TYPES = [
  "ask", "quiz", "assess", "set_level", "map", "point", "resolve_point", "set_avatar", "note", "read",
  "search", "edit_sketch", "sketch", "browser", "memory", "delete", "organize", "add_tool", "practice_test",
] as const;

/** Placement levels, as the prompt lists them and the Progress sheet draws them. */
export const LEVELS = ["Beginner", "Novice", "Intermediate", "Advanced", "Expert"] as const;

/** Words models use for a concept's status, mapped to the four the map stores. */
const STATUS_WORDS: Record<string, ConceptStatus> = {
  new: "new", "not started": "new", unseen: "new", unknown: "new",
  learning: "learning", "in progress": "learning",
  shaky: "shaky", weak: "shaky", partial: "shaky",
  solid: "solid", mastered: "solid", known: "solid", strong: "solid",
};

export type NoteMode = "append" | "replace" | "patch";

/** One exact edit: `find` must occur exactly once in the note; it is replaced by `replace`. */
export interface NotePatch {
  find: string;
  replace: string;
}

export type Segment =
  | { kind: "text"; text: string }
  | { kind: "action"; action: Action; index: number }
  /** A block the model emitted that we could not parse/validate. Shown to the learner and fed back to the model. */
  | { kind: "invalid"; raw: string; reason: string }
  | { kind: "pending"; hint?: string };

const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.length <= 8 && v.every((o) => typeof o === "string");

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

const numeric = (v: unknown) => (typeof v === "number" ? v : typeof v === "string" && v.trim() ? Number(v) : NaN);

/** Note sources as they are stored: a file id with a whole page number and/or a start second. Anything else is dropped. */
function cleanSources(raw: Record<string, unknown>[]): SourceRef[] {
  return raw.slice(0, 50).map((s) => {
    const page = numeric(s.page);
    const t0 = numeric(s.t0);
    return { fileId: s.fileId as string, ...(Number.isInteger(page) && page > 0 ? { page } : {}), ...(Number.isFinite(t0) && t0 >= 0 ? { t0 } : {}) };
  });
}

/** Opening fence of an action block: ```action plus anything up to the end of that line. */
const OPEN_RE = /```action[^\n]*\n/g;
/** A closing fence: a line that is exactly three backticks (surrounding spaces / a CR tolerated). */
const FENCE_LINE_RE = /^[ \t]*```[ \t]*\r?$/gm;
/** How many closing-fence lines we try before giving up and reporting the first one's parse error. */
const MAX_FENCE_TRIES = 6;

interface RawBlock {
  start: number;
  end: number;
  body: string;
}

/** True when a block body is syntactically JSON (one value, an array, or one object per line). */
function bodyParses(body: string): boolean {
  return !parseBody(body).invalid.some((i) => i.reason.startsWith("not valid JSON"));
}

/**
 * Find the action blocks in a reply. A block closes at a line that is exactly ``` — NOT at the first
 * ``` anywhere, because note markdown inside a JSON string may contain code fences. If the body up to
 * that line is not valid JSON, the block is extended to the next fence line (up to MAX_FENCE_TRIES).
 * Sloppy closers glued to the JSON (`}```) are still accepted when nothing else parses.
 * `openAt` is the start of a block that has no closer yet (still streaming, or cut off), else -1.
 */
function scanBlocks(content: string, streaming: boolean): { blocks: RawBlock[]; openAt: number } {
  const blocks: RawBlock[] = [];
  let pos = 0;
  for (;;) {
    OPEN_RE.lastIndex = pos;
    const open = OPEN_RE.exec(content);
    if (!open) {
      // An opener with no newline yet ("```action" at the very end) is still an open block.
      const bareOpen = content.indexOf("```action", pos);
      return { blocks, openAt: bareOpen };
    }
    const bodyStart = open.index + open[0].length;
    const closers: { at: number; end: number }[] = [];
    FENCE_LINE_RE.lastIndex = bodyStart;
    let f: RegExpExecArray | null;
    while (closers.length < MAX_FENCE_TRIES && (f = FENCE_LINE_RE.exec(content))) closers.push({ at: f.index, end: f.index + f[0].length });
    const legacyAt = content.indexOf("```", bodyStart);
    const legacy = legacyAt >= 0 ? { at: legacyAt, end: legacyAt + 3 } : undefined;

    let pick = closers.find((c) => bodyParses(content.slice(bodyStart, c.at)));
    if (!pick && legacy && bodyParses(content.slice(bodyStart, legacy.at))) pick = legacy;
    if (!pick) {
      // Nothing parses. With no fence line yet, a streaming block is simply still open.
      if (!closers.length && (streaming || !legacy)) return { blocks, openAt: open.index };
      pick = closers[0] ?? legacy!;
    }
    blocks.push({ start: open.index, end: pick.end, body: content.slice(bodyStart, pick.at) });
    pos = pick.end;
  }
}

/** Short, single-line version of a JSON.parse error ("Unexpected token } in JSON at position 42"). */
const jsonError = (e: unknown) => (e instanceof Error ? e.message : String(e)).replace(/\s+/g, " ").slice(0, 120);

function parseBody(body: string): { actions: Action[]; invalid: { raw: string; reason: string }[] } {
  const clean = body.trim();
  const out: unknown[] = [];
  const invalid: { raw: string; reason: string }[] = [];
  try {
    const j = JSON.parse(clean);
    if (Array.isArray(j)) out.push(...j);
    else out.push(j);
  } catch (e) {
    // One object per line (NDJSON) is parsed line by line; a single broken object is reported once, with the parser's reason.
    const lines = clean
      .split("\n")
      .map((l) => l.trim().replace(/,$/, ""))
      .filter(Boolean);
    const oneObjectPerLine = lines.length > 1 && lines.every((l) => l.startsWith("{") && l.endsWith("}"));
    // Valid JSON followed by trailing junk (a stray "}", a closing note, a second fence…):
    // keep the valid prefix and ignore the rest. NDJSON is handled below instead, because it
    // trips the same error at the start of its second object and must not be truncated.
    const trailing = /Unexpected non-whitespace character after JSON at position (\d+)/.exec(e instanceof Error ? e.message : String(e));
    let recovered = false;
    if (trailing && !oneObjectPerLine) {
      const n = Number(trailing[1]);
      try {
        const j = JSON.parse(clean.slice(0, n));
        if (Array.isArray(j)) out.push(...j);
        else out.push(j);
        recovered = true;
      } catch {
        /* fall through and report the original error */
      }
    }
    if (recovered) {
      /* parsed the valid prefix */
    } else if (oneObjectPerLine) {
      for (const l of lines) {
        try {
          out.push(JSON.parse(l));
        } catch (le) {
          invalid.push({ raw: l.slice(0, 200), reason: `not valid JSON (${jsonError(le)})` });
        }
      }
    } else {
      invalid.push({ raw: clean.slice(0, 200), reason: `not valid JSON (${jsonError(e)})` });
    }
  }
  const actions: Action[] = [];
  for (const o of out) {
    const r = coerceAction(o);
    if ("action" in r) actions.push(r.action);
    else invalid.push({ raw: JSON.stringify(o)?.slice(0, 200) ?? String(o), reason: r.reason });
  }
  return { actions, invalid };
}

/** Make a parsed object as acceptable as it can honestly be before validation. */
function prepareAction(o: unknown): unknown {
  if (!isRecord(o)) return o;
  if (o.type === "sketch" && Array.isArray(o.elements)) {
    const { elements, cameras } = prepareSketchElements(o.elements);
    return { ...o, elements, ...(cameras.length ? { cameras } : {}) };
  }
  if (o.type === "edit_sketch" && Array.isArray(o.ops)) return { ...o, ops: prepareSketchOps(o.ops) };
  return o;
}

const show = (v: unknown) => {
  const s = JSON.stringify(v) ?? String(v);
  return s.length > 40 ? `${s.slice(0, 40)}…` : s;
};

/** Why a parsed object is not an action we can run, or null when it is one. */
function actionProblem(a: unknown): string | null {
  if (!isRecord(a)) return `${show(a)} is not a JSON object`;
  const o = a;
  switch (o.type) {
    case "ask":
      return typeof o.question === "string" && isStringArray(o.options) ? null : "ask needs a string question and 1–8 string options";
    case "quiz":
      if (typeof o.question !== "string") return "quiz needs a string question";
      if (!isStringArray(o.options) || o.options.length < 2) return "quiz needs 2–8 string options";
      if (typeof o.answer !== "number" || !Number.isInteger(o.answer) || o.answer < 0 || o.answer >= o.options.length)
        return `quiz "answer" must be the 0-based index of the correct option (0–${o.options.length - 1}; got ${show(o.answer)})`;
      return null;
    case "assess":
      return typeof o.concept === "string" && typeof o.correct === "boolean" ? null : "assess needs a string concept and a boolean correct";
    case "set_level": {
      if (typeof o.level !== "string") return "set_level needs a string level";
      const given = o.level.trim().toLowerCase();
      // "upper-intermediate" is Intermediate. A word that fits no level, or two, is not guessed.
      const exact = LEVELS.filter((l) => given === l.toLowerCase());
      const near = exact.length ? exact : LEVELS.filter((l) => given.includes(l.toLowerCase()));
      if (near.length !== 1) return `set_level "level" must be one of ${LEVELS.join(", ")} (got ${show(o.level)})`;
      o.level = near[0];
      return null;
    }
    case "map": {
      if (typeof o.concept !== "string" || !o.concept.trim()) return "map needs a string concept";
      if (o.status === undefined || o.status === null) return null;
      const status = typeof o.status === "string" ? STATUS_WORDS[o.status.trim().toLowerCase().replace(/[_-]+/g, " ")] : undefined;
      if (!status) return `map status must be new, learning, shaky or solid (got ${show(o.status)})`;
      o.status = status;
      return null;
    }
    case "point":
      if (typeof o.text !== "string") return "point needs a string text";
      return ["careful", "confused", "next"].includes(o.kind as string) ? null : `point kind must be careful, confused or next (got ${show(o.kind)})`;
    case "resolve_point":
      return typeof o.text === "string" ? null : "resolve_point needs the point's exact text";
    case "set_avatar":
      if (o.shape !== undefined && !isAvatarShape(o.shape)) return `set_avatar: unknown shape ${show(o.shape)}`;
      if (o.color !== undefined && !isAvatarColor(o.color)) return `set_avatar: unknown color ${show(o.color)}`;
      if (o.expression !== undefined && !isAvatarExpression(o.expression)) return `set_avatar: unknown expression ${show(o.expression)}`;
      return o.shape !== undefined || o.color !== undefined || o.expression !== undefined ? null : "set_avatar needs a shape, color or expression";
    case "note":
      if (typeof (o.title ?? "") !== "string") return "note title must be a string";
      if (o.id !== undefined && typeof o.id !== "string") return "note id must be a string";
      if (o.mode !== undefined && !["append", "replace", "patch"].includes(o.mode as string)) return `note mode must be append, patch or replace (got ${show(o.mode)})`;
      if (o.mode === "patch") {
        if (typeof o.id !== "string" || !o.id) return "note patch needs the id of the note to edit";
        if (!Array.isArray(o.patches) || !o.patches.length) return 'note patch needs a non-empty "patches" array of {"find","replace"}';
        if (o.patches.length > 20) return `note patch has ${o.patches.length} patches; the limit is 20`;
        for (let i = 0; i < o.patches.length; i++) {
          const p = o.patches[i];
          if (!isRecord(p) || typeof p.find !== "string" || !p.find || typeof p.replace !== "string")
            return `note patch ${i + 1} must be {"find": non-empty string, "replace": string}`;
        }
        if (o.content !== undefined && typeof o.content !== "string") return "note content must be a string";
        return null;
      }
      if (o.folder !== undefined && typeof o.folder !== "string") return "note folder must be a string path";
      if (o.sources !== undefined && !(Array.isArray(o.sources) && o.sources.every((x) => isRecord(x) && typeof x.fileId === "string")))
        return 'note sources must be [{"fileId":string,"page"?:number,"t0"?:number}]';
      if (typeof o.content !== "string") return "note needs string content";
      if (!o.content.trim()) return o.mode === "replace" ? "note replace content is empty (to remove a note use delete)" : "note content is empty: there is nothing to write";
      if (o.mode !== undefined && (typeof o.id !== "string" || !o.id)) return `note mode "${o.mode}" needs the id of an existing note`;
      if (Array.isArray(o.sources)) o.sources = cleanSources(o.sources as Record<string, unknown>[]);
      return null;
    case "read":
      if (o.kind !== "note" && o.kind !== "sketch" && o.kind !== "guide" && o.kind !== "file") return `read kind must be note, sketch, guide or file (got ${show(o.kind)})`;
      for (const k of ["pages", "from", "to"] as const) {
        if (o[k] !== undefined && typeof o[k] !== "string" && typeof o[k] !== "number") return `read "${k}" must be a string like "12-14" or "3:10"`;
        if (typeof o[k] === "number") o[k] = String(o[k]);
      }
      return typeof o.id === "string" && !!o.id && o.id.length <= 64 ? null : "read needs the item's id";
    case "search":
      if (typeof o.query !== "string" || !o.query.trim()) return "search needs a non-empty string query";
      if (o.scope !== undefined && !["all", "files", "notes"].includes(o.scope as string)) return `search scope must be all, files or notes (got ${show(o.scope)})`;
      return null;
    case "edit_sketch": {
      if (typeof o.id !== "string" || !o.id) return "edit_sketch needs the sketch id";
      if (!Array.isArray(o.ops)) return "edit_sketch needs an ops array";
      if (!o.ops.length) return "edit_sketch has no ops to apply (delete and restoreCheckpoint entries are not edits)";
      if (o.ops.length > LIMITS.ops) return `edit_sketch has ${o.ops.length} ops; the limit is ${LIMITS.ops}`;
      for (let i = 0; i < o.ops.length; i++) {
        const p = sketchOpProblem(o.ops[i], i);
        if (p) return `edit_sketch ${p}`;
      }
      return null;
    }
    case "sketch": {
      if (typeof o.title !== "string") return "sketch needs a string title";
      if (!Array.isArray(o.elements)) return "sketch needs an elements array";
      if (!o.elements.length) return "sketch has no drawable elements (cameraUpdate, delete and restoreCheckpoint entries are not drawn)";
      if (o.elements.length > LIMITS.elements) return `sketch has ${o.elements.length} elements; the limit is ${LIMITS.elements}`;
      for (let i = 0; i < o.elements.length; i++) {
        const p = sketchElementProblem(o.elements[i], i, o.elements.length);
        if (p) return `sketch ${p}`;
      }
      return camerasProblem(o.cameras);
    }
    case "browser":
    {
      if (typeof o.url !== "string" || !o.url.trim() || o.url.length > 2048) return "browser needs a string url";
      const why = publicUrlProblem(o.url.trim());
      return why ? `browser: Leo opens public web pages only, and this address ${why}` : null;
    }
    case "memory":
      if (!["save", "update", "delete"].includes(o.op as string)) return `memory op must be save, update or delete (got ${show(o.op)})`;
      if (o.scope !== undefined && !["global", "project"].includes(o.scope as string)) return `memory scope must be global or project (got ${show(o.scope)})`;
      if (o.kind !== undefined && !["level", "goal", "preference", "strength", "weakness", "fact"].includes(o.kind as string)) return `memory kind ${show(o.kind)} is not one of level, goal, preference, strength, weakness, fact`;
      if (o.text !== undefined && !(typeof o.text === "string" && o.text.length <= 500)) return "memory text must be a string of at most 500 characters";
      if (o.id !== undefined && typeof o.id !== "string") return "memory id must be a string";
      if ((o.op === "update" || o.op === "delete") && !o.id) return `memory ${o.op} needs the memory's id${o.op === "update" ? " (use save for a new memory)" : ""}`;
      if (o.op !== "delete" && !(typeof o.text === "string" && o.text.trim())) return `memory ${o.op} needs "text"`;
      if (o.op === "save" && o.kind === undefined) return 'memory save needs a "kind": level, goal, preference, strength, weakness or fact';
      return null;
    case "delete":
      if (!["note", "sketch", "file", "tool"].includes(o.kind as string)) return `delete kind must be note, sketch, file or tool (got ${show(o.kind)})`;
      return typeof o.id === "string" && !!o.id && o.id.length <= 64 ? null : "delete needs the item's id";
    case "organize":
      return organizeProblem(o.ops);
    case "add_tool":
      if (!isToolKind(o.tool)) return `add_tool "tool" must be one of ${TOOL_KINDS.join(", ")} (got ${show(o.tool)})`;
      if (o.title !== undefined && typeof o.title !== "string") return "add_tool title must be a string";
      if (o.items !== undefined && !(Array.isArray(o.items) && o.items.every((x) => typeof x === "string"))) return "add_tool items must be [string]";
      if (o.cards !== undefined && !(Array.isArray(o.cards) && o.cards.every((c) => isRecord(c) && typeof c.front === "string" && typeof c.back === "string")))
        return 'add_tool cards must be [{"front":string,"back":string}]';
      return null;
    case "practice_test": {
      if (typeof o.title !== "string" || !o.title.trim()) return "practice_test needs a title";
      if (typeof o.minutes !== "number" || o.minutes < 1 || o.minutes > 180) return "practice_test minutes must be a number from 1 to 180";
      if (!Array.isArray(o.questions) || !o.questions.length) return "practice_test needs a non-empty questions array";
      if (o.questions.length > 40) return `practice_test has ${o.questions.length} questions; the limit is 40`;
      for (let i = 0; i < o.questions.length; i++) {
        const q = o.questions[i];
        if (!isRecord(q) || typeof q.q !== "string" || !q.q.trim()) return `practice_test question ${i + 1} needs a string "q"`;
        if (q.options !== undefined) {
          if (!isStringArray(q.options) || q.options.length < 2) return `practice_test question ${i + 1}: options must be 2–8 strings`;
          if (typeof q.answer !== "number" || !Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length)
            return `practice_test question ${i + 1}: "answer" must be the 0-based index of the correct option`;
        } else if (typeof q.model_answer !== "string") return `practice_test question ${i + 1}: open questions need a "model_answer"`;
      }
      return null;
    }
    default:
      return o.type === undefined ? "action has no \"type\"" : `unknown action type ${show(o.type)}`;
  }
}

/** Normalize a parsed object (sketch tolerance), then validate it: the action to run, or the reason it was skipped. */
function coerceAction(o: unknown): { action: Action } | { reason: string } {
  const prepared = prepareAction(o);
  const problem = actionProblem(prepared);
  return problem === null ? { action: prepared as Action } : { reason: problem };
}

/** What Leo is doing, read from the part of an action block that has streamed so far. */
export function actionHint(partial: string): string {
  const type = /"type"\s*:\s*"([a-z_]+)"/.exec(partial)?.[1];
  if (!type) return "Working\u2026";
  const field = (name: string) => {
    const m = new RegExp(`"${name}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(partial);
    return m?.[1];
  };
  switch (type) {
    case "sketch": {
      const title = field("title")?.trim();
      return title ? `Drawing \u201c${title}\u201d\u2026` : "Drawing a sketch\u2026";
    }
    case "edit_sketch":
      return "Editing the sketch\u2026";
    case "note":
      if (/"mode"\s*:\s*"patch"/.test(partial)) return "Editing a note\u2026";
      if (/"mode"\s*:\s*"replace"/.test(partial)) return "Rewriting a note\u2026";
      return /"id"\s*:/.test(partial) ? "Adding to a note\u2026" : "Writing a note\u2026";
    case "read": {
      const kind = field("kind");
      if (kind === "guide") return "Reading the Excalidraw guide\u2026";
      if (kind === "sketch") return "Reading a sketch\u2026";
      if (kind === "note") return "Reading a note\u2026";
      if (kind === "file") return "Reading your library\u2026";
      return "Reading\u2026";
    }
    case "search": {
      const q = field("query")?.trim();
      return q ? `Searching for \u201c${q.slice(0, 40)}\u201d\u2026` : "Searching your library\u2026";
    }
    case "browser":
      return "Opening the browser\u2026";
    case "memory":
      return "Saving a memory\u2026";
    case "set_level":
    case "map":
    case "assess":
    case "point":
    case "resolve_point":
      return "Updating your learning map\u2026";
    case "ask":
    case "quiz":
      return "Preparing a question\u2026";
    case "set_avatar":
      return "Updating Leo\u2019s look\u2026";
    case "delete":
      return "Preparing a deletion for your approval\u2026";
    case "organize":
      return "Preparing changes for your approval\u2026";
    case "add_tool":
      return "Adding a tool\u2026";
    case "practice_test":
      return "Building a practice test\u2026";
    default:
      return "Working\u2026";
  }
}

/** The descriptive label for the action currently streaming, if a block is still open. */
export function progressHint(content: string): string | null {
  const segs = parseSegments(content, true);
  for (let i = segs.length - 1; i >= 0; i--) {
    const s = segs[i];
    if (s.kind === "pending") return s.hint ?? null;
  }
  return null;
}

export function parseSegments(content: string, streaming = false): Segment[] {
  // Safety net: some models print a single action object with no fence. A message that is exactly
  // one valid action is treated as that action.
  const bare = content.trim();
  if (!content.includes("```") && bare.startsWith("{") && bare.endsWith("}")) {
    try {
      const r = coerceAction(JSON.parse(bare));
      if ("action" in r) return [{ kind: "action", action: r.action, index: 0 }];
    } catch {
      /* still streaming, or not JSON at all */
    }
  }
  const segs: Segment[] = [];
  let last = 0;
  let idx = 0;
  const { blocks, openAt } = scanBlocks(content, streaming);
  for (const b of blocks) {
    const before = content.slice(last, b.start);
    if (before.trim()) segs.push({ kind: "text", text: before });
    const { actions, invalid } = parseBody(b.body);
    for (const a of actions) segs.push({ kind: "action", action: a, index: idx++ });
    for (const inv of invalid) segs.push({ kind: "invalid", ...inv });
    last = b.end;
  }
  let rest = content.slice(last);
  if (openAt >= 0) {
    const open = openAt - last;
    const before = rest.slice(0, open);
    if (before.trim()) segs.push({ kind: "text", text: before });
    if (streaming) segs.push({ kind: "pending", hint: actionHint(rest.slice(open)) });
    else segs.push({ kind: "invalid", raw: rest.slice(open, open + 200), reason: "action block was cut off" });
  } else {
    if (streaming) rest = rest.replace(/`{1,3}[a-z]{0,6}$/, "");
    if (rest.trim()) segs.push({ kind: "text", text: rest });
  }
  return segs;
}

export function extractActions(content: string): Action[] {
  return parseSegments(content)
    .filter((s): s is Extract<Segment, { kind: "action" }> => s.kind === "action")
    .map((s) => s.action);
}

/** Problems the model should hear about on its next turn. */
export function invalidActionFeedback(content: string): string | null {
  const bad = parseSegments(content).filter((s): s is Extract<Segment, { kind: "invalid" }> => s.kind === "invalid");
  if (!bad.length) return null;
  return `Note: ${bad.length} of your action blocks could not be executed (${bad.map((b) => b.reason).join("; ")}). Re-emit them as valid JSON if they still matter.`;
}

/** Strip action blocks for plain-text uses (thread titles, history summaries). */
export function stripActions(content: string) {
  const { blocks } = scanBlocks(content, false);
  let out = "";
  let last = 0;
  for (const b of blocks) {
    out += content.slice(last, b.start);
    last = b.end;
  }
  return (out + content.slice(last)).trim();
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

export async function findConcept(projectId: string, name: string) {
  const all = await db.concepts.where("projectId").equals(projectId).filter((c) => !c.deletedAt).toArray();
  return all.find((c) => norm(c.name) === norm(name));
}

export async function upsertConcept(
  projectId: string,
  name: string,
  patch: Partial<Pick<Concept, "status" | "note">> = {},
  parentName?: string
): Promise<Concept> {
  const now = Date.now();
  let parentId: string | undefined;
  if (parentName && norm(parentName) !== norm(name)) {
    const parent = await upsertConcept(projectId, parentName);
    parentId = parent.id;
  }
  const existing = await findConcept(projectId, name);
  if (existing) {
    const upd: Partial<Concept> = { updatedAt: now };
    if (patch.status) upd.status = patch.status;
    if (patch.note) upd.note = patch.note;
    if (parentId && parentId !== existing.id) upd.parentId = parentId;
    await db.concepts.update(existing.id, upd);
    return { ...existing, ...upd };
  }
  const c: Concept = {
    id: uid(),
    projectId,
    name: name.trim().slice(0, 80),
    parentId,
    status: patch.status ?? "new",
    note: patch.note,
    correct: 0,
    attempts: 0,
    createdAt: now,
    updatedAt: now,
  };
  await db.concepts.add(c);
  return c;
}

const DAY = 86_400_000;

/** Record one graded outcome: stats, recent window, status and a simple spaced-review schedule. */
export async function recordQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await upsertConcept(projectId, conceptName);
  const fresh = (await db.concepts.get(c.id))!;
  let status = fresh.status;
  if (correct && status === "new") status = "learning";
  if (!correct && status === "solid") status = "shaky";
  const recent = [...(fresh.recent ?? []), correct ? 1 : 0].slice(-10);
  // Two consecutive correct answers on a learning concept earn "solid".
  if (correct && status === "learning" && recent.length >= 2 && recent.slice(-2).every((r) => r === 1)) status = "solid";
  const prev = fresh.interval ?? 0;
  const interval = correct ? Math.min(60, prev === 0 ? 1 : Math.round(prev * 2.2 * 10) / 10) : 0.5;
  const now = Date.now();
  await db.concepts.update(c.id, {
    attempts: fresh.attempts + 1,
    correct: fresh.correct + (correct ? 1 : 0),
    recent,
    status,
    interval,
    lastReviewed: now,
    nextReview: now + interval * DAY,
    updatedAt: now,
  });
}

/** Undo one graded outcome (learner disputed the answer key). */
export async function revertQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await findConcept(projectId, conceptName);
  if (!c || c.attempts === 0) return;
  const recent = [...(c.recent ?? [])];
  const idx = recent.lastIndexOf(correct ? 1 : 0);
  if (idx >= 0) recent.splice(idx, 1);
  await db.concepts.update(c.id, {
    attempts: c.attempts - 1,
    correct: Math.max(0, c.correct - (correct ? 1 : 0)),
    recent,
    updatedAt: Date.now(),
  });
}

export async function addPoint(projectId: string, kind: PointKind, text: string, author: "user" | "ai") {
  const t = text.trim();
  if (!t) return false;
  const existing = await db.points.where("projectId").equals(projectId).filter((p) => !p.deletedAt).toArray();
  if (existing.some((p) => !p.done && norm(p.text) === norm(t))) return false;
  await db.points.add({ id: uid(), projectId, kind, text: t, author, done: false, createdAt: Date.now() });
  return true;
}

/* --------------------------------------------------------------- note edits */

export const TRUNCATED_MARK = "…[truncated]";
/** In the heading of a note that was shown only in part. */
const PARTIAL_MARK = "partial view";
/** How much of a note one read, or one attachment, carries. */
export const NOTE_READ_CHARS = 12000;

/**
 * A note as the model is shown it: a `## <label> "Title" (id=…)` heading, then the text. A note
 * longer than NOTE_READ_CHARS goes out in parts. The heading then says which part this is, so a
 * partial view is recognisable whatever the note itself contains, and the block ends with the exact
 * `read` that continues it. "Note" is a read result; the other two labels are attachments.
 */
export function noteBlock(label: "Note" | "Current note:" | "Referenced note:", n: Pick<Note, "id" | "title" | "content">, from = 0): string {
  const total = n.content.length;
  const start = Math.min(Math.max(0, Math.floor(from) || 0), total);
  const end = Math.min(total, start + NOTE_READ_CHARS);
  const whole = start === 0 && end === total;
  const head = `## ${label} "${n.title.replace(/\s+/g, " ")}" (id=${n.id})${whole ? "" : ` — ${PARTIAL_MARK}: characters ${Math.min(start + 1, total)}–${end} of ${total}`}`;
  const body = n.content.slice(start, end) || (total ? `(no text after character ${total})` : "(empty)");
  const more = end < total ? `\n${TRUNCATED_MARK} ${total - end} more characters — continue with {"type":"read","kind":"note","id":"${n.id}","from":"${end}"}` : "";
  return `${head}\n${body}${more}`;
}

/** Whether Leo has seen a note's contents in this thread, and how good that view still is. */
export interface NoteView {
  seen: boolean;
  /** The latest view was only part of the note. */
  clipped: boolean;
  /**
   * The latest view cannot be trusted for a whole-note rewrite: the learner changed the note after
   * it, or it sits in an older step whose contents are no longer sent to the model.
   */
  stale?: boolean;
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * Where one item shown to the model ends: the next item the app emits, or the closing tag.
 * A note's own `## headings` are not ends — notes are markdown and are full of them.
 */
const SECTION_END = /\n(?:## [^\n]*\(id=[^)\n]+\)|## (?:Guide|Search|Browser page|File) [^\n]*|- FAILED [^\n]*|<\/workspace_context>|<\/action_results>)/;

/**
 * Scan a thread for the note's contents having reached the model: a `read` result
 * (`## Note "T" (id=X)`) or an attachment (`## Current note: "T" (id=X)` / `## Referenced note: …`).
 * Only user-role messages carry these. The latest occurrence decides `clipped`.
 *
 * With `current` (the note as it is now) the view is also checked for staleness, following what the
 * history builder really sends: only the learner's last visible message and the latest
 * <action_results> go out in full. A note Leo wrote last is trusted, because the text he wrote
 * stays on his side of the history.
 */
export function noteViewIn(
  messages: (Pick<Message, "role" | "content"> & Partial<Pick<Message, "apiContent" | "hidden">>)[],
  noteId: string,
  current?: Pick<Note, "content" | "lastEditedBy">
): NoteView {
  const heading = new RegExp(`^## (?:Note|Current note:|Referenced note:) "[^\\n]*" \\(id=${escapeRe(noteId)}\\)([^\\n]*)$`, "gm");
  const view: NoteView = { seen: false, clipped: false };
  let lastVisible = -1;
  let at = -1;
  let body = "";
  messages.forEach((m, i) => {
    if (m.role !== "user") return;
    if (!m.hidden) lastVisible = i;
    const text = m.apiContent ?? m.content;
    heading.lastIndex = 0;
    let h: RegExpExecArray | null;
    while ((h = heading.exec(text))) {
      const rest = text.slice(h.index + h[0].length);
      const stop = rest.search(SECTION_END);
      const section = stop >= 0 ? rest.slice(0, stop) : rest;
      view.seen = true;
      view.clipped = h[1].includes(PARTIAL_MARK) || section.includes(TRUNCATED_MARK);
      at = i;
      body = section.replace(/^\n/, "");
    }
  });
  if (view.seen && current && current.lastEditedBy !== "ai") {
    const now = current.content || "(empty)";
    const same = body === now || body.startsWith(`${now}\n`);
    // Still in Leo's context only if it came with the learner's latest message, or in a result of this turn that fits the budget.
    const inContext = at === lastVisible || fullResultIndexes(messages).has(at);
    if (!same || !inContext) view.stale = true;
  }
  return view;
}

/** Apply exact find/replace edits in order. Every `find` must match exactly once at the time it is applied. */
export function applyPatches(content: string, patches: NotePatch[]): { content: string } | { error: string } {
  let out = content;
  for (let i = 0; i < patches.length; i++) {
    const p = patches[i];
    const at = out.indexOf(p.find);
    if (at < 0) return { error: `patch ${i + 1}: "find" text not found (${show(p.find)}) — copy it exactly from the note` };
    if (out.indexOf(p.find, at + 1) >= 0) return { error: `patch ${i + 1}: "find" text matches more than once (${show(p.find)}) — include more surrounding text` };
    out = out.slice(0, at) + p.replace + out.slice(at + p.find.length);
  }
  return { content: out };
}

type NoteAction = Extract<Action, { type: "note" }>;

export type NoteEditPlan =
  | { kind: "apply"; content: string; mode: NoteMode }
  | { kind: "fail"; reason: string }
  /** Needs the learner's Apply / Dismiss before it runs. */
  | { kind: "confirm"; reason: string };

/**
 * Decide what an edit of an existing note does. Pure: no database access.
 * - the note must have been read or attached earlier in the thread ("read it first");
 * - default mode is append; patch needs exact, unique matches;
 * - after a clipped read only append/patch are allowed (Leo never saw the whole note);
 * - replace runs directly only on notes Leo created; on the learner's notes it waits for approval.
 * `approved` = the learner pressed Apply on a pending replace.
 */
export function planNoteEdit(existing: Pick<Note, "id" | "title" | "content" | "author">, a: NoteAction, view: NoteView, approved = false): NoteEditPlan {
  const mode: NoteMode = a.mode ?? "append";
  if (!approved && !view.seen)
    return { kind: "fail", reason: `Note “${existing.title}” not changed — read it first ({"type":"read","kind":"note","id":"${existing.id}"})` };
  if (mode === "replace" && view.clipped && !approved)
    return { kind: "fail", reason: `Note “${existing.title}” not replaced — you only saw part of it (clipped read); use append or patch` };
  if (mode === "replace" && view.stale && !approved)
    return { kind: "fail", reason: `Note “${existing.title}” not replaced — it changed after you saw it, or your copy is from an earlier step; read it again ({"type":"read","kind":"note","id":"${existing.id}"}), then replace` };
  if (mode !== "patch" && !a.content.trim() && !approved)
    return { kind: "fail", reason: mode === "replace" ? `Note “${existing.title}” not replaced — the new content is empty (to remove a note use delete)` : `Note “${existing.title}” not changed — there is nothing to add` };
  if (mode === "append") {
    const content = `${existing.content.trimEnd()}${existing.content.trim() ? "\n\n" : ""}${a.content}`;
    return { kind: "apply", content, mode };
  }
  if (mode === "patch") {
    const r = applyPatches(existing.content, a.patches ?? []);
    return "error" in r ? { kind: "fail", reason: `Note “${existing.title}” not patched — ${r.error}` } : { kind: "apply", content: r.content, mode };
  }
  if (existing.author !== "ai" && !approved) return { kind: "confirm", reason: `Replace the learner's note “${existing.title}”` };
  return { kind: "apply", content: a.content, mode };
}

interface RunOutcome {
  result: ActionResult;
  pending?: PendingAction;
  /** The note that was written, and what it said before, so the change can be shown being written. */
  noteId?: string;
  previous?: string;
}

const pendingOf = (a: Action, label: string): PendingAction => ({ id: uid(), action: a as unknown as PendingAction["action"], label, status: "pending" });

async function reindexNote(id: string) {
  const n = await db.notes.get(id);
  if (n) {
    const { indexNote } = await import("../retrieval");
    await indexNote(n);
  }
}

async function runNote(projectId: string, threadId: string | null, a: NoteAction, approved: boolean, gate = false, labels: CitationRef[] = []): Promise<RunOutcome> {
  const now = Date.now();
  const waiting = (label: string): RunOutcome => ({
    result: { type: a.type, label: `Waiting for the learner's approval — ${label.charAt(0).toLowerCase()}${label.slice(1)}`, ok: true },
    pending: pendingOf(a, label),
  });
  if (!a.id) {
    // Titles are file names, exactly as for notes the learner makes: link-safe, and unique in their folder.
    const title = readableTitle(a.title ?? "") || "Leo's note";
    const folder = a.folder?.trim() ? cleanFolder(a.folder) : undefined;
    // A note with the same title is reused, never duplicated: Leo's own note is rewritten (with a
    // version kept), a learner's note gets the new material appended.
    const same = await sameTitleNote(projectId, title, folder);
    // The preview says what Apply will really do.
    if (gate && !approved) return waiting(!same ? `Create note “${title}”` : same.author === "ai" ? `Rewrite Leo's note “${same.title}”` : `Add to your note “${same.title}”`);
    const grounded = await groundNote(projectId, labels, a.content, a.sources);
    if (same) {
      const content = same.author === "ai" ? grounded.content : `${same.content.trimEnd()}\n\n${grounded.content}`;
      await db.notes.update(same.id, {
        content,
        sources: mergeSources(same.sources, grounded.sources),
        versions: versionsWithCurrent(same, "ai", now),
        previousContent: undefined,
        lastEditedBy: "ai",
        updatedAt: now,
      });
      await reindexNote(same.id);
      return { result: { type: a.type, label: `${same.author === "ai" ? "Updated" : "Appended to"} note · ${same.title}`, ok: true }, noteId: same.id, previous: same.content };
    }
    const id = uid();
    const unique = await uniqueTitle(projectId, folder ?? "", title);
    await db.notes.add({
      id,
      projectId,
      title: unique,
      content: grounded.content,
      author: "ai",
      lastEditedBy: "ai",
      createdAt: now,
      updatedAt: now,
      ...(folder ? { folder } : {}),
      ...(grounded.sources.length ? { sources: grounded.sources } : {}),
    });
    await reindexNote(id);
    return { result: { type: a.type, label: `Created note · ${folder ? `${folder}/` : ""}${unique}`, ok: true }, noteId: id, previous: "" };
  }
  const existing = await db.notes.get(a.id);
  if (!existing || existing.projectId !== projectId || existing.deletedAt) return { result: { type: a.type, label: `Note ${a.id} not found in this project`, ok: false } };
  const msgs = threadId ? await db.messages.where("threadId").equals(threadId).sortBy("createdAt") : [];
  const plan = planNoteEdit(existing, a, noteViewIn(msgs, a.id, existing), approved);
  if (plan.kind === "fail") return { result: { type: a.type, label: plan.reason, ok: false } };
  // A different title renames the note; the same title, or none, leaves the name alone.
  const wanted = readableTitle(a.title ?? "");
  const renames = !!wanted && norm(wanted) !== norm(readableTitle(existing.title));
  if (plan.kind === "apply" && gate && !approved) {
    const verb = plan.mode === "append" ? "Add to" : plan.mode === "patch" ? "Edit" : "Replace";
    return waiting(`${verb} note “${existing.title}”${renames ? ` and rename it “${wanted}”` : ""}`);
  }
  if (plan.kind === "confirm") return waiting(plan.reason);
  await db.notes.update(a.id, {
    content: plan.content,
    // Every edit keeps what was there (last NOTE_VERSION_LIMIT), so the learner can restore it.
    versions: versionsWithCurrent(existing, "ai", now),
    previousContent: undefined,
    // `author` is who created the note; it is never rewritten.
    lastEditedBy: "ai",
    updatedAt: now,
  });
  // A rename goes through the note helper, as the learner's own does: the title stays unique in its
  // folder and [[links]] to the note in other notes are rewritten.
  let title = existing.title;
  if (renames) {
    const notes = (await db.notes.where("projectId").equals(projectId).toArray()).filter((n) => !n.deletedAt);
    title = await renameNote(notes, { ...existing, content: plan.content }, wanted);
  }
  await reindexNote(a.id);
  const verb = plan.mode === "append" ? "Appended to" : plan.mode === "patch" ? "Patched" : "Replaced";
  return { result: { type: a.type, label: `${verb} note · ${title}${title !== existing.title ? ` (renamed from “${existing.title}”)` : ""}`, ok: true }, noteId: a.id, previous: existing.content };
}

/** A folder path with every segment a valid name, as the notes sidebar would make it. */
const cleanFolder = (f: string) => cleanNoteFolder(f).slice(0, 200);

/** The live note a "create" with this title reuses, if any. Naming a folder narrows the match to that folder, so "Summary" in two folders stays two notes. */
async function sameTitleNote(projectId: string, title: string, folder: string | undefined): Promise<Note | undefined> {
  const notes = (await db.notes.where("projectId").equals(projectId).toArray()).filter((n) => !n.deletedAt);
  return notes.find((n) => norm(readableTitle(n.title)) === norm(title) && (folder === undefined || (n.folder ?? "") === folder));
}

/**
 * The existing note a `note` action will change: the one it names, or the same-title note a
 * "create" reuses. The executor and the approval preview both ask this, so the preview shows what
 * Apply does.
 */
export async function noteTarget(projectId: string, a: NoteAction): Promise<Note | undefined> {
  if (a.id) {
    const n = await db.notes.get(a.id);
    return n && n.projectId === projectId && !n.deletedAt ? n : undefined;
  }
  return sameTitleNote(projectId, readableTitle(a.title ?? "") || "Leo's note", a.folder?.trim() ? cleanFolder(a.folder) : undefined);
}

function mergeSources(a: SourceRef[] = [], b: SourceRef[] = []): SourceRef[] | undefined {
  const seen = new Set<string>();
  const out = [...a, ...b].filter((s) => {
    const k = `${s.fileId}|${s.page ?? ""}|${s.t0 ?? ""}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return out.length ? out.slice(0, 50) : undefined;
}

/**
 * Ground an AI note: collect its sources (explicit, from [S#] labels of this turn's SOURCES, from
 * "(file, p.12)" citations), and make sure the note ends with a Sources list.
 */
async function groundNote(projectId: string, labels: CitationRef[], content: string, explicit?: SourceRef[]) {
  const files = (await db.files.where("projectId").equals(projectId).toArray()).filter((f) => !f.deletedAt);
  // `labels` are the [S#] labels of the SOURCES the writing reply was given. They are passed in, not
  // looked up: this turn's assistant message is stored only after its actions have run, and an
  // approval may come many turns later, so "the last message with citations" is the wrong reply.
  const found = parseCitations(content, files, labels);
  const sources = mergeSources(
    (explicit ?? []).filter((s) => files.some((f) => f.id === s.fileId)),
    found.map((c) => ({ fileId: c.fileId, ...(c.page ? { page: c.page } : {}), ...(typeof c.t0 === "number" ? { t0: c.t0 } : {}) }))
  ) ?? [];
  if (!sources.length || /^#{1,4}\s*Sources\b/im.test(content)) return { content, sources };
  const name = (id: string) => files.find((f) => f.id === id)?.name ?? "file";
  const { clock } = await import("../retrieval");
  const list = sources
    .map((s) => `- ${name(s.fileId)}${s.page ? `, p.${s.page}` : ""}${typeof s.t0 === "number" ? `, ${clock(s.t0)}` : ""}`)
    .join("\n");
  return { content: `${content.trimEnd()}\n\n## Sources\n${list}`, sources };
}

/** A tappable citation found in text: "(book.pdf, p.12)", "[S2]", "[3:12]". */
export interface FoundCitation {
  match: string;
  fileId: string;
  page?: number;
  t0?: number;
}

/**
 * Find citations in text and resolve them to library files. [S#] uses the SOURCES labels the reply was
 * given; "(name, p.N)" matches a file by name; "[m:ss]" seeks the only (or last cited) audio/video.
 */
export function parseCitations(
  text: string,
  files: Pick<import("../db").LibFile, "id" | "name" | "kind">[],
  labels: import("../db").CitationRef[] = []
): FoundCitation[] {
  const out: FoundCitation[] = [];
  for (const m of text.matchAll(/\[S(\d{1,2})\]/g)) {
    const ref = labels.find((l) => l.label === `S${m[1]}`);
    if (ref?.fileId) out.push({ match: m[0], fileId: ref.fileId, page: ref.page, t0: ref.t0 });
  }
  const byName = (raw: string) => {
    const n = raw.replace(/[`*_"“”]/g, "").trim().toLowerCase();
    return files.find((f) => f.name.toLowerCase() === n) ?? files.find((f) => n.length > 3 && f.name.toLowerCase().startsWith(n));
  };
  let lastMedia: string | undefined;
  for (const m of text.matchAll(/\(?`?([^()`\n,]{2,120}?)`?,\s*(?:p\.?|page)\s*(\d{1,5})`?\)?/g)) {
    const f = byName(m[1]);
    if (f) out.push({ match: m[0], fileId: f.id, page: Number(m[2]) });
  }
  for (const m of text.matchAll(/\(?`?([^()`\n,]{2,120}?)`?,\s*(\d{1,2}:\d{2}(?::\d{2})?)`?\)?/g)) {
    const f = byName(m[1]);
    if (f) {
      lastMedia = f.id;
      const [a, b, c] = m[2].split(":").map(Number);
      out.push({ match: m[0], fileId: f.id, t0: c === undefined ? a * 60 + b : a * 3600 + b * 60 + c });
    }
  }
  const media = files.filter((f) => f.kind === "audio" || f.kind === "video");
  const target = lastMedia ?? labels.find((l) => typeof l.t0 === "number")?.fileId ?? (media.length === 1 ? media[0].id : undefined);
  if (target) {
    for (const m of text.matchAll(/\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/g)) {
      const t0 = m[3] === undefined ? Number(m[1]) * 60 + Number(m[2]) : Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
      out.push({ match: m[0], fileId: target, t0 });
    }
  }
  return out;
}

const DAY_MS = 86_400_000;

/** Persist a quiz as a review card (one per question text per project). */
async function saveQuizCard(projectId: string, a: Extract<Action, { type: "quiz" }>) {
  const now = Date.now();
  const existing = (await db.cards.where("projectId").equals(projectId).toArray()).find((c) => norm(c.question) === norm(a.question));
  const row = {
    question: a.question,
    options: a.options,
    answer: a.answer,
    explanation: a.explanation,
    concept: a.concept?.trim() || "General",
    source: a.source,
    updatedAt: now,
  };
  if (existing) await db.cards.update(existing.id, row);
  else await db.cards.add({ id: uid(), projectId, ...row, interval: 0, nextReview: now + DAY_MS, reps: 0, lapses: 0, createdAt: now });
}

type MemoryAction = Extract<Action, { type: "memory" }>;

/** Scope for a new memory when none is given: preferences follow the learner everywhere, the rest stays with this topic. */
export const defaultMemoryScope = (kind: MemoryKind): "global" | "project" => (kind === "preference" ? "global" : "project");

async function runMemory(projectId: string, a: MemoryAction, approved: boolean): Promise<RunOutcome> {
  const scopeIdOf = (scope: "global" | "project") => (scope === "project" ? projectId : "*");
  const now = Date.now();
  if (a.op === "delete") {
    if (!a.id) throw new Error("Memory delete needs an id");
    const existing = await db.memories.get(a.id);
    if (!existing || existing.deletedAt || (existing.projectId !== projectId && existing.projectId !== "*")) return { result: { type: a.type, label: "Memory not found", ok: false } };
    if (!approved) {
      const label = `Forget memory “${existing.text.length > 80 ? `${existing.text.slice(0, 80)}…` : existing.text}”`;
      return { result: { type: a.type, label: `Waiting for the learner's approval — ${label.toLowerCase()}`, ok: true }, pending: pendingOf(a, label) };
    }
    await db.memories.delete(a.id);
    return { result: { type: a.type, label: "Forgot that memory", ok: true } };
  }
  if (!a.text?.trim()) throw new Error("Memory save needs text");
  if (a.op === "update" && a.id) {
    const existing = await db.memories.get(a.id);
    if (!existing || existing.deletedAt || (existing.projectId !== projectId && existing.projectId !== "*")) throw new Error("Memory not found");
    const kind = a.kind ?? existing.kind;
    // Keep the memory where it is unless a scope is given explicitly.
    await db.memories.update(a.id, { projectId: a.scope ? scopeIdOf(a.scope) : existing.projectId, kind, text: a.text.trim(), updatedAt: now });
    return { result: { type: a.type, label: `Updated memory · ${kind}`, ok: true } };
  }
  if (!a.kind) throw new Error("Memory save needs a kind and text");
  const scopeId = scopeIdOf(a.scope ?? defaultMemoryScope(a.kind));
  const all = await db.memories.where("projectId").equals(scopeId).filter((m) => !m.deletedAt).toArray();
  const duplicate = all.find((m) => m.kind === a.kind && norm(m.text) === norm(a.text!));
  if (duplicate) {
    await db.memories.update(duplicate.id, { text: a.text.trim(), updatedAt: now });
    return { result: { type: a.type, label: `Updated memory · ${a.kind}`, ok: true } };
  }
  await db.memories.add({ id: uid(), projectId: scopeId, kind: a.kind, text: a.text.trim(), createdAt: now, updatedAt: now });
  return { result: { type: a.type, label: `Remembered · ${a.kind}`, ok: true } };
}

/** Run an action the learner approved from an Apply chip (a learner-note replace or a memory delete). */
export async function applyApprovedAction(projectId: string, action: Action, ctx: { threadId?: string | null; citations?: CitationRef[] } = {}): Promise<ActionResult> {
  try {
    if (action.type === "note") return (await runNote(projectId, ctx.threadId ?? null, action, true, false, ctx.citations ?? [])).result;
    if (action.type === "memory") return (await runMemory(projectId, action, true)).result;
    if (action.type === "organize") return await runOrganize(projectId, action);
    if (action.type === "add_tool") return await runAddTool(projectId, action);
    if (action.type === "delete") return (await runDelete(projectId, action, true)).result;
    return { type: action.type, label: "This action can't be approved here", ok: false };
  } catch (e) {
    return { type: action.type, label: e instanceof Error ? e.message : String(e), ok: false };
  }
}

async function runOrganize(projectId: string, a: Extract<Action, { type: "organize" }>): Promise<ActionResult> {
  const r = await applyOrganize(projectId, a.ops);
  const label = `Organized · ${r.done} ${r.done === 1 ? "change" : "changes"}${r.errors.length ? ` (${r.errors.length} skipped: ${r.errors[0]})` : ""}`;
  return { type: a.type, label, ok: r.done > 0 || !r.errors.length };
}

async function runAddTool(projectId: string, a: Extract<Action, { type: "add_tool" }>): Promise<ActionResult> {
  const t = await createTool(projectId, a.tool, { title: a.title, items: a.items, cards: a.cards });
  return { type: a.type, label: `Added tool · ${t.title}`, ok: true };
}

type DeleteAction = Extract<Action, { type: "delete" }>;

/** Delete a library item: always behind the learner's approval, and always into the Trash. */
async function runDelete(projectId: string, a: DeleteAction, approved: boolean): Promise<RunOutcome> {
  const table = a.kind === "note" ? db.notes : a.kind === "sketch" ? db.sketches : a.kind === "file" ? db.files : db.tools;
  const item = (await table.get(a.id)) as { projectId: string; title?: string; name?: string; deletedAt?: number } | undefined;
  if (!item || item.projectId !== projectId) return { result: { type: a.type, label: "That item is not in this project", ok: false } };
  if (item.deletedAt) return { result: { type: a.type, label: "Already in the Trash", ok: true } };
  const name = item.title ?? item.name ?? "item";
  if (!approved) {
    const label = `Delete “${name}”`;
    return { result: { type: a.type, label: `Waiting for the learner's approval — ${label.toLowerCase()} (to the Trash)`, ok: true }, pending: pendingOf(a, label) };
  }
  await trashItem(a.kind, a.id);
  return { result: { type: a.type, label: `Moved to Trash · ${name}`, ok: true } };
}

const toolWord = (a: Extract<Action, { type: "add_tool" }>) => a.title?.trim() || a.tool;

/** What a turn's actions produced: chips for the learner, plus material for the model's next step. */
export interface ExecutionReport {
  results: ActionResult[];
  /** One entry per `read`: the item's contents, fed back to the model as <action_results>. */
  read: string[];
  /** Images produced by reads (image files, text-less PDF pages), sent with <action_results> as vision input. */
  images?: string[];
  /** Actions waiting for the learner's Apply / Dismiss; stored on the assistant message. */
  pending: PendingAction[];
  /** The actions that actually ran. Skipped ones (see SKIPPED_AFTER_READ) never touched the workspace. */
  ran: Action[];
  /** How many actions were skipped because they came after a read/search, or because the learner stopped. */
  skipped: number;
  /** Findings Leo may act on but need not (layout check of a new sketch). They continue the loop without hiding the reply. */
  advisory: string[];
}

/** Why an action that follows a read or search in the same step is not run. Leo re-emits it once he has seen the result. */
export const SKIPPED_AFTER_READ = "not run, re-emit after you see the results";
export const SKIPPED_BY_STOP = "not run, the learner pressed Stop";

const brief = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

/** What Leo is doing with a tool, in words, for the live status in chat. Questions show as cards instead. */
export function describeAction(a: Action): string | null {
  switch (a.type) {
    case "ask":
    case "quiz":
      return null;
    case "set_level":
      return `Setting your level to ${a.level}`;
    case "map":
      return `Updating your knowledge map: ${brief(a.concept, 50)}${a.status ? ` (${a.status})` : ""}`;
    case "point":
      return `Adding to your points card: ${brief(a.text, 60)}`;
    case "resolve_point":
      return `Ticking off a point: ${brief(a.text, 60)}`;
    case "assess":
      return `Recording your answer on ${brief(a.concept, 50)}`;
    case "set_avatar":
      return "Changing my look";
    case "note":
      if (!a.id) return `Writing a note: ${brief(a.title?.trim() || "Leo's note", 50)}`;
      return a.mode === "patch" ? "Editing your note" : a.mode === "replace" ? "Rewriting the note" : "Adding to the note";
    case "read":
      if (a.kind === "file") return `Reading from your library${a.pages ? ` (page ${a.pages})` : ""}`;
      return a.kind === "guide" ? "Reading the drawing guide" : a.kind === "note" ? "Reading a note" : "Looking at a sketch";
    case "search":
      return `Searching your library for “${brief(a.query, 40)}”`;
    case "edit_sketch":
      return `Editing the sketch: ${a.ops.length} ${a.ops.length === 1 ? "change" : "changes"}`;
    case "sketch":
      return `Drawing “${brief(a.title.trim() || "a sketch", 50)}”`;
    case "browser":
      return `Opening ${brief(a.url.replace(/^https?:\/\/(www\.)?/, "").split(/[/?#]/)[0] || "a page", 40)}`;
    case "memory":
      return a.op === "delete" ? "Forgetting a memory" : a.op === "update" ? "Updating a memory" : "Saving a memory";
    case "organize":
      return `Proposing ${a.ops.length} ${a.ops.length === 1 ? "change" : "changes"} to your project`;
    case "add_tool":
      return `Adding ${toolWord(a)} to your library`;
    case "practice_test":
      return `Building a ${a.minutes}-minute practice test`;
    case "delete":
      return "Deleting an item";
    default:
      return null;
  }
}

export async function executeActions(
  projectId: string,
  threadId: string,
  actions: Action[],
  /** `citations`: the [S#] labels of the SOURCES this reply was given, so a note it writes cites those passages. */
  opts: { citations?: CitationRef[] } = {}
): Promise<ExecutionReport> {
  const results: ActionResult[] = [];
  const read: string[] = [];
  const images: string[] = [];
  const pending: PendingAction[] = [];
  const advisory: string[] = [];
  const ran: Action[] = [];
  let skipped = 0;
  // Once a step has read or searched, everything after it was written without seeing the result: it
  // is not run, and Leo is told to send it again.
  let readInStep = false;
  for (const a of actions) {
    if (isStopped()) {
      results.push({ type: a.type, label: SKIPPED_BY_STOP, ok: false });
      skipped++;
      continue;
    }
    if (readInStep) {
      results.push({ type: a.type, label: SKIPPED_AFTER_READ, ok: false });
      skipped++;
      continue;
    }
    ran.push(a);
    if (a.type === "read" || a.type === "search") readInStep = true;
    // Every tool shows up in the chat as a live step, in words.
    const doing = describeAction(a);
    const stepId = doing ? stage.start(a.type, doing) : 0;
    const before = results.length;
    try {
      switch (a.type) {
        case "set_level": {
          // Gate: placement needs evidence. Count answered ask/quiz cards in this thread.
          const project = await db.projects.get(projectId);
          if (project?.placement.status !== "done") {
            const msgs = await db.messages.where("threadId").equals(threadId).toArray();
            const answered = msgs.reduce((n, m) => n + Object.keys(m.answers ?? {}).length, 0);
            if (answered < 3) {
              results.push({ type: a.type, label: `Level not set yet — only ${answered} answered question(s); ask at least 3`, ok: false });
              break;
            }
          }
          await db.projects.update(projectId, {
            placement: {
              status: "done",
              level: a.level,
              summary: a.summary,
              startingPoint: a.startingPoint,
              at: Date.now(),
            },
            updatedAt: Date.now(),
          });
          await db.threads.update(threadId, { mode: "ask" });
          results.push({ type: a.type, label: `Level set: ${a.level}`, ok: true });
          break;
        }
        case "map": {
          const status = (["new", "learning", "shaky", "solid"] as const).includes(a.status as ConceptStatus)
            ? a.status
            : undefined;
          await upsertConcept(projectId, a.concept, { status, note: a.note }, a.parent);
          results.push({
            type: a.type,
            label: `${a.concept}${status ? ` → ${status}` : ""}`,
            ok: true,
          });
          break;
        }
        case "point": {
          const ok = await addPoint(projectId, a.kind, a.text, "ai");
          if (ok) results.push({ type: a.type, label: a.text, ok: true });
          break;
        }
        case "resolve_point": {
          const pts = await db.points.where("projectId").equals(projectId).filter((p) => !p.deletedAt).toArray();
          const target = pts.find((p) => !p.done && norm(p.text) === norm(a.text));
          if (target) {
            await db.points.update(target.id, { done: true, resolvedBy: "ai" });
            results.push({ type: a.type, label: target.text, ok: true });
          } else {
            results.push({ type: a.type, label: `No open point matches “${a.text}” exactly`, ok: false });
          }
          break;
        }
        case "assess": {
          await recordQuizResult(projectId, a.concept, a.correct);
          if (a.note) await upsertConcept(projectId, a.concept, { note: a.note });
          results.push({ type: a.type, label: `${a.concept}: ${a.correct ? "correct" : "needs work"}`, ok: true });
          break;
        }
        case "set_avatar": {
          const project = await db.projects.get(projectId);
          if (!project) break;
          const current = normalizeAvatarLook(project.avatar);
          const look = normalizeAvatarLook({ ...current, ...a }, current);
          await db.projects.update(projectId, { avatar: look, updatedAt: Date.now() });
          results.push({ type: a.type, label: `${look.shape} · ${look.color} · ${look.expression}`, ok: true });
          break;
        }
        case "note": {
          // An open editor stays on its current text until the change is written out in front of the learner.
          const held = a.id ? await db.notes.get(a.id) : undefined;
          if (held) stage.holdNote(held.id, held.content);
          const out = await runNote(projectId, threadId, a, false, approvalRequired(), opts.citations ?? []);
          results.push(out.result);
          if (out.pending) pending.push(out.pending);
          const written = out.result.ok && !out.pending && out.noteId ? await db.notes.get(out.noteId) : undefined;
          if (written) await stage.typeNote(projectId, stepId, written.id, out.previous ?? "", written.content);
          else stage.releaseNote();
          break;
        }
        case "search": {
          const { retrieve, formatSearchResults } = await import("../retrieval");
          const hits = await retrieve(projectId, a.query, 8, a.scope ?? "all");
          results.push({ type: a.type, label: `Searched · ${a.query.slice(0, 60)}`, ok: true });
          read.push(formatSearchResults(a.query, hits));
          break;
        }
        case "quiz": {
          await saveQuizCard(projectId, a);
          break;
        }
        case "read": {
          if (a.kind === "file") {
            const { readLibraryFile } = await import("./fileReader");
            stage.seekFile(a.id, a.pages);
            const out = await readLibraryFile(projectId, a);
            results.push({ type: a.type, label: out.label, ok: out.ok });
            if (out.ok) read.push(out.text);
            images.push(...out.images.slice(0, Math.max(0, 6 - images.length)));
            break;
          }
          if (a.kind === "guide") {
            const guide = GUIDES[a.id];
            if (!guide) {
              results.push({ type: a.type, label: `No guide called "${a.id}" — the only guide is "excalidraw"`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read guide · ${a.id}`, ok: true });
            // The full text, unclipped: it rides the same <action_results> path notes and sketches use.
            read.push(`## Guide "${a.id}"\n${guide}`);
            break;
          }
          if (a.kind === "note") {
            const n = await db.notes.get(a.id);
            if (!n || n.projectId !== projectId || n.deletedAt) {
              results.push({ type: a.type, label: `Note ${a.id} not found in this project`, ok: false });
              break;
            }
            // A long note is read in parts; "from" continues where the last part ended.
            const from = Number(a.from);
            const start = Number.isFinite(from) && from > 0 ? Math.min(Math.floor(from), n.content.length) : 0;
            const part = n.content.length > NOTE_READ_CHARS ? ` · characters ${Math.min(start + 1, n.content.length)}–${Math.min(n.content.length, start + NOTE_READ_CHARS)} of ${n.content.length}` : "";
            results.push({ type: a.type, label: `Read note · ${n.title}${part}`, ok: true });
            read.push(noteBlock("Note", n, start));
          } else {
            const s = await db.sketches.get(a.id);
            if (!s || s.projectId !== projectId || s.deletedAt) {
              results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read sketch · ${s.title}`, ok: true });
            read.push(`## Sketch "${s.title}" (id=${s.id}) — one line per element: ref type x y w h fill [non-default style] "label" (attached arrows read s3→s4)\n${describeSketch(s.scene)}`);
          }
          break;
        }
        case "edit_sketch": {
          const existing = await db.sketches.get(a.id);
          if (!existing || existing.projectId !== projectId || existing.deletedAt) {
            results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
            break;
          }
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          let parsed: { elements?: unknown; appState?: unknown; files?: unknown } = {};
          try {
            parsed = JSON.parse(existing.scene || "{}");
          } catch {
            parsed = {};
          }
          const elements = (Array.isArray(parsed.elements) ? parsed.elements : []) as SketchEl[];
          const byId = assignRefs(elements);
          const byRef = new Map<string, SketchEl>();
          for (const e of elements) if (!e.isDeleted) {
            const r = byId.get(e.id);
            if (r) byRef.set(r, e);
          }
          const freeRef = () => {
            let n = byRef.size + 1;
            while (byRef.has(`s${n}`)) n++;
            return `s${n}`;
          };
          const problems: string[] = [];
          let added = 0;
          let updated = 0;
          let deleted = 0;
          const changed = new Set<string>();
          // Elements added by this edit may carry an "id", so a later op in the same edit can point an arrow at them.
          const newIds = new Map<string, string>();
          // The sketch opens and each change is painted as it is made.
          const painter = await stage.editSketch(projectId, stepId, a.id);
          for (const [opIndex, op] of a.ops.entries()) {
            if (isStopped()) {
              problems.push(`stopped before op ${opIndex + 1}`);
              break;
            }
            if (opIndex) await painter.paint(elements, opIndex, a.ops.length);
            if (op.op === "camera") {
              if (op.camera) await painter.camera(op.camera);
              continue;
            }
            const target = op.ref ? byRef.get(op.ref) : undefined;
            if (op.ref && !target) {
              problems.push(`no element ${op.ref}`);
              continue;
            }
            if (op.op === "add") {
              const spec = op.element;
              if (!spec) {
                problems.push("add needs an element");
                continue;
              }
              const ref = freeRef();
              // An arrow may name existing elements; their real geometry is what it is routed between.
              const targetOf = (f: number | string | undefined): Target | undefined => {
                if (typeof f !== "string") return undefined;
                const key = newIds.get(f) ?? f;
                const t = byRef.get(key);
                return t ? { key, box: { x: t.x, y: t.y, width: t.width, height: t.height, type: t.type } } : undefined;
              };
              const plan = planElement(spec, ref, targetOf, spec.type === "rectangle" || spec.type === "ellipse" || spec.type === "diamond" ? shapeBox(spec) : undefined);
              if (spec.type === "arrow") {
                for (const [end, got] of [["from", plan.bind.start], ["to", plan.bind.end]] as const) {
                  const v = spec[end];
                  if (typeof v === "string" && !got) problems.push(`arrow ${end} "${v}" is not an element of this sketch (it was added loose)`);
                }
              }
              const made = convertToExcalidrawElements([plan.skeleton as never], { regenerateIds: true }) as unknown as SketchEl[];
              const main = made.find((e) => (e.customData as { ref?: string } | null | undefined)?.ref === ref);
              if (!main) {
                problems.push(`could not add a ${spec.type}`);
                continue;
              }
              const local = new Map(byRef);
              local.set(ref, main);
              finishPlanned([plan], local);
              for (const e of made) elements.push(e);
              byRef.set(ref, main);
              if (typeof spec.id === "string" && spec.id) newIds.set(spec.id, ref);
              // The shapes an arrow was joined to now carry its binding: repaint them too.
              for (const t of [plan.bind.start, plan.bind.end]) {
                const shape = t && byRef.get(t.key);
                if (shape) bump(shape);
              }
              added++;
            } else if (op.op === "update" && target) {
              const spec = op.element;
              if (spec) {
                const labels = elements.filter((e) => e.containerId === target.id && !e.isDeleted);
                const out = applyPatch(target, spec, labels, op.ref ?? "element");
                problems.push(...out.problems);
                if (out.moved) changed.add(target.id);
              } else bump(target);
              updated++;
            } else if (op.op === "delete" && target) {
              target.isDeleted = true;
              bump(target);
              const label = elements.find((e) => e.containerId === target.id);
              if (label) {
                label.isDeleted = true;
                bump(label);
              }
              for (const e of elements) if (e.startBinding?.elementId === target.id || e.endBinding?.elementId === target.id) bump(e);
              deleted++;
            }
          }
          // Arrows joined to shapes that moved or grew follow them.
          const followed = rerouteBoundArrows(elements, changed);
          await painter.paint(elements, a.ops.length, a.ops.length);
          if (added + updated + deleted === 0) {
            // Nothing could be applied: no new version, no "changed" time, and Leo hears why.
            painter.done();
            results.push({ type: a.type, label: `Sketch not changed — ${problems.join("; ") || "no op could be applied"}`, ok: false });
            break;
          }
          const scene = serializeAsJSON(elements as never, (parsed.appState ?? { viewBackgroundColor: "#ffffff" }) as never, (parsed.files ?? {}) as never, "local");
          // Every edit keeps the previous scene, so the learner can restore it from History.
          await db.sketches.update(a.id, {
            scene,
            versions: [...(existing.versions ?? []), { scene: existing.scene, at: Date.now(), replacedBy: "ai" as const }].slice(-SKETCH_VERSION_LIMIT),
            updatedAt: Date.now(),
          });
          const api = useApp.getState().sketchApi;
          if (api && api.sketchId === a.id) api.updateScene({ elements });
          painter.done();
          results.push({
            type: a.type,
            label: `Sketch · ${added} added, ${updated} updated, ${deleted} deleted${followed ? `, ${followed} arrow${followed === 1 ? "" : "s"} re-routed` : ""}${problems.length ? ` — ${problems.join("; ")}` : ""}`,
            ok: problems.length === 0,
          });
          break;
        }
        case "sketch": {
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          // Sizes shapes to their text, routes arrows between shapes, keeps every native style.
          const planned = planSketch(a.elements);
          const converted = convertToExcalidrawElements(planned.map((p) => p.skeleton) as never, { regenerateIds: true }) as unknown as SketchEl[];
          const byRef = new Map<string, SketchEl>();
          for (const e of converted) {
            const ref = (e.customData as { ref?: string } | null | undefined)?.ref;
            if (ref && !e.containerId) byRef.set(ref, e);
          }
          finishPlanned(planned, byRef);
          const elements = converted;
          const scene = serializeAsJSON(elements as never, { viewBackgroundColor: "#ffffff", gridSize: 20 } as never, {} as never, "local");
          const now = Date.now();
          const id = uid();
          await db.sketches.add({ id, projectId, title: a.title.trim() || "Leo's sketch", scene, createdAt: now, updatedAt: now });
          // The sketch is saved; now it opens on an empty canvas and is drawn shape by shape, camera cues included.
          await stage.drawSketch(projectId, stepId, id, elements as never, a.cameras);
          results.push({ type: a.type, label: `Created sketch · ${a.title.trim() || "Leo's sketch"}`, ok: true });
          // Composition check: overlaps are reported to Leo once, so he can fix them with edit_sketch.
          const notes = lintScene(elements);
          if (notes.length)
            advisory.push(
              `## Layout check — sketch "${a.title.trim() || "Leo's sketch"}" (id=${id})\n${notes.map((n) => `- ${n}`).join("\n")}\nIf this hurts readability, move the elements with edit_sketch (update x/y, or width/height); arrows follow. Otherwise just answer.`
            );
          break;
        }
        case "browser": {
          let url: URL;
          try {
            url = new URL(a.url);
          } catch {
            throw new Error("Invalid URL");
          }
          // Checked again here, so a stored or approved action can never skip the rule.
          const why = publicUrlProblem(url.href);
          if (why) throw new Error(`Leo opens public web pages only, and this address ${why}`);
          stage.openBrowser(projectId, url.href);
          results.push({ type: a.type, label: `Opened browser · ${url.hostname}`, ok: true });
          break;
        }
        case "memory": {
          const out = await runMemory(projectId, a, false);
          results.push(out.result);
          if (out.pending) pending.push(out.pending);
          break;
        }
        case "organize": {
          if (approvalRequired()) {
            const label = a.reason?.trim() ? `Organize: ${brief(a.reason.trim(), 80)}` : `Organize · ${a.ops.length} ${a.ops.length === 1 ? "change" : "changes"}`;
            pending.push(pendingOf(a, label));
            results.push({ type: a.type, label: `Waiting for the learner's approval — ${label.toLowerCase()}`, ok: true });
          } else results.push(await runOrganize(projectId, a));
          break;
        }
        case "add_tool": {
          if (approvalRequired()) {
            pending.push(pendingOf(a, `Add ${toolWord(a)} to the library`));
            results.push({ type: a.type, label: `Waiting for the learner's approval — add ${toolWord(a)}`, ok: true });
          } else results.push(await runAddTool(projectId, a));
          break;
        }
        case "delete": {
          // Deletions always wait for the learner's approval, even with "Always approve" on.
          const out = await runDelete(projectId, a, false);
          results.push(out.result);
          if (out.pending) pending.push(out.pending);
          break;
        }
        case "practice_test": {
          results.push({ type: a.type, label: `Practice test ready · ${a.title} (${a.questions.length} questions, ${a.minutes} min)`, ok: true });
          break;
        }
        default:
          break;
      }
    } catch (e) {
      results.push({ type: a.type, label: String(e), ok: false });
    }
    if (stepId) {
      const result = results.length > before ? results[results.length - 1] : undefined;
      stage.finish(stepId, result ? result.ok : true, result?.label);
      await stage.breathe();
    }
  }
  return { results, read, pending, ran, skipped, advisory, ...(images.length ? { images } : {}) };
}
