/**
 * Leo may open public web pages only. A page he opens loads in the learner's own browser, so an
 * address on this device or the local network (a router, a local model server, a dev server) would
 * be reached with the learner's network access — and text from a PDF or a web page could ask him to.
 *
 * This is a check of the address as written. It cannot see where a public name resolves to, so it
 * is a guard against the obvious, not a firewall. The learner can still type any address into the
 * learning browser themselves.
 *
 * Returns why the address is refused (a phrase that follows "this address …"), or null.
 */
export function publicUrlProblem(raw: string): string | null {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return "is not a valid URL";
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return "is not an http(s) page";
  if (url.username || url.password) return "carries a username or password";
  // The URL parser has already normalised the host: lower case, and IPv4 in any spelling
  // (hex, octal, a single number) rewritten as dotted decimal.
  const host = url.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "");
  if (!host) return "has no host";
  const local = "is on this device or the local network";

  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (v4) {
    const a = Number(v4[1]);
    const b = Number(v4[2]);
    const reserved =
      a === 0 || // "this network"
      a === 10 || // private
      a === 127 || // loopback
      (a === 100 && b >= 64 && b <= 127) || // carrier-grade NAT
      (a === 169 && b === 254) || // link-local
      (a === 172 && b >= 16 && b <= 31) || // private
      (a === 192 && b === 168) || // private
      a >= 224; // multicast and reserved
    return reserved ? local : null;
  }
  if (host.includes(":")) {
    // IPv6: loopback, unspecified, unique-local (fc00::/7), link-local (fe80::/10), IPv4-mapped.
    return host === "::1" || host === "::" || /^f[cd]/.test(host) || /^fe[89ab]/.test(host) || host.startsWith("::ffff:") ? local : null;
  }
  if (host === "localhost" || /\.(localhost|local|internal|lan|home|intranet|corp)$/.test(host) || host.endsWith(".home.arpa")) return local;
  // A single-label name ("intranet", "nas") only resolves on a local network.
  if (!host.includes(".")) return "is not a public host name";
  return null;
}
