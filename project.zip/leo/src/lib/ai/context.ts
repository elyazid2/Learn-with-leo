/**
 * What of Leo's own tool results stays in his context.
 *
 * Every read or search comes back to the model as an <action_results> message. Within ONE learner
 * turn they all stay in full — what Leo read in step 1 is still in front of him in step 5 — up to a
 * total cap, with the oldest collapsing first. Results from earlier turns collapse to their headings
 * (the Excalidraw guide is kept for the whole chat). chat.ts builds the history with this; the note
 * editor uses the same rule to know whether Leo still has the text of a note he wants to change.
 */

/** Most characters of <action_results> from the CURRENT learner turn that are sent in full. */
export const RESULTS_TURN_CAP = 24_000;

interface Msg {
  role: string;
  content: string;
  hidden?: boolean;
}

export const isActionResults = (m: Msg) => m.role === "user" && !!m.hidden && m.content.startsWith("<action_results>");

/**
 * Split an <action_results> body: the lead (step line and notes), the `## …` items, and the trailing
 * FAILED lines (appended after every read item, so they survive a collapse).
 */
export function splitResults(content: string): { lead: string[]; parts: string[]; failed: string[] } {
  const lines = content.replace(/^<action_results>\n?/, "").replace(/\n?<\/action_results>\s*$/, "").split("\n");
  let cut = lines.length;
  while (cut > 0 && lines[cut - 1].startsWith("- FAILED ")) cut--;
  const failed = lines.slice(cut);
  const body = lines.slice(0, cut).join("\n");
  const all = body ? body.split(/\n(?=## )/) : [];
  // Anything before the first `## ` item is the lead; it is always kept.
  const lead = all.length && !all[0].startsWith("## ") ? [all.shift()!] : [];
  return { lead, parts: all, failed };
}

/**
 * An older <action_results> body, collapsed: the step line and FAILED lines stay, each `## …` item
 * keeps only its heading — except the Excalidraw guide, which stays in full for the whole chat.
 */
export function collapseActionResults(content: string): string {
  const { lead, parts, failed } = splitResults(content);
  const out = parts.map((part) => {
    if (part.startsWith('## Guide "')) return part;
    const nl = part.indexOf("\n");
    const heading = nl >= 0 ? part.slice(0, nl) : part;
    return `${heading}\n[contents omitted from this older step — read it again if you need it]`;
  });
  return `<action_results>\n${[...lead, ...out, ...failed].join("\n")}\n</action_results>`;
}

/** Characters an <action_results> costs against the turn budget: the guide is exempt, it is kept for the whole chat anyway. */
export function resultsCost(content: string): number {
  const guide = splitResults(content).parts.filter((p) => p.startsWith('## Guide "')).reduce((n, p) => n + p.length, 0);
  return content.length - guide;
}

/**
 * Indices of the <action_results> messages sent in full: those after the learner's latest message
 * (the one that is not itself an agent-loop result), newest first, until `cap` characters are used.
 * The newest is always kept; the one that does not fit, and every older one, collapse.
 */
export function fullResultIndexes(messages: readonly Msg[], cap = RESULTS_TURN_CAP): Set<number> {
  let turnStart = -1;
  messages.forEach((m, i) => {
    if (m.role === "user" && !isActionResults(m)) turnStart = i;
  });
  const full = new Set<number>();
  let used = 0;
  for (let i = messages.length - 1; i > turnStart; i--) {
    if (!isActionResults(messages[i])) continue;
    const cost = resultsCost(messages[i].content);
    if (full.size > 0 && used + cost > cap) break;
    full.add(i);
    used += cost;
  }
  return full;
}
