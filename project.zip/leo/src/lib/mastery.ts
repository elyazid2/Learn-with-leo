import type { Concept } from "./db";

/**
 * The concepts that count toward mastery: the leaves of the knowledge map. A parent is a container
 * Leo creates to group concepts; counting it too would cap the score and count one idea twice.
 * Every screen that shows "x/y solid" or a mastery bar uses this, so the numbers agree.
 */
export function leafConcepts<T extends Pick<Concept, "id" | "parentId">>(concepts: T[]): T[] {
  const parents = new Set(concepts.map((c) => c.parentId).filter(Boolean));
  return concepts.filter((c) => !parents.has(c.id));
}
