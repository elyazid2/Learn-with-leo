/**
 * The agent loop end to end with a scripted model: what happens at the step limit, on Stop, with
 * broken or cut-off action blocks, and when a send is refused.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});
vi.mock("@/lib/retrieval", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/retrieval")>();
  return { ...actual, indexNote: vi.fn(async () => {}), retrieve: vi.fn(async () => []), retrievalQuery: () => "" };
});
vi.mock("./ai/prompt", () => ({ buildSystemPrompt: vi.fn(async () => "SYSTEM"), PLACEMENT_KICKOFF: "go" }));

type Step = { text: string; finishReason?: string; before?: () => void; abort?: boolean };
const script: { steps: Step[]; calls: { role: string; content: string }[][] } = { steps: [], calls: [] };

vi.mock("./ai/providers", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./ai/providers")>();
  return {
    ...actual,
    streamChat: async function* (_p: unknown, _m: string, _s: string, msgs: { role: string; content: string }[], _sig: unknown, onMeta?: (m: { finishReason?: string }) => void) {
      script.calls.push(msgs.map((m) => ({ role: m.role, content: m.content })));
      const step = script.steps.shift() ?? { text: "(script ended)" };
      step.before?.();
      yield step.text;
      if (step.abort) throw new DOMException("aborted", "AbortError");
      if (step.finishReason) onMeta?.({ finishReason: step.finishReason });
    },
  };
});

import { db, type Message } from "@/lib/db";
import { useApp } from "@/lib/store";
import { isBusy, runAssistant, sendMessage, stopStreaming, MAX_STEPS } from "./chat";
import { CUT_OFF_NOTICE } from "./chat";
import { isStopped } from "./turn";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const P = "p1";
const T = "t1";
const action = (o: object) => "```action\n" + JSON.stringify(o) + "\n```";
const readNote = action({ type: "read", kind: "note", id: "n1" });
const thread = async () => (await db.messages.where("threadId").equals(T).sortBy("createdAt")) as Message[];
const resultsMsgs = async () => (await thread()).filter((m) => m.role === "user" && m.hidden && m.content.startsWith("<action_results>"));

beforeEach(async () => {
  fake.reset();
  script.steps = [];
  script.calls = [];
  await db.projects.add({ id: P, name: "Bio", tag: "", color: "ink", createdAt: 1, updatedAt: 1, placement: { status: "done", level: "Novice" } } as never);
  await db.providers.add({ id: "pv", name: "Fake", type: "openai", baseUrl: "http://x", apiKey: "k", models: ["m"], createdAt: 1 } as never);
  await db.threads.add({ id: T, projectId: P, title: "t", mode: "ask", providerId: "pv", model: "m", createdAt: 1, updatedAt: 1 } as never);
  await db.notes.add({ id: "n1", projectId: P, title: "Cells", content: "Cells have a membrane.", author: "user", createdAt: 1, updatedAt: 1 } as never);
  useApp.getState().setStreaming(null);
});

describe("broken and cut-off action blocks", () => {
  it("reports an invalid block as a FAILED line and continues the loop", async () => {
    script.steps = [{ text: `Trying.\n${action({ type: "nope" })}` }, { text: "Fixed it." }];
    await sendMessage({ threadId: T, text: "do it" });
    expect(script.calls).toHaveLength(2);
    const [r] = await resultsMsgs();
    expect(r.content).toContain("You are on step 2 of 6.");
    expect(r.content).toMatch(/- FAILED action block: unknown action type/);
    const msgs = await thread();
    expect(msgs.at(-1)).toMatchObject({ role: "assistant", content: "Fixed it." });
    expect(msgs.at(-1)!.hidden).toBeUndefined();
    expect(isBusy()).toBe(false);
  });

  it("a cut-off reply is stored as received, flagged truncated, and Leo is told", async () => {
    const half = "Here is the note.\n```action\n" + '{"type":"note","title":"X","content":"abc';
    script.steps = [{ text: half, finishReason: "max_tokens" }, { text: "Done." }];
    await sendMessage({ threadId: T, text: "write it" });
    const first = (await thread()).find((m) => m.role === "assistant")!;
    expect(first.content).toBe(half); // no "(reply cut off…)" appended
    expect(first.content).not.toMatch(/cut off/i);
    expect(first.truncated).toBe(true);
    expect(first.hidden).toBeUndefined(); // the learner keeps what was written
    const [r] = await resultsMsgs();
    expect(r.content).toContain(CUT_OFF_NOTICE);
    expect(r.content).toMatch(/- FAILED action block: action block was cut off/);
    expect(script.calls).toHaveLength(2);
  });

  it.each(["length", "MAX_TOKENS"])("treats finishReason %s as truncated", async (reason) => {
    script.steps = [{ text: "partial answer", finishReason: reason }, { text: "rest" }];
    await sendMessage({ threadId: T, text: "go" });
    expect(script.calls).toHaveLength(2);
    expect((await thread()).find((m) => m.role === "assistant")!.truncated).toBe(true);
  });
});

describe("one read per step", () => {
  it("skips every action after the first read and tells Leo to re-emit it", async () => {
    script.steps = [{ text: `${readNote}\n${action({ type: "map", concept: "Membrane", status: "learning" })}` }, { text: "Answer." }];
    await sendMessage({ threadId: T, text: "go" });
    expect(await db.concepts.where("projectId").equals(P).toArray()).toHaveLength(0);
    const [r] = await resultsMsgs();
    expect(r.content).toContain("Cells have a membrane.");
    expect(r.content).toContain("- FAILED map: not run, re-emit after you see the results");
    expect(script.calls).toHaveLength(2);
  });

  it("a skipped question card does not keep its step on screen", async () => {
    script.steps = [{ text: `${readNote}\n${action({ type: "ask", question: "Q?", options: ["a", "b"] })}` }, { text: "Answer." }];
    await sendMessage({ threadId: T, text: "go" });
    const step1 = (await thread()).filter((m) => m.role === "assistant")[0];
    expect(step1.hidden).toBe(true);
  });
});

describe("the step budget", () => {
  it("numbers the steps and says 'answer now, no more reads' on the last one", async () => {
    script.steps = Array.from({ length: MAX_STEPS - 1 }, () => ({ text: readNote })).concat([{ text: "Final answer." }]);
    await sendMessage({ threadId: T, text: "go" });
    const rs = await resultsMsgs();
    expect(rs).toHaveLength(MAX_STEPS - 1);
    rs.forEach((r, i) => expect(r.content).toContain(`step ${i + 2} of 6`));
    expect(rs.at(-1)!.content).toMatch(/step 6 of 6.*answer now, no more reads/);
    expect((await thread()).at(-1)).toMatchObject({ content: "Final answer." });
  });

  it("when the last step still reads, nothing is dropped: the reads are kept and a Continue chip is offered", async () => {
    script.steps = Array.from({ length: MAX_STEPS }, () => ({ text: `Still looking.\n${readNote}` }));
    await sendMessage({ threadId: T, text: "go" });
    expect(script.calls).toHaveLength(MAX_STEPS);
    const msgs = await thread();
    const last = msgs.filter((m) => m.role === "assistant").at(-1)!;
    expect(last.continuable).toBe(true);
    expect(last.hidden).toBeUndefined();
    const lastResults = (await resultsMsgs()).at(-1)!;
    expect(lastResults.content).toContain("Cells have a membrane.");
    expect(lastResults.content).toMatch(/used up/);
    // Pressing Continue gives a fresh budget on the same turn, with the earlier results still in full.
    script.calls = [];
    script.steps = [{ text: "Now I can answer." }];
    const { continueTurn } = await import("./chat");
    await continueTurn(T);
    const sent = script.calls[0];
    expect(sent.at(-1)!.content).toContain("step 1 of 6");
    expect(sent.some((m) => m.content.includes("Cells have a membrane."))).toBe(true);
  });
});

describe("Stop", () => {
  it("is a per-turn flag: it ends the loop between steps and the next turn starts clean", async () => {
    script.steps = [{ text: readNote, before: () => stopStreaming() , abort: false }, { text: "never" }];
    // stopStreaming() sets the flag while the first stream is open; the stream itself finishes.
    await sendMessage({ threadId: T, text: "go" });
    expect(script.calls).toHaveLength(1);
    expect(await resultsMsgs()).toHaveLength(0);
    expect(isStopped()).toBe(false); // reset when the turn ended
    expect(isBusy()).toBe(false);
    // The read never ran, so nothing was learned from it, and the learner is not left with silence.
    const msgs = await thread();
    expect(msgs.filter((m) => m.role === "assistant" && !m.hidden).length).toBeGreaterThan(0);
    script.steps = [{ text: "Hello again." }];
    await sendMessage({ threadId: T, text: "again" });
    expect((await thread()).at(-1)).toMatchObject({ content: "Hello again." });
  });

  it("stopping mid-stream keeps the partial reply and does not run its actions", async () => {
    script.steps = [{ text: `Writing…\n${action({ type: "map", concept: "Ghost" })}`, before: () => stopStreaming(), abort: true }];
    await sendMessage({ threadId: T, text: "go" });
    const a = (await thread()).find((m) => m.role === "assistant")!;
    expect(a.partial).toBe(true);
    expect(await db.concepts.where("projectId").equals(P).toArray()).toHaveLength(0);
    expect(script.calls).toHaveLength(1);
  });
});

describe("sendMessage releases the lock on every way out", () => {
  it("an unknown thread returns false without leaving the chat busy", async () => {
    expect(await sendMessage({ threadId: "missing", text: "hi" })).toBe(false);
    expect(isBusy()).toBe(false);
    script.steps = [{ text: "ok" }];
    expect(await sendMessage({ threadId: T, text: "hi" })).toBe(true);
  });

  it("a database failure releases it too", async () => {
    const original = db.messages.add.bind(db.messages);
    (db.messages as unknown as { add: unknown }).add = async () => {
      throw new Error("quota");
    };
    await expect(sendMessage({ threadId: T, text: "hi" })).rejects.toThrow("quota");
    expect(isBusy()).toBe(false);
    (db.messages as unknown as { add: unknown }).add = original;
  });

  it("runAssistant without the lock refuses while busy and releases when done", async () => {
    script.steps = [{ text: "one" }];
    await runAssistant(T);
    expect(isBusy()).toBe(false);
  });
});
