/**
 * The learner's "Stop" for the turn that is running.
 *
 * An AbortController only cuts the request that is streaming right now. A turn is more than that:
 * several model steps, several actions per step, and animations that replay saved work on screen.
 * This flag covers all of it. It is set by Stop, checked between steps and between actions, and
 * makes the staged animations skip straight to the finished result (the data is saved first, so
 * skipping an animation never loses anything).
 *
 * It lives in its own module so lib/live.ts, lib/ai/actions.ts and lib/chat.ts can all read it
 * without importing each other.
 */
let stopped = false;

/** A new turn starts: nothing has been stopped yet. */
export function beginTurn() {
  stopped = false;
}

/** The turn is over; later work (approvals, edits the learner makes) must not see a stale Stop. */
export function endTurn() {
  stopped = false;
}

/** The learner pressed Stop. */
export function stopTurn() {
  stopped = true;
}

export const isStopped = () => stopped;
