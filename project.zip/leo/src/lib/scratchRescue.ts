import { db, uid, type Note, type Project } from "./db";
import { readableTitle, uniqueTitle } from "./notes";

/**
 * The scratchpad was removed from the app. What people wrote in it was not: this moves it into
 * ordinary notes, where it can be read, searched, linked and shared with Leo like anything else.
 *
 * - A project's own scratchpad becomes a note called "Scratchpad" in that project.
 * - Thoughts from the cross-project scratchpad become one note each, in a project called
 *   "Scratchpad" (created only if there is something to put in it).
 *
 * It runs on start-up and after a backup import. It is idempotent: once the old fields and rows are
 * gone there is nothing left to move, and a second run changes nothing. Each move is one
 * transaction, so an interruption can neither lose text nor copy it twice.
 */

/** Name of the note a project scratchpad becomes, and of the project that receives loose thoughts. */
export const SCRATCH_PROJECT_NAME = "Scratchpad";
/** With the name, this tag identifies the receiving project so a later run reuses it. */
const SCRATCH_PROJECT_TAG = "scratchpad";

export interface ScratchRescue {
  /** Project scratchpads that became a note in their own project. */
  projectNotes: number;
  /** Cross-project thoughts that became notes. */
  thoughts: number;
  /** The project those thoughts went to. */
  projectId?: string;
}

/** A note title from the first line of a thought, as the old "Move to a project" made it. */
function titleOf(text: string, fallback: string) {
  const first = readableTitle(text.trim().split("\n")[0] ?? "");
  return (first.length > 60 ? `${first.slice(0, 57).trimEnd()}…` : first) || fallback;
}

export async function rescueScratchpad(): Promise<ScratchRescue> {
  const out: ScratchRescue = { projectNotes: 0, thoughts: 0 };
  const made: Note[] = [];
  const now = Date.now();
  const projects = await db.projects.toArray();

  // 1. Each project's own scratchpad → a note in that project; the legacy field is removed.
  for (const p of projects) {
    if (p.scratchpad === undefined) continue;
    const text = typeof p.scratchpad === "string" ? p.scratchpad : "";
    await db.transaction("rw", [db.notes, db.projects], async () => {
      if (text.trim()) {
        const note: Note = {
          id: uid(),
          projectId: p.id,
          title: await uniqueTitle(p.id, "", SCRATCH_PROJECT_NAME),
          content: text,
          author: "user",
          lastEditedBy: "user",
          createdAt: now,
          updatedAt: now,
        };
        await db.notes.add(note);
        made.push(note);
        out.projectNotes++;
      }
      // Dexie deletes a key that is set to undefined.
      await db.projects.update(p.id, { scratchpad: undefined, ...(text.trim() ? { updatedAt: now } : {}) });
    });
  }

  // 2. Cross-project thoughts → one note each, oldest first, in a "Scratchpad" project.
  const thoughts = (await db.scratch.toArray()).sort((a, b) => a.createdAt - b.createdAt);
  if (thoughts.length) {
    const keep = thoughts.filter((t) => typeof t.text === "string" && t.text.trim());
    let home: Project | undefined = keep.length ? projects.find((p) => p.name === SCRATCH_PROJECT_NAME && p.tag === SCRATCH_PROJECT_TAG) : undefined;
    await db.transaction("rw", [db.notes, db.projects, db.scratch], async () => {
      if (keep.length && !home) {
        home = { id: uid(), name: SCRATCH_PROJECT_NAME, tag: SCRATCH_PROJECT_TAG, color: "ink", createdAt: now, updatedAt: now, placement: { status: "pending" } };
        await db.projects.add(home);
      }
      for (const t of keep) {
        const note: Note = {
          id: uid(),
          projectId: home!.id,
          title: await uniqueTitle(home!.id, "", titleOf(t.text, "Thought")),
          content: t.text,
          author: "user",
          lastEditedBy: "user",
          createdAt: t.createdAt,
          updatedAt: t.updatedAt ?? t.createdAt,
        };
        await db.notes.add(note);
        made.push(note);
        out.thoughts++;
      }
      // Blank thoughts go too: the table ends empty.
      for (const t of thoughts) await db.scratch.delete(t.id);
      if (home && keep.length) await db.projects.update(home.id, { updatedAt: now });
    });
    if (home && keep.length) out.projectId = home.id;
  }

  if (made.length) {
    try {
      const { indexNote } = await import("./retrieval");
      for (const n of made) await indexNote(n);
    } catch {
      /* not fatal: a note is indexed again the next time it is saved */
    }
  }
  return out;
}

/** One sentence for the learner about what was moved, or null when nothing was. */
export function rescueMessage(r: ScratchRescue): string | null {
  if (!r.projectNotes && !r.thoughts) return null;
  const parts: string[] = [];
  if (r.thoughts) parts.push(`${r.thoughts} ${r.thoughts === 1 ? "thought is now a note" : "thoughts are now notes"} in a “${SCRATCH_PROJECT_NAME}” project`);
  if (r.projectNotes) parts.push(`${r.projectNotes === 1 ? "a project's scratchpad is" : `${r.projectNotes} project scratchpads are`} now a note called “${SCRATCH_PROJECT_NAME}” in ${r.projectNotes === 1 ? "that project" : "each project"}`);
  return `The scratchpad has been retired. Nothing was lost: ${parts.join(", and ")}.`;
}
