import { db, uid, SKETCH_VERSION_LIMIT, type Sketch } from "./db";
import { versionsWithCurrent } from "./noteVersions";
import { snapshotMetadata } from "./itemVersions";
import { renameNote, uniqueTitle } from "./notes";
import { indexNote } from "./retrieval";

/**
 * Leo's project-organizing operations. They are proposals: the chat shows a preview and nothing
 * changes until the learner approves (unless Settings → "Always approve" is on).
 */
export type OrganizeItemKind = "note" | "sketch" | "file" | "tool";

export type OrganizeOp =
  /** A notes folder inside the current project, e.g. "Biology/Cells". */
  | { op: "create_folder"; path: string }
  /** Notes move between note folders; projects move between home-screen folders (by name). */
  | { op: "move"; kind: "note"; id: string; folder: string }
  | { op: "move"; kind: "project"; folder: string }
  | { op: "rename"; kind: OrganizeItemKind | "project"; id?: string; name: string }
  | { op: "rename"; kind: "folder"; path: string; name: string }
  | { op: "tag"; kind: OrganizeItemKind | "project"; id?: string; tags: string[] };

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
const str = (v: unknown, max = 200) => typeof v === "string" && v.trim().length > 0 && v.length <= max;
const ITEM_KINDS = ["note", "sketch", "file", "tool"];

/** What a proposal stored by an older build may still ask for; the scratchpad no longer exists. */
const RETIRED = "The scratchpad has been removed — its contents are now notes";
const isRetired = (o: OrganizeOp) => (o as { kind?: string }).kind === "scratch";

export const cleanPath = (f: string) =>
  f
    .split("/")
    .map((x) => x.trim())
    .filter(Boolean)
    .join("/")
    .slice(0, 200);

const cleanTag = (t: string) => t.trim().replace(/^#+/, "").replace(/\s+/g, "-").slice(0, 40);

/** Why an op list is invalid, or null. */
export function organizeProblem(ops: unknown): string | null {
  if (!Array.isArray(ops) || !ops.length) return 'organize needs a non-empty "ops" array';
  if (ops.length > 30) return `organize has ${ops.length} ops; the limit is 30`;
  for (let i = 0; i < ops.length; i++) {
    const o = ops[i];
    const at = `organize op ${i + 1}`;
    if (!isRecord(o)) return `${at} is not an object`;
    switch (o.op) {
      case "create_folder":
        if (!str(o.path)) return `${at}: create_folder needs a "path"`;
        break;
      case "move":
        if (o.kind === "note") {
          if (!str(o.id, 64) || typeof o.folder !== "string") return `${at}: move note needs "id" and "folder" ("" = top level)`;
        } else if (o.kind === "project") {
          if (typeof o.folder !== "string") return `${at}: move project needs "folder" (a home folder name, "" = home)`;
        } else return `${at}: move kind must be note or project`;
        break;
      case "rename":
        if (!str(o.name)) return `${at}: rename needs a "name"`;
        if (o.kind === "folder") {
          if (!str(o.path)) return `${at}: rename folder needs its "path"`;
        } else if (o.kind === "project") {
          /* current project */
        } else if (ITEM_KINDS.includes(o.kind as string)) {
          if (!str(o.id, 64)) return `${at}: rename ${String(o.kind)} needs an "id"`;
        } else return `${at}: rename kind must be note, sketch, file, tool, folder or project`;
        break;
      case "tag":
        if (!Array.isArray(o.tags) || !o.tags.length || !o.tags.every((t) => str(t, 40))) return `${at}: tag needs "tags": [string]`;
        if (o.kind !== "project") {
          if (!ITEM_KINDS.includes(o.kind as string)) return `${at}: tag kind must be note, sketch, file, tool or project`;
          if (!str(o.id, 64)) return `${at}: tag needs an "id"`;
        }
        break;
      default:
        return `${at}: op must be create_folder, move, rename or tag`;
    }
  }
  return null;
}

async function itemName(kind: string, id?: string): Promise<string> {
  if (!id) return kind;
  if (kind === "note") return (await db.notes.get(id))?.title ?? `note ${id}`;
  if (kind === "sketch") return (await db.sketches.get(id))?.title ?? `sketch ${id}`;
  if (kind === "file") return (await db.files.get(id))?.name ?? `file ${id}`;
  if (kind === "tool") return (await db.tools.get(id))?.title ?? `tool ${id}`;
  return id;
}

/** One human-readable line per op, for the approval preview. */
export async function describeOrganize(projectId: string, ops: OrganizeOp[]): Promise<string[]> {
  const project = await db.projects.get(projectId);
  const out: string[] = [];
  for (const o of ops) {
    if (isRetired(o)) out.push(`${RETIRED} (this change can no longer be applied)`);
    else if (o.op === "create_folder") out.push(`Create folder “${cleanPath(o.path)}”`);
    else if (o.op === "move") {
      if (o.kind === "project") out.push(`Move project “${project?.name ?? ""}” to ${o.folder.trim() ? `home folder “${o.folder.trim()}”` : "home"}`);
      else out.push(`Move note “${await itemName("note", o.id)}” to ${cleanPath(o.folder) ? `“${cleanPath(o.folder)}”` : "the top level"}`);
    } else if (o.op === "rename") {
      if (o.kind === "folder") out.push(`Rename folder “${cleanPath(o.path)}” → “${o.name.trim()}”`);
      else if (o.kind === "project") out.push(`Rename project “${project?.name ?? ""}” → “${o.name.trim()}”`);
      else out.push(`Rename ${o.kind} “${await itemName(o.kind, o.id)}” → “${o.name.trim()}”`);
    } else {
      const tags = o.tags.map(cleanTag).map((t) => `#${t}`).join(" ");
      out.push(o.kind === "project" ? `Tag project “${project?.name ?? ""}” as ${o.tags[0].trim()}` : `Tag ${o.kind} “${await itemName(o.kind, o.id)}” with ${tags}`);
    }
  }
  return out;
}

const mergeTags = (a: string[] | undefined, b: string[]) => [...new Set([...(a ?? []), ...b.map(cleanTag).filter(Boolean)])].slice(0, 20);

async function ensureFolder(projectId: string, path: string) {
  const p = cleanPath(path);
  if (!p) return;
  const all = await db.folders.where("projectId").equals(projectId).toArray();
  const parts = p.split("/");
  for (let i = 1; i <= parts.length; i++) {
    const sub = parts.slice(0, i).join("/");
    if (!all.some((f) => f.path === sub)) {
      const row = { id: uid(), projectId, path: sub, createdAt: Date.now() };
      await db.folders.add(row);
      all.push(row);
    }
  }
}

/** Apply approved ops. Returns a summary and any per-op problems. */
export async function applyOrganize(projectId: string, ops: OrganizeOp[]): Promise<{ done: number; errors: string[] }> {
  const errors: string[] = [];
  let done = 0;
  const now = Date.now();
  const sketchVersions = (sketch: Sketch) => [...(sketch.versions ?? []), { scene: sketch.scene, title: sketch.title, tags: sketch.tags, at: Date.now(), replacedBy: "ai" as const }].slice(-SKETCH_VERSION_LIMIT);
  const own = async <T extends { projectId: string; deletedAt?: number }>(row: T | undefined, what: string): Promise<T | null> => {
    if (!row || row.projectId !== projectId || row.deletedAt) {
      errors.push(`${what} not found in this project`);
      return null;
    }
    return row;
  };
  for (const o of ops) {
    try {
      if (isRetired(o)) {
        errors.push(RETIRED);
      } else if (o.op === "create_folder") {
        await ensureFolder(projectId, o.path);
        done++;
      } else if (o.op === "move" && o.kind === "note") {
        const n = await own(await db.notes.get(o.id), `Note ${o.id}`);
        if (!n) continue;
        const folder = cleanPath(o.folder);
        if (folder) await ensureFolder(projectId, folder);
        // Titles stay unique inside a folder, exactly as when the learner moves a note.
        const title = folder === (n.folder ?? "") ? n.title : await uniqueTitle(projectId, folder, n.title, n.id);
        await db.notes.update(n.id, { folder: folder || undefined, ...(title !== n.title ? { title } : {}), versions: versionsWithCurrent(n, "ai", now), updatedAt: now });
        done++;
      } else if (o.op === "move" && o.kind === "project") {
        const name = o.folder.trim();
        let folderId: string | undefined;
        if (name) {
          const existing = (await db.projectFolders.toArray()).find((f) => f.name.toLowerCase() === name.toLowerCase());
          folderId = existing?.id;
          if (!folderId) {
            folderId = uid();
            await db.projectFolders.add({ id: folderId, name: name.slice(0, 80), createdAt: now, updatedAt: now });
          }
        }
        await db.projects.update(projectId, { folderId, updatedAt: now });
        done++;
      } else if (o.op === "rename") {
        const name = o.name.trim().slice(0, 200);
        if (o.kind === "project") await db.projects.update(projectId, { name, updatedAt: now });
        else if (o.kind === "folder") {
          const from = cleanPath(o.path);
          const parent = from.includes("/") ? from.slice(0, from.lastIndexOf("/")) : "";
          const to = cleanPath(parent ? `${parent}/${name}` : name);
          const folders = await db.folders.where("projectId").equals(projectId).toArray();
          for (const f of folders) if (f.path === from || f.path.startsWith(from + "/")) await db.folders.update(f.id, { path: to + f.path.slice(from.length) });
          const notes = await db.notes.where("projectId").equals(projectId).toArray();
          for (const n of notes) if (!n.deletedAt && n.folder && (n.folder === from || n.folder.startsWith(from + "/"))) await db.notes.update(n.id, { folder: to + n.folder.slice(from.length), versions: versionsWithCurrent(n, "ai", now), updatedAt: now });
        } else if (o.kind === "note") {
          const n = await own(await db.notes.get(o.id!), `Note ${o.id}`);
          if (!n) continue;
          // Through the note helper, as the learner's own rename goes: the title is made link-safe,
          // stays unique in its folder, and [[links]] to the note in other notes are rewritten.
          const notes = (await db.notes.where("projectId").equals(projectId).toArray()).filter((x) => !x.deletedAt);
          await db.notes.update(n.id, { versions: versionsWithCurrent(n, "ai", now), updatedAt: now });
          await renameNote(notes, n, name);
          // Search results and citations name the note by its title.
          const fresh = await db.notes.get(n.id);
          if (fresh) await indexNote(fresh);
        } else if (o.kind === "sketch") {
          const s = await own(await db.sketches.get(o.id!), `Sketch ${o.id}`);
          if (!s) continue;
          await db.sketches.update(s.id, { title: name, versions: sketchVersions(s), updatedAt: now });
        } else if (o.kind === "file") {
          const f = await own(await db.files.get(o.id!), `File ${o.id}`);
          if (!f) continue;
          const ext = /\.[a-z0-9]{1,5}$/i.exec(f.name)?.[0] ?? "";
          await snapshotMetadata("file", f.id);
          await db.files.update(f.id, { name: /\.[a-z0-9]{1,5}$/i.test(name) ? name : name + ext });
        } else if (o.kind === "tool") {
          const t = await own(await db.tools.get(o.id!), `Tool ${o.id}`);
          if (!t) continue;
          await snapshotMetadata("tool", t.id);
          await db.tools.update(t.id, { title: name, updatedAt: now });
        }
        done++;
      } else if (o.op === "tag") {
        if (o.kind === "project") await db.projects.update(projectId, { tag: o.tags[0].trim().slice(0, 40), updatedAt: now });
        else if (o.kind === "note") {
          const n = await own(await db.notes.get(o.id!), `Note ${o.id}`);
          if (!n) continue;
          await db.notes.update(n.id, { tags: mergeTags(n.tags, o.tags), versions: versionsWithCurrent(n, "ai", now), updatedAt: now });
        } else if (o.kind === "sketch") {
          const s = await own(await db.sketches.get(o.id!), `Sketch ${o.id}`);
          if (!s) continue;
          await db.sketches.update(s.id, { tags: mergeTags(s.tags, o.tags), versions: sketchVersions(s), updatedAt: now });
        } else if (o.kind === "file") {
          const f = await own(await db.files.get(o.id!), `File ${o.id}`);
          if (!f) continue;
          await snapshotMetadata("file", f.id);
          await db.files.update(f.id, { tags: mergeTags(f.tags, o.tags) });
        } else if (o.kind === "tool") {
          const t = await own(await db.tools.get(o.id!), `Tool ${o.id}`);
          if (!t) continue;
          await snapshotMetadata("tool", t.id);
          await db.tools.update(t.id, { tags: mergeTags(t.tags, o.tags) });
        }
        done++;
      }
    } catch (e) {
      errors.push(e instanceof Error ? e.message : String(e));
    }
  }
  if (done) await db.projects.update(projectId, { updatedAt: Date.now() });
  return { done, errors };
}
