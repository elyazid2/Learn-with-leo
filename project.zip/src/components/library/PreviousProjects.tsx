import { useEffect, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { AlignLeft, ChevronDown, FileText, Film, Image as ImageIcon, Loader2, Music, PenTool } from "lucide-react";
import { db, type FileKind } from "@/lib/db";
import { copyKey, type CopyChoice } from "@/lib/libraryCopies";
import ProjectAvatar from "@/components/ProjectAvatar";
import { cn } from "@/utils/cn";

interface Item extends CopyChoice {
  title: string;
  label: string;
  fileKind?: FileKind;
  at: number;
}

function ItemIcon({ item }: { item: Item }) {
  if (item.kind === "sketch") return <PenTool size={16} />;
  if (item.kind === "note") return <FileText size={16} />;
  if (item.fileKind === "image") return <ImageIcon size={16} />;
  if (item.fileKind === "audio") return <Music size={16} />;
  if (item.fileKind === "video") return <Film size={16} />;
  if (item.fileKind === "text") return <AlignLeft size={16} />;
  return <FileText size={16} />;
}

const FILE_LABEL: Record<FileKind, string> = { pdf: "PDF", image: "Picture", audio: "Audio", video: "Video", text: "Text" };

function ProjectItems({ projectId, selected, onChange, disabled }: { projectId: string; selected: CopyChoice[]; onChange: (next: CopyChoice[]) => void; disabled: boolean }) {
  const body = useRef<HTMLDivElement>(null);
  const items = useLiveQuery(async (): Promise<Item[]> => {
    // File blobs are read only for the expanded project, never for all the closed rows.
    const [files, notes, sketches] = await Promise.all([
      db.files.where("projectId").equals(projectId).toArray(),
      db.notes.where("projectId").equals(projectId).toArray(),
      db.sketches.where("projectId").equals(projectId).toArray(),
    ]);
    return [
      ...files.map((f): Item => ({ kind: "file", id: f.id, projectId, title: f.name, fileKind: f.kind, at: f.createdAt, label: `${f.youtubeId ? "YouTube video" : FILE_LABEL[f.kind]}${f.transcript?.length || ((f.kind === "video" || f.kind === "audio") && f.indexed === "done") ? " · transcript kept" : f.indexed === "done" ? " · text kept" : ""}` })),
      ...notes.map((n): Item => ({ kind: "note", id: n.id, projectId, title: n.title || "Untitled note", label: "Note", at: n.updatedAt })),
      ...sketches.map((s): Item => ({ kind: "sketch", id: s.id, projectId, title: s.title || "Sketch", label: "Sketch", at: s.updatedAt })),
    ].sort((a, b) => b.at - a.at);
  }, [projectId]);
  useEffect(() => {
    if (items?.length) body.current?.parentElement?.scrollIntoView({ block: "nearest", behavior: "auto" });
  }, [items?.length]);
  if (!items) return <div className="flex items-center justify-center gap-2 py-5 text-[12px] text-muted"><Loader2 size={14} className="animate-spin" /> Loading items</div>;
  if (!items.length) return <p className="px-4 py-4 text-[12px] text-muted">This project has no library items yet.</p>;
  const keys = new Set(selected.map(copyKey));
  const all = items.every((item) => keys.has(copyKey(item)));
  const choose = (item: CopyChoice, checked: boolean) => {
    onChange(checked ? [...selected.filter((s) => copyKey(s) !== copyKey(item)), { kind: item.kind, id: item.id, projectId }] : selected.filter((s) => copyKey(s) !== copyKey(item)));
  };
  return <div ref={body} className="border-t border-line">
    <div className="flex items-center justify-between gap-2 px-3.5 py-1.5 text-[11.5px] text-muted"><span>{items.length} {items.length === 1 ? "item" : "items"}</span><button type="button" disabled={disabled} className="rounded-full px-2 py-1 font-medium transition-colors hover:bg-ink/[0.06] hover:text-ink disabled:opacity-40" onClick={() => {
      const other = selected.filter((s) => !items.some((i) => copyKey(i) === copyKey(s)));
      onChange(all ? other : [...other, ...items.map((i) => ({ kind: i.kind, id: i.id, projectId }))]);
    }}>{all ? "Deselect all" : "Select all"}</button></div>
    <ul className="max-h-64 overflow-y-auto pb-1">
      {items.map((item) => {
        const checked = keys.has(copyKey(item));
        return <li key={copyKey(item)}><label className={cn("flex cursor-pointer items-center gap-3 px-3.5 py-2.5 transition-colors", checked ? "bg-ink/[0.055]" : "hover:bg-ink/[0.025]", disabled && "pointer-events-none opacity-60")}>
          <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => choose(item, e.target.checked)} aria-label={`Copy ${item.title}`} className="h-4 w-4 shrink-0 accent-[var(--ink)]" />
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-ink/[0.045] text-ink/70"><ItemIcon item={item} /></span>
          <span className="min-w-0 flex-1"><span className="block truncate text-[13px] font-medium" dir="auto">{item.title}</span><span className="block text-[11.5px] text-muted">{item.label}</span></span>
        </label></li>;
      })}
    </ul>
  </div>;
}

export default function PreviousProjects({ projectId, selected, onChange, disabled }: { projectId: string; selected: CopyChoice[]; onChange: (next: CopyChoice[]) => void; disabled: boolean }) {
  const projects = useLiveQuery(async () => {
    const all = (await db.projects.orderBy("updatedAt").reverse().toArray()).filter((p) => p.id !== projectId);
    return Promise.all(all.map(async (p) => {
      const counts = await Promise.all([db.files.where("projectId").equals(p.id).count(), db.notes.where("projectId").equals(p.id).count(), db.sketches.where("projectId").equals(p.id).count()]);
      return { project: p, count: counts.reduce((a, b) => a + b, 0) };
    }));
  }, [projectId]);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  // Projects with nothing in them are left out: there is nothing there to reuse.
  const usable = (projects ?? []).filter((p) => p.count > 0);
  return <section className="mt-6 border-t border-line pt-4" aria-label="From previous projects">
    <h3 className="text-[13px] font-semibold">From previous projects</h3>
    <p className="mt-1 mb-3 text-[12px] leading-relaxed text-muted">Choose items to copy here. Transcripts, extracted text and PDF annotations come with them; the originals stay untouched.</p>
    {!projects ? <div className="flex items-center gap-2 py-3 text-[12px] text-muted"><Loader2 size={14} className="animate-spin" /> Loading your projects</div> : !usable.length ? <p className="rounded-2xl bg-ink/[0.03] px-3.5 py-4 text-[12px] text-muted">{projects.length ? "Your other projects have nothing in them to reuse yet." : "Your other projects will appear here once you create one."}</p> : <div className="divide-y divide-line overflow-hidden rounded-2xl bg-card ring-1 ring-line">
      {usable.map(({ project, count }) => {
        const isOpen = expanded.has(project.id);
        const n = selected.filter((s) => s.projectId === project.id).length;
        return <div key={project.id}>
          <button type="button" disabled={disabled} aria-expanded={isOpen} onClick={() => setExpanded((prev) => { const next = new Set(prev); if (next.has(project.id)) next.delete(project.id); else next.add(project.id); return next; })} className="flex w-full items-center gap-3 px-3.5 py-3 text-left transition-colors hover:bg-ink/[0.025] disabled:opacity-50">
            <ProjectAvatar project={project} size={34} />
            <span className="min-w-0 flex-1"><span className="block truncate text-[14px] font-medium">{project.name}</span><span className="block text-[11.5px] text-muted">{count} {count === 1 ? "item" : "items"}</span></span>
            {n > 0 && <span className="shrink-0 rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">{n} selected</span>}
            <ChevronDown size={16} className={cn("shrink-0 text-muted transition-transform", isOpen && "rotate-180")} />
          </button>
          {isOpen && <div className="fade-in"><ProjectItems projectId={project.id} selected={selected} onChange={onChange} disabled={disabled} /></div>}
        </div>;
      })}
    </div>}
  </section>;
}