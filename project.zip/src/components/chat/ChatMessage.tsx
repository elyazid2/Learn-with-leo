import { memo, useState, type ReactNode } from "react";
import {
  Brain,
  Check,
  CircleDot,
  Globe2,
  Compass,
  FileText,
  Film,
  Image as ImageIcon,
  Loader2,
  PenTool,
  RotateCcw,
  Settings2,
  TextSelect,
  AlertTriangle,
  Flag,
  Volume2,
  Square,
  X,
  Copy,
} from "lucide-react";
import { POINT_META, STATUS_META, type ContextTag, type Message, type PendingAction } from "@/lib/db";
import { parseSegments, type Action, type Segment } from "@/lib/ai/actions";
import { answerAction, disputeAnswer, resolvePending, retry } from "@/lib/chat";
import { navigate } from "@/lib/router";
import { Markdown } from "../Markdown";
import { cn } from "@/utils/cn";
import AgentAvatar from "@/components/AgentAvatar";
import { DEFAULT_AVATAR, type AgentState, type AvatarLook } from "@/lib/avatar";
import { accentText } from "@/lib/color";
import { speak, speechOutputSupported, stopSpeaking } from "@/lib/speech";
import { useApp } from "@/lib/store";
import { useLiveQuery } from "dexie-react-hooks";
import { db, type CitationRef, type LibFile } from "@/lib/db";
import { linkCitations } from "@/lib/citations";

const LETTERS = "ABCDEFGH";

export const CtxIcon = ({ kind, size = 11 }: { kind: string; size?: number }) => {
  if (kind === "note") return <FileText size={size} />;
  if (kind === "selection") return <TextSelect size={size} />;
  if (kind === "pdf") return <FileText size={size} />;
  if (kind === "image") return <ImageIcon size={size} />;
  if (kind === "sketch") return <PenTool size={size} />;
  if (kind === "audio") return <FileText size={size} />;
  if (kind === "video") return <Film size={size} />;
  if (kind === "browser") return <Compass size={size} />;
  return <CircleDot size={size} />;
};

function ContextTags({ tags }: { tags: ContextTag[] }) {
  return (
    <div className="mb-1 flex flex-wrap justify-end gap-1">
      {tags.map((t, i) => (
        <span key={i} className="flex max-w-[200px] items-center gap-1 rounded-full bg-black/[0.05] px-2 py-0.5 text-[11px] text-muted">
          <CtxIcon kind={t.kind} />
          <span className="truncate">{t.label}</span>
        </span>
      ))}
    </div>
  );
}

function ActionChip({ action }: { action: Action }) {
  let icon = <AgentAvatar size={12} frozenAt={0} />;
  let label = "";
  let color = "var(--muted)";
  switch (action.type) {
    case "map":
      color = STATUS_META[action.status ?? "new"]?.color ?? color;
      icon = <CircleDot size={11} />;
      label = `${action.concept}${action.status ? ` · ${STATUS_META[action.status]?.label ?? action.status}` : ""}`;
      break;
    case "point":
      color = POINT_META[action.kind].color;
      label = `${POINT_META[action.kind].short}: ${action.text}`;
      break;
    case "resolve_point":
      icon = <Check size={11} />;
      label = `Resolved: ${action.text}`;
      color = "#22b07d";
      break;
    case "set_level":
      icon = <Compass size={11} />;
      label = `Level set · ${action.level}`;
      color = "var(--ink)";
      break;
    case "assess":
      icon = action.correct ? <Check size={11} /> : <X size={11} />;
      label = `${action.concept}: ${action.correct ? "correct" : "needs work"}`;
      color = action.correct ? "#22b07d" : "#f0a52b";
      break;
    case "set_avatar":
      icon = <AgentAvatar size={14} frozenAt={0} look={{ shape: action.shape ?? "mark", color: action.color ?? "graphite", expression: action.expression ?? "calm" }} />;
      label = `Avatar · ${[action.shape, action.color, action.expression].filter(Boolean).join(" · ")}`;
      break;
    case "note":
      icon = <FileText size={11} />;
      label = !action.id
        ? `Saved note · ${action.title || "Leo's note"}`
        : `${action.mode === "replace" ? "Rewrote" : action.mode === "patch" ? "Edited" : "Added to"} note · ${action.title || "note"}`;
      break;
    case "sketch":
      icon = <PenTool size={11} />;
      label = `Drew sketch · ${action.title || "Leo's sketch"}`;
      break;
    case "memory":
      icon = <Brain size={11} />;
      label = action.op === "delete" ? "Asked to forget a memory" : action.op === "update" ? `Updated memory · ${action.text ?? ""}` : `Remembered · ${action.text ?? ""}`;
      break;
    case "browser": {
      icon = <Globe2 size={11} />;
      let host = action.url;
      try { host = new URL(action.url).hostname; } catch { /* keep raw */ }
      label = `Opened · ${host}`;
      break;
    }
    default:
      return null;
  }
  return (
    <span
      className="inline-flex max-w-full items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium"
      style={{ background: `color-mix(in srgb, ${color} 12%, transparent)`, color: accentText(color) }}
      title={label}
    >
      {icon}
      <span className="truncate">{label}</span>
    </span>
  );
}

function ChoiceCard({
  action,
  index,
  message,
  disabled,
}: {
  action: Extract<Action, { type: "quiz" | "ask" }>;
  index: number;
  message?: Message;
  disabled: boolean;
}) {
  const chosen = message?.answers?.[index];
  const answered = chosen !== undefined;
  const isQuiz = action.type === "quiz";
  const disputed = !!message?.disputed?.includes(index);
  // The option tapped just now, so its feedback (a pop, or a shake) plays once and not on every revisit.
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="my-2 overflow-hidden rounded-2xl bg-white ring-1 ring-line">
      <div className="flex items-center gap-1.5 px-4 pt-3 text-[11px] font-semibold text-muted">
        {isQuiz ? "Quiz" : "Question"}
        {isQuiz && action.concept && <span className="normal-case tracking-normal text-black/50">· {action.concept}</span>}
      </div>
      <div className="px-4 pb-2 pt-1 text-[15px] font-medium leading-snug">
        <Markdown>{action.question}</Markdown>
      </div>
      <div className="space-y-1.5 px-2.5 pb-2.5">
        {action.options.map((o, i) => {
          const isChosen = chosen === i;
          const isRight = isQuiz && i === action.answer;
          let state = "idle";
          if (answered) {
            if (isQuiz) state = isRight ? "right" : isChosen ? "wrong" : "dim";
            else state = isChosen ? "chosen" : "dim";
          }
          return (
            <button
              key={i}
              disabled={answered || disabled || !message}
              onClick={() => {
                if (!message) return;
                setPicked(i);
                void answerAction(message, index, action, i);
              }}
              className={cn(
                "flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-[14px] transition",
                state === "idle" && "bg-black/[0.035] hover:bg-black/[0.07] active:scale-[0.99]",
                state === "right" && "bg-ok-bg text-ok-fg ring-1 ring-ok-line",
                state === "wrong" && "bg-danger-bg text-danger-fg ring-1 ring-danger-line",
                state === "chosen" && "bg-ink text-white",
                state === "dim" && "opacity-45",
                picked === i && state === "wrong" && "shake",
                (disabled || !message) && !answered && "opacity-60"
              )}
            >
              <span
                className={cn(
                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold",
                  picked !== null && (state === "right" || state === "chosen") && "pop",
                  state === "chosen"
                    ? "bg-white/20"
                    : state === "right"
                      ? "bg-ok-bg text-ok-fg ring-1 ring-ok-line"
                      : state === "wrong"
                        ? "bg-danger-bg text-danger-fg ring-1 ring-danger-line"
                        : "bg-white ring-1 ring-line"
                )}
              >
                {state === "right" ? <Check size={13} strokeWidth={3} /> : state === "wrong" ? <X size={13} strokeWidth={3} /> : LETTERS[i]}
              </span>
              <span className="flex-1">{o}</span>
            </button>
          );
        })}
      </div>
      {answered && isQuiz && (action.explanation || message) && (
        <div className="flex items-start gap-3 border-t border-line bg-black/[0.02] px-4 py-2.5 text-[13px] text-muted">
          <div className="min-w-0 flex-1">{action.explanation && <Markdown>{action.explanation}</Markdown>}</div>
          {message && action.type === "quiz" && (
            <button
              onClick={() => disputeAnswer(message, index, action)}
              disabled={disabled || disputed}
              className="flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-[11px] font-medium text-muted hover:bg-ink/5 hover:text-ink disabled:opacity-50"
              title="Revert this grade and ask Leo to re-check the answer key"
            >
              <Flag size={11} /> {disputed ? "Disputed" : "Dispute"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

type CiteFiles = Pick<LibFile, "id" | "name" | "kind">[];

function renderSegments(segs: Segment[], message: Message | undefined, disabled: boolean, files: CiteFiles = [], labels: CitationRef[] = []) {
  const out: ReactNode[] = [];
  let chips: Action[] = [];
  const flushChips = (key: string) => {
    if (!chips.length) return;
    out.push(
      <div key={key} className="my-1.5 flex flex-wrap gap-1.5">
        {chips.map((a, i) => (
          <ActionChip key={i} action={a} />
        ))}
      </div>
    );
    chips = [];
  };
  segs.forEach((s, i) => {
    if (s.kind === "action" && s.action.type !== "quiz" && s.action.type !== "ask") {
      chips.push(s.action);
      return;
    }
    flushChips("c" + i);
    if (s.kind === "text") out.push(<Markdown key={i} className="text-[14.5px]">{linkCitations(s.text, files, labels)}</Markdown>);
    else if (s.kind === "invalid")
      out.push(
        <div key={i} className="my-1.5 inline-flex max-w-full items-start gap-1.5 rounded-2xl bg-warn-bg px-2.5 py-1 text-[11px] leading-snug text-warn-fg" title={s.raw}>
          <AlertTriangle size={11} className="mt-0.5 shrink-0" />
          <span className="min-w-0 break-words">Action skipped: {s.reason}</span>
        </div>
      );
    else if (s.kind === "pending")
      out.push(
        <div key={i} className="my-1.5 inline-flex items-center gap-1.5 rounded-full bg-black/[0.04] px-2.5 py-1 text-[11px] text-muted">
          <Loader2 size={11} className="animate-spin" /> {s.hint ?? "Working…"}
        </div>
      );
    else if (s.action.type === "quiz" || s.action.type === "ask")
      out.push(<ChoiceCard key={i} action={s.action} index={s.index} message={message} disabled={disabled} />);
  });
  flushChips("end");
  return out;
}

/** Changes Leo proposed that need the learner's OK (replacing their note, forgetting a memory). */
function PendingActions({ message, disabled }: { message: Message; disabled: boolean }) {
  const items = message.pending ?? [];
  if (!items.length) return null;
  const status: Record<PendingAction["status"], string> = { pending: "", applied: "Applied", dismissed: "Dismissed", failed: "Failed" };
  return (
    <div className="my-1.5 space-y-1.5">
      {items.map((p) => (
        <div key={p.id} className="flex flex-wrap items-center gap-2 rounded-2xl bg-warn-bg px-3 py-2 text-[12px] text-warn-fg ring-1 ring-black/5">
          <AlertTriangle size={12} className="shrink-0" />
          <span className="min-w-0 flex-1 break-words font-medium">{p.label}?</span>
          {p.status === "pending" ? (
            <span className="flex shrink-0 gap-1.5">
              <button
                onClick={() => void resolvePending(message.id, p.id, true)}
                disabled={disabled}
                className="flex items-center gap-1 rounded-full bg-ink px-2.5 py-1 text-[11px] font-semibold text-white hover:opacity-90 disabled:opacity-50"
              >
                <Check size={11} /> Apply
              </button>
              <button
                onClick={() => void resolvePending(message.id, p.id, false)}
                disabled={disabled}
                className="flex items-center gap-1 rounded-full bg-card px-2.5 py-1 text-[11px] font-medium text-ink ring-1 ring-line hover:bg-ink/5 disabled:opacity-50"
              >
                <X size={11} /> Dismiss
              </button>
            </span>
          ) : (
            <span className="shrink-0 text-[11px] opacity-80" title={p.result}>
              {status[p.status]}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

function SentDetails({ message }: { message: Message }) {
  const [open, setOpen] = useState(false);
  if (!message.apiContent || message.apiContent === message.content) return null;
  return (
    <div className="mt-1 max-w-[85%] text-right">
      <button onClick={() => setOpen((o) => !o)} className="text-[11px] text-muted underline-offset-2 hover:underline">
        {open ? "Hide what was sent" : "What was sent to the model"}
      </button>
      {open && (
        <pre className="mt-1 max-h-60 overflow-auto whitespace-pre-wrap rounded-xl bg-ink/[0.04] p-2 text-left text-[11px] leading-snug text-muted" dir="auto">
          {message.apiContent}
        </pre>
      )}
    </div>
  );
}

export const ChatMessage = memo(function ChatMessage({ message, disabled, look = DEFAULT_AVATAR }: { message: Message; disabled: boolean; look?: AvatarLook }) {
  const [speaking, setSpeaking] = useState(false);
  // Library file names, so citations in Leo's reply can open the exact page or timestamp.
  const files = useLiveQuery(
    async () =>
      message.role === "assistant" && !message.hidden
        ? (await db.files.where("projectId").equals(message.projectId).toArray()).map((f) => ({ id: f.id, name: f.name, kind: f.kind }))
        : [],
    [message.projectId, message.role, message.hidden]
  );
  if (message.hidden) return null;
  if (message.role === "user") {
    return (
      <div className="rise flex flex-col items-end">
        {message.context && <ContextTags tags={message.context} />}
        {message.images?.length ? (
          <div className="mb-1 flex gap-1">
            {message.images.map((src, i) => (
              <img key={i} src={src} alt="" className="h-16 w-16 rounded-xl object-cover ring-1 ring-line" />
            ))}
          </div>
        ) : null}
        <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-ink px-3.5 py-2 text-[14.5px] leading-relaxed text-white" dir="auto">
          {message.content}
        </div>
        <SentDetails message={message} />
      </div>
    );
  }
  if (message.error) {
    return (
      <div className="rise flex items-start gap-2">
        <AgentAvatar state="blocked" look={look} size={26} frozenAt={0} className="mt-1" />
        <div className="min-w-0 flex-1 rounded-2xl bg-danger-bg p-3 text-[13px] text-danger-fg ring-1 ring-danger-line">
          <Markdown>{message.content}</Markdown>
          <div className="mt-2 flex gap-2">
            <button onClick={() => retry(message)} disabled={disabled} className="flex items-center gap-1 rounded-full bg-card px-2.5 py-1 text-[12px] font-medium ring-1 ring-line hover:bg-ink/5">
              <RotateCcw size={12} /> Retry
            </button>
            <button onClick={() => navigate("settings")} className="flex items-center gap-1 rounded-full bg-card px-2.5 py-1 text-[12px] font-medium ring-1 ring-line hover:bg-ink/5">
              <Settings2 size={12} /> Settings
            </button>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="rise flex items-start gap-2">
      <AgentAvatar state={message.partial ? "blocked" : "done"} look={look} size={26} frozenAt={0} className="mt-1" />
      <div className="min-w-0 flex-1" dir="auto">
        {renderSegments(parseSegments(message.content), message, disabled || !!message.partial, files ?? [], message.citations)}
        <PendingActions message={message} disabled={disabled} />
        {message.partial && (
          <div className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-warn-bg px-2.5 py-1 text-[11px] text-warn-fg">
            <AlertTriangle size={11} /> Reply was cut off — its actions were not applied
          </div>
        )}
        {!message.partial && (
          <div className="mt-1 flex items-center gap-0.5">
            <CopyReply content={message.content} />
            {speechOutputSupported() && (
              <button
                onClick={() => {
                  if (speaking) {
                    stopSpeaking();
                    setSpeaking(false);
                    useApp.getState().setAgentActivity("idle", message.projectId);
                    return;
                  }
                  const started = speak(message.content, () => {
                    setSpeaking(false);
                    useApp.getState().setAgentActivity("idle", message.projectId);
                  });
                  if (started) {
                    setSpeaking(true);
                    useApp.getState().setAgentActivity("speaking", message.projectId);
                  }
                }}
                className="inline-flex h-7 items-center gap-1.5 rounded-full px-2 text-[11px] font-medium text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink"
                aria-label={speaking ? "Stop reading aloud" : "Read reply aloud"}
              >
                {speaking ? <Square size={11} fill="currentColor" /> : <Volume2 size={13} />}
                {speaking ? "Stop" : "Listen"}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
});

/** Copies Leo's prose (without the machine-readable action blocks) to the clipboard. */
function CopyReply({ content }: { content: string }) {
  const [copied, setCopied] = useState(false);
  const text = parseSegments(content)
    .map((seg) => (seg.kind === "text" ? seg.text : ""))
    .join("")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!text) return null;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      useApp.getState().showToast("Couldn't copy — your browser blocked clipboard access");
    }
  };
  return (
    <button
      onClick={() => void copy()}
      className="inline-flex h-7 items-center gap-1.5 rounded-full px-2 text-[11px] font-medium text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink"
      aria-label={copied ? "Copied" : "Copy reply"}
    >
      {copied ? <Check size={13} className="text-solid" /> : <Copy size={12} />}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

export function StreamingMessage({ content, state, look = DEFAULT_AVATAR }: { content: string; state: AgentState; look?: AvatarLook }) {
  return (
    <div className="flex items-start gap-2">
      <AgentAvatar state={state} look={look} size={28} />
      <div className="min-w-0 flex-1">
        {!content ? (
          <div className="flex gap-1 py-3">
            {[0, 1, 2].map((i) => (
              <span key={i} className="h-1.5 w-1.5 animate-bounce rounded-full bg-black/40" style={{ animationDelay: `${i * 120}ms` }} />
            ))}
          </div>
        ) : (
          renderSegments(parseSegments(content, true), undefined, true)
        )}
      </div>
    </div>
  );
}
