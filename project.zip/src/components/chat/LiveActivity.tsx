import { BookOpen, Brain, Check, FileText, Globe2, ListChecks, Loader2, PenTool, Search, Smile, Sparkles, TriangleAlert } from "lucide-react";
import { useLive, type LiveStep } from "@/lib/live";
import { cn } from "@/utils/cn";

const NONE: LiveStep[] = [];

function ToolIcon({ type }: { type: string }) {
  const size = 13;
  if (type === "sketch" || type === "edit_sketch") return <PenTool size={size} />;
  if (type === "note") return <FileText size={size} />;
  if (type === "read") return <BookOpen size={size} />;
  if (type === "search") return <Search size={size} />;
  if (type === "browser") return <Globe2 size={size} />;
  if (type === "memory") return <Sparkles size={size} />;
  if (type === "set_avatar") return <Smile size={size} />;
  if (type === "point" || type === "resolve_point") return <ListChecks size={size} />;
  return <Brain size={size} />;
}

/**
 * What Leo is doing right now, in words: one line per tool he uses this turn, with progress for
 * the long ones (drawing a sketch shape by shape, writing a note). It sits in the chat while he
 * works; the finished message keeps the result chips.
 */
export default function LiveActivity({ projectId }: { projectId: string }) {
  const steps = useLive((s) => (s.projectId === projectId ? s.steps : NONE));
  if (!steps.length) return null;
  const hidden = Math.max(0, steps.length - 6);
  return (
    <div className="ml-9 rounded-2xl bg-card p-2 ring-1 ring-line" role="status" aria-live="polite" data-live-activity>
      <div className="px-1.5 pb-1 pt-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted">Leo is working</div>
      <ul className="space-y-0.5">
        {hidden > 0 && <li className="px-1.5 py-0.5 text-[12px] text-muted">{hidden} earlier {hidden === 1 ? "step" : "steps"}</li>}
        {steps.slice(-6).map((s) => {
          const running = s.state === "running";
          return (
            <li key={s.id} data-state={s.state} className={cn("rise flex items-start gap-2 rounded-xl px-1.5 py-1 text-[13px] leading-snug", running && "bg-ink/[0.04]")}>
              <span className={cn("mt-[3px] shrink-0", running ? "text-ink" : s.state === "done" ? "text-ok-fg" : "text-danger-fg")}>
                {running ? <Loader2 size={13} className="animate-spin" /> : s.state === "done" ? <Check size={13} strokeWidth={2.6} /> : <TriangleAlert size={13} />}
              </span>
              <span className="min-w-0 flex-1">
                <span className={cn("block [overflow-wrap:anywhere]", running ? "font-medium" : "text-muted")} dir="auto">
                  {s.label}
                </span>
                {running && s.detail && <span className="block text-[12px] tabular-nums text-muted">{s.detail}</span>}
                {running && typeof s.progress === "number" && (
                  <span className="mt-1 block h-1 overflow-hidden rounded-full bg-ink/10" aria-hidden>
                    <span className="block h-full rounded-full bg-ink transition-[width] duration-150" style={{ width: `${Math.round(s.progress * 100)}%` }} />
                  </span>
                )}
              </span>
              <span className="mt-[3px] shrink-0 text-muted">
                <ToolIcon type={s.type} />
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
