import { readFile } from "node:fs/promises";
import path from "node:path";

/**
 * Serves Learn with Leo at "/".
 *
 * The app itself lives untouched in /leo (a Vite + React single-file build, local-first, data in the
 * browser's IndexedDB). `scripts/sync-leo.sh` builds it with its own toolchain and drops the one
 * self-contained index.html into /leo-dist; this route hands that file to the browser. The platform
 * shell (Next.js, /api/health, Postgres) stays as it was.
 */
export const dynamic = "force-dynamic";

const FILE = path.join(process.cwd(), "leo-dist", "index.html");

const headers = {
  "content-type": "text/html; charset=utf-8",
  "cache-control": "no-cache",
};

export async function GET() {
  try {
    return new Response(await readFile(FILE), { headers });
  } catch {
    return new Response(
      "<!doctype html><meta charset=utf-8><title>Learn with Leo</title><p style='font:16px system-ui;padding:2rem'>The Leo build is missing. Run <code>scripts/sync-leo.sh</code> to build /leo and copy it to /leo-dist.</p>",
      { status: 503, headers }
    );
  }
}
