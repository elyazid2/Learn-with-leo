import { describe, expect, it } from "vitest";
import { parseHash, projectPath, sameRoute } from "./router";

describe("router", () => {
  it("parses every screen", () => {
    expect(parseHash("")).toEqual({ name: "home" });
    expect(parseHash("#/")).toEqual({ name: "home" });
    expect(parseHash("#/folder/f1")).toEqual({ name: "home", folderId: "f1" });
    expect(parseHash("#/settings")).toEqual({ name: "settings" });
    expect(parseHash("#/memories")).toEqual({ name: "memories" });
    expect(parseHash("#/p/abc")).toEqual({ name: "project", projectId: "abc", tab: "library" });
    expect(parseHash("#/p/abc/library/f9")).toEqual({ name: "project", projectId: "abc", tab: "library", itemId: "f9" });
    expect(parseHash("#/p/abc/notes/n1")).toEqual({ name: "project", projectId: "abc", tab: "notes", itemId: "n1" });
    expect(parseHash("#/p/abc/sketch/s1")).toEqual({ name: "project", projectId: "abc", tab: "sketch", itemId: "s1" });
    expect(parseHash("#/p/abc/progress")).toEqual({ name: "project", projectId: "abc", tab: "progress" });
  });

  it("builds paths that parse back to the same place", () => {
    expect(parseHash("#/" + projectPath("abc", "notes", "n1"))).toEqual({ name: "project", projectId: "abc", tab: "notes", itemId: "n1" });
    expect(parseHash("#/" + projectPath("abc"))).toEqual({ name: "project", projectId: "abc", tab: "library" });
  });

  it("knows when a hash change leads to the same place (so nothing re-renders or fades)", () => {
    expect(sameRoute(parseHash("#/p/abc"), parseHash("#/p/abc/library"))).toBe(true);
    expect(sameRoute(parseHash("#/"), parseHash("#/unknown"))).toBe(true);
    expect(sameRoute(parseHash("#/p/abc"), parseHash("#/p/abc/library/f1"))).toBe(false);
    expect(sameRoute(parseHash("#/folder/a"), parseHash("#/folder/b"))).toBe(false);
  });
});
