import { useCallback, useEffect, useState } from "react";
import { useSettings } from "./settings";

/**
 * Motion helpers. The CSS side lives in index.css ("Motion" section): entrance classes play when
 * an element mounts; exit classes need the element kept in the page a moment longer, which is
 * what `usePresence` is for.
 */

/** True when motion should be skipped: the app's own setting, or the system preference. */
export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return true;
  if (useSettings.getState().reduceMotion) return true;
  return !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}

/**
 * Keep something mounted while it animates out.
 *
 *   const { mounted, closing, end } = usePresence(open);
 *   if (!mounted) return null;
 *   return <div className={closing ? "fade-out" : "fade-in"} onAnimationEnd={closing ? end : undefined} />;
 *
 * `closing` turns true in the same render that `open` turns false, so the exit class is never a
 * frame late. Reopening during the exit simply cancels it. Call `end` when the exit animation
 * finishes; `exitMs` is only the safety net for when that never arrives.
 */
export function usePresence(open: boolean, exitMs = 400) {
  const [present, setPresent] = useState(open);
  useEffect(() => {
    if (open) {
      setPresent(true);
      return;
    }
    if (!present) return;
    const timer = window.setTimeout(() => setPresent(false), prefersReducedMotion() ? 0 : exitMs);
    return () => window.clearTimeout(timer);
  }, [open, present, exitMs]);
  const end = useCallback(() => setPresent(false), []);
  return { mounted: open || present, closing: !open && present, end };
}
