import { useSyncExternalStore } from "react";
import { flushSync } from "react-dom";
import { prefersReducedMotion } from "./motion";

/**
 * The project home is the Library — it holds every kind of item. "notes"/"sketch" open an
 * item editor, "library/:id" opens a file, and "progress" opens the progress sheet over the library.
 */
export type Tab = "library" | "notes" | "sketch" | "progress";

export type Route =
  | { name: "home"; folderId?: string }
  | { name: "settings" }
  | { name: "memories" }
  | { name: "dev-avatars" }
  | { name: "project"; projectId: string; tab: Tab; itemId?: string };

export function parseHash(hash: string): Route {
  const parts = hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  if (parts[0] === "folder" && parts[1]) return { name: "home", folderId: parts[1] };
  if (parts[0] === "settings") return { name: "settings" };
  if (parts[0] === "memories") return { name: "memories" };
  if (parts[0] === "dev" && parts[1] === "avatars") return { name: "dev-avatars" };
  if (parts[0] === "p" && parts[1]) {
    const projectId = parts[1];
    const seg = parts[2];
    // "overview" was the old Map tab; its content now lives in the Progress sheet.
    if (seg === "progress" || seg === "overview") return { name: "project", projectId, tab: "progress" };
    if (seg === "notes") return { name: "project", projectId, tab: "notes", itemId: parts[3] || undefined };
    if (seg === "sketch" && parts[3]) return { name: "project", projectId, tab: seg, itemId: parts[3] };
    if (seg === "library" && parts[3]) return { name: "project", projectId, tab: "library", itemId: parts[3] };
    return { name: "project", projectId, tab: "library" };
  }
  return { name: "home" };
}

export function navigate(path: string, replace = false) {
  const target = "#/" + path.replace(/^\/+/, "");
  if (replace) {
    history.replaceState(null, "", target);
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = target;
  }
}

/* ------------------------------------------------------------------ store */

/**
 * One route for the whole app. Every `useRoute()` reads the same value and changes in the same
 * render, which is also what lets a screen change be wrapped in a single cross-fade.
 */
const HAS_WINDOW = typeof window !== "undefined";
let current: Route = parseHash(HAS_WINDOW ? window.location.hash : "");
const listeners = new Set<() => void>();
let listening = false;
let fading = false;

/** Two routes are the same place when they parse to the same fields. */
export const sameRoute = (a: Route, b: Route) => JSON.stringify(a) === JSON.stringify(b);

function apply(next: Route) {
  current = next;
  for (const listener of [...listeners]) listener();
}

type ViewTransition = { finished: Promise<unknown>; ready: Promise<unknown>; updateCallbackDone: Promise<unknown> };
type TransitionDocument = Document & { startViewTransition?: (update: () => void) => ViewTransition };

function onHashChange() {
  const next = parseHash(window.location.hash);
  if (sameRoute(next, current)) return;
  const doc = document as TransitionDocument;
  // Screens cross-fade where the browser can do it (View Transitions). Everywhere else, and with
  // reduced motion, in a hidden tab or while a fade is already running, the change is immediate.
  if (!doc.startViewTransition || fading || document.visibilityState !== "visible" || prefersReducedMotion()) return apply(next);
  fading = true;
  const done = () => {
    fading = false;
  };
  try {
    const transition = doc.startViewTransition(() => flushSync(() => apply(next)));
    transition.finished.then(done, done);
    // A skipped fade (a second navigation, a resize) rejects these; the route has changed either way.
    transition.ready.catch(() => {});
    transition.updateCallbackDone.catch(() => {});
  } catch {
    done();
    apply(next);
  }
}

function subscribe(listener: () => void) {
  if (!listening && HAS_WINDOW) {
    listening = true;
    window.addEventListener("hashchange", onHashChange);
  }
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

const read = () => current;

export function useRoute(): Route {
  return useSyncExternalStore(subscribe, read, read);
}

export const projectPath = (projectId: string, tab: Tab = "library", itemId?: string) =>
  `p/${projectId}/${tab}${itemId ? "/" + itemId : ""}`;
