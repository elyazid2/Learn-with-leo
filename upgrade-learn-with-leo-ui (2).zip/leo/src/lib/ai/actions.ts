import {
  db,
  uid,
  type ActionResult,
  type Concept,
  type ConceptStatus,
  type MemoryKind,
  type Message,
  type Note,
  type PendingAction,
  type PointKind,
  type SourceRef,
} from "../db";
import { versionsWithCurrent } from "../noteVersions";
import { useApp } from "../store";
// On-demand guides for Leo, bundled as raw strings so they work client-side. The markdown file is
// the Excalidraw MCP's read_me text, kept verbatim.
import excalidrawGuide from "./guides/excalidraw-readme.md?raw";

const GUIDES: Record<string, string> = { excalidraw: excalidrawGuide };
import {
  isAvatarColor,
  isAvatarExpression,
  isAvatarShape,
  normalizeAvatarLook,
  type AvatarLook,
} from "../avatar";

/** One shape Leo may ask for. In a `sketch` action `from`/`to` are element indices; in an
 * `edit_sketch` "add" op they may also name an existing element ref such as "s3". */
export interface SketchElementSpec {
  type: "rectangle" | "ellipse" | "diamond" | "arrow" | "text";
  x: number;
  y: number;
  width?: number;
  height?: number;
  text?: string;
  color?: string;
  from?: number | string;
  to?: number | string;
}

/** A single change to an existing sketch. */
export interface SketchOp {
  op: "add" | "update" | "delete";
  /** Element ref from the sketch listing, e.g. "s3". */
  ref?: string;
  /** Complete for "add"; for "update" only the fields to change are present (type, x and y may be missing). */
  element?: SketchElementSpec;
}

export type Action =
  | { type: "ask"; question: string; options: string[] }
  | {
      type: "quiz";
      question: string;
      options: string[];
      answer: number;
      explanation?: string;
      concept?: string;
      /** Where the question comes from, e.g. "book.pdf, p.12" — stored on the review card. */
      source?: string;
    }
  | { type: "set_level"; level: string; summary?: string; startingPoint?: string }
  | { type: "map"; concept: string; status?: ConceptStatus; parent?: string; note?: string }
  | { type: "point"; kind: PointKind; text: string }
  | { type: "resolve_point"; text: string }
  | { type: "set_avatar"; shape?: AvatarLook["shape"]; color?: AvatarLook["color"]; expression?: AvatarLook["expression"] }
  /** Grade an open-ended (typed) answer so it counts toward the map and review schedule. */
  | { type: "assess"; concept: string; correct: boolean; note?: string }
  /** Without an id: create. With an id: "append" (default), "patch" (exact find/replace edits) or "replace". */
  | {
      type: "note";
      id?: string;
      title: string;
      content: string;
      mode?: NoteMode;
      patches?: NotePatch[];
      /** New notes only: folder path such as "Biology/Cells". */
      folder?: string;
      /** Passages the note is grounded in. */
      sources?: SourceRef[];
    }
  | { type: "read"; kind: "note" | "sketch" | "guide"; id: string }
  /** Read a library file: PDF pages, an audio/video time range, or a text range (paginated). */
  | { type: "read"; kind: "file"; id: string; pages?: string; from?: string; to?: string }
  /** Search the library (files, notes or both); returns the top passages. */
  | { type: "search"; query: string; scope?: "all" | "files" | "notes" }
  | { type: "edit_sketch"; id: string; ops: SketchOp[] }
  | { type: "sketch"; title: string; elements: SketchElementSpec[] }
  | { type: "browser"; url: string }
  | { type: "memory"; op: "save" | "update" | "delete"; id?: string; scope?: "global" | "project"; kind?: MemoryKind; text?: string };

export type NoteMode = "append" | "replace" | "patch";

/** One exact edit: `find` must occur exactly once in the note; it is replaced by `replace`. */
export interface NotePatch {
  find: string;
  replace: string;
}

export type Segment =
  | { kind: "text"; text: string }
  | { kind: "action"; action: Action; index: number }
  /** A block the model emitted that we could not parse/validate. Shown to the learner and fed back to the model. */
  | { kind: "invalid"; raw: string; reason: string }
  | { kind: "pending"; hint?: string };

const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.length <= 8 && v.every((o) => typeof o === "string");

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

/** Opening fence of an action block: ```action plus anything up to the end of that line. */
const OPEN_RE = /```action[^\n]*\n/g;
/** A closing fence: a line that is exactly three backticks (surrounding spaces / a CR tolerated). */
const FENCE_LINE_RE = /^[ \t]*```[ \t]*\r?$/gm;
/** How many closing-fence lines we try before giving up and reporting the first one's parse error. */
const MAX_FENCE_TRIES = 6;

interface RawBlock {
  start: number;
  end: number;
  body: string;
}

/** True when a block body is syntactically JSON (one value, an array, or one object per line). */
function bodyParses(body: string): boolean {
  return !parseBody(body).invalid.some((i) => i.reason.startsWith("not valid JSON"));
}

/**
 * Find the action blocks in a reply. A block closes at a line that is exactly ``` — NOT at the first
 * ``` anywhere, because note markdown inside a JSON string may contain code fences. If the body up to
 * that line is not valid JSON, the block is extended to the next fence line (up to MAX_FENCE_TRIES).
 * Sloppy closers glued to the JSON (`}```) are still accepted when nothing else parses.
 * `openAt` is the start of a block that has no closer yet (still streaming, or cut off), else -1.
 */
function scanBlocks(content: string, streaming: boolean): { blocks: RawBlock[]; openAt: number } {
  const blocks: RawBlock[] = [];
  let pos = 0;
  for (;;) {
    OPEN_RE.lastIndex = pos;
    const open = OPEN_RE.exec(content);
    if (!open) {
      // An opener with no newline yet ("```action" at the very end) is still an open block.
      const bareOpen = content.indexOf("```action", pos);
      return { blocks, openAt: bareOpen };
    }
    const bodyStart = open.index + open[0].length;
    const closers: { at: number; end: number }[] = [];
    FENCE_LINE_RE.lastIndex = bodyStart;
    let f: RegExpExecArray | null;
    while (closers.length < MAX_FENCE_TRIES && (f = FENCE_LINE_RE.exec(content))) closers.push({ at: f.index, end: f.index + f[0].length });
    const legacyAt = content.indexOf("```", bodyStart);
    const legacy = legacyAt >= 0 ? { at: legacyAt, end: legacyAt + 3 } : undefined;

    let pick = closers.find((c) => bodyParses(content.slice(bodyStart, c.at)));
    if (!pick && legacy && bodyParses(content.slice(bodyStart, legacy.at))) pick = legacy;
    if (!pick) {
      // Nothing parses. With no fence line yet, a streaming block is simply still open.
      if (!closers.length && (streaming || !legacy)) return { blocks, openAt: open.index };
      pick = closers[0] ?? legacy!;
    }
    blocks.push({ start: open.index, end: pick.end, body: content.slice(bodyStart, pick.at) });
    pos = pick.end;
  }
}

/** Short, single-line version of a JSON.parse error ("Unexpected token } in JSON at position 42"). */
const jsonError = (e: unknown) => (e instanceof Error ? e.message : String(e)).replace(/\s+/g, " ").slice(0, 120);

function parseBody(body: string): { actions: Action[]; invalid: { raw: string; reason: string }[] } {
  const clean = body.trim();
  const out: unknown[] = [];
  const invalid: { raw: string; reason: string }[] = [];
  try {
    const j = JSON.parse(clean);
    if (Array.isArray(j)) out.push(...j);
    else out.push(j);
  } catch (e) {
    // One object per line (NDJSON) is parsed line by line; a single broken object is reported once, with the parser's reason.
    const lines = clean
      .split("\n")
      .map((l) => l.trim().replace(/,$/, ""))
      .filter(Boolean);
    const oneObjectPerLine = lines.length > 1 && lines.every((l) => l.startsWith("{") && l.endsWith("}"));
    // Valid JSON followed by trailing junk (a stray "}", a closing note, a second fence…):
    // keep the valid prefix and ignore the rest. NDJSON is handled below instead, because it
    // trips the same error at the start of its second object and must not be truncated.
    const trailing = /Unexpected non-whitespace character after JSON at position (\d+)/.exec(e instanceof Error ? e.message : String(e));
    let recovered = false;
    if (trailing && !oneObjectPerLine) {
      const n = Number(trailing[1]);
      try {
        const j = JSON.parse(clean.slice(0, n));
        if (Array.isArray(j)) out.push(...j);
        else out.push(j);
        recovered = true;
      } catch {
        /* fall through and report the original error */
      }
    }
    if (recovered) {
      /* parsed the valid prefix */
    } else if (oneObjectPerLine) {
      for (const l of lines) {
        try {
          out.push(JSON.parse(l));
        } catch (le) {
          invalid.push({ raw: l.slice(0, 200), reason: `not valid JSON (${jsonError(le)})` });
        }
      }
    } else {
      invalid.push({ raw: clean.slice(0, 200), reason: `not valid JSON (${jsonError(e)})` });
    }
  }
  const actions: Action[] = [];
  for (const o of out) {
    const r = coerceAction(o);
    if ("action" in r) actions.push(r.action);
    else invalid.push({ raw: JSON.stringify(o)?.slice(0, 200) ?? String(o), reason: r.reason });
  }
  return { actions, invalid };
}

/* ------------------------------------------------- sketch element tolerance */

const ELEMENT_TYPES = ["rectangle", "ellipse", "diamond", "arrow", "text"] as const;
const ELEMENT_TYPE_LIST = "rectangle, ellipse, diamond, arrow or text";
/** Excalidraw-guide "pseudo-elements": they steer the viewport or delete by id and are never drawn. */
const PSEUDO_ELEMENT_TYPES = new Set(["cameraUpdate", "delete", "restoreCheckpoint"]);
const HEX_COLOR = /^#[0-9a-f]{6}$/i;

const isShapeType = (t: unknown) => t === "rectangle" || t === "ellipse" || t === "diamond";
const isPseudoElement = (v: unknown) => isRecord(v) && PSEUDO_ELEMENT_TYPES.has(v.type as string);
const isHex = (v: unknown): v is string => typeof v === "string" && HEX_COLOR.test(v);

/**
 * Reduce one element — in this app's format or copied from the Excalidraw guide — to the fields this
 * app understands. Guide-style extras (id, points, roundness, fontSize, bindings, arrowheads, …) are
 * dropped, `label.text` becomes `text`, and a missing `color` is taken from backgroundColor or
 * strokeColor when that is a #rrggbb value. `resolveRef` turns an element id or original index into
 * the spec's from/to value. Values that are wrong (not numbers, bad type…) are kept so validation can
 * name them.
 */
function normalizeSketchElement(raw: unknown, resolveRef: (v: unknown) => unknown): unknown {
  if (!isRecord(raw)) return raw;
  const e = raw;
  const out: Record<string, unknown> = {};
  if (e.type !== undefined) out.type = e.type;
  for (const k of ["x", "y", "width", "height"] as const) if (e[k] !== undefined && e[k] !== null) out[k] = e[k];

  const label = isRecord(e.label) ? e.label : undefined;
  if (typeof e.text === "string") out.text = e.text;
  else if (label && typeof label.text === "string") out.text = label.text;
  else if (e.text !== undefined && e.text !== null) out.text = e.text;

  if (e.color !== undefined && e.color !== null) out.color = e.color;
  else if (isHex(e.backgroundColor)) out.color = e.backgroundColor;
  // A shape that explicitly asked for a transparent fill keeps the default fill; anything else may use its stroke colour.
  else if (isHex(e.strokeColor) && !(isShapeType(e.type) && e.backgroundColor === "transparent")) out.color = e.strokeColor;

  const from = e.from !== undefined && e.from !== null ? e.from : isRecord(e.startBinding) ? e.startBinding.elementId : undefined;
  const to = e.to !== undefined && e.to !== null ? e.to : isRecord(e.endBinding) ? e.endBinding.elementId : undefined;
  const f = resolveRef(from);
  if (f !== undefined) out.from = f;
  const t = resolveRef(to);
  if (t !== undefined) out.to = t;
  return out;
}

/**
 * Elements of a `sketch` action: drop pseudo-elements, normalize the rest, and keep arrows attached —
 * numeric from/to are re-based after the drop and guide-style ids/bindings resolve to indices.
 */
function prepareSketchElements(raw: unknown[]): unknown[] {
  const kept: number[] = [];
  const newIndex = new Map<number, number>();
  raw.forEach((e, i) => {
    if (isPseudoElement(e)) return;
    newIndex.set(i, kept.length);
    kept.push(i);
  });
  const idIndex = new Map<string, number>();
  for (const [orig, ni] of newIndex) {
    const el = raw[orig];
    if (isRecord(el) && typeof el.id === "string" && !idIndex.has(el.id)) idIndex.set(el.id, ni);
  }
  const resolveRef = (v: unknown): unknown => {
    if (typeof v === "number") return Number.isInteger(v) && v >= 0 && v < raw.length ? newIndex.get(v) : v;
    if (typeof v === "string") return idIndex.has(v) ? idIndex.get(v) : v;
    return v === null ? undefined : v;
  };
  return kept.map((i) => normalizeSketchElement(raw[i], resolveRef));
}

/** Ops of an `edit_sketch` action: pseudo-elements are not edits; everything else is normalized. */
function prepareSketchOps(raw: unknown[]): unknown[] {
  const ops: unknown[] = [];
  for (const op of raw) {
    if (!isRecord(op)) {
      ops.push(op);
      continue;
    }
    if (isPseudoElement(op) || isPseudoElement(op.element)) continue;
    const out: Record<string, unknown> = {};
    if (op.op !== undefined) out.op = op.op;
    if (op.ref !== undefined) out.ref = op.ref;
    if (op.element !== undefined && op.element !== null) out.element = normalizeSketchElement(op.element, (v) => (v === null ? undefined : v));
    ops.push(out);
  }
  return ops;
}

/** Make a parsed object as acceptable as it can honestly be before validation. */
function prepareAction(o: unknown): unknown {
  if (!isRecord(o)) return o;
  if (o.type === "sketch" && Array.isArray(o.elements)) return { ...o, elements: prepareSketchElements(o.elements) };
  if (o.type === "edit_sketch" && Array.isArray(o.ops)) return { ...o, ops: prepareSketchOps(o.ops) };
  return o;
}

const show = (v: unknown) => {
  const s = JSON.stringify(v) ?? String(v);
  return s.length > 40 ? `${s.slice(0, 40)}…` : s;
};

/** "element 3 (rectangle “Start”)" — enough for the learner and the model to find the culprit. */
function describeElement(v: Record<string, unknown>, i: number) {
  const text = typeof v.text === "string" ? v.text.trim() : "";
  const label = text ? ` \u201c${text.length > 24 ? `${text.slice(0, 24)}\u2026` : text}\u201d` : "";
  return `element ${i + 1}${typeof v.type === "string" ? ` (${v.type}${label})` : ""}`;
}

/**
 * Why one shape spec is unusable, or null when it is fine. `count` bounds numeric from/to indices
 * when they refer to a sibling; `partial` allows x/y to be omitted (an update that changes some fields).
 */
function sketchElementProblem(raw: unknown, i: number, count?: number, partial = false): string | null {
  if (!isRecord(raw)) return `element ${i + 1} is ${show(raw)}, not an object`;
  const v = raw;
  const who = describeElement(v, i);
  // An update sends only the fields to change, so its type is optional; everywhere else it is required.
  if (!(partial && v.type === undefined) && !ELEMENT_TYPES.includes(v.type as (typeof ELEMENT_TYPES)[number]))
    return `${who}: unknown type ${show(v.type ?? null)} — use ${ELEMENT_TYPE_LIST}`;
  const num = (x: unknown, min: number, max: number) => typeof x === "number" && Number.isFinite(x) && x >= min && x <= max;
  for (const k of ["x", "y"] as const) {
    if (v[k] === undefined) {
      if (!partial) return `${who}: ${k} is required`;
    } else if (!num(v[k], -2000, 2000)) return `${who}: ${k} must be a number between -2000 and 2000 (got ${show(v[k])})`;
  }
  // Arrows may point left/up (negative width/height, as in the guide); shapes cannot. A typeless update is given the benefit of the doubt.
  const arrow = v.type === "arrow" || (partial && v.type === undefined);
  if (v.width !== undefined && !num(v.width, arrow ? -1200 : 0, 1200)) return `${who}: width must be a number between ${arrow ? -1200 : 0} and 1200 (got ${show(v.width)})`;
  if (v.height !== undefined && !num(v.height, arrow ? -900 : 0, 900)) return `${who}: height must be a number between ${arrow ? -900 : 0} and 900 (got ${show(v.height)})`;
  if (v.text !== undefined && typeof v.text !== "string") return `${who}: text must be a string (got ${show(v.text)})`;
  if (typeof v.text === "string" && v.text.length > 300) return `${who}: text is ${v.text.length} characters; the limit is 300`;
  if (v.color !== undefined && !isHex(v.color)) return `${who}: color must be a #rrggbb hex value (got ${show(v.color)})`;
  for (const k of ["from", "to"] as const) {
    const x = v[k];
    if (x === undefined) continue;
    if (typeof x === "number") {
      if (!Number.isInteger(x) || x < 0 || (count !== undefined && x >= count))
        return `${who}: "${k}" must be the index of another element${count !== undefined ? ` (0–${count - 1})` : ""} (got ${show(x)})`;
    } else if (typeof x !== "string") return `${who}: "${k}" must be an element index or ref (got ${show(x)})`;
  }
  return null;
}

/** Why an op of an `edit_sketch` action is unusable, or null. */
function sketchOpProblem(raw: unknown, i: number): string | null {
  if (!isRecord(raw)) return `op ${i + 1} is ${show(raw)}, not an object`;
  const v = raw;
  const who = `op ${i + 1}${typeof v.op === "string" ? ` (${v.op}${typeof v.ref === "string" ? ` ${v.ref}` : ""})` : ""}`;
  if (v.ref !== undefined && !(typeof v.ref === "string" && /^s\d{1,4}$/.test(v.ref))) return `${who}: ref must be an element ref from the listing such as "s3" (got ${show(v.ref)})`;
  if (v.op === "add") {
    if (!isRecord(v.element)) return `${who}: add needs an "element" to draw`;
    const p = sketchElementProblem(v.element, 0, undefined, false);
    return p ? `${who}: ${p.replace(/^element 1/, "element")}` : null;
  }
  if (v.op === "update") {
    if (typeof v.ref !== "string") return `${who}: update needs the "ref" of the element to change`;
    if (v.element === undefined) return null;
    const p = sketchElementProblem(v.element, 0, undefined, true);
    return p ? `${who}: ${p.replace(/^element 1/, "element")}` : null;
  }
  if (v.op === "delete") return typeof v.ref === "string" ? null : `${who}: delete needs the "ref" of the element to remove`;
  return `${who}: unknown op ${show(v.op ?? null)} — use add, update or delete`;
}

/** Why a parsed object is not an action we can run, or null when it is one. */
function actionProblem(a: unknown): string | null {
  if (!isRecord(a)) return `${show(a)} is not a JSON object`;
  const o = a;
  switch (o.type) {
    case "ask":
      return typeof o.question === "string" && isStringArray(o.options) ? null : "ask needs a string question and 1–8 string options";
    case "quiz":
      if (typeof o.question !== "string") return "quiz needs a string question";
      if (!isStringArray(o.options)) return "quiz needs 1–8 string options";
      if (typeof o.answer !== "number" || !Number.isInteger(o.answer) || o.answer < 0 || o.answer >= o.options.length)
        return `quiz "answer" must be the 0-based index of the correct option (0–${o.options.length - 1}; got ${show(o.answer)})`;
      return null;
    case "assess":
      return typeof o.concept === "string" && typeof o.correct === "boolean" ? null : "assess needs a string concept and a boolean correct";
    case "set_level":
      return typeof o.level === "string" ? null : "set_level needs a string level";
    case "map":
      return typeof o.concept === "string" ? null : "map needs a string concept";
    case "point":
      if (typeof o.text !== "string") return "point needs a string text";
      return ["careful", "confused", "next"].includes(o.kind as string) ? null : `point kind must be careful, confused or next (got ${show(o.kind)})`;
    case "resolve_point":
      return typeof o.text === "string" ? null : "resolve_point needs the point's exact text";
    case "set_avatar":
      if (o.shape !== undefined && !isAvatarShape(o.shape)) return `set_avatar: unknown shape ${show(o.shape)}`;
      if (o.color !== undefined && !isAvatarColor(o.color)) return `set_avatar: unknown color ${show(o.color)}`;
      if (o.expression !== undefined && !isAvatarExpression(o.expression)) return `set_avatar: unknown expression ${show(o.expression)}`;
      return o.shape !== undefined || o.color !== undefined || o.expression !== undefined ? null : "set_avatar needs a shape, color or expression";
    case "note":
      if (typeof (o.title ?? "") !== "string") return "note title must be a string";
      if (o.id !== undefined && typeof o.id !== "string") return "note id must be a string";
      if (o.mode !== undefined && !["append", "replace", "patch"].includes(o.mode as string)) return `note mode must be append, patch or replace (got ${show(o.mode)})`;
      if (o.mode === "patch") {
        if (typeof o.id !== "string" || !o.id) return "note patch needs the id of the note to edit";
        if (!Array.isArray(o.patches) || !o.patches.length) return 'note patch needs a non-empty "patches" array of {"find","replace"}';
        if (o.patches.length > 20) return `note patch has ${o.patches.length} patches; the limit is 20`;
        for (let i = 0; i < o.patches.length; i++) {
          const p = o.patches[i];
          if (!isRecord(p) || typeof p.find !== "string" || !p.find || typeof p.replace !== "string")
            return `note patch ${i + 1} must be {"find": non-empty string, "replace": string}`;
        }
        if (o.content !== undefined && typeof o.content !== "string") return "note content must be a string";
        return null;
      }
      if (o.folder !== undefined && typeof o.folder !== "string") return "note folder must be a string path";
      if (o.sources !== undefined && !(Array.isArray(o.sources) && o.sources.every((x) => isRecord(x) && typeof x.fileId === "string")))
        return 'note sources must be [{"fileId":string,"page"?:number,"t0"?:number}]';
      if (typeof o.content !== "string") return "note needs string content";
      if (o.mode !== undefined && (typeof o.id !== "string" || !o.id)) return `note mode "${o.mode}" needs the id of an existing note`;
      return null;
    case "read":
      if (o.kind !== "note" && o.kind !== "sketch" && o.kind !== "guide" && o.kind !== "file") return `read kind must be note, sketch, guide or file (got ${show(o.kind)})`;
      for (const k of ["pages", "from", "to"] as const) {
        if (o[k] !== undefined && typeof o[k] !== "string" && typeof o[k] !== "number") return `read "${k}" must be a string like "12-14" or "3:10"`;
        if (typeof o[k] === "number") o[k] = String(o[k]);
      }
      return typeof o.id === "string" && !!o.id && o.id.length <= 64 ? null : "read needs the item's id";
    case "search":
      if (typeof o.query !== "string" || !o.query.trim()) return "search needs a non-empty string query";
      if (o.scope !== undefined && !["all", "files", "notes"].includes(o.scope as string)) return `search scope must be all, files or notes (got ${show(o.scope)})`;
      return null;
    case "edit_sketch": {
      if (typeof o.id !== "string" || !o.id) return "edit_sketch needs the sketch id";
      if (!Array.isArray(o.ops)) return "edit_sketch needs an ops array";
      if (!o.ops.length) return "edit_sketch has no ops to apply (cameraUpdate, delete and restoreCheckpoint entries are not edits)";
      if (o.ops.length > 40) return `edit_sketch has ${o.ops.length} ops; the limit is 40`;
      for (let i = 0; i < o.ops.length; i++) {
        const p = sketchOpProblem(o.ops[i], i);
        if (p) return `edit_sketch ${p}`;
      }
      return null;
    }
    case "sketch": {
      if (typeof o.title !== "string") return "sketch needs a string title";
      if (!Array.isArray(o.elements)) return "sketch needs an elements array";
      if (!o.elements.length) return "sketch has no drawable elements (cameraUpdate, delete and restoreCheckpoint entries are not drawn)";
      if (o.elements.length > 40) return `sketch has ${o.elements.length} elements; the limit is 40`;
      for (let i = 0; i < o.elements.length; i++) {
        const p = sketchElementProblem(o.elements[i], i, o.elements.length);
        if (p) return `sketch ${p}`;
      }
      return null;
    }
    case "browser":
      return typeof o.url === "string" && o.url.length <= 2048 ? null : "browser needs a string url";
    case "memory":
      if (!["save", "update", "delete"].includes(o.op as string)) return `memory op must be save, update or delete (got ${show(o.op)})`;
      if (o.scope !== undefined && !["global", "project"].includes(o.scope as string)) return `memory scope must be global or project (got ${show(o.scope)})`;
      if (o.kind !== undefined && !["level", "goal", "preference", "strength", "weakness", "fact"].includes(o.kind as string)) return `memory kind ${show(o.kind)} is not one of level, goal, preference, strength, weakness, fact`;
      if (o.text !== undefined && !(typeof o.text === "string" && o.text.length <= 500)) return "memory text must be a string of at most 500 characters";
      if (o.id !== undefined && typeof o.id !== "string") return "memory id must be a string";
      return null;
    default:
      return o.type === undefined ? "action has no \"type\"" : `unknown action type ${show(o.type)}`;
  }
}

/** Normalize a parsed object (sketch tolerance), then validate it: the action to run, or the reason it was skipped. */
function coerceAction(o: unknown): { action: Action } | { reason: string } {
  const prepared = prepareAction(o);
  const problem = actionProblem(prepared);
  return problem === null ? { action: prepared as Action } : { reason: problem };
}

/** What Leo is doing, read from the part of an action block that has streamed so far. */
export function actionHint(partial: string): string {
  const type = /"type"\s*:\s*"([a-z_]+)"/.exec(partial)?.[1];
  if (!type) return "Working\u2026";
  const field = (name: string) => {
    const m = new RegExp(`"${name}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(partial);
    return m?.[1];
  };
  switch (type) {
    case "sketch": {
      const title = field("title")?.trim();
      return title ? `Drawing \u201c${title}\u201d\u2026` : "Drawing a sketch\u2026";
    }
    case "edit_sketch":
      return "Editing the sketch\u2026";
    case "note":
      if (/"mode"\s*:\s*"patch"/.test(partial)) return "Editing a note\u2026";
      if (/"mode"\s*:\s*"replace"/.test(partial)) return "Rewriting a note\u2026";
      return /"id"\s*:/.test(partial) ? "Adding to a note\u2026" : "Writing a note\u2026";
    case "read": {
      const kind = field("kind");
      if (kind === "guide") return "Reading the Excalidraw guide\u2026";
      if (kind === "sketch") return "Reading a sketch\u2026";
      if (kind === "note") return "Reading a note\u2026";
      if (kind === "file") return "Reading your library\u2026";
      return "Reading\u2026";
    }
    case "search": {
      const q = field("query")?.trim();
      return q ? `Searching for \u201c${q.slice(0, 40)}\u201d\u2026` : "Searching your library\u2026";
    }
    case "browser":
      return "Opening the browser\u2026";
    case "memory":
      return "Saving a memory\u2026";
    case "set_level":
    case "map":
    case "assess":
    case "point":
    case "resolve_point":
      return "Updating your learning map\u2026";
    case "ask":
    case "quiz":
      return "Preparing a question\u2026";
    case "set_avatar":
      return "Updating Leo\u2019s look\u2026";
    default:
      return "Working\u2026";
  }
}

/** The descriptive label for the action currently streaming, if a block is still open. */
export function progressHint(content: string): string | null {
  const segs = parseSegments(content, true);
  for (let i = segs.length - 1; i >= 0; i--) {
    const s = segs[i];
    if (s.kind === "pending") return s.hint ?? null;
  }
  return null;
}

export function parseSegments(content: string, streaming = false): Segment[] {
  // Safety net: some models print a single action object with no fence. A message that is exactly
  // one valid action is treated as that action.
  const bare = content.trim();
  if (!content.includes("```") && bare.startsWith("{") && bare.endsWith("}")) {
    try {
      const r = coerceAction(JSON.parse(bare));
      if ("action" in r) return [{ kind: "action", action: r.action, index: 0 }];
    } catch {
      /* still streaming, or not JSON at all */
    }
  }
  const segs: Segment[] = [];
  let last = 0;
  let idx = 0;
  const { blocks, openAt } = scanBlocks(content, streaming);
  for (const b of blocks) {
    const before = content.slice(last, b.start);
    if (before.trim()) segs.push({ kind: "text", text: before });
    const { actions, invalid } = parseBody(b.body);
    for (const a of actions) segs.push({ kind: "action", action: a, index: idx++ });
    for (const inv of invalid) segs.push({ kind: "invalid", ...inv });
    last = b.end;
  }
  let rest = content.slice(last);
  if (openAt >= 0) {
    const open = openAt - last;
    const before = rest.slice(0, open);
    if (before.trim()) segs.push({ kind: "text", text: before });
    if (streaming) segs.push({ kind: "pending", hint: actionHint(rest.slice(open)) });
    else segs.push({ kind: "invalid", raw: rest.slice(open, open + 200), reason: "action block was cut off" });
  } else {
    if (streaming) rest = rest.replace(/`{1,3}[a-z]{0,6}$/, "");
    if (rest.trim()) segs.push({ kind: "text", text: rest });
  }
  return segs;
}

export function extractActions(content: string): Action[] {
  return parseSegments(content)
    .filter((s): s is Extract<Segment, { kind: "action" }> => s.kind === "action")
    .map((s) => s.action);
}

/** Problems the model should hear about on its next turn. */
export function invalidActionFeedback(content: string): string | null {
  const bad = parseSegments(content).filter((s): s is Extract<Segment, { kind: "invalid" }> => s.kind === "invalid");
  if (!bad.length) return null;
  return `Note: ${bad.length} of your action blocks could not be executed (${bad.map((b) => b.reason).join("; ")}). Re-emit them as valid JSON if they still matter.`;
}

/** Strip action blocks for plain-text uses (thread titles, history summaries). */
export function stripActions(content: string) {
  const { blocks } = scanBlocks(content, false);
  let out = "";
  let last = 0;
  for (const b of blocks) {
    out += content.slice(last, b.start);
    last = b.end;
  }
  return (out + content.slice(last)).trim();
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

export async function findConcept(projectId: string, name: string) {
  const all = await db.concepts.where("projectId").equals(projectId).toArray();
  return all.find((c) => norm(c.name) === norm(name));
}

export async function upsertConcept(
  projectId: string,
  name: string,
  patch: Partial<Pick<Concept, "status" | "note">> = {},
  parentName?: string
): Promise<Concept> {
  const now = Date.now();
  let parentId: string | undefined;
  if (parentName && norm(parentName) !== norm(name)) {
    const parent = await upsertConcept(projectId, parentName);
    parentId = parent.id;
  }
  const existing = await findConcept(projectId, name);
  if (existing) {
    const upd: Partial<Concept> = { updatedAt: now };
    if (patch.status) upd.status = patch.status;
    if (patch.note) upd.note = patch.note;
    if (parentId && parentId !== existing.id) upd.parentId = parentId;
    await db.concepts.update(existing.id, upd);
    return { ...existing, ...upd };
  }
  const c: Concept = {
    id: uid(),
    projectId,
    name: name.trim().slice(0, 80),
    parentId,
    status: patch.status ?? "new",
    note: patch.note,
    correct: 0,
    attempts: 0,
    createdAt: now,
    updatedAt: now,
  };
  await db.concepts.add(c);
  return c;
}

const DAY = 86_400_000;

/** Record one graded outcome: stats, recent window, status and a simple spaced-review schedule. */
export async function recordQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await upsertConcept(projectId, conceptName);
  const fresh = (await db.concepts.get(c.id))!;
  let status = fresh.status;
  if (correct && status === "new") status = "learning";
  if (!correct && status === "solid") status = "shaky";
  const recent = [...(fresh.recent ?? []), correct ? 1 : 0].slice(-10);
  // Two consecutive correct answers on a learning concept earn "solid".
  if (correct && status === "learning" && recent.length >= 2 && recent.slice(-2).every((r) => r === 1)) status = "solid";
  const prev = fresh.interval ?? 0;
  const interval = correct ? Math.min(60, prev === 0 ? 1 : Math.round(prev * 2.2 * 10) / 10) : 0.5;
  const now = Date.now();
  await db.concepts.update(c.id, {
    attempts: fresh.attempts + 1,
    correct: fresh.correct + (correct ? 1 : 0),
    recent,
    status,
    interval,
    lastReviewed: now,
    nextReview: now + interval * DAY,
    updatedAt: now,
  });
}

/** Undo one graded outcome (learner disputed the answer key). */
export async function revertQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await findConcept(projectId, conceptName);
  if (!c || c.attempts === 0) return;
  const recent = [...(c.recent ?? [])];
  const idx = recent.lastIndexOf(correct ? 1 : 0);
  if (idx >= 0) recent.splice(idx, 1);
  await db.concepts.update(c.id, {
    attempts: c.attempts - 1,
    correct: Math.max(0, c.correct - (correct ? 1 : 0)),
    recent,
    updatedAt: Date.now(),
  });
}

export async function addPoint(projectId: string, kind: PointKind, text: string, author: "user" | "ai") {
  const t = text.trim();
  if (!t) return false;
  const existing = await db.points.where("projectId").equals(projectId).toArray();
  if (existing.some((p) => !p.done && norm(p.text) === norm(t))) return false;
  await db.points.add({ id: uid(), projectId, kind, text: t, author, done: false, createdAt: Date.now() });
  return true;
}

/* ------------------------------------------------------------- sketch refs */

interface SketchEl {
  id: string;
  type: string;
  x: number;
  y: number;
  width: number;
  height: number;
  isDeleted?: boolean;
  version?: number;
  versionNonce?: number;
  text?: string;
  backgroundColor?: string;
  strokeColor?: string;
  /** Set for the text element a shape or arrow uses as its label. */
  containerId?: string;
  customData?: Record<string, unknown> | null;
  startBinding?: { elementId?: string } | null;
  endBinding?: { elementId?: string } | null;
}

const refOf = (e: SketchEl) => (typeof e.customData?.ref === "string" ? (e.customData.ref as string) : null);

/** Give every live element the next free ref (s1, s2, …). Mutates customData in place. */
function assignRefs(elements: SketchEl[]): Map<string, string> {
  const live = elements.filter((e) => !e.isDeleted);
  const used = new Set(live.map(refOf).filter((r): r is string => !!r));
  const byId = new Map<string, string>();
  let n = 1;
  for (const e of live) {
    let ref = refOf(e);
    if (!ref) {
      while (used.has(`s${n}`)) n++;
      ref = `s${n}`;
      used.add(ref);
      e.customData = { ...(e.customData ?? {}), ref };
    }
    byId.set(e.id, ref);
  }
  return byId;
}

/** Excalidraw needs a new version + nonce before it will repaint a mutated element. */
function bump(e: SketchEl) {
  e.version = (e.version ?? 1) + 1;
  e.versionNonce = Math.floor(Math.random() * 2 ** 31);
}

const r1 = (n: number) => Math.round(Number.isFinite(n) ? n : 0);

const isShape = (t: string) => t === "rectangle" || t === "ellipse" || t === "diamond";

/**
 * The Excalidraw skeleton for one shape spec, carrying its ref in customData. `idFor` resolves
 * an arrow's from/to (an element index in a `sketch`, or an existing ref in an `edit_sketch` add)
 * to the id the arrow should bind to.
 */
function skeletonOf(
  e: SketchElementSpec,
  ref: string,
  idFor: (from: number | string | undefined) => string | undefined,
  id?: string
) {
  // For text and arrows "color" is the stroke (what guide-style strokeColor means); for shapes it is the fill.
  if (e.type === "text") return { type: "text", x: e.x, y: e.y, text: e.text || "", customData: { ref }, ...(e.color ? { strokeColor: e.color } : {}) };
  if (e.type === "arrow") {
    const start = idFor(e.from);
    const end = idFor(e.to);
    return {
      type: "arrow",
      x: e.x,
      y: e.y,
      width: e.width ?? 100,
      height: e.height ?? 0,
      customData: { ref },
      ...(e.color ? { strokeColor: e.color } : {}),
      ...(e.text ? { label: { text: e.text } } : {}),
      ...(start ? { start: { id: start } } : {}),
      ...(end ? { end: { id: end } } : {}),
    };
  }
  return {
    ...(id ? { id } : {}),
    type: e.type,
    x: e.x,
    y: e.y,
    width: e.width ?? 140,
    height: e.height ?? 72,
    strokeColor: "#17171a",
    backgroundColor: e.color ?? "#e3ecfe",
    fillStyle: "solid",
    strokeWidth: 2,
    roughness: 0,
    customData: { ref },
    ...(e.text ? { label: { text: e.text } } : {}),
  };
}

/**
 * One line per element with its stable ref, e.g. `s3 rectangle 100 40 140 72 #e3ecfe "Label"`
 * and `s7 arrow s3→s4`. Refs live in element.customData.ref and are assigned in element order
 * when missing, so they stay stable between reads and edits.
 */
export function describeSketch(scene: string): string {
  let elements: SketchEl[] = [];
  try {
    elements = (JSON.parse(scene || "{}").elements ?? []) as SketchEl[];
  } catch {
    return "(this sketch could not be read)";
  }
  if (!Array.isArray(elements) || !elements.length) return "(empty sketch)";
  const byId = assignRefs(elements);
  const labelOf = new Map<string, string>();
  for (const e of elements) if (e.containerId && typeof e.text === "string") labelOf.set(e.containerId, e.text);
  const lines = elements
    .filter((e) => !e.isDeleted)
    .map((e) => {
      const ref = byId.get(e.id) ?? "?";
      const label = e.type === "text" ? e.text : labelOf.get(e.id);
      if (e.type === "arrow" || e.type === "line") {
        const from = e.startBinding?.elementId ? byId.get(e.startBinding.elementId) : undefined;
        const to = e.endBinding?.elementId ? byId.get(e.endBinding.elementId) : undefined;
        const ends = from && to ? `${from}→${to}` : `${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}`;
        return `${ref} arrow ${ends}${label ? ` "${label}"` : ""}`;
      }
      const fill = e.backgroundColor && e.backgroundColor !== "transparent" ? ` ${e.backgroundColor}` : "";
      return `${ref} ${e.type} ${r1(e.x)} ${r1(e.y)} ${r1(e.width)} ${r1(e.height)}${fill}${label ? ` "${label}"` : ""}`;
    });
  return lines.length ? lines.join("\n") : "(empty sketch)";
}

/* --------------------------------------------------------------- note edits */

export const TRUNCATED_MARK = "…[truncated]";

/** Whether Leo has seen a note's contents in this thread, and whether the latest view was clipped. */
export interface NoteView {
  seen: boolean;
  clipped: boolean;
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * Scan a thread for the note's contents having reached the model: a `read` result
 * (`## Note "T" (id=X)`) or an attachment (`## Current note: "T" (id=X)` / `## Referenced note: …`).
 * Only user-role messages carry these. The latest occurrence decides `clipped`.
 */
export function noteViewIn(messages: Pick<Message, "role" | "content" | "apiContent">[], noteId: string): NoteView {
  const heading = new RegExp(`^## (?:Note|Current note:|Referenced note:) "[^\\n]*" \\(id=${escapeRe(noteId)}\\)[^\\n]*$`, "gm");
  const view: NoteView = { seen: false, clipped: false };
  for (const m of messages) {
    if (m.role !== "user") continue;
    const text = m.apiContent ?? m.content;
    heading.lastIndex = 0;
    let h: RegExpExecArray | null;
    while ((h = heading.exec(text))) {
      const from = h.index + h[0].length;
      const rest = text.slice(from);
      const stop = rest.search(/\n## |\n<\/workspace_context>|\n<\/action_results>/);
      const section = stop >= 0 ? rest.slice(0, stop) : rest;
      view.seen = true;
      view.clipped = section.includes(TRUNCATED_MARK);
    }
  }
  return view;
}

/** Apply exact find/replace edits in order. Every `find` must match exactly once at the time it is applied. */
export function applyPatches(content: string, patches: NotePatch[]): { content: string } | { error: string } {
  let out = content;
  for (let i = 0; i < patches.length; i++) {
    const p = patches[i];
    const at = out.indexOf(p.find);
    if (at < 0) return { error: `patch ${i + 1}: "find" text not found (${show(p.find)}) — copy it exactly from the note` };
    if (out.indexOf(p.find, at + 1) >= 0) return { error: `patch ${i + 1}: "find" text matches more than once (${show(p.find)}) — include more surrounding text` };
    out = out.slice(0, at) + p.replace + out.slice(at + p.find.length);
  }
  return { content: out };
}

type NoteAction = Extract<Action, { type: "note" }>;

export type NoteEditPlan =
  | { kind: "apply"; content: string; mode: NoteMode }
  | { kind: "fail"; reason: string }
  /** Needs the learner's Apply / Dismiss before it runs. */
  | { kind: "confirm"; reason: string };

/**
 * Decide what an edit of an existing note does. Pure: no database access.
 * - the note must have been read or attached earlier in the thread ("read it first");
 * - default mode is append; patch needs exact, unique matches;
 * - after a clipped read only append/patch are allowed (Leo never saw the whole note);
 * - replace runs directly only on notes Leo created; on the learner's notes it waits for approval.
 * `approved` = the learner pressed Apply on a pending replace.
 */
export function planNoteEdit(existing: Pick<Note, "id" | "title" | "content" | "author">, a: NoteAction, view: NoteView, approved = false): NoteEditPlan {
  const mode: NoteMode = a.mode ?? "append";
  if (!approved && !view.seen)
    return { kind: "fail", reason: `Note “${existing.title}” not changed — read it first ({"type":"read","kind":"note","id":"${existing.id}"})` };
  if (mode === "replace" && view.clipped && !approved)
    return { kind: "fail", reason: `Note “${existing.title}” not replaced — you only saw part of it (clipped read); use append or patch` };
  if (mode === "append") {
    const content = `${existing.content.trimEnd()}${existing.content.trim() ? "\n\n" : ""}${a.content}`;
    return { kind: "apply", content, mode };
  }
  if (mode === "patch") {
    const r = applyPatches(existing.content, a.patches ?? []);
    return "error" in r ? { kind: "fail", reason: `Note “${existing.title}” not patched — ${r.error}` } : { kind: "apply", content: r.content, mode };
  }
  if (existing.author !== "ai" && !approved) return { kind: "confirm", reason: `Replace the learner's note “${existing.title}”` };
  return { kind: "apply", content: a.content, mode };
}

interface RunOutcome {
  result: ActionResult;
  pending?: PendingAction;
}

const pendingOf = (a: Action, label: string): PendingAction => ({ id: uid(), action: a as unknown as PendingAction["action"], label, status: "pending" });

async function reindexNote(id: string) {
  const n = await db.notes.get(id);
  if (n) {
    const { indexNote } = await import("../retrieval");
    await indexNote(n);
  }
}

async function runNote(projectId: string, threadId: string | null, a: NoteAction, approved: boolean): Promise<RunOutcome> {
  const now = Date.now();
  if (!a.id) {
    const title = a.title?.trim() || "Leo's note";
    const grounded = await groundNote(projectId, threadId, a.content, a.sources);
    // A note with the same title is reused, never duplicated: Leo's own note is rewritten (with a
    // version kept), a learner's note gets the new material appended.
    const same = (await db.notes.where("projectId").equals(projectId).toArray()).find((n) => norm(n.title) === norm(title));
    if (same) {
      const content = same.author === "ai" ? grounded.content : `${same.content.trimEnd()}\n\n${grounded.content}`;
      await db.notes.update(same.id, {
        content,
        sources: mergeSources(same.sources, grounded.sources),
        versions: versionsWithCurrent(same, "ai", now),
        lastEditedBy: "ai",
        updatedAt: now,
        ...(a.folder?.trim() && same.author === "ai" ? { folder: cleanFolder(a.folder) } : {}),
      });
      await reindexNote(same.id);
      return { result: { type: a.type, label: `${same.author === "ai" ? "Updated" : "Appended to"} note · ${same.title}`, ok: true } };
    }
    const id = uid();
    const folder = a.folder?.trim() ? cleanFolder(a.folder) : undefined;
    await db.notes.add({
      id,
      projectId,
      title,
      content: grounded.content,
      author: "ai",
      lastEditedBy: "ai",
      createdAt: now,
      updatedAt: now,
      ...(folder ? { folder } : {}),
      ...(grounded.sources.length ? { sources: grounded.sources } : {}),
    });
    await reindexNote(id);
    return { result: { type: a.type, label: `Created note · ${folder ? `${folder}/` : ""}${title}`, ok: true } };
  }
  const existing = await db.notes.get(a.id);
  if (!existing || existing.projectId !== projectId) return { result: { type: a.type, label: `Note ${a.id} not found in this project`, ok: false } };
  const msgs = threadId ? await db.messages.where("threadId").equals(threadId).sortBy("createdAt") : [];
  const plan = planNoteEdit(existing, a, noteViewIn(msgs, a.id), approved);
  if (plan.kind === "fail") return { result: { type: a.type, label: plan.reason, ok: false } };
  if (plan.kind === "confirm") {
    return {
      result: { type: a.type, label: `Waiting for the learner's approval — ${plan.reason.toLowerCase()}`, ok: true },
      pending: pendingOf(a, plan.reason),
    };
  }
  const title = a.title?.trim() || existing.title;
  await db.notes.update(a.id, {
    title,
    content: plan.content,
    // Every edit keeps what was there (last NOTE_VERSION_LIMIT), so the learner can restore it.
    versions: versionsWithCurrent(existing, "ai", now),
    previousContent: undefined,
    // `author` is who created the note; it is never rewritten.
    lastEditedBy: "ai",
    updatedAt: now,
  });
  await reindexNote(a.id);
  const verb = plan.mode === "append" ? "Appended to" : plan.mode === "patch" ? "Patched" : "Replaced";
  return { result: { type: a.type, label: `${verb} note · ${title}`, ok: true } };
}

const cleanFolder = (f: string) =>
  f
    .split("/")
    .map((x) => x.trim())
    .filter(Boolean)
    .join("/")
    .slice(0, 200);

function mergeSources(a: SourceRef[] = [], b: SourceRef[] = []): SourceRef[] | undefined {
  const seen = new Set<string>();
  const out = [...a, ...b].filter((s) => {
    const k = `${s.fileId}|${s.page ?? ""}|${s.t0 ?? ""}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return out.length ? out.slice(0, 50) : undefined;
}

/**
 * Ground an AI note: collect its sources (explicit, from [S#] labels of this turn's SOURCES, from
 * "(file, p.12)" citations), and make sure the note ends with a Sources list.
 */
async function groundNote(projectId: string, threadId: string | null, content: string, explicit?: SourceRef[]) {
  const files = await db.files.where("projectId").equals(projectId).toArray();
  const msgs = threadId ? await db.messages.where("threadId").equals(threadId).sortBy("createdAt") : [];
  const lastCitations = [...msgs].reverse().find((m) => m.citations?.length)?.citations ?? [];
  const found = parseCitations(content, files, lastCitations);
  const sources = mergeSources(
    (explicit ?? []).filter((s) => files.some((f) => f.id === s.fileId)),
    found.map((c) => ({ fileId: c.fileId, ...(c.page ? { page: c.page } : {}), ...(typeof c.t0 === "number" ? { t0: c.t0 } : {}) }))
  ) ?? [];
  if (!sources.length || /^#{1,4}\s*Sources\b/im.test(content)) return { content, sources };
  const name = (id: string) => files.find((f) => f.id === id)?.name ?? "file";
  const { clock } = await import("../retrieval");
  const list = sources
    .map((s) => `- ${name(s.fileId)}${s.page ? `, p.${s.page}` : ""}${typeof s.t0 === "number" ? `, ${clock(s.t0)}` : ""}`)
    .join("\n");
  return { content: `${content.trimEnd()}\n\n## Sources\n${list}`, sources };
}

/** A tappable citation found in text: "(book.pdf, p.12)", "[S2]", "[3:12]". */
export interface FoundCitation {
  match: string;
  fileId: string;
  page?: number;
  t0?: number;
}

/**
 * Find citations in text and resolve them to library files. [S#] uses the SOURCES labels the reply was
 * given; "(name, p.N)" matches a file by name; "[m:ss]" seeks the only (or last cited) audio/video.
 */
export function parseCitations(
  text: string,
  files: Pick<import("../db").LibFile, "id" | "name" | "kind">[],
  labels: import("../db").CitationRef[] = []
): FoundCitation[] {
  const out: FoundCitation[] = [];
  for (const m of text.matchAll(/\[S(\d{1,2})\]/g)) {
    const ref = labels.find((l) => l.label === `S${m[1]}`);
    if (ref?.fileId) out.push({ match: m[0], fileId: ref.fileId, page: ref.page, t0: ref.t0 });
  }
  const byName = (raw: string) => {
    const n = raw.replace(/[`*_"“”]/g, "").trim().toLowerCase();
    return files.find((f) => f.name.toLowerCase() === n) ?? files.find((f) => n.length > 3 && f.name.toLowerCase().startsWith(n));
  };
  let lastMedia: string | undefined;
  for (const m of text.matchAll(/\(?`?([^()`\n,]{2,120}?)`?,\s*(?:p\.?|page)\s*(\d{1,5})`?\)?/g)) {
    const f = byName(m[1]);
    if (f) out.push({ match: m[0], fileId: f.id, page: Number(m[2]) });
  }
  for (const m of text.matchAll(/\(?`?([^()`\n,]{2,120}?)`?,\s*(\d{1,2}:\d{2}(?::\d{2})?)`?\)?/g)) {
    const f = byName(m[1]);
    if (f) {
      lastMedia = f.id;
      const [a, b, c] = m[2].split(":").map(Number);
      out.push({ match: m[0], fileId: f.id, t0: c === undefined ? a * 60 + b : a * 3600 + b * 60 + c });
    }
  }
  const media = files.filter((f) => f.kind === "audio" || f.kind === "video");
  const target = lastMedia ?? labels.find((l) => typeof l.t0 === "number")?.fileId ?? (media.length === 1 ? media[0].id : undefined);
  if (target) {
    for (const m of text.matchAll(/\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/g)) {
      const t0 = m[3] === undefined ? Number(m[1]) * 60 + Number(m[2]) : Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
      out.push({ match: m[0], fileId: target, t0 });
    }
  }
  return out;
}

const DAY_MS = 86_400_000;

/** Persist a quiz as a review card (one per question text per project). */
async function saveQuizCard(projectId: string, a: Extract<Action, { type: "quiz" }>) {
  const now = Date.now();
  const existing = (await db.cards.where("projectId").equals(projectId).toArray()).find((c) => norm(c.question) === norm(a.question));
  const row = {
    question: a.question,
    options: a.options,
    answer: a.answer,
    explanation: a.explanation,
    concept: a.concept?.trim() || "General",
    source: a.source,
    updatedAt: now,
  };
  if (existing) await db.cards.update(existing.id, row);
  else await db.cards.add({ id: uid(), projectId, ...row, interval: 0, nextReview: now + DAY_MS, reps: 0, lapses: 0, createdAt: now });
}

type MemoryAction = Extract<Action, { type: "memory" }>;

/** Scope for a new memory when none is given: preferences follow the learner everywhere, the rest stays with this topic. */
export const defaultMemoryScope = (kind: MemoryKind): "global" | "project" => (kind === "preference" ? "global" : "project");

async function runMemory(projectId: string, a: MemoryAction, approved: boolean): Promise<RunOutcome> {
  const scopeIdOf = (scope: "global" | "project") => (scope === "project" ? projectId : "*");
  const now = Date.now();
  if (a.op === "delete") {
    if (!a.id) throw new Error("Memory delete needs an id");
    const existing = await db.memories.get(a.id);
    if (!existing || (existing.projectId !== projectId && existing.projectId !== "*")) return { result: { type: a.type, label: "Memory not found", ok: false } };
    if (!approved) {
      const label = `Forget memory “${existing.text.length > 80 ? `${existing.text.slice(0, 80)}…` : existing.text}”`;
      return { result: { type: a.type, label: `Waiting for the learner's approval — ${label.toLowerCase()}`, ok: true }, pending: pendingOf(a, label) };
    }
    await db.memories.delete(a.id);
    return { result: { type: a.type, label: "Forgot that memory", ok: true } };
  }
  if (!a.text?.trim()) throw new Error("Memory save needs text");
  if (a.op === "update" && a.id) {
    const existing = await db.memories.get(a.id);
    if (!existing || (existing.projectId !== projectId && existing.projectId !== "*")) throw new Error("Memory not found");
    const kind = a.kind ?? existing.kind;
    // Keep the memory where it is unless a scope is given explicitly.
    await db.memories.update(a.id, { projectId: a.scope ? scopeIdOf(a.scope) : existing.projectId, kind, text: a.text.trim(), updatedAt: now });
    return { result: { type: a.type, label: `Updated memory · ${kind}`, ok: true } };
  }
  if (!a.kind) throw new Error("Memory save needs a kind and text");
  const scopeId = scopeIdOf(a.scope ?? defaultMemoryScope(a.kind));
  const all = await db.memories.where("projectId").equals(scopeId).toArray();
  const duplicate = all.find((m) => m.kind === a.kind && norm(m.text) === norm(a.text!));
  if (duplicate) {
    await db.memories.update(duplicate.id, { text: a.text.trim(), updatedAt: now });
    return { result: { type: a.type, label: `Updated memory · ${a.kind}`, ok: true } };
  }
  await db.memories.add({ id: uid(), projectId: scopeId, kind: a.kind, text: a.text.trim(), createdAt: now, updatedAt: now });
  return { result: { type: a.type, label: `Remembered · ${a.kind}`, ok: true } };
}

/** Run an action the learner approved from an Apply chip (a learner-note replace or a memory delete). */
export async function applyApprovedAction(projectId: string, action: Action): Promise<ActionResult> {
  try {
    if (action.type === "note") return (await runNote(projectId, null, action, true)).result;
    if (action.type === "memory") return (await runMemory(projectId, action, true)).result;
    return { type: action.type, label: "This action can't be approved here", ok: false };
  } catch (e) {
    return { type: action.type, label: e instanceof Error ? e.message : String(e), ok: false };
  }
}

/** What a turn's actions produced: chips for the learner, plus material for the model's next step. */
export interface ExecutionReport {
  results: ActionResult[];
  /** One entry per `read`: the item's contents, fed back to the model as <action_results>. */
  read: string[];
  /** Images produced by reads (image files, text-less PDF pages), sent with <action_results> as vision input. */
  images?: string[];
  /** Actions waiting for the learner's Apply / Dismiss; stored on the assistant message. */
  pending: PendingAction[];
}

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n)}\n${TRUNCATED_MARK}` : s);

export async function executeActions(
  projectId: string,
  threadId: string,
  actions: Action[]
): Promise<ExecutionReport> {
  const results: ActionResult[] = [];
  const read: string[] = [];
  const images: string[] = [];
  const pending: PendingAction[] = [];
  for (const a of actions) {
    try {
      switch (a.type) {
        case "set_level": {
          // Gate: placement needs evidence. Count answered ask/quiz cards in this thread.
          const project = await db.projects.get(projectId);
          if (project?.placement.status !== "done") {
            const msgs = await db.messages.where("threadId").equals(threadId).toArray();
            const answered = msgs.reduce((n, m) => n + Object.keys(m.answers ?? {}).length, 0);
            if (answered < 3) {
              results.push({ type: a.type, label: `Level not set yet — only ${answered} answered question(s); ask at least 3`, ok: false });
              break;
            }
          }
          await db.projects.update(projectId, {
            placement: {
              status: "done",
              level: a.level,
              summary: a.summary,
              startingPoint: a.startingPoint,
              at: Date.now(),
            },
            updatedAt: Date.now(),
          });
          await db.threads.update(threadId, { mode: "ask" });
          results.push({ type: a.type, label: `Level set: ${a.level}`, ok: true });
          break;
        }
        case "map": {
          const status = (["new", "learning", "shaky", "solid"] as const).includes(a.status as ConceptStatus)
            ? a.status
            : undefined;
          await upsertConcept(projectId, a.concept, { status, note: a.note }, a.parent);
          results.push({
            type: a.type,
            label: `${a.concept}${status ? ` → ${status}` : ""}`,
            ok: true,
          });
          break;
        }
        case "point": {
          const ok = await addPoint(projectId, a.kind, a.text, "ai");
          if (ok) results.push({ type: a.type, label: a.text, ok: true });
          break;
        }
        case "resolve_point": {
          const pts = await db.points.where("projectId").equals(projectId).toArray();
          const target = pts.find((p) => !p.done && norm(p.text) === norm(a.text));
          if (target) {
            await db.points.update(target.id, { done: true, resolvedBy: "ai" });
            results.push({ type: a.type, label: target.text, ok: true });
          } else {
            results.push({ type: a.type, label: `No open point matches “${a.text}” exactly`, ok: false });
          }
          break;
        }
        case "assess": {
          await recordQuizResult(projectId, a.concept, a.correct);
          if (a.note) await upsertConcept(projectId, a.concept, { note: a.note });
          results.push({ type: a.type, label: `${a.concept}: ${a.correct ? "correct" : "needs work"}`, ok: true });
          break;
        }
        case "set_avatar": {
          const project = await db.projects.get(projectId);
          if (!project) break;
          const current = normalizeAvatarLook(project.avatar);
          const look = normalizeAvatarLook({ ...current, ...a }, current);
          await db.projects.update(projectId, { avatar: look, updatedAt: Date.now() });
          results.push({ type: a.type, label: `${look.shape} · ${look.color} · ${look.expression}`, ok: true });
          break;
        }
        case "note": {
          const out = await runNote(projectId, threadId, a, false);
          results.push(out.result);
          if (out.pending) pending.push(out.pending);
          break;
        }
        case "search": {
          const { retrieve, formatSearchResults } = await import("../retrieval");
          const hits = await retrieve(projectId, a.query, 8, a.scope ?? "all");
          results.push({ type: a.type, label: `Searched · ${a.query.slice(0, 60)}`, ok: true });
          read.push(formatSearchResults(a.query, hits));
          break;
        }
        case "quiz": {
          await saveQuizCard(projectId, a);
          break;
        }
        case "read": {
          if (a.kind === "file") {
            const { readLibraryFile } = await import("./fileReader");
            const out = await readLibraryFile(projectId, a);
            results.push({ type: a.type, label: out.label, ok: out.ok });
            if (out.ok) read.push(out.text);
            images.push(...out.images.slice(0, Math.max(0, 6 - images.length)));
            break;
          }
          if (a.kind === "guide") {
            const guide = GUIDES[a.id];
            if (!guide) {
              results.push({ type: a.type, label: `No guide called "${a.id}" — the only guide is "excalidraw"`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read guide · ${a.id}`, ok: true });
            // The full text, unclipped: it rides the same <action_results> path notes and sketches use.
            read.push(`## Guide "${a.id}"\n${guide}`);
            break;
          }
          if (a.kind === "note") {
            const n = await db.notes.get(a.id);
            if (!n || n.projectId !== projectId) {
              results.push({ type: a.type, label: `Note ${a.id} not found in this project`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read note · ${n.title}`, ok: true });
            read.push(`## Note "${n.title}" (id=${n.id})\n${clip(n.content, 12000) || "(empty)"}`);
          } else {
            const s = await db.sketches.get(a.id);
            if (!s || s.projectId !== projectId) {
              results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
              break;
            }
            results.push({ type: a.type, label: `Read sketch · ${s.title}`, ok: true });
            read.push(`## Sketch "${s.title}" (id=${s.id}) — one line per element: ref type x y w h fill "label"\n${describeSketch(s.scene)}`);
          }
          break;
        }
        case "edit_sketch": {
          const existing = await db.sketches.get(a.id);
          if (!existing || existing.projectId !== projectId) {
            results.push({ type: a.type, label: `Sketch ${a.id} not found in this project`, ok: false });
            break;
          }
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          let parsed: { elements?: unknown; appState?: unknown; files?: unknown } = {};
          try {
            parsed = JSON.parse(existing.scene || "{}");
          } catch {
            parsed = {};
          }
          const elements = (Array.isArray(parsed.elements) ? parsed.elements : []) as SketchEl[];
          const byId = assignRefs(elements);
          const byRef = new Map<string, SketchEl>();
          for (const e of elements) if (!e.isDeleted) {
            const r = byId.get(e.id);
            if (r) byRef.set(r, e);
          }
          const freeRef = () => {
            let n = byRef.size + 1;
            while (byRef.has(`s${n}`)) n++;
            return `s${n}`;
          };
          const problems: string[] = [];
          let added = 0;
          let updated = 0;
          let deleted = 0;
          for (const op of a.ops) {
            const target = op.ref ? byRef.get(op.ref) : undefined;
            if (op.ref && !target) {
              problems.push(`no element ${op.ref}`);
              continue;
            }
            if (op.op === "add") {
              const spec = op.element;
              if (!spec) {
                problems.push("add needs an element");
                continue;
              }
              const ref = freeRef();
              const made = convertToExcalidrawElements(
                [skeletonOf(spec, ref, (f) => (typeof f === "string" ? byRef.get(f)?.id : undefined)) as never],
                { regenerateIds: true }
              )[0] as SketchEl | undefined;
              if (!made) {
                problems.push(`could not add a ${spec.type}`);
                continue;
              }
              elements.push(made);
              byRef.set(ref, made);
              added++;
            } else if (op.op === "update" && target) {
              const spec = op.element;
              if (spec) {
                if (typeof spec.x === "number") target.x = spec.x;
                if (typeof spec.y === "number") target.y = spec.y;
                if (typeof spec.width === "number") target.width = spec.width;
                if (typeof spec.height === "number") target.height = spec.height;
                if (typeof spec.color === "string") {
                  if (target.type === "rectangle" || target.type === "ellipse" || target.type === "diamond") target.backgroundColor = spec.color;
                  else target.strokeColor = spec.color;
                }
                if (typeof spec.text === "string") {
                  if (target.type === "text") target.text = spec.text;
                  else {
                    const label = elements.find((e) => e.containerId === target.id && !e.isDeleted);
                    if (label) {
                      label.text = spec.text;
                      bump(label);
                    } else problems.push(`${op.ref} has no label to change`);
                  }
                }
              }
              bump(target);
              updated++;
            } else if (op.op === "delete" && target) {
              target.isDeleted = true;
              bump(target);
              const label = elements.find((e) => e.containerId === target.id);
              if (label) {
                label.isDeleted = true;
                bump(label);
              }
              for (const e of elements) if (e.startBinding?.elementId === target.id || e.endBinding?.elementId === target.id) bump(e);
              deleted++;
            }
          }
          const scene = serializeAsJSON(elements as never, (parsed.appState ?? { viewBackgroundColor: "#ffffff" }) as never, (parsed.files ?? {}) as never, "local");
          await db.sketches.update(a.id, { scene, updatedAt: Date.now() });
          const api = useApp.getState().sketchApi;
          if (api && api.sketchId === a.id) api.updateScene({ elements });
          results.push({
            type: a.type,
            label: `Sketch · ${added} added, ${updated} updated, ${deleted} deleted${problems.length ? ` — ${problems.join("; ")}` : ""}`,
            ok: problems.length === 0,
          });
          break;
        }
        case "sketch": {
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          const skeleton = a.elements.map((e, i) =>
            skeletonOf(
              e,
              `s${i + 1}`,
              (f) => {
                const t = typeof f === "number" ? a.elements[f] : undefined;
                return t && (t.type === "rectangle" || t.type === "ellipse" || t.type === "diamond") ? `shape-${f}` : undefined;
              },
              e.type === "rectangle" || e.type === "ellipse" || e.type === "diamond" ? `shape-${i}` : undefined
            )
          );
          const elements = convertToExcalidrawElements(skeleton as never, { regenerateIds: true });
          const scene = serializeAsJSON(elements, { viewBackgroundColor: "#ffffff", gridSize: 20 } as never, {} as never, "local");
          const now = Date.now();
          const id = uid();
          await db.sketches.add({ id, projectId, title: a.title.trim() || "Leo's sketch", scene, createdAt: now, updatedAt: now });
          results.push({ type: a.type, label: `Created sketch · ${a.title || "Untitled"}`, ok: true });
          break;
        }
        case "browser": {
          let url: URL;
          try {
            url = new URL(a.url);
          } catch {
            throw new Error("Invalid URL");
          }
          if (!["http:", "https:"].includes(url.protocol)) throw new Error("Leo can only open http and https pages");
          useApp.getState().setBrowserUrl(url.href);
          useApp.getState().setBrowserOpen(true);
          useApp.getState().setChatOpen(false);
          results.push({ type: a.type, label: `Opened browser · ${url.hostname}`, ok: true });
          break;
        }
        case "memory": {
          const out = await runMemory(projectId, a, false);
          results.push(out.result);
          if (out.pending) pending.push(out.pending);
          break;
        }
        default:
          break;
      }
    } catch (e) {
      results.push({ type: a.type, label: String(e), ok: false });
    }
  }
  return { results, read, pending, ...(images.length ? { images } : {}) };
}
