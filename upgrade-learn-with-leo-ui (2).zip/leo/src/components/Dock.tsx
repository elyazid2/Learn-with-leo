import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { useLiveQuery } from "dexie-react-hooks";
import type { Route } from "@/lib/router";
import { useApp } from "@/lib/store";
import { useAgentState } from "@/lib/useAgentState";
import { progressHint } from "@/lib/ai/actions";
import { AGENT_STATE_META, normalizeAvatarLook } from "@/lib/avatar";
import { useSettings } from "@/lib/settings";
import AgentAvatar from "./AgentAvatar";
import { MOD } from "./ShortcutsSheet";

/** True while a text field is focused on a touch device (the soft keyboard is almost certainly up). */
function useSoftKeyboardOpen() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!window.matchMedia?.("(pointer: coarse)").matches) return;
    const update = () => {
      const el = document.activeElement as HTMLElement | null;
      const typing =
        !!el &&
        (el.tagName === "TEXTAREA" ||
          el.isContentEditable ||
          (el.tagName === "INPUT" && !["checkbox", "radio", "range", "file", "button", "submit"].includes((el as HTMLInputElement).type)));
      setOpen(typing);
    };
    const later = () => setTimeout(update, 0);
    document.addEventListener("focusin", update);
    document.addEventListener("focusout", later);
    return () => {
      document.removeEventListener("focusin", update);
      document.removeEventListener("focusout", later);
    };
  }, []);
  return open;
}

/**
 * Floating "island": the live agent (tap to chat) plus Add on the library home.
 * It shows what the agent is doing in words, and gets out of the way while typing.
 */
export default function Dock({ project, route }: { project: Project; route: Extract<Route, { name: "project" }> }) {
  const chatOpen = useApp((s) => s.chatOpen);
  const setChatOpen = useApp((s) => s.setChatOpen);
  const setAddOpen = useApp((s) => s.setAddOpen);
  const state = useAgentState(project.id);
  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);
  const typing = useSoftKeyboardOpen();
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const developerMode = useSettings((s) => s.developerMode);
  const needsSetup = providerCount === 0 && !developerMode;
  // While Leo works, say what he is doing rather than a generic "working".
  const streaming = useApp((s) => s.streaming);
  const hint = state === "working" && streaming ? progressHint(streaming.content) : null;

  if (chatOpen || typing) return null;

  const atHome = route.tab === "progress" || (route.tab === "library" && !route.itemId);
  const contextual =
    route.tab === "notes" ? "Ask Leo about this note" : route.tab === "sketch" ? "Ask Leo about this sketch" : route.itemId ? "Ask Leo about this file" : "Ask Leo";
  const label = needsSetup ? "Set up Leo" : state === "idle" ? contextual : (hint ?? AGENT_STATE_META[state].short);

  return (
    <div className="pointer-events-none fixed inset-x-0 z-40 flex justify-center px-3" style={{ bottom: "max(14px, env(safe-area-inset-bottom))" }}>
      <div className="pointer-events-auto flex max-w-full items-center gap-1 rounded-full bg-elevated/92 p-1.5 shadow-[0_10px_36px_rgba(0,0,0,0.16)] ring-1 ring-line backdrop-blur-2xl">
        <button
          onClick={() => setChatOpen(true)}
          className="flex h-12 min-w-0 items-center gap-2.5 rounded-full pl-1 pr-4 transition-colors hover:bg-ink/[0.05]"
          aria-label={`Open Leo — ${needsSetup ? "needs an AI provider" : AGENT_STATE_META[state].label}`}
          title={`Open Leo (${MOD} J)`}
        >
          <AgentAvatar state={state} look={look} size={40} />
          <span className="truncate text-[14px] font-semibold" aria-live="polite">
            {label}
          </span>
        </button>
        {atHome && (
          <button
            onClick={() => setAddOpen(true)}
            aria-label="Add to library"
            className="flex h-12 shrink-0 items-center gap-1.5 rounded-full bg-ink pl-4 pr-5 text-[14px] font-semibold text-white transition-[transform,background-color] hover:bg-ink/90 active:scale-[0.97]"
          >
            <Plus size={18} strokeWidth={2.4} /> Add
          </button>
        )}
      </div>
    </div>
  );
}
