import { Suspense, lazy, useEffect, useState } from "react";
import { ArrowLeft, Loader2, PenTool, Trash2 } from "lucide-react";
import { db, type Project, type Sketch } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { Button, Empty, IconBtn } from "@/components/ui";
import { confirmDeletion, useSettings } from "@/lib/settings";
import { useApp } from "@/lib/store";

import { normalizeAvatarLook } from "@/lib/avatar";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

const SketchCanvas = lazy(() => import("@/components/SketchCanvas"));

export default function Sketches({ project, sketchId }: { project: Project; sketchId: string }) {
  return <SketchEditor key={sketchId} project={project} sketchId={sketchId} />;
}

/** Full-screen sketchboard: one slim 48px bar (back · title · saved · Leo · delete), the rest is canvas. */
function SketchEditor({ project, sketchId }: { project: Project; sketchId: string }) {
  const [sketch, setSketch] = useState<Sketch | null | undefined>(null);
  const [title, setTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const setChatOpen = useApp((s) => s.setChatOpen);

  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);

  useEffect(() => {
    void db.sketches.get(sketchId).then((s) => {
      setSketch(s);
      if (s) setTitle(s.title);
    });
  }, [sketchId]);

  if (sketch === null)
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="animate-spin text-muted" />
      </div>
    );
  if (!sketch)
    return (
      <Empty icon={<PenTool />} title="Sketch not found">
        <Button onClick={() => navigate(projectPath(project.id))}>Back to library</Button>
      </Empty>
    );

  const saveTitle = () => void db.sketches.update(sketch.id, { title: title.trim() || "Sketch", updatedAt: Date.now() });
  const remove = async () => {
    if (!(await confirmDeletion("Delete this sketch?"))) return;
    navigate(projectPath(project.id), true);
    await db.sketches.delete(sketch.id);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-12 shrink-0 items-center gap-1 border-b border-line/70 bg-paper px-1.5 sm:px-3">
        <IconBtn onClick={() => navigate(projectPath(project.id))} aria-label="Back to library">
          <ArrowLeft size={19} />
        </IconBtn>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onBlur={saveTitle}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          aria-label="Sketch title"
          dir="auto"
          className="min-w-0 flex-1 truncate rounded-lg bg-transparent px-1.5 py-1 text-[16px] font-semibold outline-none focus:bg-ink/[0.05]"
        />
        <span className="flex shrink-0 items-center gap-1.5 px-1.5 text-[12px] text-muted" aria-live="polite" title={saving ? "Saving" : "Saved"}>
          <span className={cn("h-1.5 w-1.5 rounded-full transition-colors", saving ? "bg-shaky" : "bg-solid")} />
          <span className="hidden sm:inline">{saving ? "Saving" : "Saved"}</span>
        </span>
        <button
          onClick={() => setChatOpen(true)}
          aria-label="Ask Leo about this sketch"
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-full py-1 pl-1 pr-3 text-[14px] font-semibold transition-colors hover:bg-ink/[0.06]"
        >
          <AgentAvatar state="idle" look={look} size={28} frozenAt={0} /> Leo
        </button>
        <IconBtn onClick={() => void remove()} aria-label="Delete sketch" className="hover:text-danger-fg">
          <Trash2 size={17} />
        </IconBtn>
      </div>
      <div className="relative min-h-0 flex-1">
        <Suspense
          fallback={
            <div className="flex h-full items-center justify-center">
              <Loader2 className="animate-spin text-muted" />
            </div>
          }
        >
          <SketchCanvas sketch={sketch} title={title} onSaving={setSaving} />
        </Suspense>
      </div>
    </div>
  );
}
