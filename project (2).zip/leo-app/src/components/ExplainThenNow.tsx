import { useEffect, useState } from "react";
import { History, MessageCircle, PenLine, X } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { askLeo } from "@/lib/chat";
import { Button, Sheet } from "@/components/ui";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

const hiddenKey = (id: string) => `harness.explainHidden.${id}`;
const words = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0);
const day = (t: number) => new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

/**
 * "How would I explain it?" — written once at the start of a project, compared later only when the
 * learner presses "Compare with then". Leo never prompts for it on his own.
 */
export default function ExplainThenNow({ project }: { project: Project }) {
  const before = project.explanation?.before;
  const [hidden, setHidden] = useState(() => localStorage.getItem(hiddenKey(project.id)) === "1");
  const [writing, setWriting] = useState(false);
  const [draft, setDraft] = useState("");
  const [comparing, setComparing] = useState(false);

  if (!before) {
    if (hidden) return null;
    return (
      <section className="mb-6 rounded-2xl bg-card p-4 ring-1 ring-line" aria-label="Your starting explanation">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05]">
            <PenLine size={17} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[14px] font-semibold">How would you explain {project.name} right now?</div>
            <p className="text-[12.5px] text-muted">Optional. Write it in your own words — later you can compare it with how you'd explain it then.</p>
          </div>
          <button
            onClick={() => {
              localStorage.setItem(hiddenKey(project.id), "1");
              setHidden(true);
            }}
            aria-label="Hide"
            className="rounded-full p-1.5 text-muted hover:bg-ink/[0.05] hover:text-ink"
          >
            <X size={15} />
          </button>
        </div>
        {writing ? (
          <div className="mt-3">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={4}
              dir="auto"
              autoFocus
              placeholder={`${project.name} is…`}
              aria-label="Your explanation"
              className="w-full resize-y rounded-xl bg-ink/[0.035] p-3 text-[15px] leading-relaxed outline-none ring-1 ring-line focus:ring-ink/30"
            />
            <div className="mt-2 flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setWriting(false)}>
                Cancel
              </Button>
              <Button
                disabled={!draft.trim()}
                onClick={() => void db.projects.update(project.id, { explanation: { ...project.explanation, before: { text: draft.trim(), at: Date.now() } } })}
              >
                Save my explanation
              </Button>
            </div>
          </div>
        ) : (
          <Button variant="soft" size="sm" className="mt-3" onClick={() => setWriting(true)}>
            Write it
          </Button>
        )}
      </section>
    );
  }

  return (
    <>
      <div className="mb-6 flex items-center gap-3 rounded-2xl bg-card px-4 py-3 ring-1 ring-line">
        <History size={17} className="shrink-0 text-muted" />
        <div className="min-w-0 flex-1">
          <div className="text-[13.5px] font-semibold">Your first explanation</div>
          <div className="truncate text-[12px] text-muted">
            {day(before.at)} · {words(before.text)} words
          </div>
        </div>
        <Button size="sm" variant="soft" onClick={() => setComparing(true)}>
          Compare with then
        </Button>
      </div>
      <CompareSheet project={project} open={comparing} onClose={() => setComparing(false)} />
    </>
  );
}

function CompareSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const before = project.explanation?.before;
  const after = project.explanation?.after;
  const [step, setStep] = useState<"write" | "show">("write");
  const [draft, setDraft] = useState("");
  useEffect(() => {
    if (open) {
      setStep("write");
      setDraft(after?.text ?? "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  if (!before) return null;

  const compare = async () => {
    const text = draft.trim();
    if (!text) return;
    await db.projects.update(project.id, { explanation: { ...project.explanation, after: { text, at: Date.now() } } });
    setStep("show");
  };
  const now = step === "show" ? { text: draft.trim(), at: after?.text === draft.trim() ? after.at : Date.now() } : null;

  const discuss = () => {
    if (!now) return;
    onClose();
    void askLeo(
      project.id,
      `Here's how I explained ${project.name} at the start (${day(before.at)}) and how I'd explain it now. Show them side by side, point out what I now understand better, what's still missing or wrong, and suggest one thing to work on.\n\nTHEN:\n${before.text}\n\nNOW:\n${now.text}`
    );
  };

  return (
    <Sheet open={open} onClose={onClose} wide title={step === "write" ? "How would you explain it now?" : "Then and now"} description={step === "write" ? "Write it fresh, without looking. Then Leo puts both side by side." : undefined}>
      {step === "write" ? (
        <div>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={7}
            dir="auto"
            autoFocus
            placeholder={`${project.name} is…`}
            aria-label="Your explanation now"
            className="w-full resize-y rounded-2xl bg-ink/[0.035] p-3.5 text-[15px] leading-relaxed outline-none ring-1 ring-line focus:ring-ink/30"
          />
          <Button size="lg" className="mt-3 w-full" disabled={!draft.trim()} onClick={() => void compare()}>
            Compare with then
          </Button>
        </div>
      ) : (
        now && (
          <div>
            <div className="mb-4 flex items-center gap-3">
              <AgentAvatar state="speaking" size={36} />
              <p className="text-[14px] leading-snug">Here's how you explained it then, next to how you explain it now.</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { label: "Then", e: before },
                { label: "Now", e: now },
              ].map(({ label, e }) => (
                <div key={label} className={cn("min-w-0 rounded-2xl p-4 ring-1", label === "Now" ? "bg-card ring-ink/20" : "bg-ink/[0.035] ring-line")}>
                  <div className="mb-1.5 flex items-baseline justify-between gap-2">
                    <span className="text-[12px] font-semibold uppercase tracking-wide text-muted">{label}</span>
                    <span className="text-[11.5px] tabular-nums text-muted">
                      {day(e.at)} · {words(e.text)} words
                    </span>
                  </div>
                  <p className="whitespace-pre-wrap text-[14.5px] leading-relaxed" dir="auto">
                    {e.text}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="soft" onClick={() => setStep("write")}>
                Edit now
              </Button>
              <Button className="flex-1" onClick={discuss}>
                <MessageCircle size={16} /> Ask Leo what changed
              </Button>
            </div>
          </div>
        )
      )}
    </Sheet>
  );
}
