import { useEffect } from "react";
import { Focus } from "lucide-react";
import { useFocusMode } from "@/lib/focusMode";
import { useRoute } from "@/lib/router";
import { isSheetOpen } from "@/components/ui";
import { cn } from "@/utils/cn";

const isTyping = (el: Element | null) => {
  const h = el as HTMLElement | null;
  return !!h && (h.tagName === "INPUT" || h.tagName === "TEXTAREA" || h.tagName === "SELECT" || h.isContentEditable);
};

/** The focus button in an item's top bar. In focus mode the same button floats in the corner. */
export function FocusToggle({ className }: { className?: string }) {
  const on = useFocusMode((s) => s.on);
  return (
    <button
      type="button"
      onClick={() => useFocusMode.getState().toggle()}
      aria-pressed={on}
      aria-label={on ? "Leave focus mode" : "Focus mode"}
      title={on ? "Leave focus mode (F or two-finger tap)" : "Focus mode: hide everything but this item (F or two-finger tap)"}
      className={cn("flex h-9 w-9 items-center justify-center rounded-full text-ink/75 transition-colors hover:bg-ink/[0.06] hover:text-ink", className)}
    >
      <Focus size={17} />
    </button>
  );
}

/**
 * Global wiring for focus mode inside a project: the F key, a two-finger tap anywhere, and Esc to
 * leave. While it is on, the only control left on screen is the same focus button, faded in a corner.
 */
export default function FocusModeHost() {
  const route = useRoute();
  const on = useFocusMode((s) => s.on);
  const inProject = route.name === "project";

  useEffect(() => {
    if (!inProject && useFocusMode.getState().on) useFocusMode.getState().set(false);
  }, [inProject]);

  useEffect(() => {
    if (!inProject) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || isTyping(document.activeElement) || isSheetOpen()) return;
      if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        useFocusMode.getState().toggle();
      } else if (e.key === "Escape" && useFocusMode.getState().on) {
        useFocusMode.getState().set(false);
      }
    };
    // Two-finger tap: both fingers down and up quickly, without moving (so pinch-zoom is untouched).
    let start: { t: number; pts: { x: number; y: number }[] } | null = null;
    let moved = false;
    const onStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        start = { t: Date.now(), pts: Array.from(e.touches).map((t) => ({ x: t.clientX, y: t.clientY })) };
        moved = false;
      } else if (e.touches.length > 2) start = null;
    };
    const onMove = (e: TouchEvent) => {
      if (!start) return;
      for (const t of Array.from(e.touches)) {
        const near = start.pts.some((p) => Math.hypot(p.x - t.clientX, p.y - t.clientY) < 14);
        if (!near) moved = true;
      }
    };
    const onEnd = (e: TouchEvent) => {
      if (!start || e.touches.length > 0) return;
      const quick = Date.now() - start.t < 320;
      start = null;
      if (quick && !moved && !isSheetOpen()) useFocusMode.getState().toggle();
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("touchstart", onStart, { passive: true });
    window.addEventListener("touchmove", onMove, { passive: true });
    window.addEventListener("touchend", onEnd, { passive: true });
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("touchstart", onStart);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onEnd);
    };
  }, [inProject]);

  if (!inProject || !on) return null;
  return (
    <div className="fixed right-3 top-[max(env(safe-area-inset-top),10px)] z-[55] opacity-40 transition-opacity hover:opacity-100 focus-within:opacity-100">
      <FocusToggle className="bg-elevated/90 shadow-sm ring-1 ring-line backdrop-blur" />
    </div>
  );
}
