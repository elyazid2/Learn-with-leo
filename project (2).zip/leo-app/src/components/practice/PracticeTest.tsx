import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, ClipboardCheck, Clock, Play, X } from "lucide-react";
import { db, type Message, type PracticeTest, type TestAttempt } from "@/lib/db";
import { recordQuizResult, type Action } from "@/lib/ai/actions";
import { askLeo } from "@/lib/chat";
import { confirmDialog } from "@/lib/confirm";
import { Button } from "@/components/ui";
import { cn } from "@/utils/cn";

type TestAction = Extract<Action, { type: "practice_test" }>;

const mmss = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};

/** The test as stored: created the first time it is started, keyed by the message that proposed it. */
async function ensureTest(id: string, projectId: string, a: TestAction): Promise<PracticeTest> {
  const existing = await db.tests.get(id);
  if (existing) return existing;
  const test: PracticeTest = {
    id,
    projectId,
    title: a.title.trim(),
    minutes: Math.round(a.minutes),
    source: a.source,
    questions: a.questions.map((q) => ({ q: q.q, options: q.options, answer: q.answer, modelAnswer: q.model_answer, concept: q.concept })),
    attempts: [],
    createdAt: Date.now(),
  };
  await db.tests.put(test);
  return test;
}

export function PracticeTestCard({ message, index, action }: { message: Message; index: number; action: TestAction }) {
  const id = `${message.id}-${index}`;
  const stored = useLiveQuery(() => db.tests.get(id), [id]);
  const [running, setRunning] = useState<PracticeTest | null>(null);
  const last = stored?.attempts[stored.attempts.length - 1];
  const mcq = action.questions.filter((q) => q.options).length;
  return (
    <div className="my-2 rounded-2xl bg-card p-3.5 ring-1 ring-line">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ink text-white">
          <ClipboardCheck size={18} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[14px] font-semibold" dir="auto">
            {action.title}
          </div>
          <div className="text-[12px] text-muted">
            {action.questions.length} questions · {Math.round(action.minutes)} min{action.source ? ` · from ${action.source}` : ""}
            {mcq < action.questions.length ? ` · ${action.questions.length - mcq} open` : ""}
          </div>
          {last && (
            <div className="mt-1 text-[12px] font-medium">
              Last attempt: {last.correct}/{last.graded} multiple-choice correct{last.timedOut ? " (time ran out)" : ""}
            </div>
          )}
        </div>
      </div>
      <Button className="mt-3 w-full" onClick={() => void ensureTest(id, message.projectId, action).then(setRunning)}>
        <Play size={15} /> {last ? "Take it again" : "Start timed test"}
      </Button>
      {running && createPortal(<TestRunner test={running} onClose={() => setRunning(null)} />, document.body)}
    </div>
  );
}

function TestRunner({ test, onClose }: { test: PracticeTest; onClose: () => void }) {
  const [answers, setAnswers] = useState<(number | string | null)[]>(() => test.questions.map(() => null));
  const [startedAt] = useState(() => Date.now());
  const endsAt = startedAt + test.minutes * 60_000;
  const [now, setNow] = useState(() => Date.now());
  const [result, setResult] = useState<TestAttempt | null>(null);
  const submitted = useRef(false);
  const answersRef = useRef(answers);
  answersRef.current = answers;

  const submit = async (timedOut: boolean) => {
    if (submitted.current) return;
    submitted.current = true;
    const given = answersRef.current;
    let correct = 0;
    let graded = 0;
    for (let i = 0; i < test.questions.length; i++) {
      const q = test.questions[i];
      if (!q.options) continue;
      graded++;
      const ok = given[i] === q.answer;
      if (ok) correct++;
      if (q.concept) await recordQuizResult(test.projectId, q.concept, ok);
    }
    const attempt: TestAttempt = { answers: given, startedAt, finishedAt: Date.now(), correct, graded, timedOut };
    const fresh = await db.tests.get(test.id);
    await db.tests.update(test.id, { attempts: [...(fresh?.attempts ?? []), attempt].slice(-20) });
    setResult(attempt);
  };

  useEffect(() => {
    if (result) return;
    const t = window.setInterval(() => {
      const n = Date.now();
      setNow(n);
      if (n >= endsAt) void submit(true);
    }, 250);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [result, endsAt]);

  const left = endsAt - now;
  const answered = answers.filter((a) => a !== null && a !== "").length;
  const open = test.questions.map((q, i) => ({ q, i })).filter(({ q }) => !q.options);

  const leave = async () => {
    if (!result && !(await confirmDialog({ title: "Leave the test?", message: "Your answers so far will be lost.", confirmLabel: "Leave" }))) return;
    onClose();
  };

  const gradeWithLeo = () => {
    if (!result) return;
    const lines = test.questions.map((q, i) => {
      const a = result.answers[i];
      if (q.options) return `${i + 1}. [MC${q.concept ? ` · ${q.concept}` : ""}] ${q.q}\n   My answer: ${typeof a === "number" ? q.options[a] : "(none)"} — ${a === q.answer ? "correct" : `wrong (correct: ${q.options[q.answer ?? 0]})`}`;
      return `${i + 1}. [OPEN${q.concept ? ` · ${q.concept}` : ""}] ${q.q}\n   Model answer: ${q.modelAnswer ?? "-"}\n   My answer: ${typeof a === "string" && a.trim() ? a.trim() : "(blank)"}`;
    });
    const prompt = `I finished the practice test “${test.title}” (${mmss(result.finishedAt - result.startedAt)} of ${test.minutes} min${result.timedOut ? ", time ran out" : ""}). Multiple-choice: ${result.correct}/${result.graded} correct (already recorded). Please grade my open answers with assess actions, give a short score summary and tell me what to review.\n\n${lines.join("\n")}`;
    onClose();
    void askLeo(test.projectId, prompt);
  };

  return (
    <div className="fade-in fixed inset-0 z-[80] flex flex-col bg-paper" role="dialog" aria-modal="true" aria-label={`Practice test: ${test.title}`} data-no-capture>
      <header className="border-b border-line/70 bg-paper/90 pt-[env(safe-area-inset-top)] backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-3xl items-center gap-2 px-3">
          <button onClick={() => void leave()} aria-label="Close test" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-ink/[0.06]">
            <X size={18} />
          </button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-[15px] font-semibold">{test.title}</div>
            <div className="text-[12px] text-muted">{result ? "Results" : `${answered}/${test.questions.length} answered`}</div>
          </div>
          {!result && (
            <span className={cn("flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[14px] font-semibold tabular-nums", left < 60_000 ? "bg-danger-bg text-danger-fg" : "bg-ink/[0.06]")} role="timer" aria-live="off">
              <Clock size={14} /> {mmss(left)}
            </span>
          )}
        </div>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl space-y-4 px-4 pb-40 pt-5">
          {result && (
            <div className="rounded-2xl bg-ink p-4 text-white">
              <div className="display text-[28px] leading-none">
                {result.correct}/{result.graded}
              </div>
              <div className="mt-1 text-[13px] opacity-80">
                multiple-choice correct{result.timedOut ? " · time ran out" : ""} · {mmss(result.finishedAt - result.startedAt)} used
                {open.length ? ` · ${open.length} open ${open.length === 1 ? "answer" : "answers"} for Leo to grade` : ""}
              </div>
            </div>
          )}
          {test.questions.map((q, i) => {
            const a = (result ? result.answers : answers)[i];
            return (
              <section key={i} className="rounded-2xl bg-card p-4 ring-1 ring-line">
                <div className="mb-2.5 text-[15px] font-medium leading-snug" dir="auto">
                  <span className="mr-1.5 text-muted tabular-nums">{i + 1}.</span>
                  {q.q}
                </div>
                {q.options ? (
                  <div className="space-y-1.5">
                    {q.options.map((o, j) => {
                      const chosen = a === j;
                      const right = result && j === q.answer;
                      const wrong = result && chosen && j !== q.answer;
                      return (
                        <button
                          key={j}
                          disabled={!!result}
                          onClick={() => setAnswers((list) => list.map((x, k) => (k === i ? j : x)))}
                          className={cn(
                            "flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[14px] ring-1 transition-colors",
                            right ? "bg-[#16a07222] ring-[#16a072]" : wrong ? "bg-danger-bg ring-danger-fg/50" : chosen ? "bg-ink text-white ring-ink" : "ring-line hover:bg-ink/[0.04]"
                          )}
                        >
                          <span className={cn("flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold ring-1", chosen && !result ? "bg-white text-ink ring-white" : "ring-current/30")}>
                            {right ? <Check size={12} /> : String.fromCharCode(65 + j)}
                          </span>
                          <span dir="auto">{o}</span>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <>
                    <textarea
                      value={typeof a === "string" ? a : ""}
                      readOnly={!!result}
                      onChange={(e) => setAnswers((list) => list.map((x, k) => (k === i ? e.target.value : x)))}
                      rows={3}
                      dir="auto"
                      placeholder="Your answer"
                      aria-label={`Answer to question ${i + 1}`}
                      className="w-full resize-y rounded-xl bg-ink/[0.035] p-3 text-[14px] outline-none ring-1 ring-line focus:ring-ink/30"
                    />
                    {result && q.modelAnswer && (
                      <p className="mt-2 rounded-xl bg-ink/[0.04] p-2.5 text-[13px] text-muted" dir="auto">
                        <span className="font-semibold text-ink">Model answer: </span>
                        {q.modelAnswer}
                      </p>
                    )}
                  </>
                )}
              </section>
            );
          })}
        </div>
      </div>
      <div className="border-t border-line/70 bg-paper/95 px-4 pb-[max(env(safe-area-inset-bottom),12px)] pt-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl gap-2">
          {result ? (
            <>
              <Button size="lg" variant="soft" className="flex-1" onClick={onClose}>
                Done
              </Button>
              <Button size="lg" className="flex-1" onClick={gradeWithLeo}>
                {open.length ? "Have Leo grade open answers" : "Review with Leo"}
              </Button>
            </>
          ) : (
            <Button size="lg" className="flex-1" onClick={() => void submit(false)}>
              Submit answers
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export const usePracticeTests = (projectId: string) =>
  useLiveQuery(() => db.tests.where("projectId").equals(projectId).reverse().sortBy("createdAt"), [projectId]);

export const testSummary = (t: PracticeTest) => {
  const last = t.attempts[t.attempts.length - 1];
  return last ? `${last.correct}/${last.graded}` : "not taken";
};

export function useNow(interval = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), interval);
    return () => window.clearInterval(t);
  }, [interval]);
  return useMemo(() => now, [now]);
}
