import { useEffect, useRef, useState } from "react";
import { Captions, FlaskConical, Loader2, Mic, Square } from "lucide-react";
import { Button, Sheet } from "@/components/ui";
import { useApp } from "@/lib/store";
import { useSettings } from "@/lib/settings";
import { db, type LibFile } from "@/lib/db";
import { startMic, sttConfigured, transcribeClip, type MicSession, type SttSegment } from "@/lib/stt";
import { indexTranscript } from "@/lib/retrieval";
import { navigate } from "@/lib/router";
import { cn } from "@/utils/cn";

/** Demo transcripts are always labelled, so they are never mistaken for real ones. */
export function DemoBadge({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full bg-warn-bg px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-warn-fg ring-1 ring-black/5", className)}>
      <FlaskConical size={11} /> Demo
    </span>
  );
}

/**
 * The editable preview every transcription goes through. Nothing is saved or sent until the
 * learner presses the confirm button; "Discard" throws the text away.
 */
export function TranscriptSheet({
  open,
  title,
  demo,
  busy,
  error,
  text,
  onText,
  onConfirm,
  onCancel,
  confirmLabel,
  hint,
}: {
  open: boolean;
  title: string;
  demo: boolean;
  busy: boolean;
  error: string;
  text: string;
  onText: (t: string) => void;
  onConfirm: () => void;
  onCancel: () => void;
  confirmLabel: string;
  hint?: string;
}) {
  return (
    <Sheet
      open={open}
      onClose={onCancel}
      title={
        <span className="flex items-center gap-2">
          {title}
          {demo && <DemoBadge />}
        </span>
      }
      description={demo ? "Demo mode: sample text, not your speech. Turn it off in Settings → Speech to text." : hint ?? "Check and edit the text. Nothing is saved or sent until you confirm."}
      footer={
        <div className="flex gap-2">
          <Button size="lg" variant="soft" className="flex-1" onClick={onCancel}>
            Discard
          </Button>
          <Button size="lg" className="flex-1" disabled={busy || !text.trim()} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </div>
      }
    >
      <div data-no-capture>
        {busy && (
          <div className="mb-2 flex items-center gap-2 text-[13px] text-muted" role="status">
            <Loader2 size={14} className="animate-spin" /> {demo ? "Streaming demo text…" : "Transcribing on your Whisper server…"}
          </div>
        )}
        {error && (
          <p role="alert" className="mb-2 rounded-xl bg-danger-bg px-3 py-2 text-[13px] text-danger-fg">
            {error}
          </p>
        )}
        <textarea
          value={text}
          onChange={(e) => onText(e.target.value)}
          readOnly={busy}
          rows={8}
          dir="auto"
          aria-label={demo ? "Demo transcript preview" : "Transcript preview"}
          placeholder={busy ? "" : "No text yet"}
          className={cn(
            "w-full resize-y rounded-2xl bg-ink/[0.035] p-3.5 text-[15px] leading-relaxed outline-none ring-1 ring-line focus:ring-ink/30",
            demo && "border-l-4 border-warn-fg/60"
          )}
        />
      </div>
    </Sheet>
  );
}

/**
 * Mic button: tap to record, tap again to stop. The clip goes to the Whisper server (or the Demo
 * stream) and the text opens in an editable preview; `onConfirm` only runs on the learner's OK.
 */
export function MicButton({
  onConfirm,
  context,
  confirmLabel = "Insert text",
  className,
  size = 17,
}: {
  onConfirm: (text: string) => void;
  context: string;
  confirmLabel?: string;
  className?: string;
  size?: number;
}) {
  const [phase, setPhase] = useState<"idle" | "recording" | "preview">("idle");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [demo, setDemo] = useState(false);
  const session = useRef<MicSession | null>(null);
  const abort = useRef<AbortController | null>(null);

  useEffect(
    () => () => {
      session.current?.cancel();
      abort.current?.abort();
    },
    []
  );

  const start = async () => {
    if (!sttConfigured()) {
      useApp.getState().showToast("Set your Whisper server (or Demo mode) in Settings → Speech to text");
      navigate("settings");
      return;
    }
    try {
      session.current = await startMic();
      setPhase("recording");
    } catch (e) {
      useApp.getState().showToast((e as Error).message);
    }
  };

  const stop = async () => {
    const s = session.current;
    session.current = null;
    if (!s) return;
    const blob = await s.stop();
    const isDemo = useSettings.getState().demoTranscription;
    setDemo(isDemo);
    setText("");
    setError("");
    setBusy(true);
    setPhase("preview");
    const ctrl = new AbortController();
    abort.current = ctrl;
    try {
      await transcribeClip(blob, (t) => !ctrl.signal.aborted && setText(t), ctrl.signal, (Date.now() - s.startedAt) / 1000);
    } catch (e) {
      if ((e as Error).name !== "AbortError") setError((e as Error).message);
    } finally {
      if (!ctrl.signal.aborted) setBusy(false);
    }
  };

  const close = () => {
    abort.current?.abort();
    setBusy(false);
    setPhase("idle");
  };

  const recording = phase === "recording";
  return (
    <>
      <button
        type="button"
        onClick={() => void (recording ? stop() : start())}
        className={cn(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors",
          recording ? "animate-pulse bg-danger-fg text-white" : "text-ink/70 hover:bg-ink/[0.08] hover:text-ink",
          className
        )}
        aria-label={recording ? `Stop recording (${context})` : `Speak (${context})`}
        aria-pressed={recording}
        title={recording ? "Stop and preview" : "Speech to text"}
      >
        {recording ? <Square size={size - 4} fill="currentColor" /> : <Mic size={size} />}
      </button>
      <TranscriptSheet
        open={phase === "preview"}
        title={`Speech to text · ${context}`}
        demo={demo}
        busy={busy}
        error={error}
        text={text}
        onText={setText}
        confirmLabel={confirmLabel}
        onCancel={close}
        onConfirm={() => {
          const t = text.trim();
          close();
          if (t) onConfirm(t);
        }}
      />
    </>
  );
}

/** Even spread of edited text over the clip, used when the learner changed the server's words. */
function spread(text: string, duration: number): SttSegment[] {
  const sentences = text.split(/(?<=[.!?])\s+/).filter((s) => s.trim());
  const total = sentences.reduce((n, s) => n + s.length, 0) || 1;
  let t = 0;
  return sentences.map((s) => {
    const d = (s.length / total) * duration;
    const seg = { t0: t, t1: t + d, text: s.trim() };
    t += d;
    return seg;
  });
}

/**
 * Transcript of a recording or audio file: runs on request, shows the editable preview, and only
 * saves the transcript (and makes it searchable for Leo) after the learner confirms.
 */
export function RecordingTranscriber({ file }: { file: LibFile }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [demo, setDemo] = useState(false);
  const segments = useRef<SttSegment[] | undefined>(undefined);
  const raw = useRef("");
  const abort = useRef<AbortController | null>(null);
  const saved = file.transcript?.length ? file.transcript.map((s) => s.text).join(" ") : "";

  const run = async () => {
    if (!sttConfigured()) {
      useApp.getState().showToast("Set your Whisper server (or Demo mode) in Settings → Speech to text");
      return;
    }
    const isDemo = useSettings.getState().demoTranscription;
    setDemo(isDemo);
    setOpen(true);
    setText("");
    setError("");
    setBusy(true);
    const ctrl = new AbortController();
    abort.current = ctrl;
    try {
      const r = await transcribeClip(file.blob, (t) => !ctrl.signal.aborted && setText(t), ctrl.signal, file.duration);
      segments.current = r.segments;
      raw.current = r.text;
    } catch (e) {
      if ((e as Error).name !== "AbortError") setError((e as Error).message);
    } finally {
      if (!ctrl.signal.aborted) setBusy(false);
    }
  };

  const close = () => {
    abort.current?.abort();
    setBusy(false);
    setOpen(false);
  };

  const save = async () => {
    const t = text.trim();
    if (!t) return;
    const duration = file.duration ?? Math.max(1, t.split(/\s+/).length * 0.4);
    const segs = segments.current && t === raw.current.trim() && !demo ? segments.current : spread(t, duration);
    await db.files.update(file.id, { transcript: segs, transcriptSource: "audio", transcriptState: "done", transcriptNote: demo ? "Demo transcript (sample text)" : undefined });
    await indexTranscript(file, segs);
    close();
    useApp.getState().showToast(demo ? "Saved demo transcript" : "Transcript saved — Leo can search it now", { tone: "success" });
  };

  return (
    <div className="mt-4 rounded-2xl bg-card p-4 ring-1 ring-line">
      <div className="flex items-center gap-2">
        <Captions size={16} className="text-muted" />
        <span className="flex-1 text-[14px] font-semibold">Transcript</span>
        {file.transcriptNote?.startsWith("Demo") && <DemoBadge />}
        <Button size="sm" variant="soft" onClick={() => void run()}>
          <Mic size={14} /> {saved ? "Transcribe again" : "Transcribe"}
        </Button>
      </div>
      {saved ? (
        <p className="mt-2 max-h-56 overflow-y-auto whitespace-pre-wrap text-[14px] leading-relaxed text-ink/85" dir="auto" data-ctx-source={`transcript of ${file.name}`}>
          {saved}
        </p>
      ) : (
        <p className="mt-1.5 text-[13px] text-muted">Uses your local Whisper server. You'll see an editable preview before anything is saved.</p>
      )}
      <TranscriptSheet
        open={open}
        title="Transcript preview"
        demo={demo}
        busy={busy}
        error={error}
        text={text}
        onText={setText}
        confirmLabel="Save transcript"
        onCancel={close}
        onConfirm={() => void save()}
      />
    </div>
  );
}
