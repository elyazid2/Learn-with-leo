import { useState } from "react";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { useSettings } from "@/lib/settings";
import { Button, Field, Toggle, inputCls } from "@/components/ui";
import { whisperEndpoint } from "@/lib/stt";
import { DemoBadge } from "@/components/stt/Dictation";

/** Settings → Approvals: whether Leo's organizing and note changes need a preview first. */
export function ApprovalSection() {
  const alwaysApprove = useSettings((s) => s.alwaysApprove);
  const setSettings = useSettings((s) => s.setSettings);
  return (
    <section className="mt-10">
      <h2 className="mb-3 text-[13px] font-semibold text-muted">Approvals</h2>
      <div className="rounded-2xl bg-card p-4 ring-1 ring-line">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="text-sm font-semibold">Always approve</div>
            <p className="mt-0.5 text-[13px] leading-relaxed text-muted">
              {alwaysApprove
                ? "On: Leo's folders, moves, renames, tags, tools and note edits apply right away."
                : "Off: nothing Leo organizes or writes changes until you see a preview (old vs new for notes) and approve it. You can edit his text before accepting."}
            </p>
          </div>
          <Toggle checked={alwaysApprove} onChange={(v) => setSettings({ alwaysApprove: v })} label="Always approve" />
        </div>
      </div>
    </section>
  );
}

/** Settings → Speech to text: the learner's local Whisper server, and a Demo mode for testing the UI. */
export function SpeechToTextSection() {
  const whisperUrl = useSettings((s) => s.whisperUrl);
  const demo = useSettings((s) => s.demoTranscription);
  const setSettings = useSettings((s) => s.setSettings);
  const [draft, setDraft] = useState(whisperUrl);
  const [check, setCheck] = useState<{ state: "idle" | "busy" | "ok" | "fail"; text?: string }>({ state: "idle" });

  const commit = () => {
    const v = draft.trim();
    if (v !== whisperUrl) setSettings({ whisperUrl: v });
    setCheck({ state: "idle" });
  };

  const test = async () => {
    commit();
    const endpoint = whisperEndpoint(draft);
    if (!endpoint) return setCheck({ state: "fail", text: "Enter a URL first" });
    setCheck({ state: "busy" });
    try {
      const origin = new URL(endpoint).origin;
      const ctrl = new AbortController();
      const t = window.setTimeout(() => ctrl.abort(), 6000);
      const res = await fetch(origin, { method: "GET", signal: ctrl.signal }).finally(() => window.clearTimeout(t));
      setCheck({ state: "ok", text: `Server reachable (${res.status}). Transcripts go to ${endpoint}` });
    } catch (e) {
      setCheck({ state: "fail", text: (e as Error).name === "TypeError" && /URL/i.test((e as Error).message) ? "That isn't a valid URL" : "Couldn't reach the server. Check the address, that it's running, and that it allows this page (CORS)." });
    }
  };

  return (
    <section className="mt-10" data-no-capture>
      <h2 className="text-[13px] font-semibold text-muted">Speech to text</h2>
      <p className="mt-0.5 mb-3 text-[13px] text-muted">
        Your local Whisper server for recording transcripts and the mic buttons in Leo's chat and the note editor. You always get an editable preview; nothing is saved or sent until you confirm.
      </p>
      <div className="space-y-4 rounded-2xl bg-card p-4 ring-1 ring-line">
        <Field label="Whisper server URL" hint="e.g. http://192.168.1.20:8080/inference (whisper.cpp) or http://localhost:8000 (OpenAI-compatible: /v1/audio/transcriptions is added).">
          <input
            className={inputCls}
            value={draft}
            inputMode="url"
            autoComplete="off"
            spellCheck={false}
            placeholder="http://localhost:8000"
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => e.key === "Enter" && commit()}
          />
        </Field>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="soft" size="sm" onClick={() => void test()} disabled={check.state === "busy"}>
            {check.state === "busy" && <Loader2 size={14} className="animate-spin" />} Test connection
          </Button>
          {check.state === "ok" && (
            <span className="flex items-center gap-1 text-[12.5px] text-[#0f7a56]">
              <CheckCircle2 size={14} /> {check.text}
            </span>
          )}
          {check.state === "fail" && (
            <span className="flex items-center gap-1 text-[12.5px] text-danger-fg">
              <XCircle size={14} /> {check.text}
            </span>
          )}
        </div>
        <div className="flex items-center gap-4 border-t border-line pt-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sm font-semibold">
              Demo transcription mode <DemoBadge />
            </div>
            <p className="mt-0.5 text-[13px] leading-relaxed text-muted">
              Skips the server and streams sample text word by word after a short delay — handy for trying the UI on your phone. Every preview is labelled “Demo”.
            </p>
          </div>
          <Toggle checked={demo} onChange={(v) => setSettings({ demoTranscription: v })} label="Demo transcription mode" />
        </div>
      </div>
    </section>
  );
}
