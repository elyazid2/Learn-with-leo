import { useEffect, useRef, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeftRight, Calculator, Check, CheckSquare, Clock, Flag, Layers, Pause, Play, Plus, RotateCcw, Ruler, Shuffle, Trash2, X } from "lucide-react";
import { db, uid, type Project, type ToolItem, type ToolKind } from "@/lib/db";
import { saveToolState, TOOL_META } from "@/lib/tools";
import { navigate, projectPath } from "@/lib/router";
import { confirmDeletion } from "@/lib/settings";
import { useApp } from "@/lib/store";
import { Button, Empty, Segmented, inputCls } from "@/components/ui";
import { PaneBar } from "@/components/Pane";
import { cn } from "@/utils/cn";

export const TOOL_ICON: Record<ToolKind, (size: number) => ReactNode> = {
  clock: (s) => <Clock size={s} />,
  calculator: (s) => <Calculator size={s} />,
  converter: (s) => <Ruler size={s} />,
  checklist: (s) => <CheckSquare size={s} />,
  flashcards: (s) => <Layers size={s} />,
};

/** Keeps a tool's state locally and writes every change through to the library item. */
function useToolState<T extends Record<string, unknown>>(tool: ToolItem, defaults: T): [T, (patch: Partial<T> | ((s: T) => Partial<T>)) => void] {
  const [state, setState] = useState<T>(() => ({ ...defaults, ...(tool.state as Partial<T>) }));
  const ref = useRef(state);
  const set = (patch: Partial<T> | ((s: T) => Partial<T>)) => {
    const next = { ...ref.current, ...(typeof patch === "function" ? patch(ref.current) : patch) };
    ref.current = next;
    setState(next);
    void saveToolState(tool.id, next);
  };
  return [state, set];
}

function useTick(active: boolean, ms = 200) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [active, ms]);
  return active ? now : Date.now();
}

function beep() {
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    [0, 0.35, 0.7].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.25);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.3);
    });
    window.setTimeout(() => void ctx.close(), 1500);
  } catch {
    /* no audio */
  }
  navigator.vibrate?.([200, 100, 200]);
}

const fmt = (ms: number, tenths = false) => {
  const total = Math.max(0, ms);
  const h = Math.floor(total / 3_600_000);
  const m = Math.floor((total % 3_600_000) / 60_000);
  const s = Math.floor((total % 60_000) / 1000);
  const d = Math.floor((total % 1000) / 100);
  return `${h ? `${h}:` : ""}${h ? String(m).padStart(2, "0") : m}:${String(s).padStart(2, "0")}${tenths ? `.${d}` : ""}`;
};

const bigDigits = "display text-[64px] leading-none tabular-nums sm:text-[84px]";
const roundBtn = "flex h-14 w-14 items-center justify-center rounded-full transition-colors";

/* ------------------------------------------------------------------ clock */

type ClockState = {
  tab: "pomodoro" | "stopwatch" | "countdown";
  work: number;
  brk: number;
  phase: "work" | "break";
  pEndsAt: number | null;
  pLeft: number | null;
  rounds: number;
  swStart: number | null;
  swElapsed: number;
  laps: number[];
  cdMinutes: number;
  cdSeconds: number;
  cdEndsAt: number | null;
  cdLeft: number | null;
};

function ClockTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<ClockState>(tool, {
    tab: "pomodoro",
    work: 25,
    brk: 5,
    phase: "work",
    pEndsAt: null,
    pLeft: null,
    rounds: 0,
    swStart: null,
    swElapsed: 0,
    laps: [],
    cdMinutes: 5,
    cdSeconds: 0,
    cdEndsAt: null,
    cdLeft: null,
  });
  const running = s.pEndsAt !== null || s.swStart !== null || s.cdEndsAt !== null;
  const now = useTick(true, running ? 100 : 1000);

  // Finishing a pomodoro phase or a countdown rings once and stops.
  useEffect(() => {
    if (s.pEndsAt !== null && now >= s.pEndsAt) {
      beep();
      const nextPhase = s.phase === "work" ? "break" : "work";
      set({ pEndsAt: null, pLeft: null, phase: nextPhase, rounds: s.phase === "work" ? s.rounds + 1 : s.rounds });
      useApp.getState().showToast(s.phase === "work" ? "Focus block done — take a break" : "Break over — back to it");
    }
    if (s.cdEndsAt !== null && now >= s.cdEndsAt) {
      beep();
      set({ cdEndsAt: null, cdLeft: null });
      useApp.getState().showToast("Countdown finished");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [now]);

  const phaseMs = (s.phase === "work" ? s.work : s.brk) * 60_000;
  const pLeft = s.pEndsAt !== null ? s.pEndsAt - now : s.pLeft ?? phaseMs;
  const sw = s.swElapsed + (s.swStart !== null ? now - s.swStart : 0);
  const cdTotal = (s.cdMinutes * 60 + s.cdSeconds) * 1000;
  const cdLeft = s.cdEndsAt !== null ? s.cdEndsAt - now : s.cdLeft ?? cdTotal;

  return (
    <div className="mx-auto max-w-xl px-4 pb-36 pt-6">
      <div className="mb-6 text-center text-[14px] font-medium tabular-nums text-muted">
        {new Date(now).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
      </div>
      <Segmented
        value={s.tab}
        onChange={(tab) => set({ tab })}
        label="Clock mode"
        className="mx-auto mb-8 w-full"
        options={[
          { value: "pomodoro", label: "Pomodoro" },
          { value: "stopwatch", label: "Stopwatch" },
          { value: "countdown", label: "Countdown" },
        ]}
      />
      {s.tab === "pomodoro" && (
        <div className="text-center">
          <div className={cn("mb-2 inline-flex rounded-full px-3 py-1 text-[12px] font-semibold", s.phase === "work" ? "bg-ink text-white" : "bg-[#16a07222] text-[#0f7a56]")}>
            {s.phase === "work" ? "Focus" : "Break"} · round {s.rounds + 1}
          </div>
          <div className={bigDigits} role="timer">{fmt(pLeft)}</div>
          <div className="mx-auto mt-4 h-1.5 max-w-xs overflow-hidden rounded-full bg-ink/10">
            <div className="h-full rounded-full bg-ink transition-[width]" style={{ width: `${Math.min(100, (1 - pLeft / phaseMs) * 100)}%` }} />
          </div>
          <div className="mt-8 flex items-center justify-center gap-4">
            <button className={cn(roundBtn, "bg-ink/[0.06] hover:bg-ink/10")} aria-label="Reset" onClick={() => set({ pEndsAt: null, pLeft: null })}>
              <RotateCcw size={20} />
            </button>
            {s.pEndsAt !== null ? (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white")} aria-label="Pause" onClick={() => set({ pEndsAt: null, pLeft: s.pEndsAt! - Date.now() })}>
                <Pause size={24} />
              </button>
            ) : (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white")} aria-label="Start" onClick={() => set({ pEndsAt: Date.now() + (s.pLeft ?? phaseMs) })}>
                <Play size={24} />
              </button>
            )}
            <button className={cn(roundBtn, "bg-ink/[0.06] hover:bg-ink/10")} aria-label="Skip phase" onClick={() => set({ pEndsAt: null, pLeft: null, phase: s.phase === "work" ? "break" : "work" })}>
              <Flag size={20} />
            </button>
          </div>
          <div className="mx-auto mt-8 grid max-w-xs grid-cols-2 gap-3 text-left">
            <label className="text-[12px] font-medium text-muted">
              Focus (min)
              <input type="number" min={1} max={180} className={cn(inputCls, "mt-1")} value={s.work} onChange={(e) => set({ work: Math.max(1, Math.min(180, Number(e.target.value) || 25)), pLeft: null })} />
            </label>
            <label className="text-[12px] font-medium text-muted">
              Break (min)
              <input type="number" min={1} max={60} className={cn(inputCls, "mt-1")} value={s.brk} onChange={(e) => set({ brk: Math.max(1, Math.min(60, Number(e.target.value) || 5)), pLeft: null })} />
            </label>
          </div>
        </div>
      )}
      {s.tab === "stopwatch" && (
        <div className="text-center">
          <div className={bigDigits} role="timer">{fmt(sw, true)}</div>
          <div className="mt-8 flex items-center justify-center gap-4">
            <button className={cn(roundBtn, "bg-ink/[0.06] hover:bg-ink/10")} aria-label="Reset" onClick={() => set({ swStart: null, swElapsed: 0, laps: [] })}>
              <RotateCcw size={20} />
            </button>
            {s.swStart !== null ? (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white")} aria-label="Pause" onClick={() => set({ swStart: null, swElapsed: sw })}>
                <Pause size={24} />
              </button>
            ) : (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white")} aria-label="Start" onClick={() => set({ swStart: Date.now() })}>
                <Play size={24} />
              </button>
            )}
            <button className={cn(roundBtn, "bg-ink/[0.06] hover:bg-ink/10 disabled:opacity-40")} aria-label="Lap" disabled={!sw} onClick={() => set({ laps: [sw, ...s.laps].slice(0, 50) })}>
              <Flag size={20} />
            </button>
          </div>
          {s.laps.length > 0 && (
            <ol className="mx-auto mt-8 max-w-xs divide-y divide-line rounded-2xl text-[14px] tabular-nums ring-1 ring-line">
              {s.laps.map((l, i) => (
                <li key={i} className="flex justify-between px-4 py-2">
                  <span className="text-muted">Lap {s.laps.length - i}</span>
                  <span>{fmt(l, true)}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      )}
      {s.tab === "countdown" && (
        <div className="text-center">
          <div className={bigDigits} role="timer">{fmt(cdLeft)}</div>
          {s.cdEndsAt === null && s.cdLeft === null && (
            <div className="mx-auto mt-6 grid max-w-xs grid-cols-2 gap-3 text-left">
              <label className="text-[12px] font-medium text-muted">
                Minutes
                <input type="number" min={0} max={600} className={cn(inputCls, "mt-1")} value={s.cdMinutes} onChange={(e) => set({ cdMinutes: Math.max(0, Math.min(600, Number(e.target.value) || 0)) })} />
              </label>
              <label className="text-[12px] font-medium text-muted">
                Seconds
                <input type="number" min={0} max={59} className={cn(inputCls, "mt-1")} value={s.cdSeconds} onChange={(e) => set({ cdSeconds: Math.max(0, Math.min(59, Number(e.target.value) || 0)) })} />
              </label>
              <div className="col-span-2 flex flex-wrap gap-1.5">
                {[1, 5, 10, 15, 30, 45].map((m) => (
                  <button key={m} onClick={() => set({ cdMinutes: m, cdSeconds: 0 })} className="rounded-full px-3 py-1 text-[12px] font-medium ring-1 ring-line hover:bg-ink/[0.05]">
                    {m} min
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="mt-8 flex items-center justify-center gap-4">
            <button className={cn(roundBtn, "bg-ink/[0.06] hover:bg-ink/10")} aria-label="Reset" onClick={() => set({ cdEndsAt: null, cdLeft: null })}>
              <RotateCcw size={20} />
            </button>
            {s.cdEndsAt !== null ? (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white")} aria-label="Pause" onClick={() => set({ cdEndsAt: null, cdLeft: s.cdEndsAt! - Date.now() })}>
                <Pause size={24} />
              </button>
            ) : (
              <button className={cn(roundBtn, "h-16 w-16 bg-ink text-white disabled:opacity-40")} disabled={!cdTotal && !s.cdLeft} aria-label="Start" onClick={() => set({ cdEndsAt: Date.now() + (s.cdLeft ?? cdTotal) })}>
                <Play size={24} />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------- calculator */

const FUNCS: Record<string, (x: number, deg: boolean) => number> = {
  sqrt: (x) => Math.sqrt(x),
  abs: (x) => Math.abs(x),
  ln: (x) => Math.log(x),
  log: (x) => Math.log10(x),
  sin: (x, d) => Math.sin(d ? (x * Math.PI) / 180 : x),
  cos: (x, d) => Math.cos(d ? (x * Math.PI) / 180 : x),
  tan: (x, d) => Math.tan(d ? (x * Math.PI) / 180 : x),
};

/** A small recursive-descent evaluator: + − × ÷ ^ %, parentheses, functions, π and e. No eval. */
export function evaluate(input: string, deg = true): number {
  const src = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/π/g, "pi").replace(/\s+/g, "");
  let i = 0;
  const peek = () => src[i];
  const expect = (c: string) => {
    if (src[i] !== c) throw new Error(`Expected ${c}`);
    i++;
  };
  const primary = (): number => {
    const c = peek();
    if (c === "(") {
      i++;
      const v = expr();
      expect(")");
      return v;
    }
    if (c === "-") {
      i++;
      return -power();
    }
    if (c === "+") {
      i++;
      return power();
    }
    const num = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(src.slice(i));
    if (num) {
      i += num[0].length;
      return parseFloat(num[0]);
    }
    const id = /^[a-z]+/i.exec(src.slice(i));
    if (id) {
      const name = id[0].toLowerCase();
      i += id[0].length;
      if (name === "pi") return Math.PI;
      if (name === "e") return Math.E;
      const f = FUNCS[name];
      if (!f) throw new Error(`Unknown function ${name}`);
      expect("(");
      const v = expr();
      expect(")");
      return f(v, deg);
    }
    throw new Error("Unexpected input");
  };
  const postfix = (): number => {
    let v = primary();
    while (peek() === "%") {
      i++;
      v = v / 100;
    }
    return v;
  };
  const power = (): number => {
    const base = postfix();
    if (peek() === "^") {
      i++;
      return Math.pow(base, power());
    }
    return base;
  };
  const term = (): number => {
    let v = power();
    while (peek() === "*" || peek() === "/") {
      const op = src[i++];
      const r = power();
      v = op === "*" ? v * r : v / r;
    }
    return v;
  };
  const expr = (): number => {
    let v = term();
    while (peek() === "+" || peek() === "-") {
      const op = src[i++];
      const r = term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  };
  if (!src) throw new Error("Empty");
  const v = expr();
  if (i < src.length) throw new Error("Unexpected input");
  return v;
}

const showNum = (v: number) => (Number.isFinite(v) ? String(Number(v.toPrecision(12))) : v > 0 ? "∞" : v < 0 ? "-∞" : "Error");

function CalculatorTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ expr: string; deg: boolean; history: { e: string; r: string }[] }>(tool, { expr: "", deg: true, history: [] });
  let preview = "";
  try {
    preview = s.expr ? showNum(evaluate(s.expr, s.deg)) : "";
  } catch {
    preview = "";
  }
  const press = (k: string) => {
    if (k === "C") return set({ expr: "" });
    if (k === "⌫") return set({ expr: s.expr.slice(0, -1) });
    if (k === "=") {
      try {
        const r = showNum(evaluate(s.expr, s.deg));
        set({ expr: r === "Error" ? s.expr : r, history: [{ e: s.expr, r }, ...s.history].slice(0, 20) });
      } catch {
        useApp.getState().showToast("That expression isn't complete");
      }
      return;
    }
    set({ expr: s.expr + k });
  };
  const keys = ["C", "(", ")", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "⌫", "="];
  const fns = ["sqrt(", "^", "%", "π", "sin(", "cos(", "tan(", "log(", "ln(", "abs("];
  return (
    <div className="mx-auto max-w-sm px-4 pb-36 pt-6">
      <div className="rounded-3xl bg-card p-4 ring-1 ring-line">
        <input
          value={s.expr}
          onChange={(e) => set({ expr: e.target.value })}
          onKeyDown={(e) => e.key === "Enter" && press("=")}
          aria-label="Expression"
          inputMode="decimal"
          className="w-full bg-transparent text-right text-[28px] font-medium tabular-nums outline-none"
          placeholder="0"
        />
        <div className="h-6 text-right text-[16px] tabular-nums text-muted">{preview && preview !== s.expr ? `= ${preview}` : ""}</div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <div className="flex flex-wrap gap-1">
          {fns.map((f) => (
            <button key={f} onClick={() => press(f)} className="rounded-full px-2.5 py-1 text-[12px] font-medium ring-1 ring-line hover:bg-ink/[0.05]">
              {f.replace("(", "")}
            </button>
          ))}
        </div>
      </div>
      <button onClick={() => set({ deg: !s.deg })} className="mt-2 rounded-full px-2.5 py-1 text-[12px] font-semibold ring-1 ring-line hover:bg-ink/[0.05]">
        {s.deg ? "DEG" : "RAD"}
      </button>
      <div className="mt-3 grid grid-cols-4 gap-2">
        {keys.map((k) => (
          <button
            key={k}
            onClick={() => press(k)}
            className={cn(
              "h-14 rounded-2xl text-[20px] font-medium transition-colors active:scale-[0.97]",
              k === "=" ? "bg-ink text-white" : /[÷×−+]/.test(k) ? "bg-ink/10 hover:bg-ink/15" : "bg-ink/[0.04] hover:bg-ink/[0.08]"
            )}
          >
            {k}
          </button>
        ))}
      </div>
      {s.history.length > 0 && (
        <ul className="mt-5 divide-y divide-line rounded-2xl text-[13px] ring-1 ring-line">
          {s.history.map((h, i) => (
            <li key={i}>
              <button onClick={() => set({ expr: h.r })} className="flex w-full justify-between gap-3 px-3 py-2 text-left tabular-nums hover:bg-ink/[0.03]">
                <span className="truncate text-muted">{h.e}</span>
                <span className="font-medium">{h.r}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* --------------------------------------------------------- unit converter */

const UNITS: Record<string, Record<string, number>> = {
  Length: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344 },
  Mass: { mg: 1e-6, g: 0.001, kg: 1, t: 1000, oz: 0.028349523125, lb: 0.45359237 },
  Volume: { ml: 0.001, l: 1, "m³": 1000, tsp: 0.00492892, tbsp: 0.0147868, cup: 0.236588, "fl oz": 0.0295735, gal: 3.785411784 },
  Area: { "cm²": 1e-4, "m²": 1, ha: 1e4, "km²": 1e6, "ft²": 0.09290304, acre: 4046.8564224 },
  Speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704, knot: 0.514444 },
  Time: { s: 1, min: 60, h: 3600, day: 86400, week: 604800, year: 31557600 },
  Data: { B: 1, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1048576, GiB: 1073741824 },
  Temperature: { "°C": 1, "°F": 1, K: 1 },
};

function convertTemp(v: number, from: string, to: string) {
  const c = from === "°C" ? v : from === "°F" ? ((v - 32) * 5) / 9 : v - 273.15;
  return to === "°C" ? c : to === "°F" ? (c * 9) / 5 + 32 : c + 273.15;
}

function ConverterTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ cat: string; from: string; to: string; value: string }>(tool, { cat: "Length", from: "m", to: "ft", value: "1" });
  const units = Object.keys(UNITS[s.cat] ?? UNITS.Length);
  const v = parseFloat(s.value.replace(",", "."));
  const out = Number.isFinite(v) ? (s.cat === "Temperature" ? convertTemp(v, s.from, s.to) : (v * UNITS[s.cat][s.from]) / UNITS[s.cat][s.to]) : NaN;
  return (
    <div className="mx-auto max-w-md px-4 pb-36 pt-6">
      <div className="flex flex-wrap gap-1.5">
        {Object.keys(UNITS).map((c) => (
          <button
            key={c}
            onClick={() => {
              const u = Object.keys(UNITS[c]);
              set({ cat: c, from: u[0], to: u[1] ?? u[0] });
            }}
            className={cn("rounded-full px-3 py-1.5 text-[13px] font-medium ring-1 transition-colors", c === s.cat ? "bg-ink text-white ring-ink" : "ring-line hover:bg-ink/[0.05]")}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="mt-6 space-y-3 rounded-3xl bg-card p-4 ring-1 ring-line">
        <div className="flex gap-2">
          <input value={s.value} onChange={(e) => set({ value: e.target.value })} inputMode="decimal" aria-label="Value" className={cn(inputCls, "flex-1 text-[18px] tabular-nums")} />
          <select value={s.from} onChange={(e) => set({ from: e.target.value })} aria-label="From unit" className={cn(inputCls, "w-28")}>
            {units.map((u) => (
              <option key={u}>{u}</option>
            ))}
          </select>
        </div>
        <div className="flex justify-center">
          <button onClick={() => set({ from: s.to, to: s.from })} aria-label="Swap units" className="flex h-9 w-9 items-center justify-center rounded-full ring-1 ring-line hover:bg-ink/[0.05]">
            <ArrowLeftRight size={15} className="rotate-90" />
          </button>
        </div>
        <div className="flex gap-2">
          <output className={cn(inputCls, "flex flex-1 items-center text-[18px] font-semibold tabular-nums")} aria-live="polite">
            {Number.isFinite(out) ? showNum(out) : "—"}
          </output>
          <select value={s.to} onChange={(e) => set({ to: e.target.value })} aria-label="To unit" className={cn(inputCls, "w-28")}>
            {units.map((u) => (
              <option key={u}>{u}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- checklist */

type CheckItem = { id: string; text: string; done: boolean };

function ChecklistTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ items: CheckItem[] }>(tool, { items: [] });
  const [text, setText] = useState("");
  const done = s.items.filter((i) => i.done).length;
  const add = () => {
    const t = text.trim();
    if (!t) return;
    set({ items: [...s.items, { id: uid(), text: t.slice(0, 300), done: false }] });
    setText("");
  };
  return (
    <div className="mx-auto max-w-xl px-4 pb-36 pt-6">
      {s.items.length > 0 && (
        <div className="mb-4">
          <div className="mb-1.5 flex justify-between text-[13px] text-muted">
            <span>
              {done} of {s.items.length} done
            </span>
            {done > 0 && (
              <button onClick={() => set({ items: s.items.filter((i) => !i.done) })} className="font-medium hover:text-ink">
                Clear done
              </button>
            )}
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-ink/10">
            <div className="h-full rounded-full bg-ink transition-[width]" style={{ width: `${(done / s.items.length) * 100}%` }} />
          </div>
        </div>
      )}
      <ul className="space-y-1.5">
        {s.items.map((it) => (
          <li key={it.id} className="group flex items-center gap-3 rounded-2xl bg-card px-3 py-2.5 ring-1 ring-line">
            <button
              onClick={() => set({ items: s.items.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x)) })}
              aria-label={it.done ? `Mark “${it.text}” not done` : `Mark “${it.text}” done`}
              className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-lg ring-1 transition-colors", it.done ? "bg-ink text-white ring-ink" : "ring-ink/25 hover:bg-ink/[0.05]")}
            >
              {it.done && <Check size={14} strokeWidth={3} />}
            </button>
            <input
              value={it.text}
              onChange={(e) => set({ items: s.items.map((x) => (x.id === it.id ? { ...x, text: e.target.value } : x)) })}
              aria-label="Item text"
              dir="auto"
              className={cn("min-w-0 flex-1 bg-transparent text-[15px] outline-none", it.done && "text-muted line-through")}
            />
            <button onClick={() => set({ items: s.items.filter((x) => x.id !== it.id) })} aria-label={`Delete “${it.text}”`} className="rounded-lg p-1 text-muted opacity-60 hover:bg-danger-bg hover:text-danger-fg group-hover:opacity-100">
              <X size={15} />
            </button>
          </li>
        ))}
      </ul>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Add an item" aria-label="New checklist item" className={cn(inputCls, "flex-1")} dir="auto" />
        <Button type="submit" disabled={!text.trim()}>
          <Plus size={16} /> Add
        </Button>
      </form>
    </div>
  );
}

/* -------------------------------------------------------------- flash cards */

type FlashCard = { id: string; front: string; back: string; inSack: boolean };

function FlashcardsTool({ tool }: { tool: ToolItem }) {
  const [s, set] = useToolState<{ cards: FlashCard[] }>(tool, { cards: [] });
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [current, setCurrent] = useState<string | null>(null);
  const [flipped, setFlipped] = useState(false);
  const sack = s.cards.filter((c) => c.inSack);
  const card = s.cards.find((c) => c.id === current && c.inSack) ?? null;

  const draw = (exclude?: string) => {
    const pool = s.cards.filter((c) => c.inSack && c.id !== exclude);
    const from = pool.length ? pool : s.cards.filter((c) => c.inSack);
    setCurrent(from.length ? from[Math.floor(Math.random() * from.length)].id : null);
    setFlipped(false);
  };
  const gotIt = () => {
    if (!card) return;
    const cards = s.cards.map((c) => (c.id === card.id ? { ...c, inSack: false } : c));
    set({ cards });
    const pool = cards.filter((c) => c.inSack);
    setCurrent(pool.length ? pool[Math.floor(Math.random() * pool.length)].id : null);
    setFlipped(false);
  };

  return (
    <div className="mx-auto max-w-xl px-4 pb-36 pt-6">
      <div className="mb-3 flex items-center justify-between text-[13px] text-muted">
        <span>
          {sack.length} in the sack · {s.cards.length - sack.length} learned
        </span>
        {s.cards.length > 0 && sack.length < s.cards.length && (
          <button onClick={() => set({ cards: s.cards.map((c) => ({ ...c, inSack: true })) })} className="flex items-center gap-1 font-medium hover:text-ink">
            <RotateCcw size={13} /> Refill sack
          </button>
        )}
      </div>
      {card ? (
        <div>
          <button
            onClick={() => setFlipped((f) => !f)}
            className="flex min-h-[220px] w-full flex-col items-center justify-center rounded-3xl bg-card p-6 text-center shadow-[0_10px_30px_rgba(0,0,0,0.08)] ring-1 ring-line transition-transform active:scale-[0.99]"
            aria-label={flipped ? "Show front" : "Flip card"}
          >
            <span className="mb-3 text-[11px] font-semibold uppercase tracking-wide text-muted">{flipped ? "Back" : "Front"}</span>
            <span className="whitespace-pre-wrap text-[20px] font-medium leading-snug" dir="auto">
              {flipped ? card.back : card.front}
            </span>
            {!flipped && <span className="mt-4 text-[12px] text-muted">Tap to flip</span>}
          </button>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button size="lg" variant="soft" onClick={() => draw(card.id)}>
              <Shuffle size={16} /> Again later
            </Button>
            <Button size="lg" onClick={gotIt} disabled={!flipped}>
              <Check size={16} /> Got it
            </Button>
          </div>
        </div>
      ) : (
        <div className="rounded-3xl bg-ink/[0.035] p-6 text-center ring-1 ring-line">
          <Layers size={26} className="mx-auto text-muted" />
          <p className="mt-2 text-[14px] text-muted">{s.cards.length === 0 ? "Add a few cards below, then draw from the sack." : sack.length ? "Ready when you are." : "The sack is empty — you got them all. Refill it to go again."}</p>
          {sack.length > 0 && (
            <Button className="mt-3" onClick={() => draw()}>
              <Shuffle size={16} /> Draw a card
            </Button>
          )}
        </div>
      )}
      <form
        className="mt-6 space-y-2 rounded-2xl bg-card p-3 ring-1 ring-line"
        onSubmit={(e) => {
          e.preventDefault();
          if (!front.trim() || !back.trim()) return;
          set({ cards: [...s.cards, { id: uid(), front: front.trim(), back: back.trim(), inSack: true }] });
          setFront("");
          setBack("");
        }}
      >
        <div className="text-[13px] font-semibold">New card</div>
        <input value={front} onChange={(e) => setFront(e.target.value)} placeholder="Front (question)" aria-label="Card front" className={inputCls} dir="auto" />
        <input value={back} onChange={(e) => setBack(e.target.value)} placeholder="Back (answer)" aria-label="Card back" className={inputCls} dir="auto" />
        <Button type="submit" className="w-full" disabled={!front.trim() || !back.trim()}>
          <Plus size={16} /> Put in the sack
        </Button>
      </form>
      {s.cards.length > 0 && (
        <ul className="mt-4 divide-y divide-line rounded-2xl text-[13px] ring-1 ring-line">
          {s.cards.map((c) => (
            <li key={c.id} className="flex items-center gap-2 px-3 py-2">
              <span className={cn("h-2 w-2 shrink-0 rounded-full", c.inSack ? "bg-ink/30" : "bg-[#16a072]")} title={c.inSack ? "In the sack" : "Learned"} />
              <span className="min-w-0 flex-1 truncate" dir="auto">
                {c.front} <span className="text-muted">— {c.back}</span>
              </span>
              <button onClick={() => set({ cards: s.cards.filter((x) => x.id !== c.id) })} aria-label={`Delete card ${c.front}`} className="rounded-lg p-1 text-muted hover:bg-danger-bg hover:text-danger-fg">
                <X size={14} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* --------------------------------------------------------------- the page */

export default function ToolView({ project, toolId }: { project: Project; toolId: string }) {
  const tool = useLiveQuery(() => db.tools.get(toolId), [toolId], null as ToolItem | null | undefined);
  if (tool === null) return null;
  if (!tool || tool.projectId !== project.id)
    return (
      <Empty className="min-h-[60vh]" icon={<Layers />} title="Tool not found" text="It may have been removed from the library.">
        <Button onClick={() => navigate(projectPath(project.id))}>Back to library</Button>
      </Empty>
    );
  const remove = async () => {
    if (!(await confirmDeletion(`“${tool.title}” and what it saved will be removed from the library.`, { title: "Remove tool?", confirmLabel: "Remove" }))) return;
    navigate(projectPath(project.id), true);
    await db.tools.delete(tool.id);
  };
  return (
    <div className="h-full">
      <PaneBar>
        <div className="flex min-w-[6rem] flex-1 basis-[6rem] items-center gap-2 px-1.5">
          <span className="text-muted">{TOOL_ICON[tool.kind](17)}</span>
          <div className="min-w-0">
            <div className="truncate text-[14px] font-semibold">{tool.title}</div>
            <div className="truncate text-[12px] text-muted">{TOOL_META[tool.kind].desc}</div>
          </div>
        </div>
        <button onClick={() => void remove()} aria-label="Remove tool" title="Remove tool" className="flex h-9 w-9 items-center justify-center rounded-lg text-muted transition-colors hover:bg-danger-bg hover:text-danger-fg">
          <Trash2 size={16} />
        </button>
      </PaneBar>
      {tool.kind === "clock" && <ClockTool key={tool.id} tool={tool} />}
      {tool.kind === "calculator" && <CalculatorTool key={tool.id} tool={tool} />}
      {tool.kind === "converter" && <ConverterTool key={tool.id} tool={tool} />}
      {tool.kind === "checklist" && <ChecklistTool key={tool.id} tool={tool} />}
      {tool.kind === "flashcards" && <FlashcardsTool key={tool.id} tool={tool} />}
    </div>
  );
}
