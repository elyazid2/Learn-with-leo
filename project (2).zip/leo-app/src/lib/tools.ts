import { db, uid, type ToolItem, type ToolKind } from "./db";

export const TOOL_META: Record<ToolKind, { title: string; desc: string }> = {
  clock: { title: "Clock", desc: "Pomodoro, stopwatch and countdown" },
  calculator: { title: "Calculator", desc: "Arithmetic, powers, roots and trig" },
  converter: { title: "Unit converter", desc: "Length, mass, temperature, volume and more" },
  checklist: { title: "Checklist", desc: "Tick off tasks as you go" },
  flashcards: { title: "Flash cards", desc: "A sack of cards to draw and study" },
};

export const TOOL_KINDS = Object.keys(TOOL_META) as ToolKind[];
export const isToolKind = (v: unknown): v is ToolKind => typeof v === "string" && v in TOOL_META;

export interface ToolSeed {
  title?: string;
  items?: string[];
  cards?: { front: string; back: string }[];
}

/** Add a tool to a project's library. Tools never run until they are added like this. */
export async function createTool(projectId: string, kind: ToolKind, seed: ToolSeed = {}): Promise<ToolItem> {
  const now = Date.now();
  const state: Record<string, unknown> = {};
  if (kind === "checklist") state.items = (seed.items ?? []).slice(0, 100).map((text) => ({ id: uid(), text: text.slice(0, 300), done: false }));
  if (kind === "flashcards")
    state.cards = (seed.cards ?? []).slice(0, 300).map((c) => ({ id: uid(), front: c.front.slice(0, 500), back: c.back.slice(0, 1000), inSack: true }));
  const tool: ToolItem = { id: uid(), projectId, kind, title: seed.title?.trim().slice(0, 120) || TOOL_META[kind].title, state, createdAt: now, updatedAt: now };
  await db.tools.add(tool);
  await db.projects.update(projectId, { updatedAt: now });
  return tool;
}

export async function saveToolState(id: string, state: Record<string, unknown>) {
  await db.tools.update(id, { state, updatedAt: Date.now() });
}
