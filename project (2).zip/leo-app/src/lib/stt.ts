import { useSettings } from "./settings";

/**
 * Speech-to-text through the learner's own local Whisper server (Settings → Speech to text), or a
 * clearly labelled Demo stream that never touches the network. Nothing here saves or sends text
 * anywhere: callers show an editable preview first and only act on what the learner confirms.
 */

export interface SttSegment {
  t0: number;
  t1: number;
  text: string;
}

export interface SttResult {
  text: string;
  /** Timed segments when the server returned them (verbose_json). */
  segments?: SttSegment[];
  demo: boolean;
}

export const DEMO_SAMPLES = [
  "This is demo text, not a real transcript. The quick brown fox jumps over the lazy dog while the learner checks that the preview streams word by word.",
  "Demo transcript: photosynthesis turns light energy into chemical energy. Chlorophyll absorbs mostly blue and red light, and the plant releases oxygen as a by-product.",
  "Demo mode is on. Today I want to review the difference between mitosis and meiosis, then quiz myself on the stages before the exam next week.",
];

export const sttDemo = () => useSettings.getState().demoTranscription;
export const sttConfigured = () => sttDemo() || !!useSettings.getState().whisperUrl.trim();

/** The URL as entered; a bare host gets the OpenAI-compatible path most local servers expose. */
export function whisperEndpoint(raw: string): string {
  const url = raw.trim().replace(/\/+$/, "");
  if (!url) return "";
  try {
    const u = new URL(url);
    if (u.pathname === "" || u.pathname === "/") return `${url}/v1/audio/transcriptions`;
    if (/\/v1$/.test(u.pathname)) return `${url}/audio/transcriptions`;
  } catch {
    /* validated by the caller */
  }
  return url;
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = window.setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      window.clearTimeout(t);
      reject(new DOMException("Aborted", "AbortError"));
    });
  });

/** Demo: after a short "thinking" delay, emit sample text one word at a time. */
async function streamDemo(onPartial: (text: string) => void, signal?: AbortSignal, duration?: number): Promise<SttResult> {
  const sample = DEMO_SAMPLES[Math.floor(Math.random() * DEMO_SAMPLES.length)];
  const words = sample.split(/\s+/);
  await sleep(700, signal);
  let text = "";
  for (const w of words) {
    text = text ? `${text} ${w}` : w;
    onPartial(text);
    await sleep(55 + Math.random() * 70, signal);
  }
  const total = duration && duration > 0 ? duration : words.length * 0.4;
  return { text, demo: true, segments: [{ t0: 0, t1: total, text }] };
}

function extOf(type: string) {
  if (type.includes("wav")) return "wav";
  if (type.includes("ogg")) return "ogg";
  if (type.includes("mp4") || type.includes("m4a") || type.includes("aac")) return "m4a";
  if (type.includes("mpeg") || type.includes("mp3")) return "mp3";
  return "webm";
}

async function postWhisper(endpoint: string, blob: Blob, format: "verbose_json" | "json", signal?: AbortSignal): Promise<Response> {
  const form = new FormData();
  form.append("file", blob, `audio.${extOf(blob.type)}`);
  form.append("model", "whisper-1");
  form.append("response_format", format);
  form.append("temperature", "0");
  return fetch(endpoint, { method: "POST", body: form, signal });
}

function parseWhisper(body: string): { text: string; segments?: SttSegment[] } {
  try {
    const data = JSON.parse(body) as { text?: unknown; segments?: unknown; transcription?: unknown };
    const segments = Array.isArray(data.segments)
      ? (data.segments as { start?: unknown; end?: unknown; text?: unknown }[])
          .filter((s) => typeof s.text === "string")
          .map((s) => ({ t0: Number(s.start) || 0, t1: Number(s.end) || 0, text: String(s.text).trim() }))
          .filter((s) => s.text)
      : undefined;
    const text = typeof data.text === "string" ? data.text : segments?.map((s) => s.text).join(" ") ?? "";
    return { text: text.trim(), segments: segments?.length ? segments : undefined };
  } catch {
    return { text: body.trim() };
  }
}

/**
 * Transcribe one clip. `onPartial` receives text as it becomes available (word by word in Demo
 * mode, once at the end from a server). Throws with a readable message when the server fails.
 */
export async function transcribeClip(blob: Blob, onPartial: (text: string) => void, signal?: AbortSignal, duration?: number): Promise<SttResult> {
  if (sttDemo()) return streamDemo(onPartial, signal, duration);
  const endpoint = whisperEndpoint(useSettings.getState().whisperUrl);
  if (!endpoint) throw new Error("Add your Whisper server URL in Settings → Speech to text, or turn on Demo mode");
  try {
    new URL(endpoint);
  } catch {
    throw new Error("The Whisper server URL in Settings isn't a valid address");
  }
  let res: Response;
  try {
    res = await postWhisper(endpoint, blob, "verbose_json", signal);
    // Some servers only know "json": try once more with the plain format.
    if (!res.ok && res.status !== 404) res = await postWhisper(endpoint, blob, "json", signal);
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new Error(`Couldn't reach the Whisper server at ${endpoint}. Is it running, and does it allow this page (CORS)?`);
  }
  const body = await res.text();
  if (!res.ok) throw new Error(`Whisper server answered ${res.status}${body ? `: ${body.slice(0, 140)}` : ""}`);
  const out = parseWhisper(body);
  onPartial(out.text);
  return { ...out, demo: false };
}

/* ------------------------------------------------------------- microphone */

export interface MicSession {
  /** Stop and get the recording. */
  stop: () => Promise<Blob>;
  cancel: () => void;
  startedAt: number;
}

/** Start recording from the microphone. In Demo mode no microphone is needed. */
export async function startMic(): Promise<MicSession> {
  const startedAt = Date.now();
  if (sttDemo() && !navigator.mediaDevices?.getUserMedia) {
    return { stop: async () => new Blob([], { type: "audio/webm" }), cancel: () => {}, startedAt };
  }
  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (e) {
    if (sttDemo()) return { stop: async () => new Blob([], { type: "audio/webm" }), cancel: () => {}, startedAt };
    throw new Error((e as Error).name === "NotAllowedError" ? "Microphone access was blocked" : "No microphone available");
  }
  const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"].find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m));
  const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const parts: BlobPart[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size) parts.push(e.data);
  };
  rec.start(250);
  const release = () => stream.getTracks().forEach((t) => t.stop());
  return {
    startedAt,
    stop: () =>
      new Promise<Blob>((resolve) => {
        rec.onstop = () => {
          release();
          resolve(new Blob(parts, { type: rec.mimeType || "audio/webm" }));
        };
        if (rec.state === "inactive") {
          release();
          resolve(new Blob(parts, { type: rec.mimeType || "audio/webm" }));
        } else rec.stop();
      }),
    cancel: () => {
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
      release();
    },
  };
}
