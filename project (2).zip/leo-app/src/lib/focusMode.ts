import { create } from "zustand";

/**
 * Focus mode: one button, the F key or a two-finger tap hides everything except the item that is
 * open. The same button / key / gesture brings the interface back.
 */
interface FocusModeStore {
  on: boolean;
  toggle: () => void;
  set: (on: boolean) => void;
}

export const useFocusMode = create<FocusModeStore>((set, get) => ({
  on: false,
  toggle: () => set({ on: !get().on }),
  set: (on) => set({ on }),
}));

useFocusMode.subscribe((s) => {
  if (typeof document === "undefined") return;
  if (s.on) document.documentElement.setAttribute("data-focus-mode", "");
  else document.documentElement.removeAttribute("data-focus-mode");
});
