import { useEffect, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeft, ArrowRightLeft, StickyNote, Trash2 } from "lucide-react";
import { db, uid, type ScratchItem } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { scratchToNote } from "@/lib/organize";
import { timeAgo } from "@/lib/media";
import { useApp } from "@/lib/store";
import { Button, Empty, IconBtn, Sheet } from "@/components/ui";
import ProjectAvatar from "@/components/ProjectAvatar";
import { MicButton } from "@/components/stt/Dictation";

/** One cross-project place for loose thoughts. Items can be moved into a project as notes later. */
export default function Scratchpad() {
  const items = useLiveQuery(() => db.scratch.orderBy("updatedAt").reverse().toArray(), []);
  const [text, setText] = useState("");
  const [moving, setMoving] = useState<ScratchItem | null>(null);
  const ta = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!("ontouchstart" in window)) ta.current?.focus();
  }, []);

  const add = async (value = text) => {
    const t = value.trim();
    if (!t) return;
    const now = Date.now();
    await db.scratch.add({ id: uid(), text: t.slice(0, 20000), createdAt: now, updatedAt: now });
    setText("");
  };

  return (
    <div className="mx-auto min-h-full max-w-2xl px-5 pb-24 pt-[max(env(safe-area-inset-top),16px)]">
      <header className="flex items-center gap-2 py-3">
        <IconBtn onClick={() => (history.length > 1 ? history.back() : navigate(""))} aria-label="Back">
          <ArrowLeft size={19} />
        </IconBtn>
        <h1 className="display text-[27px] leading-none">Scratchpad</h1>
      </header>
      <p className="mb-4 text-[13px] text-muted">Loose thoughts from anywhere. Move one into a project when it finds a home.</p>

      <div className="rounded-2xl bg-card p-3 ring-1 ring-line">
        <textarea
          ref={ta}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !("ontouchstart" in window)) {
              e.preventDefault();
              void add();
            }
          }}
          rows={3}
          dir="auto"
          placeholder="Jot something down…"
          aria-label="New scratchpad thought"
          className="w-full resize-none bg-transparent text-[16px] leading-relaxed outline-none placeholder:text-muted/80"
        />
        <div className="flex items-center justify-end gap-1">
          <MicButton context="Scratchpad" confirmLabel="Add to text" onConfirm={(t) => setText((v) => (v.trim() ? `${v.trimEnd()} ${t}` : t))} />
          <Button onClick={() => void add()} disabled={!text.trim()}>
            Save thought
          </Button>
        </div>
      </div>

      {items && items.length === 0 && <Empty className="mt-10" icon={<StickyNote />} title="Nothing here yet" text="Ideas, questions, things to look up later — they all fit." />}

      <ul className="mt-5 space-y-2">
        {(items ?? []).map((it) => (
          <ScratchRow key={it.id} item={it} onMove={() => setMoving(it)} />
        ))}
      </ul>

      <MoveSheet item={moving} onClose={() => setMoving(null)} />
    </div>
  );
}

function ScratchRow({ item, onMove }: { item: ScratchItem; onMove: () => void }) {
  const [value, setValue] = useState(item.text);
  useEffect(() => setValue(item.text), [item.text]);
  const save = async () => {
    const t = value.trim();
    if (!t) return setValue(item.text);
    if (t !== item.text) await db.scratch.update(item.id, { text: t, updatedAt: Date.now() });
  };
  return (
    <li className="group rounded-2xl bg-card p-3 ring-1 ring-line">
      <textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={() => void save()}
        rows={Math.min(8, Math.max(1, value.split("\n").length))}
        dir="auto"
        aria-label="Scratchpad thought"
        className="w-full resize-none bg-transparent text-[15px] leading-relaxed outline-none"
      />
      <div className="mt-1 flex items-center gap-1 text-[12px] text-muted">
        <span className="flex-1 tabular-nums">{timeAgo(item.updatedAt)}</span>
        <button onClick={onMove} className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-ink/80 ring-1 ring-line hover:bg-ink/[0.05]">
          <ArrowRightLeft size={12} /> Move to project
        </button>
        <button onClick={() => void db.scratch.delete(item.id)} aria-label="Delete thought" className="rounded-full p-1.5 hover:bg-danger-bg hover:text-danger-fg">
          <Trash2 size={14} />
        </button>
      </div>
    </li>
  );
}

function MoveSheet({ item, onClose }: { item: ScratchItem | null; onClose: () => void }) {
  const projects = useLiveQuery(() => db.projects.orderBy("updatedAt").reverse().toArray(), []);
  const move = async (projectId: string, open: boolean) => {
    if (!item) return;
    const note = await scratchToNote(item.id, projectId);
    onClose();
    if (!note) return;
    useApp.getState().showToast(`Moved to ${projects?.find((p) => p.id === projectId)?.name ?? "project"} as a note`, { tone: "success" });
    if (open) navigate(projectPath(projectId, "notes", note.id));
  };
  return (
    <Sheet open={!!item} onClose={onClose} title="Move to a project" description="It becomes a note in that project and leaves the scratchpad.">
      {projects && projects.length === 0 && <p className="text-[14px] text-muted">Create a project first.</p>}
      <ul className="max-h-[50dvh] divide-y divide-line overflow-y-auto rounded-2xl ring-1 ring-line">
        {(projects ?? []).map((p) => (
          <li key={p.id} className="flex items-center gap-3 px-3 py-2.5">
            <ProjectAvatar project={p} size={32} />
            <span className="min-w-0 flex-1 truncate text-[14px] font-medium">{p.name}</span>
            <Button size="sm" variant="soft" onClick={() => void move(p.id, false)}>
              Move
            </Button>
            <Button size="sm" onClick={() => void move(p.id, true)}>
              Move & open
            </Button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}
