import { redirect } from "next/navigation";

/**
 * Learn with Leo (Harness) is a local-first, single-file Vite app that lives in `leo-app/` and is
 * built unchanged with its own `vite build`. The built `index.html` is served statically from
 * `public/leo/`; this shell only points the preview at it.
 */
export default function HomePage() {
  redirect("/leo/index.html");
}
