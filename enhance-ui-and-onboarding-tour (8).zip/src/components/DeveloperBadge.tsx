import { useSettings } from "@/lib/settings";
import { useApp } from "@/lib/store";
import { NARROW, effectiveDock, useLayout } from "@/lib/layout";

export default function DeveloperBadge() {
  const active = useSettings((s) => s.developerMode);
  const chatOpen = useApp((s) => s.chatOpen);
  const dock = useLayout((s) => effectiveDock(s.tempDock ?? s.chatDock, window.innerWidth < NARROW));
  // A chat docked on the left, below or fullscreen sits where the badge would be.
  if (!active || (chatOpen && dock !== "float" && dock !== "right")) return null;
  return (
    <div className="pointer-events-none fixed bottom-[calc(max(env(safe-area-inset-bottom),12px)+76px)] left-3 z-40 rounded-full bg-ink px-2.5 py-1 text-[11px] font-semibold text-white shadow-lg">
      Dev · local mock
    </div>
  );
}
