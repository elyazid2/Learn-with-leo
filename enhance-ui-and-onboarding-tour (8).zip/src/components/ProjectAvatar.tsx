import type { Project } from "@/lib/db";
import { iconComponent, iconOf } from "@/lib/projectIcon";
import { cn } from "@/utils/cn";

type Iconish = Pick<Project, "icon" | "tag" | "name"> & { color?: string };

/** Project badge: a minimal line icon on a neutral tile, or an uploaded image/logo. No color tint. */
export default function ProjectAvatar({ project, size = 36, className }: { project: Iconish; size?: number; animate?: boolean; className?: string }) {
  const icon = iconOf(project);
  const radius = size >= 40 ? "rounded-2xl" : "rounded-xl";
  if (icon.kind === "image")
    return (
      <img
        src={icon.src}
        alt=""
        aria-hidden
        draggable={false}
        className={cn("shrink-0 select-none bg-card object-cover ring-1 ring-line", radius, className)}
        style={{ width: size, height: size }}
      />
    );
  const Glyph = iconComponent(icon.name);
  return (
    <div
      aria-hidden
      className={cn("flex shrink-0 select-none items-center justify-center bg-ink/[0.045] text-ink ring-1 ring-inset ring-line", radius, className)}
      style={{ width: size, height: size }}
    >
      <Glyph size={Math.round(size * 0.5)} strokeWidth={size >= 48 ? 1.6 : 1.8} />
    </div>
  );
}
