import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, Layers, X } from "lucide-react";
import { db, type Card } from "@/lib/db";
import { answerCard, dueCards } from "@/lib/cards";
import { Markdown } from "./Markdown";
import { Button } from "./ui";
import { cn } from "@/utils/cn";

const LETTERS = "ABCDEFGH";

/** Review saved quiz cards that are due — served straight from the database, no LLM call. */
export default function ReviewCards({ projectId }: { projectId: string }) {
  const total = useLiveQuery(() => db.cards.where("projectId").equals(projectId).count(), [projectId]) ?? 0;
  const dueCount = useLiveQuery(() => db.cards.where("projectId").equals(projectId).filter((c) => c.nextReview <= Date.now()).count(), [projectId]) ?? 0;
  const [queue, setQueue] = useState<Card[] | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState({ right: 0, done: 0 });

  if (!total) return null;
  const card = queue?.[0];

  const start = async () => {
    setQueue(await dueCards(projectId));
    setPicked(null);
    setScore({ right: 0, done: 0 });
  };
  const choose = async (i: number) => {
    if (!card || picked !== null) return;
    setPicked(i);
    const ok = await answerCard(card, i);
    setScore((s) => ({ right: s.right + (ok ? 1 : 0), done: s.done + 1 }));
  };
  const next = () => {
    setQueue((q) => (q ? q.slice(1) : q));
    setPicked(null);
  };

  return (
    <section className="rounded-2xl bg-card p-4 ring-1 ring-line">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Layers size={16} className="text-muted" />
          <div>
            <div className="text-[14px] font-semibold">Review cards</div>
            <div className="text-[12px] text-muted">
              {dueCount} due · {total} saved from Leo's quizzes
            </div>
          </div>
        </div>
        {!queue && (
          <Button size="sm" onClick={() => void start()} disabled={!dueCount}>
            Review
          </Button>
        )}
        {queue && (
          <Button size="sm" variant="ghost" onClick={() => setQueue(null)}>
            Close
          </Button>
        )}
      </div>

      {queue && !card && (
        <p className="mt-3 text-[14px]">
          {score.done ? `Done — ${score.right}/${score.done} correct. Your map and review schedule were updated.` : "Nothing due right now."}
        </p>
      )}

      {card && (
        <div className="mt-3">
          <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-muted">
            {card.concept}
            {card.source ? ` · ${card.source}` : ""}
          </div>
          <Markdown className="text-[14.5px]">{card.question}</Markdown>
          <div className="mt-2 space-y-1.5">
            {card.options.map((o, i) => {
              const isAnswer = picked !== null && i === card.answer;
              const isWrong = picked === i && i !== card.answer;
              return (
                <button
                  key={i}
                  onClick={() => void choose(i)}
                  disabled={picked !== null}
                  className={cn(
                    "flex w-full items-start gap-2 rounded-xl px-3 py-2 text-left text-[14px] ring-1 ring-line",
                    isAnswer && "bg-emerald-50 ring-emerald-300",
                    isWrong && "bg-rose-50 ring-rose-300",
                    picked === null && "hover:bg-black/[0.03]"
                  )}
                >
                  <span className="font-semibold text-muted">{LETTERS[i]}</span>
                  <span className="min-w-0 flex-1">{o}</span>
                  {isAnswer && <Check size={15} className="text-emerald-600" />}
                  {isWrong && <X size={15} className="text-rose-600" />}
                </button>
              );
            })}
          </div>
          {picked !== null && (
            <div className="mt-2">
              {card.explanation && <Markdown className="text-[13px] text-muted">{card.explanation}</Markdown>}
              <Button size="sm" className="mt-2" onClick={next}>
                Next ({queue!.length - 1} left)
              </Button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
