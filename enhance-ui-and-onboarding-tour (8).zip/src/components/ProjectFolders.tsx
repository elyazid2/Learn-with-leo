import { useEffect, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, ChevronRight, Folder, FolderInput, House, Loader2, Trash2 } from "lucide-react";
import { db, type Project, type ProjectFolder } from "@/lib/db";
import { createProjectFolder, deleteProjectFolder, moveProject, renameProjectFolder } from "@/lib/projectFolders";
import { useApp } from "@/lib/store";
import { confirmDialog } from "@/lib/confirm";
import { Button, Field, Sheet, inputCls } from "./ui";
import { cn } from "@/utils/cn";

export function FolderEditSheet({ open, folder, onClose, onSaved, onDeleted }: {
  open: boolean;
  folder?: ProjectFolder;
  onClose: () => void;
  onSaved?: (folder: ProjectFolder) => void;
  onDeleted?: () => void;
}) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const wasOpen = useRef(false);
  useEffect(() => {
    if (open && !wasOpen.current) { setName(folder?.name ?? ""); setError(""); }
    wasOpen.current = open;
  }, [open, folder]);
  const save = async () => {
    if (!name.trim() || lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      if (folder) {
        await renameProjectFolder(folder.id, name);
        onSaved?.({ ...folder, name: name.trim(), updatedAt: Date.now() });
      } else {
        const created = await createProjectFolder(name);
        onSaved?.(created);
      }
      useApp.getState().showToast(folder ? "Folder renamed" : "Folder created", { tone: "success" });
      onClose();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { lock.current = false; setBusy(false); }
  };
  const remove = async () => {
    if (!folder || lock.current) return;
    if (!(await confirmDialog({ title: `Delete "${folder.name}"?`, message: "Only the folder is removed. All its projects return to the home screen; nothing inside the projects is deleted.", confirmLabel: "Delete folder", tone: "danger" }))) return;
    lock.current = true;
    setBusy(true);
    try {
      const count = await deleteProjectFolder(folder.id);
      useApp.getState().showToast(`Folder deleted${count ? `; ${count} ${count === 1 ? "project returned" : "projects returned"} to home` : ""}`);
      onDeleted?.();
      onClose();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { lock.current = false; setBusy(false); }
  };
  return (
    <Sheet open={open} onClose={onClose} title={folder ? "Edit folder" : "New folder"} description={folder ? "Rename or remove this folder. Its projects are always kept." : "Keep related projects together. Folders have one level only."}
      footer={<div className="flex gap-2">
        <Button size="lg" className="flex-1" disabled={!name.trim() || busy} onClick={() => void save()}>{busy ? <Loader2 size={16} className="animate-spin" /> : <Folder size={16} />}{folder ? "Save name" : "Create folder"}</Button>
        {folder && <Button size="lg" variant="danger" disabled={busy} onClick={() => void remove()} aria-label="Delete folder"><Trash2 size={16} /></Button>}
      </div>}>
      <Field label="Folder name"><input autoFocus className={inputCls} value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.nativeEvent.isComposing) { e.preventDefault(); void save(); } }} maxLength={80} placeholder="e.g. Languages or This semester" /></Field>
      {error && <p role="alert" className="mt-3 text-[13px] text-danger-fg">{error}</p>}
    </Sheet>
  );
}

export function MoveProjectSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const folders = useLiveQuery(() => db.projectFolders.orderBy("name").toArray(), []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const lock = useRef(false);
  const move = async (folderId: string | null) => {
    if (lock.current) return;
    if ((project.folderId ?? null) === folderId) return onClose();
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      await moveProject(project.id, folderId);
      const label = folders?.find((f) => f.id === folderId)?.name;
      useApp.getState().showToast(label ? `Moved to ${label}` : "Moved to home", { tone: "success" });
      onClose();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { lock.current = false; setBusy(false); }
  };
  const choices = [{ id: null, name: "Home", hint: "Not in a folder" }, ...(folders ?? []).map((f) => ({ id: f.id, name: f.name, hint: "Project folder" }))];
  return (
    <Sheet open={open} onClose={onClose} title="Move project" description={`Choose where "${project.name}" belongs.`}>
      <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-card ring-1 ring-line">
        {choices.map((f) => {
          const active = f.id === (project.folderId ?? null);
          return <li key={f.id ?? "home"}><button type="button" disabled={busy} onClick={() => void move(f.id)} aria-pressed={active} className={cn("flex w-full items-center gap-3 px-3.5 py-3 text-left transition-colors disabled:opacity-50", active ? "bg-ink/[0.05]" : "hover:bg-ink/[0.035]")}>
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-ink/75">{f.id ? <Folder size={18} /> : <House size={18} />}</span>
            <span className="min-w-0 flex-1"><span className="block truncate text-[14px] font-medium">{f.name}</span><span className="block text-[12px] text-muted">{f.hint}</span></span>
            {active && <Check size={17} className="shrink-0" />}
          </button></li>;
        })}
      </ul>
      {folders?.length === 0 && <p className="mt-3 text-[12px] text-muted">Create a folder on the home screen first.</p>}
      {error && <p role="alert" className="mt-3 text-[13px] text-danger-fg">{error}</p>}
    </Sheet>
  );
}

export function ProjectFolderRow({ project, onClick }: { project: Project; onClick: () => void }) {
  const folder = useLiveQuery(() => project.folderId ? db.projectFolders.get(project.folderId) : undefined, [project.folderId]);
  return <button type="button" onClick={onClick} className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.035]">
    <FolderInput size={18} className="shrink-0 text-muted" />
    <span className="min-w-0 flex-1"><span className="block text-[14px] font-medium">Move to folder</span><span className="block truncate text-[12px] text-muted">{folder?.name ?? "Home (not in a folder)"}</span></span>
    <ChevronRight size={16} className="text-muted" />
  </button>;
}

export function ProjectMenuSheet({ project, onClose }: { project: Project | null; onClose: () => void }) {
  const [moving, setMoving] = useState(false);
  useEffect(() => { if (!project) setMoving(false); }, [project]);
  return <>
    <Sheet open={!!project && !moving} onClose={onClose} title={project?.name} description="Organize this project without changing its contents.">
      {project && <ProjectFolderRow project={project} onClick={() => setMoving(true)} />}
    </Sheet>
    {project && <MoveProjectSheet project={project} open={moving} onClose={() => { setMoving(false); onClose(); }} />}
  </>;
}
