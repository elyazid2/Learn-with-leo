import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  /** Short label for what this boundary wraps ("message", "screen"). */
  scope?: string;
  /** Compact inline fallback (for list items) vs. a full card. */
  inline?: boolean;
  /** Reset the boundary when this key changes (e.g. route). */
  resetKey?: string;
}

interface State {
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(`[${this.props.scope ?? "ui"}]`, error, info.componentStack);
  }

  componentDidUpdate(prev: Props) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null });
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    if (this.props.inline) {
      return (
        <div className="rounded-xl bg-danger-bg px-3 py-2 text-[12px] text-danger-fg" role="alert">
          This {this.props.scope ?? "item"} couldn't be displayed ({error.message.slice(0, 120)}).
        </div>
      );
    }
    return (
      <div className="mx-auto flex min-h-[60dvh] max-w-md flex-col items-center justify-center p-6 text-center" role="alert">
        <h2 className="display text-[22px]">Something went wrong</h2>
        <p className="mt-2 text-sm text-muted">{error.message.slice(0, 300)}</p>
        <div className="mt-4 flex justify-center gap-2">
          <button onClick={() => this.setState({ error: null })} className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-white">
            Try again
          </button>
          <button
            onClick={() => {
              location.hash = "";
              location.reload();
            }}
            className="rounded-full bg-ink/[0.06] px-4 py-2 text-sm font-medium"
          >
            Go home
          </button>
        </div>
        <p className="mt-3 text-[12px] text-muted">Your data is safe — it lives in this device's database, not in this screen.</p>
      </div>
    );
  }
}
