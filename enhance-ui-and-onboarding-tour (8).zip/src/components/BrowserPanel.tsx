import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, ArrowRight, BookmarkPlus, BookOpenText, CirclePlay, Columns2, ExternalLink, Globe2, Loader2, Puzzle, RefreshCw, Sparkles, TriangleAlert, X } from "lucide-react";
import { db, setKV, uid } from "@/lib/db";
import { useApp } from "@/lib/store";
import { DEFAULT_PREFS, hostOf, refusesEmbedding, safeUrl, useBrowser, youtubeRef, type BrowserPrefs, type YouTubeRef } from "@/lib/browser";
import { readPage, type ReadResult } from "@/lib/reader";
import { NARROW, useLayout } from "@/lib/layout";
import { useRoute } from "@/lib/router";
import { Button, IconBtn } from "@/components/ui";
import YouTubePlayer from "@/components/YouTubePlayer";
import { cn } from "@/utils/cn";

/**
 * The learning browser. There is no server behind this app, so pages load straight from their own
 * sites in a sandboxed frame (it cannot navigate the app away or reach your library), and YouTube
 * links play in the app's own clean player. Leo reads a page when its site allows other pages to
 * fetch it; a site that refuses to be framed gets a clear message with ways forward.
 */

const START = [
  ["Wikipedia", "https://en.m.wikipedia.org/wiki/Special:Random"],
  ["Khan Academy", "https://www.khanacademy.org/"],
  ["OpenStax", "https://openstax.org/subjects"],
  ["Project Gutenberg", "https://www.gutenberg.org/"],
] as const;

const ADDONS: { key: keyof BrowserPrefs; name: string; hosts: string; description: string }[] = [
  { key: "cleanYoutube", name: "YouTube Focus", hosts: "youtube.com, youtu.be", description: "Video links play in a clean player: no recommendations, no comments, no YouTube controls. Just the video." },
  { key: "reader", name: "Quiet article", hosts: "*", description: "Opens a page as plain text when its site can be read: no sidebars, banners or cookie bars." },
  { key: "night", name: "Night reading", hosts: "*", description: "Inverts bright pages for late-night study." },
];

/** Paste (or type) a YouTube link and play it. */
function YouTubePrompt({ onPlay, autoFocus }: { onPlay: (url: string) => void; autoFocus?: boolean }) {
  const [value, setValue] = useState("");
  const url = safeUrl(value);
  const ok = !!url && !!youtubeRef(url);
  const paste = async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) return;
      setValue(text);
      const u = safeUrl(text);
      if (u && youtubeRef(u)) onPlay(u);
    } catch {
      useApp.getState().showToast("Paste the link into the box instead");
    }
  };
  return (
    <form
      className="flex items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (ok && url) onPlay(url);
      }}
    >
      <div className="relative min-w-0 flex-1">
        <CirclePlay size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
        <input
          autoFocus={autoFocus}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onPaste={(e) => {
            const text = e.clipboardData.getData("text").trim();
            const u = safeUrl(text);
            if (u && youtubeRef(u)) {
              e.preventDefault();
              onPlay(u);
            }
          }}
          aria-label="YouTube link"
          placeholder="Paste a YouTube link"
          enterKeyHint="go"
          className="h-10 w-full rounded-full bg-ink/[0.05] pl-10 pr-3 text-[16px] outline-none ring-1 ring-transparent focus:ring-ink/20"
        />
      </div>
      <Button type="button" variant="soft" onClick={() => void paste()}>
        Paste
      </Button>
      <Button type="submit" disabled={!ok}>
        Play
      </Button>
    </form>
  );
}

/** A YouTube link: the video in the clean player, with its title for Leo. */
function VideoStage({ url, video, clean, foot }: { url: string; video: YouTubeRef; clean: boolean; foot: HTMLElement | null }) {
  const setBrowser = useApp((s) => s.setBrowser);
  const [meta, setMeta] = useState<{ title: string; author: string } | null>(null);

  useEffect(() => {
    const ac = new AbortController();
    setMeta(null);
    fetch(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(`https://www.youtube.com/watch?v=${video.id}`)}`, { signal: ac.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { title?: string; author_name?: string } | null) => {
        if (!j?.title || ac.signal.aborted) return;
        const next = { title: String(j.title).slice(0, 300), author: String(j.author_name ?? "").slice(0, 120) };
        setMeta(next);
        // Leo cannot watch video; he is told what is playing so questions about it make sense.
        setBrowser({
          url,
          title: next.title,
          text: `YouTube video "${next.title}"${next.author ? ` by ${next.author}` : ""}. You cannot watch or hear it; ask the learner what part they need help with.`,
          capturedAt: Date.now(),
        });
        void setKV("browser.current", { url, title: next.title });
      })
      .catch(() => {});
    return () => ac.abort();
  }, [url, video.id, setBrowser]);

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-4xl px-3 pb-6 pt-4">
        <YouTubePlayer key={video.id} id={video.id} start={video.start} vertical={video.vertical} clean={clean} title={meta?.title} />
        {meta && (
          <div className="mt-3 px-1">
            <h2 className="display text-[19px] leading-snug" dir="auto">
              {meta.title}
            </h2>
            {meta.author && <div className="mt-0.5 text-[13px] text-muted">{meta.author}</div>}
          </div>
        )}
        <p className="mt-3 px-1 text-[13px] text-muted">
          {clean ? "YouTube Focus is on: no recommendations, no Shorts, no comments. Just the video." : "YouTube Focus is off, so this is YouTube's own player."}
        </p>
      </div>
      {foot && createPortal(<span className="min-w-0 flex-1 truncate text-[12px] text-muted">{meta ? `Video · ${meta.title}` : "Video"}</span>, foot)}
    </div>
  );
}

function Fallback({ host, kind, url, readable, onRead, onRetry }: { host: string; kind: "refused" | "failed" | "self"; url: string; readable: boolean; onRead: () => void; onRetry: () => void }) {
  const title = kind === "failed" ? "This page didn't load" : `${host || "This site"} can't be shown here`;
  const text =
    kind === "refused"
      ? "This site doesn't allow its pages to be shown inside other apps. You can still open it in a new tab."
      : kind === "self"
        ? "That address is this app itself."
        : "The site took too long to answer. Check the address and your connection, or open it in a new tab.";
  return (
    <div className="flex h-full items-center justify-center overflow-y-auto p-6" role="alert">
      <div className="max-w-sm text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-card text-ink/70 ring-1 ring-line">
          <TriangleAlert size={24} />
        </div>
        <h2 className="display text-[21px] leading-tight text-balance">{title}</h2>
        <p className="mt-2 text-[14px] leading-relaxed text-muted text-pretty">{text}</p>
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          {kind !== "self" && (
            <Button onClick={() => window.open(url, "_blank", "noopener")}>
              <ExternalLink size={15} /> Open in a new tab
            </Button>
          )}
          {readable && (
            <Button variant="soft" onClick={onRead}>
              <BookOpenText size={15} /> Read as text
            </Button>
          )}
          {kind !== "self" && (
            <Button variant="ghost" onClick={onRetry}>
              Try anyway
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

/** A web page: the live site in a frame, a text-only reading view, or a clear message when neither works. */
function WebStage({ url, prefs, foot, inProject, onLoading }: { url: string; prefs: BrowserPrefs; foot: HTMLElement | null; inProject: boolean; onLoading: (loading: boolean) => void }) {
  const host = hostOf(url);
  const learned = useBrowser((s) => s.learned);
  const go = useBrowser((s) => s.go);
  const setBrowser = useApp((s) => s.setBrowser);
  const page = useApp((s) => s.browser);
  const [forced, setForced] = useState(false);
  const [status, setStatus] = useState<"loading" | "ready" | "failed">("loading");
  const [read, setRead] = useState<ReadResult | null>(null);
  const [view, setView] = useState<"page" | "reader">("page");

  const self = (() => {
    try {
      return new URL(url).origin === window.location.origin;
    } catch {
      return false;
    }
  })();
  const refused = !forced && refusesEmbedding(host, learned);
  const readable = !!read && read.ok;
  const showReader = readable && (view === "reader" || (prefs.reader && view === "page" && !forced));
  const framed = !self && !refused && !showReader && status !== "failed";

  // Leo reads the page when the site lets other pages fetch it.
  useEffect(() => {
    const ac = new AbortController();
    void readPage(url, ac.signal).then((r) => {
      if (ac.signal.aborted) return;
      setRead(r);
      if (!r.ok) return;
      setBrowser({ url: r.url, title: r.title, text: r.text.slice(0, 40000), capturedAt: Date.now() });
      void setKV("browser.current", { url: r.url, title: r.title });
    });
    return () => ac.abort();
  }, [url, setBrowser]);

  // A frame that never finishes loading is reported instead of spinning forever.
  useEffect(() => {
    if (!framed || status !== "loading") return;
    const t = window.setTimeout(() => setStatus((s) => (s === "loading" ? "failed" : s)), 15000);
    return () => window.clearTimeout(t);
  }, [framed, status]);

  useEffect(() => {
    onLoading(framed && status === "loading");
    return () => onLoading(false);
  }, [framed, status, onLoading]);

  const saveToLibrary = async () => {
    const projectId = window.location.hash.match(/#\/p\/([^/]+)/)?.[1];
    if (!projectId || !page) return useApp.getState().showToast("Open a project to save pages into it");
    const now = Date.now();
    const excerpt = page.text.slice(0, 1800);
    await db.notes.add({
      id: uid(),
      projectId,
      title: page.title.slice(0, 120) || "Web page",
      content: `Source: [${page.title}](${page.url})\n\n> ${excerpt.replace(/\n+/g, "\n> ")}${page.text.length > 1800 ? "\n>\n> …" : ""}`,
      author: "user",
      createdAt: now,
      updatedAt: now,
    });
    useApp.getState().showToast("Saved to library as a note", { tone: "success" });
  };

  const retry = () => {
    useBrowser.getState().forget(host);
    setForced(true);
    setStatus("loading");
    setView("page");
  };

  const footer = (
    <>
      <span className="min-w-0 flex-1 truncate text-[12px] text-muted">
        {readable ? `Leo can read this page · ${read.words.toLocaleString()} words` : read ? "Leo can't read this site directly" : "Loading…"}
      </span>
      {framed && (
        <button
          type="button"
          onClick={() => useBrowser.getState().learn(host)}
          className="hidden h-8 shrink-0 items-center rounded-full px-3 text-[12px] font-medium text-muted transition-colors hover:bg-ink/[0.06] hover:text-ink sm:inline-flex"
          title="Blank or broken? Some sites refuse to be shown inside other apps."
        >
          Not loading?
        </button>
      )}
      {readable && (
        <IconBtn onClick={() => setView(showReader ? "page" : "reader")} aria-label={showReader ? "Show the live page" : "Read as text"} aria-pressed={showReader} className={cn(showReader && "bg-ink/[0.08] text-ink")}>
          <BookOpenText size={17} />
        </IconBtn>
      )}
      <IconBtn onClick={() => window.open(url, "_blank", "noopener")} aria-label="Open in a new tab">
        <ExternalLink size={16} />
      </IconBtn>
      {inProject && (
        <IconBtn onClick={() => void saveToLibrary()} disabled={!page} aria-label="Save page to library">
          <BookmarkPlus size={17} />
        </IconBtn>
      )}
    </>
  );

  return (
    <>
      {showReader ? (
        <div className="h-full overflow-y-auto" data-ctx-source={`web page "${read.title}"`}>
          <article className="mx-auto max-w-[70ch] px-5 py-8">
            <div className="text-[12px] text-muted">{host} · reading view</div>
            <h1 className="display mt-1 text-[28px] leading-tight" dir="auto">
              {read.title}
            </h1>
            <div className="mt-5 space-y-4 text-[16.5px] leading-[1.75]" dir="auto">
              {read.text.split(/\n\n+/).map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
            {read.links.length > 0 && (
              <div className="mt-8 border-t border-line pt-5">
                <h2 className="mb-2 text-[13px] font-medium text-muted">Links on this page</h2>
                <div className="flex flex-wrap gap-1.5">
                  {read.links.map((l) => (
                    <button key={l.href} type="button" onClick={() => go(l.href)} className="max-w-full truncate rounded-full bg-card px-3 py-1.5 text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.04]">
                      {l.text}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </article>
        </div>
      ) : self ? (
        <Fallback host={host} kind="self" url={url} readable={false} onRead={() => {}} onRetry={() => {}} />
      ) : refused ? (
        <Fallback host={host} kind="refused" url={url} readable={readable} onRead={() => setView("reader")} onRetry={retry} />
      ) : status === "failed" ? (
        <Fallback host={host} kind="failed" url={url} readable={readable} onRead={() => setView("reader")} onRetry={retry} />
      ) : (
        <>
          <iframe
            src={url}
            title={`Web page: ${host}`}
            onLoad={() => setStatus("ready")}
            // No top-navigation permission: a page can never replace the app.
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation"
            allow="fullscreen; picture-in-picture"
            referrerPolicy="strict-origin-when-cross-origin"
            className="h-full w-full border-0 bg-[#fff]"
            style={prefs.night ? { filter: "invert(0.9) hue-rotate(180deg)" } : undefined}
          />
          {status === "loading" && (
            <div className="pointer-events-none absolute inset-x-0 top-3 flex justify-center">
              <span className="flex items-center gap-2 rounded-full bg-elevated px-3 py-1.5 text-[12px] font-medium shadow-[0_6px_20px_rgba(0,0,0,0.14)] ring-1 ring-line">
                <Loader2 size={13} className="animate-spin" /> Loading {host}
              </span>
            </div>
          )}
        </>
      )}
      {foot && createPortal(footer, foot)}
    </>
  );
}

export function BrowserView({ variant, onClose, tools, topInset = true }: { variant: "overlay" | "pane"; onClose: () => void; tools?: ReactNode; topInset?: boolean }) {
  const current = useBrowser((s) => s.current);
  const nonce = useBrowser((s) => s.nonce);
  const cursor = useBrowser((s) => s.cursor);
  const stackSize = useBrowser((s) => s.stack.length);
  const prefs = useBrowser((s) => s.prefs);
  const go = useBrowser((s) => s.go);
  const step = useBrowser((s) => s.step);
  const storeUrl = useApp((s) => s.browserUrl);
  const route = useRoute();
  const inProject = route.name === "project";

  const [address, setAddress] = useState(current);
  const [loading, setLoading] = useState(false);
  const [panel, setPanel] = useState<"none" | "addons">("none");
  const [prompt, setPrompt] = useState(false);
  const [foot, setFoot] = useState<HTMLElement | null>(null);
  const field = useRef<HTMLInputElement>(null);

  useEffect(() => useBrowser.getState().init(), []);

  // Leo (or any other part of the app) points the browser somewhere by setting browserUrl.
  useEffect(() => {
    if (!storeUrl || storeUrl === useBrowser.getState().current) return;
    const u = safeUrl(storeUrl);
    if (u) useBrowser.getState().go(u);
  }, [storeUrl]);

  useEffect(() => {
    if (document.activeElement !== field.current) setAddress(current);
  }, [current]);

  const submit = () => {
    const u = safeUrl(address);
    if (!u) return;
    field.current?.blur();
    setAddress(u);
    go(u);
  };
  const play = (u: string) => {
    setPrompt(false);
    go(u);
  };

  const video = current ? youtubeRef(current) : null;
  const enabled = ADDONS.filter((a) => prefs[a.key]).length;

  return (
    <div
      className={cn("flex flex-col bg-paper", variant === "overlay" ? "fixed inset-0 z-[45]" : "h-full min-h-0 w-full", topInset && "pt-[env(safe-area-inset-top)]")}
      role={variant === "overlay" ? "dialog" : "region"}
      aria-modal={variant === "overlay" ? "true" : undefined}
      aria-label="Learning browser"
    >
      <header className="flex h-14 shrink-0 items-center gap-1 border-b border-line px-2 sm:gap-1.5 sm:px-3">
        <IconBtn onClick={onClose} aria-label="Close browser">
          <X size={19} />
        </IconBtn>
        <IconBtn onClick={() => step(-1)} disabled={cursor <= 0} aria-label="Back" className="hidden sm:flex">
          <ArrowLeft size={17} />
        </IconBtn>
        <IconBtn onClick={() => step(1)} disabled={cursor >= stackSize - 1} aria-label="Forward" className="hidden sm:flex">
          <ArrowRight size={17} />
        </IconBtn>
        <form
          className="relative min-w-0 flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          {loading ? (
            <Loader2 size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 animate-spin text-muted" />
          ) : (
            <Globe2 size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          )}
          <input
            ref={field}
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onFocus={(e) => e.currentTarget.select()}
            onBlur={(e) => {
              e.currentTarget.scrollLeft = 0;
            }}
            aria-label="Search or enter address"
            enterKeyHint="go"
            placeholder="Search, or paste a website or YouTube link"
            className="h-10 w-full rounded-full bg-ink/[0.05] pl-10 pr-3 text-[16px] outline-none ring-1 ring-transparent focus:ring-ink/20"
          />
        </form>
        <IconBtn onClick={() => setPrompt((p) => !p)} aria-label="Play a YouTube video" aria-pressed={prompt} className={cn(prompt && "bg-ink/[0.08] text-ink")}>
          <CirclePlay size={18} />
        </IconBtn>
        <IconBtn onClick={() => useBrowser.getState().reload()} disabled={!current} aria-label="Reload" className="hidden sm:flex">
          <RefreshCw size={16} />
        </IconBtn>
        <IconBtn onClick={() => setPanel(panel === "addons" ? "none" : "addons")} aria-label="Add-ons" aria-pressed={panel === "addons"} className="relative">
          <Puzzle size={17} />
          {enabled > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-solid" />}
        </IconBtn>
        {tools}
      </header>

      {prompt && (
        <div className="shrink-0 border-b border-line bg-card px-3 py-2.5">
          <div className="mx-auto max-w-2xl">
            <YouTubePrompt onPlay={play} autoFocus />
          </div>
        </div>
      )}

      <div className="relative min-h-0 flex-1">
        {!current ? (
          <div className="h-full overflow-y-auto">
            <div className="mx-auto max-w-2xl px-5 py-10">
              <h2 className="display text-[23px]">Browse with Leo</h2>
              <p className="mt-1 text-[14px] text-muted">Watch a video without the distractions, or open a page and ask Leo about it. Leo reads pages whose sites allow it, and you can save them to your library.</p>
              <div className="mt-6 rounded-2xl bg-card p-4 ring-1 ring-line">
                <div className="mb-2.5 text-[14px] font-semibold">Watch a YouTube video</div>
                <YouTubePrompt onPlay={play} />
                <p className="mt-2 text-[12px] text-muted">It plays here in a clean player: just the video, with no recommendations or comments.</p>
              </div>
              <div className="mt-6 text-[13px] font-medium text-muted">Or start from</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {START.map(([label, u]) => (
                  <button key={u} onClick={() => go(u)} className="rounded-full bg-card px-3.5 py-2 text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.03]">
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : video ? (
          <VideoStage key={`${current}:${nonce}`} url={current} video={video} clean={prefs.cleanYoutube} foot={foot} />
        ) : (
          <WebStage key={`${current}:${nonce}`} url={current} prefs={prefs} foot={foot} inProject={inProject} onLoading={setLoading} />
        )}

        {panel === "addons" && (
          <aside className="absolute inset-y-0 right-0 z-10 w-full max-w-md overflow-y-auto border-l border-line bg-paper p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="display text-[20px]">Add-ons</h3>
              <IconBtn onClick={() => setPanel("none")} aria-label="Close add-ons">
                <X size={17} />
              </IconBtn>
            </div>
            <p className="mb-3 text-[13px] text-muted">Ways to make pages calmer. Pages load straight from their own sites, so add-ons change how a page is shown here; they can't run scripts inside it.</p>
            <div className="space-y-2">
              {ADDONS.map((a) => {
                const on = (prefs ?? DEFAULT_PREFS)[a.key];
                return (
                  <div key={a.key} className="rounded-2xl bg-card p-3 ring-1 ring-line">
                    <div className="flex items-start gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="text-[14px] font-semibold">{a.name}</div>
                        <div className="text-[12px] text-muted">{a.hosts}</div>
                        <p className="mt-1 text-[13px] text-muted">{a.description}</p>
                      </div>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={on}
                        aria-label={`Toggle ${a.name}`}
                        onClick={() => useBrowser.getState().setPrefs({ [a.key]: !on })}
                        className={cn("relative h-6 w-10 shrink-0 rounded-full transition-colors", on ? "bg-ink" : "bg-ink/15")}
                      >
                        <span className={cn("absolute left-0 top-0.5 h-5 w-5 rounded-full bg-card shadow transition-transform", on ? "translate-x-[18px]" : "translate-x-0.5")} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </aside>
        )}
      </div>

      {current && (
        <footer className="flex shrink-0 items-center gap-1.5 border-t border-line bg-paper/95 px-3 py-2 pb-[max(8px,env(safe-area-inset-bottom))]">
          <div className="flex sm:hidden">
            <IconBtn onClick={() => step(-1)} disabled={cursor <= 0} aria-label="Back">
              <ArrowLeft size={17} />
            </IconBtn>
            <IconBtn onClick={() => step(1)} disabled={cursor >= stackSize - 1} aria-label="Forward">
              <ArrowRight size={17} />
            </IconBtn>
          </div>
          <div ref={setFoot} className="contents" />
          {inProject && (
            <Button size="sm" onClick={() => useApp.getState().setChatOpen(true)}>
              <Sparkles size={14} /> Ask Leo
            </Button>
          )}
        </footer>
      )}
    </div>
  );
}

/** The browser over the whole app. Inside a project it can instead sit beside the work as a pane. */
export default function BrowserPanel() {
  const open = useApp((s) => s.browserOpen);
  const setOpen = useApp((s) => s.setBrowserOpen);
  const route = useRoute();
  const projectId = route.name === "project" ? route.projectId : null;
  const beside = useLayout((s) => !!projectId && s.sideProject === projectId && s.side?.kind === "browser");
  if (!open || beside) return null;
  const canDock = !!projectId && window.innerWidth >= NARROW;
  return (
    <BrowserView
      variant="overlay"
      onClose={() => setOpen(false)}
      tools={
        canDock ? (
          <IconBtn onClick={() => projectId && useLayout.getState().openSide(projectId, { kind: "browser" })} aria-label="Show beside the project" className="hidden sm:flex">
            <Columns2 size={17} />
          </IconBtn>
        ) : undefined
      }
    />
  );
}
