import { useEffect } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { PenTool } from "lucide-react";
import { db, type Sketch } from "@/lib/db";
import { hasSketchPreviews, queueSketchPreviews, sketchPreview } from "@/lib/sketchPreviews";
import { useResolvedTheme } from "@/lib/settings";
import { cn } from "@/utils/cn";

/** Repairs old previews and watches new/edited sketches, regardless of who created them. */
export function useSketchPreviewRepair() {
  const sketches = useLiveQuery(() => db.sketches.toArray(), []);
  useEffect(() => {
    for (const sketch of sketches ?? []) if (!hasSketchPreviews(sketch)) queueSketchPreviews(sketch.id);
  }, [sketches]);
}

export default function SketchThumbnail({ sketch, className }: { sketch: Sketch; className?: string }) {
  const theme = useResolvedTheme();
  const src = sketchPreview(sketch, theme);
  return <div aria-hidden data-sketch-preview={sketch.id} data-thumb-theme={theme} className={cn("flex h-full w-full items-center justify-center overflow-hidden bg-card text-muted", className)}>
    {src ? <img src={src} alt="" draggable={false} className="h-full w-full object-contain p-2" loading="lazy" /> : <div className="flex h-full w-full items-center justify-center" style={{ backgroundImage: "radial-gradient(color-mix(in srgb, var(--ink) 14%, transparent) 1px, transparent 1px)", backgroundSize: "14px 14px" }}><PenTool size={22} /></div>}
  </div>;
}