import { Component, useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowRight, X } from "lucide-react";
import { db } from "@/lib/db";
import { startPlacement } from "@/lib/chat";
import { navigate, type Route } from "@/lib/router";
import { useApp } from "@/lib/store";
import { useSettings } from "@/lib/settings";
import { useTour, type TourChapter, type TourEnd } from "@/lib/tour";
import type { AgentState } from "@/lib/avatar";
import { Button, isSheetOpen } from "@/components/ui";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ steps */

interface Step {
  key: string;
  /** `data-tour` names Leo can point at. The first one that is on screen wins; none = centered card. */
  targets?: string[];
  title: string;
  body: string;
  /** Leo's face once he has finished the sentence. */
  mood?: AgentState;
}

interface StepContext {
  hasProjects: boolean;
  needsSetup: boolean;
  placementWaiting: boolean;
}

/** Only the pillars: projects, the model, the library, the chat, the knowledge map. */
function stepsFor(chapter: TourChapter, ctx: StepContext): Step[] {
  if (chapter === "home") {
    return [
      {
        key: "hello",
        title: "Hi, I'm Leo.",
        body: "I'm the tutor inside Harness. Give me a minute and I'll show you the few things that matter. You'll pick up the rest as you go.",
        mood: "waiting",
      },
      {
        key: "projects",
        targets: ["new-project"],
        title: "Start with a project",
        body: "Make one project for each thing you want to learn: a language, an exam, a new skill. Everything for that topic stays together inside it.",
      },
      {
        key: "model",
        targets: ["provider", "settings"],
        title: "Give me a brain",
        body: "I run on an AI provider you connect in Settings: your own key, or a local model. Your library stays on this device. I only read the passages a question needs, plus anything you attach.",
      },
      {
        key: "go",
        // Someone replaying the tour already has projects: point at one of theirs, not at "New project".
        targets: ctx.hasProjects ? ["project", "new-project"] : ["new-project"],
        title: "Your turn",
        body: ctx.hasProjects
          ? "Open a project and I'll meet you inside to show you the library, the chat and your knowledge map."
          : "Create your first project and I'll meet you inside to show you the library, the chat and your knowledge map.",
        mood: "done",
      },
    ];
  }
  return [
    {
      key: "library",
      targets: ["add"],
      title: "Fill your library",
      body: "Add PDFs, recordings, pictures, notes and sketches. This is the material I teach from, so my answers can point back to your own pages.",
    },
    {
      key: "leo",
      targets: ["leo"],
      title: "Ask me anything",
      body: "Tap me to chat. I'll find your level with a few questions, teach in small steps and quiz you as we go. I can also write notes and draw sketches for you.",
    },
    {
      key: "map",
      targets: ["progress"],
      title: "Watch your map grow",
      body: "Every quiz updates your knowledge map: what's solid, what's shaky and what's due for review. Open Progress to see it.",
    },
    {
      key: "end",
      title: "That's the tour",
      body: ctx.placementWaiting
        ? "A few quick questions will tell me where to start. You can replay this tour any time from Settings."
        : ctx.needsSetup
          ? "One thing left: connect a model so I can answer. You can replay this tour any time from Settings."
          : "I'm down here whenever you need me. You can replay this tour any time from Settings.",
      mood: "done",
    },
  ];
}

/* --------------------------------------------------------------- geometry */

const PAD = 6;
const MARGIN = 12;
const GAP = 16;

const clamp = (n: number, lo: number, hi: number) => Math.min(Math.max(n, lo), Math.max(lo, hi));

interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
}

interface Pos {
  left: number;
  top: number;
  /** Which edge of the card the pointer sits on (null when the card is centered or overlapping). */
  side: "top" | "bottom" | null;
  arrowX: number;
}

function findTarget(tokens: string[]): HTMLElement | null {
  for (const token of tokens) {
    for (const el of document.querySelectorAll<HTMLElement>(`[data-tour~="${token}"]`)) {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) return el;
    }
  }
  return null;
}

/** Follows the element a step points at: scrolls it into view once, then tracks its box. */
function useSpot(targets: string[] | undefined, stepKey: string): Box | null {
  const [box, setBox] = useState<Box | null>(null);
  const tokenKey = targets?.join(" ") ?? "";

  useLayoutEffect(() => {
    const tokens = tokenKey ? tokenKey.split(" ") : [];
    let el = findTarget(tokens);
    if (el) {
      const r = el.getBoundingClientRect();
      if (r.top < 8 || r.bottom > window.innerHeight - 8) el.scrollIntoView({ block: "center" });
    }
    const measure = () => {
      if (!el || !el.isConnected) el = findTarget(tokens);
      const r = el?.getBoundingClientRect();
      if (!el || !r || !r.width || !r.height) {
        el = null;
        setBox(null);
        return;
      }
      const radius = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
      const next: Box = { x: r.left, y: r.top, w: r.width, h: r.height, r: Math.min(radius, r.height / 2) };
      setBox((b) => (b && b.x === next.x && b.y === next.y && b.w === next.w && b.h === next.h && b.r === next.r ? b : next));
    };
    measure();
    // Layout can still settle (fonts, entrance animations, the dock label), so keep checking.
    const id = window.setInterval(measure, 250);
    window.addEventListener("resize", measure);
    window.addEventListener("scroll", measure, true);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("resize", measure);
      window.removeEventListener("scroll", measure, true);
    };
  }, [stepKey, tokenKey]);

  return box;
}

/** The card sits beside what it describes: above targets low on the screen, below ones near the top. */
function place(box: Box | null, cw: number, ch: number, vp: { w: number; h: number }): Pos {
  if (!box) {
    return { left: Math.round((vp.w - cw) / 2), top: Math.round(Math.max(MARGIN, (vp.h - ch) / 2)), side: null, arrowX: 0 };
  }
  const cx = box.x + box.w / 2;
  const left = clamp(cx - cw / 2, MARGIN, vp.w - cw - MARGIN);
  const roomAbove = box.y - PAD - GAP - MARGIN;
  const roomBelow = vp.h - (box.y + box.h + PAD) - GAP - MARGIN;
  const preferAbove = box.y + box.h / 2 > vp.h / 2;
  const above = preferAbove ? roomAbove >= ch || roomAbove >= roomBelow : roomBelow < ch && roomAbove > roomBelow;
  const fits = above ? roomAbove >= ch : roomBelow >= ch;
  const top = clamp(above ? box.y - PAD - GAP - ch : box.y + box.h + PAD + GAP, MARGIN, vp.h - ch - MARGIN);
  return {
    left: Math.round(left),
    top: Math.round(top),
    side: fits ? (above ? "bottom" : "top") : null,
    arrowX: Math.round(clamp(cx - left, 28, cw - 28)),
  };
}

/* ------------------------------------------------------------------ parts */

/**
 * Leo "says" each line. The full sentence is laid out from the first frame (the unspoken part is
 * invisible), so the card never changes size while he talks. Screen readers get the whole line at once.
 */
function Typed({ text, instant, onDone }: { text: string; instant: boolean; onDone: () => void }) {
  const [shown, setShown] = useState(instant ? text.length : 0);
  const done = useRef(onDone);
  useEffect(() => {
    done.current = onDone;
  });
  useEffect(() => {
    if (instant) {
      setShown(text.length);
      done.current();
      return;
    }
    const per = clamp(900 / text.length, 5, 16);
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const k = Math.min(text.length, Math.floor((t - t0) / per) + 1);
      setShown(k);
      if (k < text.length) raf = requestAnimationFrame(tick);
      else done.current();
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [text, instant]);
  return (
    <>
      <span className="sr-only">{text}</span>
      <span aria-hidden>
        {text.slice(0, shown)}
        <span className="opacity-0">{text.slice(shown)}</span>
      </span>
    </>
  );
}

/** A broken tour must never take the app down with it, or leave it locked behind an overlay. */
class Quiet extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error) {
    console.error("[tour]", error);
    document.getElementById("root")?.removeAttribute("inert");
    useTour.getState().end("interrupted");
  }

  render() {
    return this.state.failed ? null : this.props.children;
  }
}

/* ------------------------------------------------------------------- host */

export default function Tour({ route }: { route: Route }) {
  return (
    <Quiet>
      <TourHost route={route} />
    </Quiet>
  );
}

/** Decides when a chapter may start, and closes it if the screen it describes goes away. */
function TourHost({ route }: { route: Route }) {
  const chapter = useTour((s) => s.chapter);
  const seenHome = useTour((s) => s.seen.home);
  const seenProject = useTour((s) => s.seen.project);
  const replayRequested = useTour((s) => s.replayRequested);
  const start = useTour((s) => s.start);
  const end = useTour((s) => s.end);
  const markSeen = useTour((s) => s.markSeen);
  const chatOpen = useApp((s) => s.chatOpen);
  const projectCount = useLiveQuery(() => db.projects.count(), []);

  const onHome = route.name === "home";
  const projectId = route.name === "project" ? route.projectId : null;
  const atLibrary = route.name === "project" && route.tab === "library" && !route.itemId;

  useEffect(() => {
    if (chapter) return;
    if (onHome) {
      if (replayRequested) {
        start("home");
        return;
      }
      if (seenHome || projectCount === undefined) return;
      if (projectCount > 0) {
        // Someone who already has projects is not a new user: never interrupt them.
        markSeen({ home: true, project: true });
        return;
      }
      const id = window.setInterval(() => {
        if (!isSheetOpen()) start("home");
      }, 700);
      return () => window.clearInterval(id);
    }
    if (atLibrary && seenHome && !seenProject && !chatOpen) {
      // Wait until the room is actually visible: no sheet on top, the dock on screen.
      const id = window.setInterval(() => {
        if (!isSheetOpen() && findTarget(["leo"])) start("project");
      }, 650);
      return () => window.clearInterval(id);
    }
  }, [chapter, onHome, atLibrary, seenHome, seenProject, projectCount, chatOpen, replayRequested, start, markSeen]);

  const fits = chapter === "home" ? onHome : chapter === "project" ? atLibrary && !chatOpen : true;
  useEffect(() => {
    if (chapter && !fits) end("interrupted");
  }, [chapter, fits, end]);

  if (!chapter || !fits) return null;
  return <TourOverlay key={chapter} chapter={chapter} projectId={projectId} hasProjects={(projectCount ?? 0) > 0} />;
}

/* ---------------------------------------------------------------- overlay */

const SCROLL_KEYS = new Set(["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End"]);

function TourOverlay({ chapter, projectId, hasProjects }: { chapter: TourChapter; projectId: string | null; hasProjects: boolean }) {
  const index = useTour((s) => s.step);
  const setStep = useTour((s) => s.setStep);
  const end = useTour((s) => s.end);
  const deferred = useTour((s) => s.deferredPlacement);
  const providerCount = useLiveQuery(() => db.providers.count(), []);
  const developerMode = useSettings((s) => s.developerMode);
  const reduceSetting = useSettings((s) => s.reduceMotion);
  const [systemReduced] = useState(() => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false);
  const reduced = reduceSetting || systemReduced;

  const needsSetup = providerCount === 0 && !developerMode;
  const placementWaiting = !!projectId && deferred === projectId && !needsSetup;
  const steps = useMemo(() => stepsFor(chapter, { hasProjects, needsSetup, placementWaiting }), [chapter, hasProjects, needsSetup, placementWaiting]);
  const i = Math.min(index, steps.length - 1);
  const step = steps[i];
  const last = i === steps.length - 1;
  const stepId = `${chapter}/${step.key}`;

  const box = useSpot(step.targets, stepId);
  const [vp, setVp] = useState(() => ({ w: window.innerWidth, h: window.innerHeight }));
  const [pos, setPos] = useState<Pos | null>(null);
  const [spoken, setSpoken] = useState<string | null>(null);
  const talking = !reduced && spoken !== stepId;

  const rootRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const bodyId = useId();

  const close = useCallback(
    (reason: TourEnd, then?: () => void) => {
      const held = useTour.getState().deferredPlacement;
      end(reason);
      if (reason === "skipped") useApp.getState().showToast("Tour skipped. You can replay it from Settings.");
      if (chapter === "project") {
        useTour.getState().deferPlacement(null);
        // Placement was held back so the tour could go first. It starts now, as the learner asked.
        if (held && held === projectId && !then) {
          window.setTimeout(() => void startPlacement(held), 180);
          return;
        }
      }
      then?.();
    },
    [chapter, projectId, end]
  );

  let primary: { label: string; run: () => void };
  let secondary: { label: string; run: () => void } | null = null;
  if (!last) {
    primary = { label: i === 0 && chapter === "home" ? "Let's go" : "Next", run: () => setStep(i + 1) };
    secondary = i === 0 ? { label: "Skip", run: () => close("skipped") } : { label: "Back", run: () => setStep(i - 1) };
  } else if (chapter === "home") {
    if (hasProjects) primary = { label: "Got it", run: () => close("done") };
    else {
      primary = { label: "Create a project", run: () => close("done", () => useTour.getState().requestCreate()) };
      secondary = { label: "Later", run: () => close("done") };
    }
  } else if (placementWaiting) {
    primary = { label: "Start placement", run: () => close("done") };
  } else if (needsSetup) {
    primary = { label: "Set up Leo", run: () => close("done", () => navigate("settings")) };
    secondary = { label: "Later", run: () => close("done") };
  } else {
    primary = { label: "Chat with Leo", run: () => close("done", () => useApp.getState().setChatOpen(true)) };
    secondary = { label: "Done", run: () => close("done") };
  }

  const primaryRun = useRef(primary.run);
  useEffect(() => {
    primaryRun.current = primary.run;
  });

  // The page underneath is out of reach while Leo talks: no focus, no clicks, no scrolling.
  useEffect(() => {
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const overlay = rootRef.current;
    const block = (e: Event) => e.preventDefault();
    overlay?.addEventListener("wheel", block, { passive: false });
    overlay?.addEventListener("touchmove", block, { passive: false });
    const onResize = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", onResize);
    return () => {
      root?.removeAttribute("inert");
      overlay?.removeEventListener("wheel", block);
      overlay?.removeEventListener("touchmove", block);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  // The tour owns the keyboard while it is open, so shortcuts underneath stay quiet.
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Escape") {
        e.preventDefault();
        close("skipped");
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        if (!last) setStep(i + 1);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        if (i > 0) setStep(i - 1);
      } else if (e.key === "Enter") {
        if (document.activeElement instanceof HTMLButtonElement) return;
        e.preventDefault();
        primaryRun.current();
      } else if (e.key === "Tab") {
        const els = Array.from(cardRef.current?.querySelectorAll<HTMLElement>("button:not([disabled])") ?? []);
        if (!els.length) return;
        const at = els.indexOf(document.activeElement as HTMLElement);
        if (e.shiftKey && at <= 0) {
          e.preventDefault();
          els[els.length - 1].focus();
        } else if (!e.shiftKey && (at === -1 || at === els.length - 1)) {
          e.preventDefault();
          els[0].focus();
        }
      } else if (SCROLL_KEYS.has(e.key)) {
        e.preventDefault();
      }
    };
    window.addEventListener("keydown", on, true);
    return () => window.removeEventListener("keydown", on, true);
  }, [i, last, close, setStep]);

  // Each step moves focus to the card, so Enter continues and screen readers hear the new line.
  // It waits for the first placement: a card that is still hidden for measuring can't take focus.
  const placed = pos !== null;
  useEffect(() => {
    if (placed) cardRef.current?.focus({ preventScroll: true });
  }, [stepId, placed]);

  // The card's size depends on the step's text and buttons, so those re-run the placement too.
  const layoutKey = `${stepId}|${primary.label}|${secondary?.label ?? ""}`;
  useLayoutEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    const next = place(box, card.offsetWidth, card.offsetHeight, vp);
    setPos((p) => (p && p.left === next.left && p.top === next.top && p.side === next.side && p.arrowX === next.arrowX ? p : next));
  }, [box, vp, layoutKey]);

  const spot = box
    ? {
        left: box.x - PAD,
        top: box.y - PAD,
        width: box.w + PAD * 2,
        height: box.h + PAD * 2,
        borderRadius: Math.min(box.r + PAD, (box.h + PAD * 2) / 2),
      }
    : { left: vp.w / 2, top: vp.h / 2, width: 0, height: 0, borderRadius: 0 };

  return createPortal(
    <div ref={rootRef} className="fade-in fixed inset-0 z-[140]" style={{ touchAction: "none" }}>
      <div className="tour-spot" data-empty={box ? undefined : "true"} style={spot} aria-hidden />
      <div
        ref={cardRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={bodyId}
        tabIndex={-1}
        className="tour-card rise fixed w-[min(380px,calc(100vw-24px))] rounded-3xl bg-elevated p-5 shadow-[0_24px_70px_rgba(0,0,0,0.35)] outline-none ring-1 ring-line"
        style={pos ? { left: pos.left, top: pos.top } : { left: 0, top: 0, visibility: "hidden" }}
      >
        {pos?.side && (
          <span
            aria-hidden
            className={cn(
              "absolute h-3.5 w-3.5 rotate-45 border-line bg-elevated",
              pos.side === "top" ? "-top-[7px] border-l border-t" : "-bottom-[7px] border-b border-r"
            )}
            style={{ left: pos.arrowX - 7 }}
          />
        )}
        <div className="flex items-start gap-3">
          <AgentAvatar state={talking ? "speaking" : (step.mood ?? "idle")} size={48} label="Leo" />
          <div className="min-w-0 flex-1 pt-0.5" aria-live="polite" aria-atomic="true">
            <div className="text-[12px] font-medium tabular-nums text-muted">
              Leo · {i + 1} of {steps.length}
            </div>
            <h2 id={titleId} className="display text-[20px] leading-tight">
              {step.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={() => close("skipped")}
            aria-label="Skip the tour"
            title="Skip the tour (Esc)"
            className="-mr-1.5 -mt-1.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-muted transition-colors hover:bg-ink/[0.06] hover:text-ink"
          >
            <X size={16} />
          </button>
        </div>
        <p id={bodyId} aria-live="polite" className="mt-3 text-[15px] leading-relaxed text-ink/85 text-pretty">
          <Typed key={stepId} text={step.body} instant={reduced} onDone={() => setSpoken(stepId)} />
        </p>
        <div className="mt-5 flex items-center gap-2">
          <div className="flex flex-1 items-center gap-1.5" aria-hidden>
            {steps.map((s, k) => (
              <span
                key={s.key}
                className={cn("h-1.5 rounded-full transition-all duration-300", k === i ? "w-5 bg-ink" : k < i ? "w-1.5 bg-ink/45" : "w-1.5 bg-ink/15")}
              />
            ))}
          </div>
          {secondary && (
            <Button variant="ghost" className="whitespace-nowrap" onClick={secondary.run}>
              {secondary.label}
            </Button>
          )}
          <Button className="whitespace-nowrap" onClick={primary.run}>
            {primary.label}
            {!last && <ArrowRight size={16} />}
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
