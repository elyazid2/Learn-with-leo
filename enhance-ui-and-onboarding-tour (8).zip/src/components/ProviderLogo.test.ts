import { describe, expect, it } from "vitest";
import { logoKeyFor } from "./ProviderLogo";

describe("provider logos", () => {
  it("uses the preset's own logo in the Add provider sheet", () => {
    expect(logoKeyFor({ key: "gemini", type: "gemini", name: "Google Gemini" })).toBe("gemini");
    expect(logoKeyFor({ key: "lmstudio", type: "openai", name: "LM Studio (local)" })).toBe("lmstudio");
  });

  it("gives custom OpenAI-compatible endpoints a generic icon, not OpenAI's logo", () => {
    expect(logoKeyFor({ key: "custom", type: "openai", name: "Custom (OpenAI-compatible)", baseUrl: "" })).toBeNull();
    expect(logoKeyFor({ type: "openai", name: "Custom (OpenAI-compatible)", baseUrl: "https://my.host/v1" })).toBeNull();
  });

  it("recognizes saved providers by endpoint first, even when renamed", () => {
    expect(logoKeyFor({ type: "openai", name: "Work", baseUrl: "https://api.openai.com/v1" })).toBe("openai");
    expect(logoKeyFor({ type: "openai", name: "x", baseUrl: "https://openrouter.ai/api/v1" })).toBe("openrouter");
    expect(logoKeyFor({ type: "openai", name: "Home box", baseUrl: "http://192.168.1.4:11434/v1" })).toBe("ollama");
    expect(logoKeyFor({ type: "openai", name: "NVIDIA NIM", baseUrl: "/api/nim" })).toBe("nvidia");
  });

  it("falls back to the API type for Anthropic and Gemini", () => {
    expect(logoKeyFor({ type: "anthropic", name: "Team key" })).toBe("anthropic");
    expect(logoKeyFor({ type: "gemini", name: "Personal" })).toBe("gemini");
  });
});
