import { useRef, useState } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import type { ProjectIcon } from "@/lib/db";
import { ICON_CHOICES, defaultIconFor, iconComponent, iconLabel, iconOf } from "@/lib/projectIcon";
import { iconFromImage } from "@/lib/media";
import ProjectAvatar from "./ProjectAvatar";
import { Button, Segmented } from "./ui";
import { cn } from "@/utils/cn";

type Tab = "icon" | "image";

/** Choose a project icon: a minimal line icon from a curated set, or an uploaded image/logo. */
export default function ProjectIconPicker({ value, onChange, tag }: { value?: ProjectIcon; onChange: (icon: ProjectIcon) => void; tag: string }) {
  // Older projects may hold an emoji; the picker works with the line icon that stands in for it.
  const shown = iconOf({ icon: value, tag });
  const [tab, setTab] = useState<Tab>(shown.kind);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const lastIcon = useRef(shown.kind === "icon" ? shown.name : defaultIconFor(tag));
  const lastImage = useRef(shown.kind === "image" ? shown.src : "");

  const chooseIcon = (name: string) => {
    lastIcon.current = name;
    onChange({ kind: "icon", name });
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setError("");
    if (t === "icon" && shown.kind !== "icon") onChange({ kind: "icon", name: lastIcon.current });
    if (t === "image" && shown.kind !== "image" && lastImage.current) onChange({ kind: "image", src: lastImage.current });
  };

  const onFile = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    setError("");
    const src = await iconFromImage(file);
    setBusy(false);
    if (!src) {
      setError("That image couldn't be read. Try a PNG, JPG, SVG or WebP.");
      return;
    }
    lastImage.current = src;
    onChange({ kind: "image", src });
  };

  return (
    <div>
      <div className="flex items-center gap-4">
        <ProjectAvatar project={{ icon: shown, tag, name: "Preview" }} size={60} />
        <Segmented<Tab>
          value={tab}
          onChange={switchTab}
          options={[
            { value: "icon", label: "Icon" },
            { value: "image", label: "Image or logo" },
          ]}
        />
      </div>

      {tab === "icon" ? (
        <div className="mt-3 grid grid-cols-8 gap-1" role="listbox" aria-label="Icon">
          {ICON_CHOICES.map((name) => {
            const selected = shown.kind === "icon" && shown.name === name;
            const Glyph = iconComponent(name);
            return (
              <button
                key={name}
                type="button"
                role="option"
                aria-selected={selected}
                aria-label={iconLabel(name)}
                title={iconLabel(name)}
                onClick={() => chooseIcon(name)}
                className={cn(
                  "flex aspect-square items-center justify-center rounded-xl transition-colors",
                  selected ? "bg-ink/[0.08] text-ink ring-2 ring-ink" : "text-ink/70 hover:bg-ink/[0.05] hover:text-ink"
                )}
              >
                <Glyph size={20} strokeWidth={1.75} />
              </button>
            );
          })}
        </div>
      ) : (
        <div className="mt-3 rounded-2xl bg-ink/[0.035] p-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <Button type="button" variant="soft" onClick={() => fileRef.current?.click()} disabled={busy}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} />}
              {shown.kind === "image" ? "Change image" : "Choose image"}
            </Button>
            {shown.kind === "image" && (
              <Button type="button" variant="ghost" onClick={() => switchTab("icon")}>
                Use an icon instead
              </Button>
            )}
          </div>
          <p className="mt-2 text-[12px] leading-relaxed text-muted">Photos are cropped to a square. Logos with a transparent background are kept whole.</p>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              void onFile(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </div>
      )}
      {error && <p className="mt-2 text-[12px] text-danger-fg">{error}</p>}
    </div>
  );
}
