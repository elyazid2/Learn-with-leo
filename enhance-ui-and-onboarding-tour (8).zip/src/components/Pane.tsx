import { createContext, useContext, useMemo, useRef, useState, type KeyboardEvent as RKeyboardEvent, type PointerEvent as RPointerEvent, type ReactNode, type RefObject, type UIEvent } from "react";
import { createPortal } from "react-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { useShallow } from "zustand/react/shallow";
import { AlignLeft, BookOpen, FileText, Film, Globe2, Image as ImageIcon, Music, PenTool, X } from "lucide-react";
import { db, type FileKind, type Project } from "@/lib/db";
import { ARRANGEMENTS, sameTarget, targetKey, useLayout, type Arrangement, type PaneTarget } from "@/lib/layout";
import { Sheet } from "@/components/ui";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ pane */

export interface PaneApi {
  /** The main pane follows the address; the second pane is opened beside it. */
  primary: boolean;
  /** Where a document puts its title, controls and actions: the pane's one top bar. */
  slot: HTMLElement | null;
  /** Leave the open item: back to the library in the main pane, close the second pane otherwise. */
  close: (replace?: boolean) => void;
  /** Show another item in this pane. */
  open: (target: PaneTarget) => void;
}

const PaneContext = createContext<PaneApi>({ primary: true, slot: null, close: () => {}, open: () => {} });

export const usePane = () => useContext(PaneContext);

/** A document's bar. It fills the pane's single top bar instead of stacking a second one under it. */
export function PaneBar({ children }: { children: ReactNode }) {
  const { slot } = usePane();
  return slot ? createPortal(children, slot) : null;
}

export function PaneShell({
  label,
  primary,
  close,
  open,
  leading,
  bar,
  trailing,
  wide,
  compact,
  topInset,
  bodyClass,
  bodyRef,
  onBodyScroll,
  overlay,
  children,
}: {
  label: string;
  primary: boolean;
  close: (replace?: boolean) => void;
  open: (target: PaneTarget) => void;
  /** Before the document's bar: the back button. */
  leading?: ReactNode;
  /** Shown when no document fills the bar (the project's own bar). */
  bar?: ReactNode;
  /** After the document's bar: layout, fullscreen, close. */
  trailing?: ReactNode;
  /** Documents use the full width; the project bar keeps the page's reading width. */
  wide?: boolean;
  compact?: boolean;
  topInset?: boolean;
  bodyClass?: string;
  bodyRef?: RefObject<HTMLDivElement | null>;
  onBodyScroll?: (e: UIEvent<HTMLDivElement>) => void;
  /** Floats over the pane (the dock). */
  overlay?: ReactNode;
  children: ReactNode;
}) {
  const [slot, setSlot] = useState<HTMLElement | null>(null);
  const api = useMemo<PaneApi>(() => ({ primary, slot, close, open }), [primary, slot, close, open]);
  return (
    <section aria-label={label} className="relative flex min-h-0 min-w-0 flex-1 flex-col">
      <header className={cn("@container relative z-20 shrink-0 border-b border-line/70 bg-paper/85 backdrop-blur-xl", topInset && "pt-[env(safe-area-inset-top)]")}>
        <div className={cn("flex flex-wrap items-center gap-x-1 gap-y-0.5 px-2 sm:px-3", compact ? "min-h-12" : "min-h-14", !wide && "mx-auto max-w-5xl")}>
          {leading}
          {bar}
          <div ref={setSlot} className="contents" />
          {trailing}
        </div>
      </header>
      <PaneContext.Provider value={api}>
        <div ref={bodyRef} onScroll={onBodyScroll} className={cn("relative min-h-0 flex-1", bodyClass)}>
          {children}
        </div>
        {overlay}
      </PaneContext.Provider>
    </section>
  );
}

/* --------------------------------------------------------------- divider */

/** The draggable edge between two panes (or a pane and the docked chat). */
export function Divider({
  dir,
  container,
  value,
  onChange,
  invert,
  label,
}: {
  dir: "row" | "column";
  container: RefObject<HTMLDivElement | null>;
  value: number;
  onChange: (share: number) => void;
  /** The share belongs to the pane after the divider. */
  invert?: boolean;
  label: string;
}) {
  const dragging = useRef(false);
  const move = (e: RPointerEvent) => {
    if (!dragging.current) return;
    const box = container.current?.getBoundingClientRect();
    if (!box || !box.width || !box.height) return;
    const at = dir === "row" ? (e.clientX - box.left) / box.width : (e.clientY - box.top) / box.height;
    onChange(invert ? 1 - at : at);
  };
  const stop = () => {
    dragging.current = false;
  };
  const onKey = (e: RKeyboardEvent) => {
    const back = dir === "row" ? "ArrowLeft" : "ArrowUp";
    const forward = dir === "row" ? "ArrowRight" : "ArrowDown";
    if (e.key !== back && e.key !== forward) return;
    e.preventDefault();
    const step = (e.key === forward ? 0.03 : -0.03) * (invert ? -1 : 1);
    onChange(value + step);
  };
  return (
    <div
      role="separator"
      aria-orientation={dir === "row" ? "vertical" : "horizontal"}
      aria-label={label}
      aria-valuenow={Math.round(value * 100)}
      aria-valuemin={20}
      aria-valuemax={80}
      tabIndex={0}
      onKeyDown={onKey}
      onPointerDown={(e) => {
        dragging.current = true;
        e.currentTarget.setPointerCapture(e.pointerId);
      }}
      onPointerMove={move}
      onPointerUp={stop}
      onPointerCancel={stop}
      className={cn("group relative z-30 shrink-0 touch-none bg-line outline-none", dir === "row" ? "w-px cursor-col-resize" : "h-px cursor-row-resize")}
    >
      <span className={cn("absolute", dir === "row" ? "inset-y-0 -left-1.5 w-3" : "inset-x-0 -top-1.5 h-3")} />
      <span
        aria-hidden
        className={cn(
          "pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink/25 transition-colors group-hover:bg-ink/60 group-focus-visible:bg-ink",
          dir === "row" ? "h-9 w-1" : "h-1 w-9"
        )}
      />
    </div>
  );
}

/* ---------------------------------------------------------------- layout */

/** A thumbnail of an arrangement: dark = this page, light = the second pane, outline = Leo. */
function Diagram({ a }: { a: Arrangement }) {
  const block = "rounded-[3px]";
  if (a.focus || a.chat === "full") {
    return (
      <span aria-hidden className="flex h-10 w-16 rounded-md bg-ink/[0.06] p-[3px]">
        <span className={cn("flex-1", block, a.focus === "side" ? "bg-ink/30" : a.focus === "main" ? "bg-ink/75" : "border-[1.5px] border-ink/70")} />
      </span>
    );
  }
  const chat = <span className={cn(block, "shrink-0 border-[1.5px] border-ink/70", a.chat === "bottom" ? "h-[36%]" : "w-[32%]")} />;
  return (
    <span aria-hidden className={cn("relative flex h-10 w-16 gap-[2px] rounded-md bg-ink/[0.06] p-[3px]", a.chat === "bottom" ? "flex-col" : "flex-row")}>
      {a.chat === "left" && chat}
      <span className={cn("flex min-h-0 min-w-0 flex-1 gap-[2px]", a.split === "column" ? "flex-col" : "flex-row")}>
        <span className={cn("flex-1 bg-ink/75", block)} />
        {a.split !== "none" && <span className={cn("flex-1 bg-ink/30", block)} />}
      </span>
      {(a.chat === "right" || a.chat === "bottom") && chat}
      {a.chat === "float" && <span className={cn("absolute bottom-[5px] right-[5px] h-[42%] w-[30%] border-[1.5px] border-ink/70 bg-paper", block)} />}
    </span>
  );
}

const FILE_WORD: Record<FileKind, string> = { pdf: "PDF", image: "Picture", video: "Video", audio: "Audio", text: "Text file" };

function TargetIcon({ target, fileKind }: { target: PaneTarget; fileKind?: FileKind }) {
  if (target.kind === "library") return <BookOpen size={16} />;
  if (target.kind === "browser") return <Globe2 size={16} />;
  if (target.kind === "sketch") return <PenTool size={16} />;
  if (target.kind === "note") return <FileText size={16} />;
  if (fileKind === "video") return <Film size={16} />;
  if (fileKind === "image") return <ImageIcon size={16} />;
  if (fileKind === "audio") return <Music size={16} />;
  if (fileKind === "text") return <AlignLeft size={16} />;
  return <FileText size={16} />;
}

interface Choice {
  target: PaneTarget;
  title: string;
  label: string;
  at: number;
  fileKind?: FileKind;
}

function SidePicker({ project, main, side, onPick }: { project: Project; main: PaneTarget; side: PaneTarget | null; onPick: (t: PaneTarget | null) => void }) {
  const items = useLiveQuery(async (): Promise<Choice[]> => {
    const [notes, sketches, files] = await Promise.all([
      db.notes.where("projectId").equals(project.id).toArray(),
      db.sketches.where("projectId").equals(project.id).toArray(),
      db.files.where("projectId").equals(project.id).toArray(),
    ]);
    return [
      ...notes.map((n): Choice => ({ target: { kind: "note", id: n.id }, title: n.title || "Untitled note", label: "Note", at: n.updatedAt })),
      ...sketches.map((s): Choice => ({ target: { kind: "sketch", id: s.id }, title: s.title || "Sketch", label: "Sketch", at: s.updatedAt })),
      ...files.map((f): Choice => ({ target: { kind: "file", id: f.id }, title: f.name, label: FILE_WORD[f.kind], at: f.createdAt, fileKind: f.kind })),
    ].sort((a, b) => b.at - a.at);
  }, [project.id]);

  const fixed: Choice[] = [
    { target: { kind: "library" }, title: "Library", label: "Everything in this project", at: 0 },
    { target: { kind: "browser" }, title: "Web browser", label: "Pages and YouTube videos", at: 0 },
  ];
  const all = [...fixed, ...(items ?? [])].filter((c) => !sameTarget(c.target, main));

  return (
    <ul className="max-h-[38dvh] divide-y divide-line overflow-y-auto rounded-2xl ring-1 ring-line">
      {side && (
        <li>
          <button type="button" onClick={() => onPick(null)} className="flex w-full items-center gap-3 px-3.5 py-2.5 text-left text-[14px] transition-colors hover:bg-ink/[0.04]">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-muted">
              <X size={16} />
            </span>
            <span className="font-medium">Close the second pane</span>
          </button>
        </li>
      )}
      {all.map((c) => {
        const active = sameTarget(c.target, side);
        return (
          <li key={targetKey(c.target)}>
            <button
              type="button"
              aria-pressed={active}
              onClick={() => onPick(c.target)}
              className={cn("flex w-full items-center gap-3 px-3.5 py-2.5 text-left transition-colors", active ? "bg-ink/[0.06]" : "hover:bg-ink/[0.04]")}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-ink/80">
                <TargetIcon target={c.target} fileKind={c.fileKind} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[14px] font-medium" dir="auto">
                  {c.title}
                </span>
                <span className="block truncate text-[12px] text-muted">{c.label}</span>
              </span>
              {active && <span className="shrink-0 rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">Showing</span>}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

/** Every layout state in one place: how the panes and Leo's chat are arranged, and what sits beside the page. */
export function LayoutSheet({ project, open, onClose, main, small }: { project: Project; open: boolean; onClose: () => void; main: PaneTarget; small: boolean }) {
  const s = useLayout(useShallow((x) => ({ chatDock: x.tempDock ?? x.chatDock, splitDir: x.splitDir, side: x.side, sideProject: x.sideProject, focus: x.focus })));
  const side = s.sideProject === project.id && s.side && !sameTarget(s.side, main) ? s.side : null;
  // Phones have no room for columns, so only the arrangements that fit are offered.
  const list = small ? ARRANGEMENTS.filter((a) => a.split !== "row" && a.chat !== "left" && a.chat !== "right") : ARRANGEMENTS;
  const isActive = (a: Arrangement) => {
    if (a.focus) return s.focus === a.focus && (a.focus === "main" || !!side);
    if (s.focus) return false;
    if (a.chat === "full") return s.chatDock === "full";
    if (s.chatDock !== a.chat) return false;
    return a.split === "none" ? !side : !!side && (small ? a.split === "column" : s.splitDir === a.split);
  };
  return (
    <Sheet open={open} onClose={onClose} title="Layout" description="Arrange the page, a second pane and Leo's chat." wide>
      <div className="space-y-5">
        <section>
          <h3 className="mb-2 text-[13px] font-medium text-muted">Arrangement</h3>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {list.map((a) => {
              const active = isActive(a);
              return (
                <button
                  key={a.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => {
                    useLayout.getState().apply(project.id, a, main);
                    onClose();
                  }}
                  className={cn(
                    "flex flex-col items-center gap-1.5 rounded-2xl px-1.5 py-2.5 text-center ring-1 transition-colors",
                    active ? "bg-ink/[0.07] ring-ink" : "ring-line hover:bg-ink/[0.04]"
                  )}
                >
                  <Diagram a={a} />
                  <span className="text-[11.5px] font-medium leading-tight">{a.label}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-muted">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-[3px] bg-ink/75" /> This page
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-[3px] bg-ink/30" /> Second pane
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-[3px] border-[1.5px] border-ink/70" /> Leo
            </span>
          </p>
        </section>
        <section>
          <h3 className="mb-2 text-[13px] font-medium text-muted">Second pane shows</h3>
          {open && (
            <SidePicker
              project={project}
              main={main}
              side={side}
              onPick={(t) => {
                if (t) useLayout.getState().openSide(project.id, t);
                else useLayout.getState().closeSide();
                onClose();
              }}
            />
          )}
        </section>
      </div>
    </Sheet>
  );
}
