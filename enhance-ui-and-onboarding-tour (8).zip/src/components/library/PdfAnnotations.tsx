import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent, type RefObject } from "react";
import { Eraser, Highlighter, ListFilter, MousePointer2, PenLine, StickyNote, Trash2, Undo2, X } from "lucide-react";
import type { PdfAnnotation, PdfPoint, PdfRect } from "@/lib/db";
import { HIGHLIGHT_COLORS, PEN_COLORS, PEN_WIDTHS, annotationLabel, normalizePoint, normalizeRects, strokeAt, strokePath } from "@/lib/pdfAnnotations";
import { Button, Sheet } from "@/components/ui";
import { cn } from "@/utils/cn";

export type PdfTool = "select" | "highlight" | "pen" | "eraser" | "note";

export interface PdfMarksApi {
  tool: PdfTool;
  highlightColor: string;
  penColor: string;
  penWidth: number;
  notePage: number | null;
  noteSeed: string;
  onOpenNote: (page: number, seed?: string) => void;
  onCloseNote: () => void;
  onSaveNote: (page: number, text: string) => void;
  onDeleteNote: (page: number) => void;
  onHighlight: (page: number, rects: PdfRect[], text: string, color: string) => void;
  onInk: (page: number, points: PdfPoint[], width: number) => void;
  onErase: (id: string) => void;
}

/* ------------------------------------------------------------------ toolbar */

function ToolButton({ active, onClick, label, children, dot }: { active?: boolean; onClick: () => void; label: string; children: React.ReactNode; dot?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={!!active}
      aria-label={label}
      title={label}
      className={cn("relative flex h-9 w-9 items-center justify-center rounded-full transition-colors sm:h-8 sm:w-8", active ? "bg-ink text-white" : "text-ink/75 hover:bg-ink/[0.08] hover:text-ink")}
    >
      {children}
      {dot && <span aria-hidden className="absolute bottom-0.5 right-0.5 h-2 w-2 rounded-full ring-1 ring-paper" style={{ background: dot }} />}
    </button>
  );
}

function Swatches<T extends { name: string; hex: string }>({ colors, value, onPick }: { colors: readonly T[]; value: string; onPick: (hex: string) => void }) {
  return (
    <div className="flex items-center gap-1.5">
      {colors.map((c) => (
        <button
          key={c.hex}
          type="button"
          onClick={() => onPick(c.hex)}
          aria-label={c.name}
          aria-pressed={value === c.hex}
          title={c.name}
          className={cn("h-5 w-5 rounded-full ring-1 ring-black/15 transition-transform", value === c.hex ? "scale-110 ring-2 ring-ink" : "hover:scale-110")}
          style={{ background: c.hex }}
        />
      ))}
    </div>
  );
}

/** Highlight, pen, eraser and page-note tools in the PDF's own top bar. */
export function PdfToolbar({
  tool,
  onTool,
  highlightColor,
  onHighlightColor,
  penColor,
  onPenColor,
  penWidth,
  onPenWidth,
  count,
  onUndo,
  onList,
}: {
  tool: PdfTool;
  onTool: (t: PdfTool) => void;
  highlightColor: string;
  onHighlightColor: (c: string) => void;
  penColor: string;
  onPenColor: (c: string) => void;
  penWidth: number;
  onPenWidth: (w: number) => void;
  count: number;
  onUndo: () => void;
  onList: () => void;
}) {
  const [palette, setPalette] = useState<null | "highlight" | "pen">(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!palette) return;
    const away = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) setPalette(null);
    };
    const key = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.stopPropagation();
      setPalette(null);
    };
    document.addEventListener("pointerdown", away);
    document.addEventListener("keydown", key, true);
    return () => {
      document.removeEventListener("pointerdown", away);
      document.removeEventListener("keydown", key, true);
    };
  }, [palette]);

  return (
    <div ref={ref} className="relative flex shrink-0 items-center gap-0.5 rounded-full bg-ink/[0.05] p-0.5" role="toolbar" aria-label="PDF annotation tools">
      <ToolButton active={tool === "select"} onClick={() => onTool("select")} label="Select text (V)">
        <MousePointer2 size={15} />
      </ToolButton>
      <ToolButton
        active={tool === "highlight"}
        onClick={() => {
          onTool("highlight");
          setPalette((p) => (p === "highlight" ? null : "highlight"));
        }}
        label="Highlight (H)"
        dot={highlightColor}
      >
        <Highlighter size={15} />
      </ToolButton>
      <ToolButton
        active={tool === "pen"}
        onClick={() => {
          onTool("pen");
          setPalette((p) => (p === "pen" ? null : "pen"));
        }}
        label="Draw (P)"
        dot={penColor}
      >
        <PenLine size={15} />
      </ToolButton>
      <ToolButton active={tool === "eraser"} onClick={() => onTool("eraser")} label="Eraser (E)">
        <Eraser size={15} />
      </ToolButton>
      <ToolButton active={tool === "note"} onClick={() => onTool("note")} label="Page note (N)">
        <StickyNote size={15} />
      </ToolButton>
      <span aria-hidden className="mx-0.5 h-4 w-px bg-line" />
      <ToolButton onClick={onUndo} label="Undo last annotation">
        <Undo2 size={15} />
      </ToolButton>
      <button
        type="button"
        onClick={onList}
        aria-label="All annotations"
        title="All annotations"
        className="relative flex h-9 items-center gap-1 rounded-full px-2 text-[12px] font-medium text-ink/75 transition-colors hover:bg-ink/[0.08] hover:text-ink sm:h-8"
      >
        <ListFilter size={15} />
        {count > 0 && <span className="tabular-nums">{count}</span>}
      </button>

      {palette === "highlight" && (
        <div className="absolute right-0 top-full z-40 mt-1 rounded-2xl bg-elevated p-2 shadow-[0_16px_40px_rgba(0,0,0,0.2)] ring-1 ring-line">
          <div className="mb-1 px-0.5 text-[11px] font-medium text-muted">Highlight colour</div>
          <Swatches colors={HIGHLIGHT_COLORS} value={highlightColor} onPick={(c) => onHighlightColor(c)} />
        </div>
      )}
      {palette === "pen" && (
        <div className="absolute right-0 top-full z-40 mt-1 rounded-2xl bg-elevated p-2 shadow-[0_16px_40px_rgba(0,0,0,0.2)] ring-1 ring-line">
          <div className="mb-1 px-0.5 text-[11px] font-medium text-muted">Pen colour</div>
          <Swatches colors={PEN_COLORS} value={penColor} onPick={(c) => onPenColor(c)} />
          <div className="mt-2 mb-1 px-0.5 text-[11px] font-medium text-muted">Thickness</div>
          <div className="flex items-center gap-1">
            {PEN_WIDTHS.map((w) => (
              <button
                key={w.px}
                type="button"
                aria-pressed={penWidth === w.px}
                onClick={() => onPenWidth(w.px)}
                className={cn("flex h-7 flex-1 items-center justify-center rounded-lg ring-1 transition-colors", penWidth === w.px ? "bg-ink text-white ring-ink" : "ring-line hover:bg-ink/[0.05]")}
                title={w.name}
              >
                <span className="rounded-full" style={{ width: Math.max(4, w.px), height: Math.max(4, w.px), background: "currentColor" }} />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------- marks */

/**
 * Everything drawn on one page: saved highlights, pen strokes and its note, plus the live layers
 * for selecting text and drawing. Coordinates are page-relative, so marks survive zoom and resize.
 */
export function PdfMarks({
  page,
  marks,
  pageRef,
  width,
  height,
  api,
}: {
  page: number;
  marks: PdfAnnotation[];
  pageRef: RefObject<HTMLDivElement | null>;
  width: number;
  height: number;
  api: PdfMarksApi;
}) {
  const [picked, setPicked] = useState<{ rects: PdfRect[]; text: string; x: number; y: number } | null>(null);
  const [live, setLive] = useState<PdfPoint[] | null>(null);
  const [draft, setDraft] = useState("");
  const drawing = useRef(false);
  const erasing = useRef(false);
  const erased = useRef(new Set<string>());

  const note = marks.find((m): m is Extract<PdfAnnotation, { kind: "note" }> => m.kind === "note");
  const highlights = marks.filter((m): m is Extract<PdfAnnotation, { kind: "highlight" }> => m.kind === "highlight");
  const inks = marks.filter((m): m is Extract<PdfAnnotation, { kind: "ink" }> => m.kind === "ink");
  const noteOpen = api.notePage === page;
  const strokes = useMemo(() => inks.map((m) => ({ id: m.id, points: m.points })), [inks]);

  useEffect(() => {
    if (noteOpen) setDraft(note?.text ?? api.noteSeed ?? "");
    // Only when the editor opens: typing must not be overwritten by a live update.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [noteOpen, page]);

  useEffect(() => {
    if (!picked) return;
    const clear = () => setPicked(null);
    window.addEventListener("scroll", clear, true);
    return () => window.removeEventListener("scroll", clear, true);
  }, [picked]);

  // Text selection → a small palette right above it. This is the main way to highlight.
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const read = () => {
      if (api.tool === "pen" || api.tool === "eraser") return;
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return;
      const range = sel.getRangeAt(0);
      if (!el.contains(range.commonAncestorContainer)) return;
      const text = sel.toString().replace(/\s+/g, " ").trim();
      if (!text) return;
      const box = el.getBoundingClientRect();
      const rects = normalizeRects([...range.getClientRects()].filter((r) => r.width > 1 && r.height > 1), box);
      if (!rects.length) return;
      const first = range.getClientRects()[0];
      if (!first) return;
      setPicked({
        rects,
        text,
        x: Math.max(6, Math.min(first.left - box.left, box.width - 250)),
        y: Math.max(6, first.top - box.top - 46),
      });
    };
    const onUp = (e: Event) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("[data-pdf-ui]")) return;
      if (api.tool === "note") {
        api.onOpenNote(page);
        return;
      }
      window.setTimeout(read, 0);
    };
    const onDown = (e: Event) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("[data-pdf-ui]")) return;
      setPicked(null);
    };
    el.addEventListener("pointerup", onUp);
    el.addEventListener("keyup", onUp);
    el.addEventListener("pointerdown", onDown);
    return () => {
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("keyup", onUp);
      el.removeEventListener("pointerdown", onDown);
    };
  }, [api, page, pageRef]);

  const toPoint = (e: RPointerEvent) => {
    const box = pageRef.current?.getBoundingClientRect();
    return box ? normalizePoint(e.clientX, e.clientY, box) : { x: 0, y: 0 };
  };

  const eraseAt = (p: PdfPoint) => {
    const hit = strokeAt(strokes, p, 0.014);
    if (!hit || erased.current.has(hit)) return;
    erased.current.add(hit);
    api.onErase(hit);
  };

  const drawingLayer = api.tool === "pen" || api.tool === "eraser";

  return (
    <>
      {highlights.map((h) =>
        h.rects.map((r, i) => (
          <span
            key={`${h.id}:${i}`}
            aria-hidden
            className="pointer-events-none absolute z-[1] rounded-[2px]"
            style={{ left: `${r.x * 100}%`, top: `${r.y * 100}%`, width: `${r.w * 100}%`, height: `${r.h * 100}%`, background: h.color, opacity: 0.45, mixBlendMode: "multiply" }}
          />
        ))
      )}

      <svg aria-hidden className="pointer-events-none absolute inset-0 z-[2] h-full w-full" viewBox={`0 0 ${Math.max(1, width)} ${Math.max(1, height)}`} fill="none">
        {inks.map((m) => (
          <path key={m.id} d={strokePath(m.points, width, height)} stroke={m.color} strokeWidth={Math.max(1, m.width * width)} strokeLinecap="round" strokeLinejoin="round" />
        ))}
        {live && live.length > 1 && (
          <path d={strokePath(live, width, height)} stroke={api.penColor} strokeWidth={Math.max(1, (api.penWidth / Math.max(1, pageRef.current?.getBoundingClientRect().width ?? width)) * width)} strokeLinecap="round" strokeLinejoin="round" />
        )}
      </svg>

      {drawingLayer && (
        <div
          data-pdf-ui
          className="absolute inset-0 z-[3] touch-none"
          style={{ cursor: api.tool === "eraser" ? "cell" : "crosshair" }}
          onPointerDown={(e) => {
            if (api.tool === "eraser") {
              erasing.current = true;
              eraseAt(toPoint(e));
              return;
            }
            drawing.current = true;
            setLive([toPoint(e)]);
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (api.tool === "eraser") {
              if (erasing.current) eraseAt(toPoint(e));
              return;
            }
            if (!drawing.current) return;
            setLive((pts) => (pts ? [...pts, toPoint(e)] : pts));
          }}
          onPointerUp={() => {
            if (api.tool === "pen" && live && live.length > 1 && pageRef.current) {
              const pageWidth = pageRef.current.getBoundingClientRect().width || width;
              api.onInk(page, live, api.penWidth / pageWidth);
            }
            drawing.current = false;
            erasing.current = false;
            setLive(null);
          }}
          onPointerCancel={() => {
            drawing.current = false;
            erasing.current = false;
            setLive(null);
          }}
        />
      )}

      {picked && (
        <div
          data-pdf-ui
          className="absolute z-30 flex items-center gap-1 rounded-full bg-elevated p-1 shadow-[0_8px_24px_rgba(0,0,0,0.25)] ring-1 ring-line"
          style={{ left: picked.x, top: picked.y }}
          onMouseDown={(e) => e.preventDefault()}
          role="toolbar"
          aria-label="Highlight the selected text"
        >
          <span className="pl-1 pr-0.5 text-muted">
            <Highlighter size={13} />
          </span>
          {HIGHLIGHT_COLORS.map((c) => (
            <button
              key={c.hex}
              type="button"
              aria-label={`Highlight ${c.name.toLowerCase()}`}
              title={c.name}
              onClick={() => {
                api.onHighlight(page, picked.rects, picked.text, c.hex);
                window.getSelection()?.removeAllRanges();
                setPicked(null);
              }}
              className="h-6 w-6 rounded-full ring-1 ring-black/15 transition-transform hover:scale-110"
              style={{ background: c.hex }}
            />
          ))}
          <span aria-hidden className="mx-0.5 h-4 w-px bg-line" />
          <button
            type="button"
            onClick={() => {
              api.onOpenNote(page, `“${picked.text}”\n\n`);
              setPicked(null);
            }}
            aria-label="Turn the selection into a page note"
            title="Add a note about this"
            className="flex h-6 w-6 items-center justify-center rounded-full text-ink/70 hover:bg-ink/[0.07] hover:text-ink"
          >
            <StickyNote size={13} />
          </button>
          <button type="button" onClick={() => setPicked(null)} aria-label="Close" className="flex h-6 w-6 items-center justify-center rounded-full text-muted hover:bg-ink/[0.07]">
            <X size={14} />
          </button>
        </div>
      )}

      {note && !noteOpen && (
        <button
          type="button"
          data-pdf-ui
          onClick={() => api.onOpenNote(page)}
          aria-label={`Edit the note on page ${page}`}
          className="absolute right-2 top-2 z-[4] flex w-[min(15rem,58%)] items-start gap-1.5 rounded-lg border border-[#e6d27a] bg-[#fff9db] p-2 text-left text-[#5f4b00] shadow-[0_6px_18px_rgba(0,0,0,0.16)] transition-transform hover:-translate-y-0.5"
        >
          <StickyNote size={13} className="mt-0.5 shrink-0" />
          <span className="line-clamp-4 text-[11.5px] leading-snug">{note.text}</span>
        </button>
      )}

      {noteOpen && (
        <div data-pdf-ui className="absolute right-2 top-2 z-[5] w-[min(18rem,88%)] rounded-xl bg-white p-2 text-[#17171a] shadow-[0_14px_36px_rgba(0,0,0,0.28)] ring-1 ring-black/10">
          <div className="mb-1 flex items-center gap-1.5 px-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-[#6b6b6b]">
            <StickyNote size={12} /> Note on page {page}
          </div>
          <textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                e.stopPropagation();
                api.onCloseNote();
              }
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") api.onSaveNote(page, draft);
            }}
            rows={4}
            placeholder="What matters on this page?"
            aria-label={`Note on page ${page}`}
            className="w-full resize-y rounded-lg border border-black/10 bg-[#fffdf3] px-2 py-1.5 text-[16px] leading-relaxed outline-none focus:border-black/30 sm:text-[12.5px]"
          />
          <div className="mt-1.5 flex items-center gap-1">
            {note && (
              <button type="button" onClick={() => api.onDeleteNote(page)} className="rounded-full px-2 py-1 text-[11.5px] font-medium text-[#b42318] hover:bg-[#fee4e2]">
                Delete
              </button>
            )}
            <span className="flex-1" />
            <button type="button" onClick={api.onCloseNote} className="rounded-full px-2 py-1 text-[11.5px] font-medium text-[#666] hover:bg-black/5">
              Cancel
            </button>
            <button type="button" onClick={() => api.onSaveNote(page, draft)} className="rounded-full bg-[#17171a] px-2.5 py-1 text-[11.5px] font-semibold text-white hover:bg-black">
              Save
            </button>
          </div>
        </div>
      )}
    </>
  );
}

/* --------------------------------------------------------------------- list */

/** Every highlight, drawing and page note in the PDF, grouped by page. */
export function AnnotationsSheet({
  open,
  onClose,
  marks,
  current,
  onGoToPage,
  onDelete,
  onClearPage,
}: {
  open: boolean;
  onClose: () => void;
  marks: PdfAnnotation[];
  current: number;
  onGoToPage: (page: number) => void;
  onDelete: (id: string) => void;
  onClearPage: (page: number) => void;
}) {
  const pages = useMemo(() => {
    const m = new Map<number, PdfAnnotation[]>();
    for (const a of marks) m.set(a.page, [...(m.get(a.page) ?? []), a]);
    return [...m.entries()].sort((a, b) => a[0] - b[0]);
  }, [marks]);

  return (
    <Sheet open={open} onClose={onClose} title="Annotations" description="Highlights, drawings and page notes, saved with this PDF." wide>
      {pages.length === 0 ? (
        <div className="rounded-2xl bg-card p-6 text-center ring-1 ring-line">
          <Highlighter size={22} className="mx-auto text-muted" />
          <h3 className="mt-2 text-[15px] font-semibold">Nothing marked yet</h3>
          <p className="mx-auto mt-1 max-w-xs text-[13px] leading-relaxed text-muted">Select text on a page to highlight it, use the pen to draw, or add a note to a page. Annotations stay with the PDF.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {pages.map(([page, items]) => (
            <section key={page}>
              <div className="mb-1.5 flex items-center gap-2 px-1">
                <button type="button" onClick={() => onGoToPage(page)} className={cn("text-[13px] font-semibold transition-colors hover:text-ink", page === current ? "text-ink" : "text-ink/75")}>
                  Page {page}
                  {page === current && <span className="ml-1.5 rounded-full bg-ink px-1.5 py-0.5 text-[10px] font-medium text-white">here</span>}
                </button>
                <span className="text-[12px] text-muted">
                  {items.length} {items.length === 1 ? "mark" : "marks"}
                </span>
                <span className="flex-1" />
                <button type="button" onClick={() => onClearPage(page)} className="rounded-full px-2 py-1 text-[11.5px] font-medium text-muted transition-colors hover:bg-danger-bg hover:text-danger-fg">
                  Clear page
                </button>
              </div>
              <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-card ring-1 ring-line">
                {items.map((a) => (
                  <li key={a.id} className="flex items-start gap-3 px-3.5 py-2.5">
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink/[0.05] text-ink/70">
                      {a.kind === "highlight" ? <Highlighter size={14} /> : a.kind === "ink" ? <PenLine size={14} /> : <StickyNote size={14} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-medium">{annotationLabel(a)}</div>
                      <p className="line-clamp-2 text-[12px] leading-relaxed text-muted" dir="auto">
                        {a.kind === "highlight" ? a.text : a.kind === "note" ? a.text : `${a.points.length} points · ${a.color}`}
                      </p>
                    </div>
                    {a.kind === "highlight" && (
                      <span aria-hidden className="mt-1 h-3.5 w-3.5 shrink-0 rounded-full ring-1 ring-black/10" style={{ background: a.color }} />
                    )}
                    <button type="button" onClick={() => onDelete(a.id)} aria-label={`Delete ${annotationLabel(a)}`} className="rounded-full p-1.5 text-muted transition-colors hover:bg-danger-bg hover:text-danger-fg">
                      <Trash2 size={14} />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
          <Button variant="ghost" size="sm" onClick={onClose}>
            Done
          </Button>
        </div>
      )}
    </Sheet>
  );
}
