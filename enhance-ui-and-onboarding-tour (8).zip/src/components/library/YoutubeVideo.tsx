import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowRight, Captions, ClipboardPaste, Copy, ExternalLink, FileText, Loader2, Play, RefreshCw, Search, Sparkles, TriangleAlert, Upload, X } from "lucide-react";
import { db, uid, type LibFile, type Note, type TranscriptSegment } from "@/lib/db";
import { useApp } from "@/lib/store";
import { usePane } from "@/components/Pane";
import { refreshYoutubeCaptions, rememberDuration, saveTranscript, stamp, transcriptLabel, transcriptExcerpt, watchUrl, parseTranscriptText } from "@/lib/youtube";
import { transcribeBlob, transcriptionConfigured } from "@/lib/transcribe";
import { indexNote } from "@/lib/retrieval";
import { navigate } from "@/lib/router";
import { Button, Sheet } from "@/components/ui";
import YouTubePlayer from "@/components/YouTubePlayer";
import YoutubeGlyph from "@/components/YoutubeGlyph";
import { cn } from "@/utils/cn";

const markdownClock = (s: number) => stamp(s);

/**
 * A YouTube video in the library: the clean player, its details, and the transcript Leo reads.
 * The transcript can come from YouTube's captions, be pasted, or be produced once from an uploaded
 * copy of the video through the learner's transcription provider.
 */
export default function YoutubeVideoPage({ file: initial, bar }: { file: LibFile; bar: ReactNode }) {
  // The row is live, so the transcript filling in (or its duration arriving) is shown as it lands.
  const live = useLiveQuery(() => db.files.get(initial.id), [initial.id]);
  const file = live ?? initial;
  const pane = usePane();
  const [time, setTime] = useState(0);
  const [seek, setSeek] = useState<{ t: number; n: number } | null>(null);
  const seekCount = useRef(0);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<"captions" | "upload" | null>(null);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasted, setPasted] = useState("");
  const [pasteError, setPasteError] = useState("");
  const [showAll, setShowAll] = useState(false);
  const upload = useRef<HTMLInputElement>(null);
  const reported = useRef(0);

  const chunks = useLiveQuery(() => db.chunks.where("sourceId").equals(initial.id).toArray(), [initial.id, file.transcript?.length, file.transcriptState]);
  const segments: TranscriptSegment[] = useMemo(() => {
    if (file.transcript?.length) return file.transcript;
    return (chunks ?? [])
      .filter((c) => typeof c.t0 === "number")
      .map((c) => ({ t0: c.t0 ?? 0, t1: c.t1 ?? (c.t0 ?? 0) + 4, text: c.text }))
      .sort((a, b) => a.t0 - b.t0);
  }, [file.transcript, chunks]);

  const key = `${segments.length}:${segments[0]?.t0 ?? 0}:${file.transcriptState ?? ""}`;

  // Leo receives the transcript with every message while this page is open (see the chat composer).
  useEffect(() => {
    useApp.getState().setVideo({ fileId: file.id, title: file.name, text: transcriptExcerpt(file, 6000) });
    return () => {
      if (useApp.getState().video?.fileId === file.id) useApp.getState().setVideo(null);
    };
  }, [file.id, file.name, key]); // eslint-disable-line react-hooks/exhaustive-deps

  const currentSeg = segments.find((s) => time >= s.t0 && time < s.t1) ?? null;
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? segments.filter((s) => s.text.toLowerCase().includes(q)) : segments;
  }, [segments, query]);
  const shown = showAll ? filtered : filtered.slice(0, 400);

  const jump = (t: number) => {
    seekCount.current += 1;
    setSeek({ t, n: seekCount.current });
    setTime(t);
  };

  const onProgress = (t: number, duration: number) => {
    setTime(t);
    if (duration > 0 && Math.abs(duration - reported.current) > 1) {
      reported.current = duration;
      void rememberDuration(file, duration);
    }
  };

  const retryCaptions = async () => {
    setBusy("captions");
    try {
      const ok = await refreshYoutubeCaptions(file.id);
      useApp.getState().showToast(ok ? "Transcript saved" : "YouTube still won't share the captions here", { tone: ok ? "success" : "error" });
    } finally {
      setBusy(null);
    }
  };

  const onUpload = async (uploaded?: File) => {
    if (!uploaded) return;
    if (!transcriptionConfigured()) {
      useApp.getState().showToast("Transcription isn't set up yet. Choose a provider in Settings → Transcription.", {
        action: { label: "Settings", onClick: () => navigate("settings") },
      });
      return;
    }
    setBusy("upload");
    await db.files.update(file.id, { transcriptState: "fetching", transcriptNote: `Listening to “${uploaded.name}”…` });
    try {
      const segs = await transcribeBlob(uploaded);
      if (!segs.length) throw new Error("No speech was found in that file.");
      await saveTranscript(file.id, segs, "audio");
      useApp.getState().showToast("Transcript ready — Leo can now quiz you on the video", { tone: "success" });
    } catch (e) {
      const why = e instanceof Error ? e.message : String(e);
      await db.files.update(file.id, { transcriptState: "failed", transcriptNote: why.slice(0, 240) });
      useApp.getState().showToast(`Transcription failed: ${why}`);
    } finally {
      setBusy(null);
    }
  };

  const savePasted = async () => {
    const segs = parseTranscriptText(pasted, file.duration ?? 0);
    if (!segs.length) {
      setPasteError("Add at least a sentence of the transcript.");
      return;
    }
    await saveTranscript(file.id, segs, "pasted");
    setPasteOpen(false);
    setPasted("");
    setPasteError("");
    useApp.getState().showToast("Transcript saved — Leo can now quiz you on the video", { tone: "success" });
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(segments.map((s) => `[${stamp(s.t0)}] ${s.text}`).join("\n"));
      useApp.getState().showToast("Transcript copied");
    } catch {
      useApp.getState().showToast("Your browser didn't allow copying");
    }
  };

  const saveAsNote = async () => {
    const now = Date.now();
    const id = uid();
    const content = [
      `Source: [${file.name}](${file.youtubeUrl ?? watchUrl(file.youtubeId ?? "")})${file.channel ? ` · ${file.channel}` : ""}`,
      "",
      ...segments.map((s) => `**[${markdownClock(s.t0)}](${watchUrl(file.youtubeId ?? "")}&t=${Math.floor(s.t0)}s)** ${s.text}`),
    ].join("\n\n");
    const note: Note = { id, projectId: file.projectId, title: `${file.name} — transcript`, content, author: "user", createdAt: now, updatedAt: now };
    await db.notes.add(note);
    await indexNote(note);
    useApp.getState().showToast("Transcript saved as a note", { tone: "success", action: { label: "Open", onClick: () => pane.open({ kind: "note", id }) } });
  };

  const empty = file.transcriptState === "fetching";
  const unavailable = file.transcriptState === "unavailable" || file.transcriptState === "failed";

  return (
    <>
      {bar}
      <div className="@container min-h-0 overflow-y-auto pb-24">
        <div className="mx-auto grid max-w-6xl gap-4 p-3 pb-28 sm:p-4 @3xl:grid-cols-[minmax(0,1fr)_23rem] @3xl:items-start @3xl:gap-5">
          <div className="min-w-0">
            <YouTubePlayer
              key={file.youtubeId}
              id={file.youtubeId ?? ""}
              title={file.name}
              clean
              onProgress={onProgress}
              seek={seek}
            />
            <div className="mt-3 px-0.5">
              <h1 className="display text-[20px] leading-snug" dir="auto">
                {file.name}
              </h1>
              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] text-muted">
                {file.channel && <span className="truncate">{file.channel}</span>}
                {file.channel && <span aria-hidden>·</span>}
                <span className="inline-flex items-center gap-1">
                  <YoutubeGlyph size={13} /> YouTube
                </span>
                {file.duration ? (
                  <>
                    <span aria-hidden>·</span>
                    <span className="tabular-nums">{stamp(file.duration)}</span>
                  </>
                ) : null}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button onClick={() => useApp.getState().setChatOpen(true)}>
                  <Sparkles size={15} /> Ask Leo about this video
                </Button>
                {file.youtubeUrl && (
                  <Button variant="soft" onClick={() => window.open(file.youtubeUrl, "_blank", "noopener")}>
                    <ExternalLink size={15} /> Open on YouTube
                  </Button>
                )}
              </div>
              <p className="mt-3 text-[12.5px] leading-relaxed text-muted">
                Leo can't watch the video, but he reads the transcript and can answer, explain and quiz you on any part of it. Tap a timestamp to jump there.
              </p>
            </div>
          </div>

          <aside aria-label="Video transcript" className="min-w-0 rounded-2xl bg-card ring-1 ring-line @3xl:sticky @3xl:top-3">
            <div className="border-b border-line px-3.5 py-2.5">
              <div className="flex items-center gap-2">
                <Captions size={16} className="shrink-0 text-muted" />
                <h2 className="min-w-0 flex-1 text-[14px] font-semibold">Transcript</h2>
                {segments.length > 0 && <span className="rounded-full bg-ink/[0.06] px-2 py-0.5 text-[11px] font-medium text-muted">{segments.length} lines</span>}
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[12px]">
                <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5", segments.length ? "bg-ok-bg text-ok-fg" : "bg-ink/[0.05] text-muted")}>
                  {segments.length ? transcriptLabel(file) : file.transcriptState === "fetching" ? "Fetching…" : "No transcript yet"}
                </span>
                {segments.length > 0 && (
                  <>
                    <button type="button" onClick={() => void copy()} className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink">
                      <Copy size={12} /> Copy
                    </button>
                    <button type="button" onClick={() => void saveAsNote()} className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink">
                      <FileText size={12} /> Save to notes
                    </button>
                  </>
                )}
              </div>
              {segments.length > 3 && (
                <div className="relative mt-2">
                  <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Find a line"
                    aria-label="Find a line in the transcript"
                    className="h-8 w-full rounded-full bg-ink/[0.05] pl-8 pr-7 text-[16px] outline-none focus:bg-ink/[0.08] sm:text-[13px]"
                  />
                  {query && (
                    <button type="button" onClick={() => setQuery("")} className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted hover:bg-ink/[0.06]" aria-label="Clear search">
                      <X size={12} />
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="max-h-[26rem] overflow-y-auto p-2 @3xl:max-h-[calc(100dvh-14rem)]">
              {segments.length > 0 ? (
                <>
                  {filtered.length === 0 && <p className="px-2.5 py-6 text-center text-[13px] text-muted">No line matches “{query}”.</p>}
                  <ul className="space-y-0.5">
                    {shown.map((s, i) => {
                      const active = currentSeg === s;
                      return (
                        <li key={`${s.t0}:${i}`}>
                          <button
                            type="button"
                            onClick={() => jump(s.t0)}
                            aria-current={active ? "true" : undefined}
                            className={cn(
                              "flex w-full items-start gap-2 rounded-xl px-2 py-1.5 text-left transition-colors",
                              active ? "bg-ink/[0.07]" : "hover:bg-ink/[0.04]"
                            )}
                          >
                            <span className={cn("mt-0.5 shrink-0 rounded-full px-1.5 py-0.5 text-[11px] font-medium tabular-nums", active ? "bg-ink text-white" : "bg-ink/[0.05] text-muted")}>
                              {stamp(s.t0)}
                            </span>
                            <span className="min-w-0 flex-1 text-[13px] leading-relaxed" dir="auto">
                              {s.text}
                            </span>
                            {active && <Play size={11} className="mt-1 shrink-0 text-ink" fill="currentColor" />}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                  {filtered.length > shown.length && (
                    <button type="button" onClick={() => setShowAll(true)} className="mt-1 flex w-full items-center justify-center gap-1 rounded-xl px-2 py-2 text-[12.5px] font-medium text-muted hover:bg-ink/[0.04] hover:text-ink">
                      Show all {filtered.length} lines <ArrowRight size={13} />
                    </button>
                  )}
                </>
              ) : empty ? (
                <div className="px-3 py-6 text-center">
                  <Loader2 size={20} className="mx-auto animate-spin text-muted" />
                  <p className="mt-2 text-[13px] font-medium">Fetching the transcript…</p>
                  <p className="mt-1 text-[12px] leading-relaxed text-muted">{file.transcriptNote ?? "YouTube's captions are being looked up. You can add a transcript yourself below if it takes long."}</p>
                </div>
              ) : (
                <div className="p-1.5">
                  <div className="rounded-xl bg-ink/[0.03] p-3">
                    <div className="flex items-start gap-2">
                      <TriangleAlert size={15} className={cn("mt-0.5 shrink-0", unavailable ? "text-warn-fg" : "text-muted")} />
                      <div className="min-w-0">
                        <div className="text-[13px] font-semibold">Leo needs the transcript</div>
                        <p className="mt-0.5 text-[12px] leading-relaxed text-muted">
                          {file.transcriptNote ?? "This video has no transcript yet."} Without one, Leo can still answer general questions, but not quiz you on the video's content.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-2 grid gap-1.5">
                    <Button size="sm" onClick={() => setPasteOpen(true)}>
                      <ClipboardPaste size={14} /> Paste a transcript
                    </Button>
                    <Button size="sm" variant="soft" disabled={busy === "upload"} onClick={() => upload.current?.click()}>
                      {busy === "upload" ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />} Transcribe the video's audio
                    </Button>
                    <Button size="sm" variant="ghost" disabled={busy === "captions"} onClick={() => void retryCaptions()}>
                      {busy === "captions" ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} Try YouTube's captions again
                    </Button>
                  </div>
                  <p className="mt-2 px-1 text-[11px] leading-relaxed text-muted">
                    Transcribing needs a provider in Settings → Transcription. The uploaded file is used once and not stored.
                  </p>
                </div>
              )}
            </div>
            <input
              ref={upload}
              type="file"
              accept="video/*,audio/*"
              className="hidden"
              onChange={(e) => {
                void onUpload(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
          </aside>
        </div>
      </div>

      <Sheet open={pasteOpen} onClose={() => setPasteOpen(false)} title="Paste a transcript" description="Use the text from YouTube's “Show transcript”, or any accurate transcript.">
        <div className="space-y-3">
          <textarea
            value={pasted}
            onChange={(e) => {
              setPasted(e.target.value);
              setPasteError("");
            }}
            rows={10}
            dir="auto"
            aria-label="Transcript text"
            placeholder={"You can keep timestamps, one per line:\n0:00 Welcome back\n0:12 Today we look at cells\n\nOr paste plain text and Harness will spread it across the video."}
            className="w-full resize-y rounded-2xl border border-line bg-card px-3.5 py-3 font-mono text-[13px] leading-relaxed outline-none focus:border-ink/30 focus:ring-4 focus:ring-black/[0.05]"
          />
          {pasteError && <p className="text-[12px] text-danger-fg">{pasteError}</p>}
          <p className="text-[12px] leading-relaxed text-muted">
            Timestamps make the transcript more useful: Leo can point to an exact moment and the video can jump there. Each line becomes searchable.
          </p>
          <Button size="lg" className="w-full" disabled={!pasted.trim()} onClick={() => void savePasted()}>
            <Captions size={16} /> Save transcript
          </Button>
        </div>
      </Sheet>
    </>
  );
}
