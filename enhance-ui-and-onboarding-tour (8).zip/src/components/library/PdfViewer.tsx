import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { Loader2, Minus, Plus, RotateCcw } from "lucide-react";
import type { PDFDocumentProxy } from "pdfjs-dist/legacy/build/pdf.mjs";
import type { LibFile, PdfAnnotation } from "@/lib/db";
import { closePdf, getPdfjs, openPdf, setPdfReaderActive } from "@/lib/media";
import { useApp } from "@/lib/store";
import { arabicFallback } from "@/lib/pdfAssets";
import { HIGHLIGHT_COLORS, PEN_COLORS, PEN_WIDTHS, addHighlight, addInk, clearPage, deleteAnnotation, listAnnotations, pageMarksSummary, savePageNote, undoLast } from "@/lib/pdfAnnotations";
import { confirmDialog } from "@/lib/confirm";
import { isSheetOpen } from "@/components/ui";
import { AnnotationsSheet, PdfMarks, PdfToolbar, type PdfMarksApi, type PdfTool } from "./PdfAnnotations";

const TOUCH = typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches;
/** Phones: at most 2× and ~5 MP per page — sharp text, and safe for iOS's canvas memory limit. */
const MAX_DPR = TOUCH ? 2 : 3;
const MAX_CANVAS_PIXELS = TOUCH ? 5_000_000 : 16_000_000;
/** Pages are drawn when they are within this many viewports of the visible area; beyond that they are released. */
const PRELOAD = "120%";
/** Pages drawn at the same time. Keeps canvas memory flat on phones and big documents. */
const CONCURRENCY = TOUCH ? 1 : 2;
/** Space kept above a page when jumping to it. */
const TOP_GAP = 72;
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 3;
const ZOOM_STEP = 0.25;
const NO_MARKS: PdfAnnotation[] = [];

interface Job {
  priority: () => number;
  run: (signal: AbortSignal) => Promise<void>;
  ctrl: AbortController;
}

/**
 * Runs page renders with a small concurrency limit, nearest-to-the-reader first. A cancelled job
 * frees its slot immediately, so a stuck page can never block the pages after it (this was the
 * cause of "only page 1 renders").
 */
class RenderScheduler {
  private queue: Job[] = [];
  private running = 0;
  constructor(private readonly limit: number) {}

  schedule(priority: () => number, run: (signal: AbortSignal) => Promise<void>): () => void {
    const job: Job = { priority, run, ctrl: new AbortController() };
    this.queue.push(job);
    this.pump();
    return () => {
      const i = this.queue.indexOf(job);
      if (i >= 0) this.queue.splice(i, 1);
      job.ctrl.abort();
    };
  }

  private pump() {
    while (this.running < this.limit && this.queue.length > 0) {
      this.queue.sort((a, b) => a.priority() - b.priority());
      const job = this.queue.shift() as Job;
      this.running++;
      const aborted = new Promise<void>((resolve) => job.ctrl.signal.addEventListener("abort", () => resolve(), { once: true }));
      Promise.race([job.run(job.ctrl.signal), aborted])
        .catch(() => {
          /* each page reports its own failure */
        })
        .finally(() => {
          this.running--;
          this.pump();
        });
    }
  }
}

/**
 * Continuous-scroll PDF reader. Only pages near the viewport are rendered (IntersectionObserver),
 * every page has a placeholder of the right height so scrolling works for 500+ page files, and
 * pages that scroll away are cancelled and released. `bar` renders the single top bar and receives
 * the page/zoom controls to place inside it.
 */
export default function PdfViewer({ file, bar }: { file: LibFile; bar?: (controls: ReactNode) => ReactNode }) {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [err, setErr] = useState("");
  const [ratio, setRatio] = useState(1.294);
  const [fitWidth, setFitWidth] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [current, setCurrent] = useState(1);
  const [draft, setDraft] = useState<string | null>(null);
  const [scroller, setScroller] = useState<HTMLDivElement | null>(null);
  // Annotation tools: highlights, pen, eraser, page notes.
  const [tool, setTool] = useState<PdfTool>("select");
  const [highlightColor, setHighlightColor] = useState<string>(HIGHLIGHT_COLORS[0].hex);
  const [penColor, setPenColor] = useState<string>(PEN_COLORS[0].hex);
  const [penWidth, setPenWidth] = useState<number>(PEN_WIDTHS[1].px);
  const [notePage, setNotePage] = useState<number | null>(null);
  const [noteSeed, setNoteSeed] = useState("");
  const [listOpen, setListOpen] = useState(false);
  const annotations = useLiveQuery(() => listAnnotations(file.id), [file.id]) ?? NO_MARKS;
  const byPage = useMemo(() => {
    const map = new Map<number, PdfAnnotation[]>();
    for (const a of annotations) map.set(a.page, [...(map.get(a.page) ?? []), a]);
    return map;
  }, [annotations]);
  const showToast = useApp((s) => s.showToast);
  const [scheduler] = useState(() => new RenderScheduler(CONCURRENCY));
  const pageEls = useRef<(HTMLDivElement | null)[]>([]);
  const currentRef = useRef(1);
  currentRef.current = current;
  const restored = useRef(false);
  const raf = useRef(0);
  const setPdf = useApp((s) => s.setPdf);
  const width = Math.max(0, Math.floor(fitWidth * zoom));

  // While reading, background indexing steps aside (it would load a second copy of the PDF).
  useEffect(() => {
    setPdfReaderActive(true);
    return () => setPdfReaderActive(false);
  }, []);

  useEffect(() => {
    let d: PDFDocumentProxy | null = null;
    let cancelled = false;
    restored.current = false;
    setErr("");
    openPdf(file.blob)
      .then(async (x) => {
        if (cancelled) return closePdf(x);
        d = x;
        try {
          const vp = (await x.getPage(1)).getViewport({ scale: 1 });
          if (!cancelled) setRatio(vp.height / vp.width);
        } catch {
          /* keep default ratio */
        }
        if (!cancelled) setDoc(x);
      })
      .catch((e) => {
        if (!cancelled) setErr(String(e?.message || e));
      });
    return () => {
      cancelled = true;
      closePdf(d);
      setDoc(null);
    };
  }, [file.id, file.blob]);

  useEffect(() => {
    if (!scroller) return;
    const ro = new ResizeObserver(() => setFitWidth(Math.max(0, Math.min(scroller.clientWidth - 24, 900))));
    ro.observe(scroller);
    return () => ro.disconnect();
  }, [scroller]);

  const register = useCallback((n: number, el: HTMLDivElement | null) => {
    pageEls.current[n - 1] = el;
  }, []);

  const scrollToPage = useCallback(
    (n: number, smooth = false) => {
      const el = pageEls.current[n - 1];
      const sc = scroller;
      if (!el || !sc) return;
      const top = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop;
      sc.scrollTo({ top: Math.max(0, top - TOP_GAP), behavior: smooth ? "smooth" : "auto" });
    },
    [scroller]
  );

  /** Current page = the last page whose top is above 35% of the visible area (binary search over page rects). */
  const measure = useCallback(() => {
    const sc = scroller;
    if (!sc) return;
    const probe = sc.getBoundingClientRect().top + sc.clientHeight * 0.35;
    const els = pageEls.current;
    let lo = 0;
    let hi = els.length - 1;
    let found = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const el = els[mid];
      if (!el) {
        lo = mid + 1;
        continue;
      }
      if (el.getBoundingClientRect().top <= probe) {
        found = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    const cur = found + 1;
    if (cur !== currentRef.current) setCurrent(cur);
  }, [scroller]);

  const schedule = useCallback(() => {
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0;
      measure();
    });
  }, [measure]);

  useEffect(() => {
    window.addEventListener("resize", schedule);
    return () => {
      window.removeEventListener("resize", schedule);
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [schedule]);

  // Reopen where you left off.
  useLayoutEffect(() => {
    if (!doc || width <= 0 || restored.current) return;
    restored.current = true;
    const saved = Math.min(doc.numPages, Math.max(1, Number(localStorage.getItem("pdfpage." + file.id)) || 1));
    if (saved > 1) {
      setCurrent(saved);
      requestAnimationFrame(() => scrollToPage(saved));
    }
  }, [doc, width, file.id, scrollToPage]);

  // A tapped citation ("book.pdf, p.12") jumps here even when this PDF is already open.
  useEffect(() => {
    const on = (e: Event) => {
      const d = (e as CustomEvent<{ fileId: string; page?: number }>).detail;
      if (!doc || d?.fileId !== file.id || !d.page) return;
      const p = Math.min(doc.numPages, Math.max(1, d.page));
      setCurrent(p);
      requestAnimationFrame(() => scrollToPage(p));
    };
    window.addEventListener("harness:seek", on);
    return () => window.removeEventListener("harness:seek", on);
  }, [doc, file.id, scrollToPage]);

  // Keep the current page in view when zooming.
  const prevWidth = useRef(width);
  useLayoutEffect(() => {
    if (prevWidth.current > 0 && prevWidth.current !== width) scrollToPage(currentRef.current);
    prevWidth.current = width;
  }, [width, scrollToPage]);

  useEffect(() => {
    localStorage.setItem("pdfpage." + file.id, String(current));
  }, [current, file.id]);

  // Share the page being read with Leo.
  useEffect(() => {
    if (!doc) return;
    let alive = true;
    const t = window.setTimeout(async () => {
      try {
        const tc = await (await doc.getPage(current)).getTextContent();
        const text = tc.items
          .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
          .join("")
          .replace(/[ \t]+/g, " ")
          .trim();
        // What the learner marked on this page is part of the page for Leo, too.
        const marked = pageMarksSummary(annotations.filter((a) => a.page === current));
        if (alive) setPdf({ fileId: file.id, name: file.name, page: current, pages: doc.numPages, text: marked ? `${text}\n\n${marked}` : text });
      } catch {
        /* document closed while switching */
      }
    }, 200);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [doc, current, file.id, file.name, setPdf, annotations]);
  // Only clear what this viewer shared: a second pane may be showing another PDF.
  useEffect(
    () => () => {
      if (useApp.getState().pdf?.fileId === file.id) setPdf(null);
    },
    [setPdf, file.id]
  );

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  const numPages = doc?.numPages ?? file.pages ?? 0;
  const commitDraft = () => {
    const n = parseInt(draft ?? "", 10);
    if (n >= 1 && n <= numPages) {
      setCurrent(n);
      scrollToPage(n, true);
    }
    setDraft(null);
  };
  const zoomBy = (d: number) => setZoom((z) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round((z + d) / ZOOM_STEP) * ZOOM_STEP)));

  const goTo = useCallback(
    (page: number) => {
      setCurrent(page);
      scrollToPage(page, true);
    },
    [scrollToPage]
  );

  const removeOne = useCallback(
    async (id: string) => {
      const row = annotations.find((a) => a.id === id);
      await deleteAnnotation(id);
      showToast(row ? `${row.kind === "highlight" ? "Highlight" : row.kind === "ink" ? "Drawing" : "Page note"} removed` : "Removed");
    },
    [annotations, showToast]
  );

  const marksApi = useMemo<PdfMarksApi>(
    () => ({
      tool,
      highlightColor,
      penColor,
      penWidth,
      notePage,
      noteSeed,
      onOpenNote: (page, seed) => {
        setNoteSeed(seed ?? "");
        setNotePage(page);
        if (page !== currentRef.current) goTo(page);
      },
      onCloseNote: () => {
        setNotePage(null);
        setNoteSeed("");
      },
      onSaveNote: (page, text) => {
        void savePageNote(file.projectId, file.id, page, text).then((row) => {
          setNotePage(null);
          setNoteSeed("");
          showToast(text.trim() ? "Page note saved" : "Page note removed", row ? { action: { label: "Undo", onClick: () => void deleteAnnotation(row.id) } } : undefined);
        });
      },
      onDeleteNote: (page) => {
        void savePageNote(file.projectId, file.id, page, "").then(() => {
          setNotePage(null);
          showToast("Page note removed");
        });
      },
      onHighlight: (page, rects, text, color) => {
        void addHighlight(file.projectId, file.id, page, color, rects, text).then((row) => {
          if (row) showToast(`Highlighted · page ${page}`, { action: { label: "Undo", onClick: () => void deleteAnnotation(row.id) } });
        });
      },
      onInk: (page, points, width) => {
        void addInk(file.projectId, file.id, page, penColor, width, points).then((row) => {
          if (row) showToast("Drawing saved", { action: { label: "Undo", onClick: () => void deleteAnnotation(row.id) } });
        });
      },
      onErase: (id) => void deleteAnnotation(id),
    }),
    [tool, highlightColor, penColor, penWidth, notePage, noteSeed, file.projectId, file.id, goTo, showToast]
  );

  const undo = async () => {
    const row = await undoLast(file.id);
    if (!row) return showToast("Nothing to undo on this PDF");
    showToast(`Removed ${row.kind === "highlight" ? "a highlight" : row.kind === "ink" ? "a drawing" : "a page note"} · page ${row.page}`);
  };

  const clear = async (page: number) => {
    const ok = await confirmDialog({ title: `Clear page ${page}?`, message: "Highlights, drawings and the page note on this page will be removed. This cannot be undone.", confirmLabel: "Clear page", tone: "danger" });
    if (!ok) return;
    const n = await clearPage(file.id, page);
    showToast(`Cleared ${n} ${n === 1 ? "mark" : "marks"} on page ${page}`);
  };

  // Keyboard: V select, H highlight, P pen, E eraser, N page note, Esc back to selecting.
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const el = e.target as HTMLElement | null;
      if (el?.closest("input,textarea,select,[contenteditable=true]") || isSheetOpen()) return;
      const k = e.key.toLowerCase();
      const toolKey: Record<string, PdfTool> = { v: "select", h: "highlight", p: "pen", e: "eraser", n: "note" };
      if (k === "escape") {
        if (notePage !== null) {
          setNotePage(null);
          e.preventDefault();
        } else if (tool !== "select") {
          setTool("select");
          e.preventDefault();
        }
        return;
      }
      if (!toolKey[k]) return;
      e.preventDefault();
      setTool(toolKey[k]);
      if (k === "n") setNotePage(currentRef.current);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [notePage, tool]);

  const controls = (
    <div className="flex flex-wrap items-center justify-center gap-1.5">
      <PdfToolbar
        tool={tool}
        onTool={(t) => {
          setTool(t);
          if (t === "note") setNotePage(currentRef.current);
        }}
        highlightColor={highlightColor}
        onHighlightColor={setHighlightColor}
        penColor={penColor}
        onPenColor={setPenColor}
        penWidth={penWidth}
        onPenWidth={setPenWidth}
        count={annotations.length}
        onUndo={() => void undo()}
        onList={() => setListOpen(true)}
      />
      <div className="flex shrink-0 items-center gap-0.5 rounded-full bg-ink/[0.05] p-0.5 text-[13px] tabular-nums">
      <button
        type="button"
        onClick={() => zoomBy(-ZOOM_STEP)}
        disabled={zoom <= ZOOM_MIN}
        aria-label="Zoom out"
        className="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-ink/[0.07] disabled:opacity-35 sm:h-8 sm:w-8"
      >
        <Minus size={16} />
      </button>
      <button
        type="button"
        onClick={() => setZoom(1)}
        aria-label="Reset zoom to 100%"
        title="Reset zoom to 100%"
        className="h-9 min-w-[52px] rounded-full px-1.5 font-medium transition-colors hover:bg-ink/[0.07] sm:h-8"
      >
        {Math.round(zoom * 100)}%
      </button>
      <button
        type="button"
        onClick={() => zoomBy(ZOOM_STEP)}
        disabled={zoom >= ZOOM_MAX}
        aria-label="Zoom in"
        className="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-ink/[0.07] disabled:opacity-35 sm:h-8 sm:w-8"
      >
        <Plus size={16} />
      </button>
      <span className="mx-1 h-4 w-px bg-line" aria-hidden />
      <label className="flex items-center gap-1 pl-1 pr-2">
        <input
          value={draft ?? String(current)}
          onChange={(e) => setDraft(e.target.value.replace(/\D/g, ""))}
          onFocus={(e) => {
            setDraft(String(current));
            e.currentTarget.select();
          }}
          onBlur={commitDraft}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          inputMode="numeric"
          aria-label="Go to page"
          className="h-9 w-12 rounded-full bg-ink/[0.06] text-center text-[16px] outline-none focus:bg-ink/[0.1] sm:h-8 sm:text-[13px]"
        />
        <span className="text-muted">/ {numPages || "…"}</span>
      </label>
      </div>
    </div>
  );

  return (
    <div className="absolute inset-0 flex flex-col">
      {bar ? bar(controls) : <div className="flex shrink-0 justify-center border-b border-line bg-paper px-2 py-2">{controls}</div>}
      <div
        ref={setScroller}
        onScroll={schedule}
        data-pdf-scroller
        data-ctx-source={`PDF "${file.name}" p.${current}`}
        className="relative min-h-0 flex-1 overflow-auto overscroll-contain bg-document"
      >
        {err ? (
          <p className="p-6 text-center text-sm text-danger-fg">Couldn&apos;t open this PDF: {err}</p>
        ) : !doc || width <= 0 ? (
          <div className="flex justify-center py-24">
            <Loader2 className="animate-spin text-muted" />
          </div>
        ) : (
          <div className="mx-auto flex w-max min-w-full flex-col items-center gap-3 px-3 pb-36 pt-4">
            {Array.from({ length: doc.numPages }, (_, i) => (
              <PdfPage
                key={i + 1}
                doc={doc}
                num={i + 1}
                width={width}
                ratio={ratio}
                root={scroller}
                scheduler={scheduler}
                currentRef={currentRef}
                register={register}
                marks={byPage.get(i + 1) ?? NO_MARKS}
                marksApi={marksApi}
              />
            ))}
          </div>
        )}
      </div>
      <AnnotationsSheet
        open={listOpen}
        onClose={() => setListOpen(false)}
        marks={annotations}
        current={current}
        onGoToPage={(p) => {
          goTo(p);
          setListOpen(false);
        }}
        onDelete={(id) => void removeOne(id)}
        onClearPage={(p) => void clear(p)}
      />
    </div>
  );
}

type PageState = "idle" | "queued" | "rendering" | "rendered" | "error";

function PdfPage({
  doc,
  num,
  width,
  ratio,
  root,
  scheduler,
  currentRef,
  register,
  marks,
  marksApi,
}: {
  doc: PDFDocumentProxy;
  num: number;
  width: number;
  ratio: number;
  root: HTMLDivElement | null;
  scheduler: RenderScheduler;
  currentRef: { current: number };
  register: (n: number, el: HTMLDivElement | null) => void;
  marks: PdfAnnotation[];
  marksApi: PdfMarksApi;
}) {
  const box = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [ownRatio, setOwnRatio] = useState<number | null>(null);
  const [state, setState] = useState<PageState>("idle");
  const [attempt, setAttempt] = useState(0);
  /** Width the current bitmap was drawn at (0 = nothing drawn). */
  const drawnAt = useRef(0);

  useEffect(() => {
    register(num, box.current);
    return () => register(num, null);
  }, [num, register]);

  // Lazy: a page only becomes eligible to draw when it is near the reader.
  useEffect(() => {
    const el = box.current;
    if (!el || !root) return;
    const io = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { root, rootMargin: `${PRELOAD} 0px` });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);

  const release = useCallback(() => {
    const c = canvasRef.current;
    if (c) {
      c.width = 0;
      c.height = 0;
    }
    textRef.current?.replaceChildren();
    drawnAt.current = 0;
    setState("idle");
  }, []);

  // Far away: give the memory back.
  useEffect(() => {
    if (!visible) release();
  }, [visible, release]);

  // Zoom changed: the old bitmap is the wrong size.
  useEffect(() => {
    if (drawnAt.current !== 0 && drawnAt.current !== width) release();
  }, [width, release]);

  useEffect(() => {
    if (!visible || width <= 0 || drawnAt.current === width) return;
    setState((s) => (s === "rendered" ? s : "queued"));
    const cancel = scheduler.schedule(
      () => Math.abs(num - currentRef.current),
      async (signal) => {
        setState((s) => (s === "rendered" ? s : "rendering"));
        try {
          const page = await doc.getPage(num);
          if (signal.aborted) return;
          const base = page.getViewport({ scale: 1 });
          setOwnRatio(base.height / base.width);
          const scale = width / base.width;
          const vp = page.getViewport({ scale });
          const dpr =
            attempt > 0
              ? 1
              : Math.max(1, Math.min(window.devicePixelRatio || 1, MAX_DPR, Math.sqrt(MAX_CANVAS_PIXELS / (vp.width * vp.height))));
          const canvas = canvasRef.current;
          const raw = canvas?.getContext("2d");
          // Text in fonts the PDF doesn't embed falls back to a bundled Arabic face.
          const ctx = raw ? arabicFallback(raw) : null;
          if (!canvas || !ctx) throw new Error("Canvas unavailable (out of memory?)");
          canvas.width = Math.max(1, Math.floor(vp.width * dpr));
          canvas.height = Math.max(1, Math.floor(vp.height * dpr));
          canvas.style.width = `${Math.floor(vp.width)}px`;
          canvas.style.height = `${Math.floor(vp.height)}px`;
          const task = page.render({ canvasContext: ctx, canvas, viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
          const stop = () => task.cancel();
          signal.addEventListener("abort", stop, { once: true });
          try {
            await task.promise;
          } finally {
            signal.removeEventListener("abort", stop);
          }
          if (signal.aborted) return;
          drawnAt.current = width;
          setState("rendered");
          page.cleanup();

          // The text layer is best-effort: a failure here must never block the page image.
          try {
            const tc = await page.getTextContent();
            if (signal.aborted) return;
            const div = textRef.current;
            if (!div) return;
            div.replaceChildren();
            div.style.setProperty("--total-scale-factor", String(scale));
            const pdfjs = await getPdfjs();
            if (signal.aborted) return;
            const layer = new pdfjs.TextLayer({ textContentSource: tc, container: div, viewport: vp });
            const stopLayer = () => layer.cancel();
            signal.addEventListener("abort", stopLayer, { once: true });
            try {
              await layer.render();
            } finally {
              signal.removeEventListener("abort", stopLayer);
            }
          } catch {
            /* no selectable text on this page */
          }
        } catch (e) {
          if (signal.aborted) return;
          const msg = `${(e as Error)?.name ?? ""} ${(e as Error)?.message ?? ""}`;
          if (/cancel|abort/i.test(msg)) return;
          console.warn(`PDF page ${num} failed to render`, e);
          drawnAt.current = 0;
          // One automatic retry at 1× resolution, then show the error with a Retry button.
          if (attempt === 0) setAttempt(1);
          else setState("error");
        }
      }
    );
    return cancel;
  }, [visible, width, doc, num, scheduler, currentRef, attempt]);

  const height = Math.round(width * (ownRatio ?? ratio));
  return (
    <div
      ref={box}
      data-page={num}
      data-state={state}
      className="pdf-page relative shrink-0 overflow-hidden rounded-[4px] bg-[#fff] shadow-[0_1px_4px_rgba(0,0,0,0.14)]"
      style={{ width, height }}
    >
      <canvas ref={canvasRef} className="block" />
      <div ref={textRef} className="textLayer" />
      {state === "rendered" && <PdfMarks page={num} marks={marks} pageRef={box} width={width} height={height} api={marksApi} />}
      {state !== "rendered" && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 text-[13px] font-medium text-[#6e6e6e]">
          {state === "error" ? (
            <>
              <span>Couldn&apos;t show page {num}</span>
              <button
                type="button"
                onClick={() => {
                  drawnAt.current = 0;
                  setAttempt((a) => a + 1);
                }}
                className="pointer-events-auto inline-flex h-8 items-center gap-1.5 rounded-full bg-[#17171a] px-3.5 text-[12px] font-semibold text-[#fff]"
              >
                <RotateCcw size={13} /> Retry
              </button>
            </>
          ) : (
            <span className="tabular-nums">{num}</span>
          )}
        </div>
      )}
    </div>
  );
}
