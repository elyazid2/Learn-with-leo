import { useEffect, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ClipboardPaste, Loader2, TriangleAlert } from "lucide-react";
import { db, type LibFile } from "@/lib/db";
import { addYoutubeVideo, fetchYoutubeMeta, youtubeRef, type YoutubeMeta } from "@/lib/youtube";
import { useApp } from "@/lib/store";
import { Button, Field, Sheet, inputCls } from "@/components/ui";
import YoutubeGlyph from "@/components/YoutubeGlyph";
import { cn } from "@/utils/cn";

/**
 * Add a YouTube video to the library: paste a link, check the preview, add it. The video becomes an
 * ordinary Video item, plays in the clean player, and its transcript is fetched in the background so
 * Leo can teach and quiz from it. No browser, no address bar.
 */
export default function YoutubeAddSheet({
  open,
  onClose,
  projectId,
  onAdded,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  onAdded: (file: LibFile) => void;
}) {
  const [url, setUrl] = useState("");
  const [meta, setMeta] = useState<YoutubeMeta | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [adding, setAdding] = useState(false);
  const [clipboardFailed, setClipboardFailed] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const wasOpen = useRef(false);
  const ref = youtubeRef(url);
  const refId = ref?.id;

  const existing = useLiveQuery(
    async (): Promise<LibFile | undefined> => (refId ? (await db.files.where("youtubeId").equals(refId).toArray()).find((f) => f.projectId === projectId) : undefined),
    [refId, projectId]
  );

  useEffect(() => {
    if (open && !wasOpen.current) {
      setUrl("");
      setMeta(null);
      setError("");
      setAdding(false);
      setClipboardFailed(false);
      window.setTimeout(() => input.current?.focus(), 120);
    }
    wasOpen.current = open;
  }, [open]);

  // The preview only looks the video up once the link is a complete, valid one.
  useEffect(() => {
    if (!open || !refId) {
      setMeta(null);
      setLoading(false);
      if (url.trim()) setError(refId ? "" : "That isn't a YouTube video link. Copy the link from the video's page.");
      return;
    }
    let alive = true;
    setLoading(true);
    const t = window.setTimeout(() => {
      void fetchYoutubeMeta(refId)
        .then((m) => {
          if (!alive) return;
          setMeta(m);
          setError(m ? "" : "YouTube didn't return any information for that video. Check that the link opens a public video.");
        })
        .finally(() => {
          if (alive) setLoading(false);
        });
    }, 350);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [open, refId, url]);

  const paste = async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) return;
      setUrl(text);
      setClipboardFailed(false);
    } catch {
      setClipboardFailed(true);
      input.current?.focus();
    }
  };

  const add = async () => {
    if (!ref || adding) return;
    if (existing) {
      onClose();
      onAdded(existing);
      return;
    }
    setAdding(true);
    setError("");
    try {
      const { file, existing: already } = await addYoutubeVideo(projectId, url);
      useApp.getState().showToast(already ? "That video is already in this project" : "Video added — fetching its transcript", { tone: already ? "info" : "success" });
      onClose();
      onAdded(file);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setAdding(false);
    }
  };

  const canAdd = !!ref && !!meta && !loading && !adding;

  return (
    <Sheet open={open} onClose={onClose} title="YouTube link" description="Plays here in a clean player, with no YouTube page around it."
      footer={<Button size="lg" className="w-full" disabled={!canAdd} onClick={() => void add()}>
        {adding ? <Loader2 size={17} className="animate-spin" /> : <YoutubeGlyph size={17} />}
        {existing ? "Open video" : adding ? "Adding..." : "Add video"}
      </Button>}>
      <div className="space-y-5">
        <Field label="Video link">
          <div className="flex items-center gap-2">
            <div className="relative min-w-0 flex-1">
              <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted">
                <YoutubeGlyph size={18} />
              </span>
              <input
                ref={input}
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value);
                  setClipboardFailed(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && canAdd) void add();
                }}
                placeholder="Paste a link: youtube.com/watch?v=… or youtu.be/…"
                aria-label="YouTube link"
                inputMode="url"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className={cn(inputCls, "pl-10 text-[15px]")}
              />
            </div>
            <Button variant="soft" onClick={() => void paste()} className="shrink-0">
              <ClipboardPaste size={15} /> Paste
            </Button>
          </div>
          {clipboardFailed && <span className="mt-1.5 block text-[12px] text-muted">Your browser didn't allow reading the clipboard. Paste with {navigator.platform.includes("Mac") ? "⌘V" : "Ctrl+V"} instead.</span>}
        </Field>

        {!url.trim() && (
          <div className="rounded-2xl bg-ink/[0.03] p-3.5 text-[13px] leading-relaxed text-muted">
            <div className="font-medium text-ink">What gets saved</div>
            <p className="mt-0.5">The title, channel, thumbnail and transcript. The video itself stays on YouTube; Harness never downloads it.</p>
          </div>
        )}

        {loading && (
          <div className="flex items-center gap-3 rounded-2xl bg-ink/[0.03] p-3.5 text-[13px] text-muted">
            <Loader2 size={16} className="animate-spin" /> Looking the video up…
          </div>
        )}

        {meta && !loading && (
          <div className="flex items-center gap-3.5 rounded-2xl bg-card p-3 ring-1 ring-line">
            <img src={meta.thumb} alt="" className="aspect-video w-28 shrink-0 rounded-xl object-cover ring-1 ring-line" loading="lazy" />
            <div className="min-w-0 flex-1">
              <div className="line-clamp-2 text-[14px] font-semibold leading-snug" dir="auto">
                {meta.title}
              </div>
              <div className="mt-0.5 truncate text-[12px] text-muted">{meta.channel}</div>
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]">
                {existing ? (
                  <span className="rounded-full bg-warn-bg px-2 py-0.5 font-medium text-warn-fg">Already in this project</span>
                ) : (
                  <span className="rounded-full bg-ok-bg px-2 py-0.5 font-medium text-ok-fg">Plays in Harness</span>
                )}
                <span className="rounded-full bg-ink/[0.05] px-2 py-0.5 text-muted">Transcript for Leo</span>
              </div>
            </div>
          </div>
        )}

        {error && (
          <p className="flex items-start gap-2 text-[13px] leading-relaxed text-danger-fg" role="alert">
            <TriangleAlert size={15} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </p>
        )}

        <p className="text-[12px] leading-relaxed text-muted">
          Harness tries YouTube's captions as soon as the video is added. If YouTube withholds them, the video page lets you paste a transcript or transcribe the audio once, so Leo can still quiz you.
        </p>

      </div>
    </Sheet>
  );
}
