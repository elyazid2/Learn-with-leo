import { confirmDialog } from "@/lib/confirm";
import { useEffect, useRef, useState, type PointerEvent as RPointerEvent, type ReactNode } from "react";
import { Check, Pause, Play, Square, Trash2 } from "lucide-react";
import { formatDuration } from "@/lib/media";
import { BAR_COUNT, discardRecording, saveRecording, setRecordingName, stopRecording, togglePause, useRecorder } from "@/lib/recorder";
import { cn } from "@/utils/cn";

const PILL_H = 64;
const POS_KEY = "harness.recorder";

interface Pt {
  x: number;
  y: number;
}

const loadPos = (): Pt | null => {
  try {
    return JSON.parse(localStorage.getItem(POS_KEY) || "null");
  } catch {
    return null;
  }
};

function useViewportSize() {
  const get = () => ({ w: window.innerWidth, h: Math.round(window.visualViewport?.height ?? window.innerHeight) });
  const [vp, setVp] = useState(get);
  useEffect(() => {
    const on = () => setVp(get());
    window.addEventListener("resize", on);
    window.visualViewport?.addEventListener("resize", on);
    return () => {
      window.removeEventListener("resize", on);
      window.visualViewport?.removeEventListener("resize", on);
    };
  }, []);
  return vp;
}

/**
 * Floating voice-recorder pill. Mounted once at App level; all state lives in the global
 * recorder store, so recording continues across navigation. Drag it anywhere like Leo's bubble.
 */
export default function RecorderPill() {
  const phase = useRecorder((s) => s.phase);
  const elapsed = useRecorder((s) => s.elapsed);
  const levels = useRecorder((s) => s.levels);
  const name = useRecorder((s) => s.name);
  const saving = useRecorder((s) => s.saving);
  const previewUrl = useRecorder((s) => s.previewUrl);
  const vp = useViewportSize();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState<Pt>(() => loadPos() ?? { x: -1, y: -1 });
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number; moved: boolean } | null>(null);

  useEffect(() => setPlaying(false), [previewUrl]);

  if (phase === "idle") return null;

  const width = Math.min(420, vp.w - 16);
  const x = pos.x < 0 ? (vp.w - width) / 2 : Math.min(Math.max(8, pos.x), vp.w - width - 8);
  const y = pos.y < 0 ? vp.h - PILL_H - 92 : Math.min(Math.max(8, pos.y), vp.h - PILL_H - 8);

  const onDown = (e: RPointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest("button,input")) return;
    drag.current = { sx: e.clientX, sy: e.clientY, ox: x, oy: y, moved: false };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onMove = (e: RPointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;
    if (!d.moved && Math.hypot(dx, dy) < 5) return;
    d.moved = true;
    setPos({ x: d.ox + dx, y: d.oy + dy });
  };
  const onUp = () => {
    const d = drag.current;
    drag.current = null;
    if (d?.moved) localStorage.setItem(POS_KEY, JSON.stringify({ x, y }));
  };

  const live = phase === "recording";
  const done = phase === "done";

  const togglePreview = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) void a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    else {
      a.pause();
      setPlaying(false);
    }
  };

  const discard = async () => {
    if (done && !(await confirmDialog({ title: "Discard recording?", message: "This recording hasn't been saved to your library.", confirmLabel: "Discard", tone: "danger" }))) return;
    discardRecording();
  };

  return (
    <div
      data-no-capture
      role="region"
      aria-label="Voice recorder"
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      className="rise fixed z-[60] flex touch-none select-none items-center gap-2 rounded-[22px] bg-elevated/95 pl-3 pr-2 shadow-[0_12px_36px_rgba(0,0,0,0.18)] ring-1 ring-line backdrop-blur-2xl cursor-grab active:cursor-grabbing"
      style={{ left: x, top: y + (window.visualViewport?.offsetTop ?? 0), height: PILL_H, width }}
    >
      {done ? (
        <>
          <audio ref={audioRef} src={previewUrl} onEnded={() => setPlaying(false)} className="hidden" />
          <PillBtn label={playing ? "Pause preview" : "Play preview"} onClick={togglePreview}>
            {playing ? <Pause size={17} /> : <Play size={17} className="translate-x-px" />}
          </PillBtn>
          <div className="min-w-0 flex-1">
            <input
              value={name}
              onChange={(e) => setRecordingName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void saveRecording()}
              aria-label="Recording name"
              placeholder="Name"
              className="h-10 w-full rounded-xl bg-ink/[0.05] px-3 text-[14px] font-medium outline-none focus:bg-ink/[0.08] focus:ring-1 focus:ring-ink/15"
            />
          </div>
          <span className="shrink-0 text-[12px] font-semibold tabular-nums text-muted">{formatDuration(elapsed)}</span>
          <button
            type="button"
            onClick={() => void saveRecording()}
            disabled={saving}
            className="flex h-10 shrink-0 items-center gap-1.5 rounded-full bg-ink px-3.5 text-[13px] font-semibold text-white transition-opacity disabled:opacity-40"
          >
            <Check size={15} strokeWidth={2.6} /> Save
          </button>
          <PillBtn label="Discard recording" onClick={discard} danger>
            <Trash2 size={16} />
          </PillBtn>
        </>
      ) : (
        <>
          <div className="flex w-[54px] shrink-0 items-center gap-1.5">
            <span className={cn("h-2 w-2 shrink-0 rounded-full", live ? "animate-pulse bg-[#e5485e]" : "bg-muted")} aria-hidden />
            <span className="text-[14px] font-semibold tabular-nums" aria-live="off">
              {formatDuration(elapsed)}
            </span>
          </div>
          <div className="flex h-10 min-w-0 flex-1 items-center justify-between gap-[3px]" aria-hidden>
            {levels.slice(-BAR_COUNT).map((l, i) => (
              <span
                key={i}
                className="min-w-[3px] max-w-[8px] flex-1 rounded-full transition-[height] duration-100"
                style={{ height: `${Math.max(14, Math.min(100, l * 100))}%`, background: live ? "#e5485e" : "var(--muted)", opacity: live ? 0.45 + l * 0.55 : 0.45 }}
              />
            ))}
          </div>
          <span className="sr-only" aria-live="polite">
            {phase === "starting" ? "Starting recording" : live ? "Recording" : "Paused"}
          </span>
          <PillBtn label={phase === "paused" ? "Resume" : "Pause"} onClick={togglePause} disabled={phase === "starting"}>
            {phase === "paused" ? <Play size={17} className="translate-x-px" /> : <Pause size={17} />}
          </PillBtn>
          <button
            type="button"
            onClick={stopRecording}
            disabled={phase === "starting"}
            aria-label="Stop recording"
            title="Stop"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-white transition-transform active:scale-95 disabled:opacity-40"
          >
            <Square size={14} fill="currentColor" />
          </button>
          <PillBtn label="Discard recording" onClick={discard} danger>
            <Trash2 size={16} />
          </PillBtn>
        </>
      )}
    </div>
  );
}

function PillBtn({ label, onClick, children, danger, disabled }: { label: string; onClick: () => void; children: ReactNode; danger?: boolean; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      title={label}
      className={cn(
        "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors disabled:opacity-40",
        danger ? "text-muted hover:bg-danger-bg hover:text-danger-fg" : "bg-ink/[0.06] text-ink hover:bg-ink/[0.1]"
      )}
    >
      {children}
    </button>
  );
}
