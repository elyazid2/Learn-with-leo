/** A play button in a rounded screen, drawn to match the app's Lucide line icons. */
export default function YoutubeGlyph({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      <rect x="2" y="5" width="20" height="14" rx="4.5" />
      <path d="M10 9.2 15.2 12 10 14.8Z" fill="currentColor" stroke="none" />
    </svg>
  );
}
