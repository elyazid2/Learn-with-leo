import { useEffect, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import {
  ArrowLeft,
  Check,
  ChevronRight,
  Eye,
  EyeOff,
  Loader2,
  Plus,
  RefreshCw,
  Star,
  Trash2,
  Brain,
  Globe2,
  Zap,
  Keyboard,
  Compass,
} from "lucide-react";
import { db, setKV, uid, type Provider, type ProviderType } from "@/lib/db";
import { navigate } from "@/lib/router";
import { PRESETS, TYPE_LABEL, listModels, streamChat, type Preset } from "@/lib/ai/providers";
import { getDefaultModel, type ModelRef } from "@/lib/chat";
import { modelLabel } from "@/lib/models";
import { useApp } from "@/lib/store";
import { Button, Field, IconBtn, Segmented, Sheet, Toggle, inputCls } from "@/components/ui";
import AgentAvatar from "@/components/AgentAvatar";
import LeoPromptSection from "@/components/settings/DevOptions";
import BackupExportSection from "@/components/settings/BackupExport";
import { AGENT_STATE_META, type AgentState } from "@/lib/avatar";
import { useSettings, useResolvedTheme, confirmDeletion, type ForcedAgentState } from "@/lib/settings";
import PreferenceSections from "@/components/settings/Preferences";
import ProviderLogo from "@/components/ProviderLogo";
import TranscriptionSection from "@/components/settings/Transcription";
import { cn } from "@/utils/cn";
import { useTour } from "@/lib/tour";

export default function Settings() {
  const providers = useLiveQuery(() => db.providers.orderBy("id").toArray(), []);
  const [def, setDef] = useState<ModelRef | null>(null);
  const [editing, setEditing] = useState<Provider | null>(null);
  const [picking, setPicking] = useState(false);
  const [defaultPicking, setDefaultPicking] = useState(false);
  const theme = useResolvedTheme();

  useEffect(() => {
    getDefaultModel().then(setDef);
  }, [providers]);

  const setDefault = async (ref: ModelRef) => {
    await setKV("defaultModel", ref);
    setDef(ref);
  };

  return (
    <div className="mx-auto min-h-full max-w-2xl px-5 pb-24 pt-[max(env(safe-area-inset-top),16px)]" data-no-capture>
      <header className="flex items-center gap-2 py-3">
        <IconBtn onClick={() => (history.length > 1 ? history.back() : navigate(""))} aria-label="Back">
          <ArrowLeft size={19} />
        </IconBtn>
        <h1 className="display text-[27px] leading-none">Settings</h1>
      </header>

      {providers && providers.length === 0 && (
        <div className="rise mb-6 mt-2 flex items-start gap-3.5 rounded-2xl bg-ink p-4 text-white">
          {/* This banner is the inverse of the theme, so Leo is drawn for the opposite surface or he vanishes into it. */}
          <AgentAvatar state="blocked" size={40} surface={theme === "dark" ? "light" : "dark"} />
          <div className="min-w-0 flex-1">
            <div className="text-[15px] font-semibold">Start here: give Leo a brain</div>
            <p className="mt-0.5 text-[13px] leading-relaxed opacity-75">
              Add an AI provider (OpenAI, Anthropic, Gemini, OpenRouter, or a local model). Just exploring? Turn on Developer mode below for a built-in mock tutor.
            </p>
            <button
              onClick={() => setPicking(true)}
              className="mt-3 inline-flex h-9 items-center gap-1.5 rounded-full bg-white/15 px-3.5 text-[13px] font-semibold transition-colors hover:bg-white/25"
            >
              <Plus size={15} /> Add provider
            </button>
          </div>
        </div>
      )}

      <PreferenceSections />

      <section className="mt-8">
        <h2 className="mb-3 text-[13px] font-semibold text-muted">Leo</h2>
        <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-line">
          <button
            onClick={() => {
              useTour.getState().replay();
              navigate("");
            }}
            className="flex w-full items-center gap-3 border-b border-line px-4 py-4 text-left transition-colors hover:bg-ink/[0.03]"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ink/[0.05]"><Compass size={18} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold">Take Leo's tour</span>
              <span className="block text-[12px] text-muted">A one-minute walk through projects, your library, the chat and your knowledge map.</span>
            </span>
            <ChevronRight size={16} className="text-muted" />
          </button>
          <button onClick={() => navigate("memories")} className="flex w-full items-center gap-3 border-b border-line px-4 py-4 text-left transition-colors hover:bg-ink/[0.03]">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ink/[0.05]"><Brain size={18} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold">Memory</span>
              <span className="block text-[12px] text-muted">What Leo remembers about your goals, level, preferences and gaps — view, edit or forget.</span>
            </span>
            <ChevronRight size={16} className="text-muted" />
          </button>
          <button onClick={() => useApp.getState().setShortcutsOpen(true)} className="hidden w-full items-center gap-3 border-b border-line px-4 py-4 text-left transition-colors hover:bg-ink/[0.03] sm:flex">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ink/[0.05]"><Keyboard size={18} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold">Keyboard shortcuts</span>
              <span className="block text-[12px] text-muted">Search, open Leo and more without the mouse. Press ? anywhere.</span>
            </span>
            <ChevronRight size={16} className="text-muted" />
          </button>
          <button onClick={() => { useApp.getState().setBrowserOpen(true); }} className="flex w-full items-center gap-3 px-4 py-4 text-left transition-colors hover:bg-ink/[0.03]">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ink/[0.05]"><Globe2 size={18} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold">Learning browser</span>
              <span className="block text-[12px] text-muted">Watch YouTube in a clean player and open pages inside Harness. Leo reads the pages whose sites allow it.</span>
            </span>
            <ChevronRight size={16} className="text-muted" />
          </button>
        </div>
      </section>

      <section className="mt-10">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <h2 className="text-[13px] font-semibold text-muted">AI providers</h2>
            <p className="mt-0.5 text-[13px] text-muted">Leo thinks with these models. Keys stay on this device; requests go straight from your browser.</p>
          </div>
        </div>
        <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-line">
          {providers?.map((p) => {
            const isDef = def?.providerId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setEditing(p)}
                className="flex w-full items-center gap-3 border-b border-line px-4 py-3.5 text-left last:border-0 hover:bg-black/[0.02]"
              >
                <ProviderLogo provider={p} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 font-medium">
                    {p.name}
                    {isDef && <Star size={12} className="fill-amber-400 text-amber-400" />}
                  </div>
                  <div className="truncate text-[12px] text-muted">
                    {TYPE_LABEL[p.type]} · {p.models.length} model{p.models.length === 1 ? "" : "s"}
                    {p.type === "openai" && p.baseUrl ? ` · ${safeHost(p.baseUrl)}` : ""}
                  </div>
                </div>
                <ChevronRight size={16} className="text-muted" />
              </button>
            );
          })}
          <button onClick={() => setPicking(true)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left text-sm font-medium hover:bg-black/[0.02]">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-black/[0.05]">
              <Plus size={16} />
            </div>
            Add provider
          </button>
        </div>

        {!!providers?.length && (
          <div className="mt-4 rounded-2xl bg-card p-4 ring-1 ring-line">
            <span className="mb-1.5 block text-[12px] font-medium text-muted">Default model for new chats</span>
            <button
              onClick={() => setDefaultPicking(true)}
              className="flex w-full items-center gap-3 rounded-2xl bg-ink/[0.035] p-3 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.06]"
            >
              <AgentAvatar size={32} frozenAt={0} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[14px] font-semibold">{def ? modelLabel(def.model) : "Choose a model"}</span>
                <span className="block truncate text-[12px] text-muted">{providers.find((p) => p.id === def?.providerId)?.name ?? "No enabled model yet"}</span>
              </span>
              <ChevronRight size={16} className="shrink-0 text-muted" />
            </button>
            <p className="mt-2 text-xs text-muted">Each chat can also pick its own provider and model from the chat header.</p>
          </div>
        )}
      </section>

      <TranscriptionSection />
      <LeoPromptSection />
      <DeveloperSection />
      <BackupExportSection />

      <section className="mt-10 text-center text-xs text-muted">
        <p>Harness · local-first. No accounts, no servers, no tracking.</p>
      </section>

      <PresetSheet
        open={picking}
        onClose={() => setPicking(false)}
        onPick={(preset) => {
          setPicking(false);
          setEditing({
            id: "",
            name: preset.name,
            type: preset.type,
            baseUrl: preset.baseUrl,
            apiKey: "",
            catalogModels: preset.models,
            models: preset.models,
            defaultModel: preset.models[0] ?? "",
            createdAt: Date.now(),
            ...({ __hint: preset.hint } as object),
          } as Provider);
        }}
      />
      <Sheet open={defaultPicking} onClose={() => setDefaultPicking(false)} title="Default model">
        <p className="-mt-2 mb-3 text-[13px] text-muted">Only models you enabled are listed. Each chat can still pick its own.</p>
        <div className="max-h-[60dvh] space-y-4 overflow-y-auto">
          {(providers ?? []).map((p) => (
            <section key={p.id}>
              <h3 className="mb-1 px-1 text-[12px] font-semibold text-muted">{p.name}</h3>
              {p.models.length ? (
                <div className="space-y-0.5">
                  {p.models.map((m) => {
                    const selected = def?.providerId === p.id && def?.model === m;
                    return (
                      <button
                        key={m}
                        onClick={() => { void setDefault({ providerId: p.id, model: m }); setDefaultPicking(false); }}
                        className={cn("flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors", selected ? "bg-ink/[0.06]" : "hover:bg-ink/[0.04]")}
                      >
                        <span className={cn("flex h-8 w-8 items-center justify-center rounded-full text-[12px] font-bold", selected ? "bg-ink text-white" : "bg-ink/[0.06] text-muted")}>{selected ? "✓" : "•"}</span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[14px] font-semibold">{modelLabel(m)}</span>
                          <span className="block truncate text-[11px] text-muted">{m}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <p className="px-2 py-2 text-[12px] text-muted">No enabled models — open this provider and enable some.</p>
              )}
            </section>
          ))}
        </div>
      </Sheet>
      {editing && (
        <ProviderEditor
          provider={editing}
          onClose={() => setEditing(null)}
          isDefault={def?.providerId === editing.id}
          onMakeDefault={(m) => setDefault({ providerId: editing.id, model: m })}
        />
      )}
    </div>
  );
}

const safeHost = (u: string) => {
  // A relative base URL (the NVIDIA NIM proxy) has no host to show.
  if (u === "/api/nim") return "NVIDIA NIM";
  try {
    return new URL(u).host;
  } catch {
    return u;
  }
};

function PresetSheet({ open, onClose, onPick }: { open: boolean; onClose: () => void; onPick: (p: Preset) => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="Add provider">
      <div className="grid grid-cols-2 gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.key}
            onClick={() => onPick(p)}
            className="flex items-center gap-2.5 rounded-2xl p-3 text-left ring-1 ring-line transition hover:bg-black/[0.03]"
          >
            <ProviderLogo provider={p} />
            <div className="min-w-0">
              <div className="truncate text-sm font-medium">{p.name}</div>
              <div className="truncate text-[11px] text-muted">{TYPE_LABEL[p.type]}</div>
            </div>
          </button>
        ))}
      </div>
    </Sheet>
  );
}

function ProviderEditor({
  provider,
  onClose,
  isDefault,
  onMakeDefault,
}: {
  provider: Provider;
  onClose: () => void;
  isDefault: boolean;
  onMakeDefault: (model: string) => void;
}) {
  const showToast = useApp((s) => s.showToast);
  const [p, setP] = useState<Provider>(provider);
  const [showKey, setShowKey] = useState(false);
  const [newModel, setNewModel] = useState("");
  const [fetching, setFetching] = useState(false);
  const [test, setTest] = useState<{ state: "idle" | "running" | "ok" | "fail"; msg?: string }>({ state: "idle" });
  const [filter, setFilter] = useState("");
  const hint = (provider as unknown as { __hint?: string }).__hint;
  const isNew = !provider.id;

  const upd = (patch: Partial<Provider>) => setP((x) => ({ ...x, ...patch }));

  const save = async () => {
    const clean: Provider = {
      id: p.id || uid(),
      name: p.name.trim() || "Provider",
      type: p.type,
      baseUrl: p.baseUrl.trim(),
      apiKey: p.apiKey.trim(),
      catalogModels: p.catalogModels ?? p.models,
      models: p.models,
      defaultModel: p.models.includes(p.defaultModel) ? p.defaultModel : p.models[0] ?? "",
      timeout: p.timeout,
      maxTokens: p.maxTokens,
      createdAt: p.createdAt || Date.now(),
    };
    await db.providers.put(clean);
    const count = await db.providers.count();
    if (count === 1) await setKV("defaultModel", { providerId: clean.id, model: clean.defaultModel });
    showToast(isNew ? "Provider added" : "Saved");
    onClose();
  };

  const remove = async () => {
    if (!(await confirmDeletion(`Its API key and model list will be removed from this device.`, { title: `Remove ${p.name}?`, confirmLabel: "Remove" }))) return;
    await db.providers.delete(p.id);
    onClose();
  };

  const fetchModels = async () => {
    setFetching(true);
    try {
      const ms = await listModels(p);
      if (!ms.length) throw new Error("No models returned");
      const catalogModels = Array.from(new Set([...(p.catalogModels ?? []), ...ms])).sort();
      const models = p.models.filter((m) => catalogModels.includes(m));
      const enabled = models.length ? models : p.models.length ? p.models : [];
      upd({ catalogModels, models: enabled, defaultModel: enabled.includes(p.defaultModel) ? p.defaultModel : enabled[0] ?? "" });
      showToast(`${ms.length} catalog models found — choose which to enable`);
    } catch (e) {
      showToast(`Couldn't fetch models: ${(e as Error).message.slice(0, 80)}`);
    } finally {
      setFetching(false);
    }
  };

  const runTest = async () => {
    const model = p.defaultModel || p.models[0];
    if (!model) return setTest({ state: "fail", msg: "Add a model first" });
    setTest({ state: "running" });
    try {
      let out = "";
      for await (const t of streamChat(p, model, "Reply with exactly: OK", [{ role: "user", content: "ping" }])) {
        out += t;
        if (out.length > 40) break;
      }
      setTest({ state: "ok", msg: out.trim().slice(0, 40) || "(empty reply)" });
    } catch (e) {
      setTest({ state: "fail", msg: (e as Error).message });
    }
  };

  const addModel = () => {
    const m = newModel.trim();
    if (!m) return;
    const catalogModels = Array.from(new Set([...(p.catalogModels ?? p.models), m]));
    const models = p.models.includes(m) ? p.models : [...p.models, m];
    upd({ catalogModels, models, defaultModel: p.defaultModel || m });
    setNewModel("");
  };

  const catalog = p.catalogModels?.length ? p.catalogModels : p.models;
  const shown = catalog.filter((m) => m.toLowerCase().includes(filter.toLowerCase()));
  const toggleModel = (m: string) => {
    const enabled = p.models.includes(m);
    const models = enabled ? p.models.filter((x) => x !== m) : [...p.models, m];
    upd({ models, defaultModel: enabled && p.defaultModel === m ? models[0] ?? "" : p.defaultModel || m });
  };

  return (
    <Sheet open onClose={onClose} title={isNew ? `Add ${provider.name}` : p.name} wide>
      <div className="space-y-4">
        {hint && <p className="rounded-2xl bg-warn-bg p-3 text-[13px] text-warn-fg">{hint}</p>}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name">
            <input className={inputCls} value={p.name} onChange={(e) => upd({ name: e.target.value })} />
          </Field>
          <Field label="API type">
            <Segmented<ProviderType>
              className="flex w-full [&>button]:flex-1 [&>button]:py-2"
              value={p.type}
              onChange={(type) => {
                const isPresetUrl = !p.baseUrl || PRESETS.some((pr) => pr.baseUrl === p.baseUrl);
                const def = PRESETS.find((pr) => pr.type === type && pr.key !== "custom");
                upd({ type, baseUrl: isPresetUrl && def ? def.baseUrl : p.baseUrl });
              }}
              options={[
                { value: "openai", label: "OpenAI" },
                { value: "anthropic", label: "Anthropic" },
                { value: "gemini", label: "Gemini" },
              ]}
            />
          </Field>
        </div>
        <Field label="Base URL">
          <input className={inputCls} value={p.baseUrl} placeholder="https://…/v1" onChange={(e) => upd({ baseUrl: e.target.value })} />
        </Field>
        <Field label="API key">
          <div className="relative">
            <input
              className={cn(inputCls, "pr-12 font-mono text-[13px]")}
              type={showKey ? "text" : "password"}
              value={p.apiKey}
              autoComplete="new-password"
              name="llm-api-key"
              placeholder="sk-…"
              onChange={(e) => upd({ apiKey: e.target.value })}
            />
            <IconBtn className="absolute right-1.5 top-1/2 -translate-y-1/2" onClick={() => setShowKey((s) => !s)}>
              {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
            </IconBtn>
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Timeout (s)" hint="Per request; slow local models may need more">
            <input
              className={inputCls}
              type="number"
              min={10}
              max={900}
              value={p.timeout ?? 120}
              onChange={(e) => upd({ timeout: Math.max(10, Math.min(900, Number(e.target.value) || 120)) })}
            />
          </Field>
          <Field label="Max output tokens" hint={p.type === "anthropic" ? "Required by Anthropic" : "Not sent for this API type"}>
            <input
              className={inputCls}
              type="number"
              min={256}
              max={64000}
              step={256}
              value={p.maxTokens ?? 8192}
              disabled={p.type !== "anthropic"}
              onChange={(e) => upd({ maxTokens: Math.max(256, Math.min(64000, Number(e.target.value) || 8192)) })}
            />
          </Field>
        </div>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[12px] font-medium text-muted">Available models</span>
            <Button size="sm" variant="soft" onClick={fetchModels} disabled={fetching}>
              {fetching ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} Fetch
            </Button>
          </div>
          {catalog.length > 5 && (
            <input className={cn(inputCls, "mb-2 py-2 text-[16px]")} placeholder="Filter catalog" value={filter} onChange={(e) => setFilter(e.target.value)} />
          )}
          <p className="mb-2 text-[12px] text-muted">Enable only models you want available in chat. Tap a checked model's default button to choose its provider default.</p>
          <div className="max-h-56 divide-y divide-line overflow-y-auto rounded-2xl bg-ink/[0.025] px-3">
            {shown.map((m) => {
              const enabled = p.models.includes(m);
              return (
                <div key={m} className="flex items-center gap-2 py-1.5">
                  <input type="checkbox" checked={enabled} onChange={() => toggleModel(m)} aria-label={`Enable ${modelLabel(m)}`} className="h-4 w-4 accent-black" />
                  <button onClick={() => enabled && upd({ defaultModel: m })} disabled={!enabled} className="min-w-0 flex-1 py-1 text-left text-[13px] disabled:text-muted/60">
                    <span className="block truncate">{modelLabel(m)}</span>
                    <span className="block truncate text-[11px] text-muted">{m}</span>
                  </button>
                  {enabled && (
                    <button onClick={() => upd({ defaultModel: m })} aria-label={`Use ${modelLabel(m)} as provider default`} className={cn("rounded-full px-2 py-1 text-[11px]", p.defaultModel === m ? "bg-ink text-white" : "text-muted hover:bg-ink/[0.05]")}>
                      {p.defaultModel === m ? "Default" : "Make default"}
                    </button>
                  )}
                </div>
              );
            })}
            {shown.length === 0 && <p className="py-4 text-center text-[13px] text-muted">Fetch models or add a model ID below.</p>}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              className={cn(inputCls, "py-2 text-sm")}
              placeholder="Add model id"
              value={newModel}
              onChange={(e) => setNewModel(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addModel()}
            />
            <Button variant="soft" onClick={addModel}>
              Add
            </Button>
          </div>
          <p className="mt-1.5 text-xs text-muted">{p.models.length} enabled · Your default is marked above.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 rounded-2xl bg-black/[0.03] p-3">
          <Button size="sm" variant="outline" onClick={runTest} disabled={test.state === "running"}>
            {test.state === "running" ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />} Test connection
          </Button>
          {test.state === "ok" && (
            <span className="flex items-center gap-1 text-[13px] text-ok-fg">
              <Check size={14} /> Works — “{test.msg}”
            </span>
          )}
          {test.state === "fail" && <span className="w-full text-[12px] text-danger-fg">{test.msg}</span>}
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          <Button size="lg" className="flex-1" onClick={save} disabled={!p.models.length || !p.defaultModel || (!p.baseUrl && p.type === "openai")}>
            {isNew ? "Add provider" : "Save"}
          </Button>
          {!isNew && !isDefault && (
            <Button size="lg" variant="soft" onClick={() => onMakeDefault(p.defaultModel || p.models[0])}>
              <Star size={15} /> Default
            </Button>
          )}
          {!isNew && (
            <Button size="lg" variant="danger" onClick={remove} aria-label="Delete provider">
              <Trash2 size={16} />
            </Button>
          )}
        </div>
      </div>
    </Sheet>
  );
}

function DeveloperSection() {
  const developerMode = useSettings((s) => s.developerMode);
  const forcedAgentState = useSettings((s) => s.forcedAgentState);
  const mockBehavior = useSettings((s) => s.mockBehavior);
  const mockDelay = useSettings((s) => s.mockDelay);
  const setSettings = useSettings((s) => s.setSettings);
  const states: AgentState[] = ["idle", "listening", "thinking", "speaking", "working", "waiting", "blocked", "done"];

  return (
    <section className="mt-10">
      <div className="mb-3 flex items-center gap-2">
        <h2 className="text-[13px] font-semibold text-muted">Developer mode</h2>
        {developerMode && <span className="rounded-full bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">Local mock active</span>}
      </div>
      <div className="rounded-2xl bg-card p-4 ring-1 ring-line">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="text-sm font-semibold">Use the offline mock provider</div>
            <p className="mt-0.5 text-[13px] leading-relaxed text-muted">Simulates delays, streaming, actions, quizzes and failures. No network requests. Turning this on replaces your AI provider until you turn it off.</p>
          </div>
          <Toggle checked={developerMode} onChange={(developerMode) => setSettings({ developerMode })} label="Developer mode" />
        </div>
        {developerMode && (
          <div className="mt-5 space-y-5 border-t border-line pt-5">
            <div>
              <div className="mb-2 text-[12px] font-medium text-muted">Force Leo's state</div>
              <div className="grid grid-cols-4 gap-1.5">
                {(["auto", ...states] as ForcedAgentState[]).map((state) => (
                  <button
                    key={state}
                    onClick={() => setSettings({ forcedAgentState: state })}
                    className={cn(
                      "flex min-w-0 flex-col items-center gap-1 rounded-2xl px-1 py-2 text-[11px] font-medium capitalize ring-1 transition",
                      forcedAgentState === state ? "bg-ink text-white ring-ink" : "ring-line hover:bg-black/[0.03]"
                    )}
                  >
                    {state === "auto" ? <span className="flex h-8 items-center text-sm">A</span> : <AgentAvatar state={state} size={32} frozenAt={0} />}
                    <span className="max-w-full truncate">{state === "auto" ? "Auto" : AGENT_STATE_META[state].label}</span>
                  </button>
                ))}
              </div>
            </div>
            <Button variant="soft" onClick={() => navigate("dev/avatars")}>
              Open avatar sheet
            </Button>
            <Field label="Mock response">
              <Segmented<"auto" | "error">
                className="flex w-full [&>button]:flex-1 [&>button]:py-2"
                value={mockBehavior}
                onChange={(mockBehavior) => setSettings({ mockBehavior })}
                options={[{ value: "auto", label: "Stream normally" }, { value: "error", label: "Simulate error" }]}
              />
            </Field>
            <Field label={`Thinking delay · ${mockDelay} ms`}>
              <input
                type="range"
                min={0}
                max={3000}
                step={100}
                value={mockDelay}
                onChange={(e) => setSettings({ mockDelay: Number(e.target.value) })}
                className="w-full accent-black"
              />
            </Field>
          </div>
        )}
      </div>
    </section>
  );
}
