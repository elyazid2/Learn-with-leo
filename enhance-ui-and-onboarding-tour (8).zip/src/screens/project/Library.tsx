import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { AlignLeft, BookOpen, Captions, Copy, Download, ExternalLink, FileText, Film, Image as ImageIcon, Loader2, Mic, Music, PenTool, Pencil, Play, Plus, Trash2, TrendingUp } from "lucide-react";
import { colorOf, db, uid, type FileKind, type LibFile, type Note, type Project, type Sketch } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { addFile, formatBytes, formatDuration, frameDataUrl, imageToDataUrl, kindOf, removeFile, timeAgo, videoInfo } from "@/lib/media";
import { useApp } from "@/lib/store";
import { download } from "@/lib/backup";
import { snippetOf } from "@/lib/blocks";
import { accentText, readableOn } from "@/lib/color";
import { confirmDeletion } from "@/lib/settings";
import { Button, Empty, IconBtn, Sheet } from "@/components/ui";
import PdfViewer from "@/components/library/PdfViewer";
import AudioPlayer, { Waveform } from "@/components/library/AudioPlayer";
import { startRecording } from "@/lib/recorder";
import AgentAvatar from "@/components/AgentAvatar";
import YoutubeGlyph from "@/components/YoutubeGlyph";
import YoutubeAddSheet from "@/components/library/YoutubeAdd";
import YoutubeVideoPage from "@/components/library/YoutubeVideo";
import { transcriptLabel } from "@/lib/youtube";
import { LearningCard, useHasLearning } from "@/components/Progress";
import { cn } from "@/utils/cn";
import { PaneBar, usePane } from "@/components/Pane";
import PreviousProjects from "@/components/library/PreviousProjects";
import { copyLibraryItems, type CopyChoice } from "@/lib/libraryCopies";
import SketchThumbnail from "@/components/SketchThumbnail";

type Filter = "all" | "note" | "sketch" | FileKind;
type UploadKind = "pdf" | "image" | "video" | "audio" | "text";
type AddChoice = "note" | "voice" | "sketch" | "youtube" | UploadKind;

type Entry =
  | { kind: "note"; id: string; title: string; at: number; note: Note }
  | { kind: "sketch"; id: string; title: string; at: number; sketch: Sketch }
  | { kind: FileKind; id: string; title: string; at: number; file: LibFile };

const FILTER_LABEL: Record<Filter, string> = {
  all: "All",
  note: "Notes",
  sketch: "Sketches",
  pdf: "PDFs",
  image: "Pictures",
  video: "Videos",
  audio: "Audio",
  text: "Text",
};
const FILTER_ORDER: Filter[] = ["note", "sketch", "pdf", "image", "video", "audio", "text"];
const ACCEPT_ALL = "application/pdf,.pdf,image/*,video/*,.mp4,.mov,.webm,.m4v,audio/*,.m4a,.mp3,.wav,.ogg,text/plain,text/markdown,.txt,.md";
const ACCEPT: Record<UploadKind, string> = {
  pdf: "application/pdf,.pdf",
  image: "image/*",
  video: "video/*,.mp4,.mov,.webm,.m4v",
  audio: "audio/*,.m4a,.mp3,.wav,.ogg,.aac,.flac",
  text: "text/plain,text/markdown,.txt,.md",
};

export default function Library({ project, fileId }: { project: Project; fileId?: string }) {
  if (fileId) return <FileViewer project={project} fileId={fileId} />;
  return <LibraryHome project={project} />;
}

async function createNote(projectId: string) {
  const now = Date.now();
  const n: Note = { id: uid(), projectId, title: "", content: "", author: "user", createdAt: now, updatedAt: now };
  await db.notes.add(n);
  await db.projects.update(projectId, { updatedAt: now });
  navigate(projectPath(projectId, "notes", n.id));
}

async function createSketch(projectId: string, count: number) {
  const now = Date.now();
  const s: Sketch = { id: uid(), projectId, title: `Sketch ${count}`, scene: "", createdAt: now, updatedAt: now };
  await db.sketches.add(s);
  await db.projects.update(projectId, { updatedAt: now });
  navigate(projectPath(projectId, "sketch", s.id));
}

function LibraryHome({ project }: { project: Project }) {
  const files = useLiveQuery(() => db.files.where("projectId").equals(project.id).toArray(), [project.id]);
  const notes = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]);
  const sketches = useLiveQuery(() => db.sketches.where("projectId").equals(project.id).toArray(), [project.id]);
  const addOpen = useApp((s) => s.addOpen);
  const setAddOpen = useApp((s) => s.setAddOpen);
  const showToast = useApp((s) => s.showToast);
  const [filter, setFilter] = useState<Filter>("all");
  const [youtubeOpen, setYoutubeOpen] = useState(false);
  const [busy, setBusy] = useState(0);
  const [drag, setDrag] = useState(false);
  const dragDepth = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const col = colorOf(project.color);
  const hasLearning = useHasLearning(project);
  const pane = usePane();

  const items = useMemo<Entry[]>(() => {
    const out: Entry[] = [];
    for (const n of notes ?? []) out.push({ kind: "note", id: n.id, title: n.title || "Untitled note", at: n.updatedAt, note: n });
    for (const s of sketches ?? []) out.push({ kind: "sketch", id: s.id, title: s.title || "Sketch", at: s.updatedAt, sketch: s });
    for (const f of files ?? []) out.push({ kind: f.kind, id: f.id, title: f.name.replace(/\.[a-z0-9]+$/i, ""), at: f.createdAt, file: f });
    return out.sort((a, b) => b.at - a.at);
  }, [files, notes, sketches]);

  const counts = useMemo(() => {
    const c: Partial<Record<Filter, number>> = {};
    for (const it of items) c[it.kind] = (c[it.kind] ?? 0) + 1;
    return c;
  }, [items]);

  useEffect(() => {
    if (filter !== "all" && !counts[filter]) setFilter("all");
  }, [counts, filter]);

  // Older uploads may have a black or missing poster frame: rebuild it once in the background.
  useEffect(() => {
    const stale = (files ?? []).filter((f) => f.kind === "video" && !f.youtubeId && (f.thumbVersion ?? 0) < 2).slice(0, 4);
    if (!stale.length) return;
    let cancelled = false;
    void (async () => {
      for (const f of stale) {
        if (cancelled) return;
        const info = await videoInfo(f.blob);
        if (cancelled) return;
        await db.files.update(f.id, { thumb: info.thumb ?? f.thumb, duration: f.duration ?? info.duration, thumbVersion: 2 });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [files]);

  const upload = async (list: FileList | File[] | null) => {
    if (!list) return;
    const arr = Array.from(list);
    let skipped = 0;
    const failed: string[] = [];
    setBusy((b) => b + arr.length);
    try {
      for (const f of arr) {
        try {
          if (!kindOf(f)) skipped++;
          else await addFile(project.id, f, f.name);
        } catch (e) {
          failed.push(`${f.name}: ${(e as Error).message}`);
        } finally {
          setBusy((b) => Math.max(0, b - 1));
        }
      }
    } finally {
      setBusy(0);
    }
    const added = arr.length - skipped - failed.length;
    if (failed.length) showToast(`Couldn't add ${failed.length}: ${failed[0].slice(0, 90)}`);
    else if (skipped) showToast(`${skipped} file${skipped === 1 ? "" : "s"} skipped — that type isn't supported`);
    else if (added > 0) showToast(added === 1 ? `Added "${arr[0].name}"` : `Added ${added} files to the library`, { tone: "success" });
  };

  const pick = (kind: UploadKind) => {
    const el = inputRef.current;
    if (!el) return;
    el.accept = ACCEPT[kind];
    el.click();
  };

  const onAdd = (choice: AddChoice) => {
    setAddOpen(false);
    if (choice === "note") void createNote(project.id);
    else if (choice === "sketch") void createSketch(project.id, (sketches?.length ?? 0) + 1);
    else if (choice === "voice") void startRecording(project.id);
    else if (choice === "youtube") setYoutubeOpen(true);
    else pick(choice);
  };

  const open = (e: Entry) => {
    if (e.kind === "note") navigate(projectPath(project.id, "notes", e.id));
    else if (e.kind === "sketch") navigate(projectPath(project.id, "sketch", e.id));
    else navigate(projectPath(project.id, "library", e.id));
  };

  const loading = files === undefined || notes === undefined || sketches === undefined;
  const shown = items.filter((it) => filter === "all" || it.kind === filter);
  const filters = (["all", ...FILTER_ORDER.filter((f) => counts[f])] as Filter[]).filter((f) => f === "all" || counts[f]);

  return (
    <div
      className="relative mx-auto min-h-full max-w-5xl px-4 pb-36 pt-4"
      onDragEnter={(e) => {
        if (!e.dataTransfer.types.includes("Files")) return;
        e.preventDefault();
        dragDepth.current++;
        setDrag(true);
      }}
      onDragOver={(e) => {
        if (!e.dataTransfer.types.includes("Files")) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
      }}
      onDragLeave={() => {
        dragDepth.current = Math.max(0, dragDepth.current - 1);
        if (!dragDepth.current) setDrag(false);
      }}
      onDrop={(e) => {
        if (!e.dataTransfer.files.length) return;
        e.preventDefault();
        dragDepth.current = 0;
        setDrag(false);
        void upload(e.dataTransfer.files);
      }}
    >
      {drag && (
        <div className="fade-in pointer-events-none fixed inset-0 z-[45] flex items-center justify-center bg-paper/70 p-6 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-3 rounded-3xl border-2 border-dashed border-ink/25 bg-card px-10 py-9 text-center shadow-xl">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-ink text-white">
              <Plus size={26} />
            </span>
            <div className="display text-[20px]">Drop to add to {project.name}</div>
            <div className="text-[13px] text-muted">PDFs, pictures, audio, video and text files</div>
          </div>
        </div>
      )}
      {hasLearning && (
        <div className="mb-7">
          <LearningCard project={project} />
        </div>
      )}

      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-baseline gap-2">
          <h2 className="display text-[22px] leading-none">Library</h2>
          {items.length > 0 && (
            <span className="text-[13px] tabular-nums text-muted">
              {items.length} {items.length === 1 ? "item" : "items"}
            </span>
          )}
        </div>
        {!hasLearning && (
          <button
            onClick={() => navigate(projectPath(project.id, "progress"))}
            data-tour="progress"
            className="inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 text-[13px] font-medium leading-none text-muted ring-1 ring-line transition-colors hover:bg-ink/[0.04] hover:text-ink"
          >
            <TrendingUp size={15} /> Progress
          </button>
        )}
      </div>

      {items.length > 0 && <FilterTabs filters={filters} filter={filter} onChange={setFilter} total={items.length} counts={counts} />}

      {!loading && items.length === 0 && busy === 0 && (
        <Empty
          icon={<BookOpen size={24} />}
          title="Everything for this topic lives here"
          text="Notes, voice notes, sketches, PDFs, pictures and videos. Tap Add, or drop files anywhere on this page."
        >
          <Button size="lg" onClick={() => setAddOpen(true)}>
            <Plus size={17} /> Add to library
          </Button>
          <div className="flex w-full flex-wrap justify-center gap-2">
            <Button variant="soft" onClick={() => onAdd("pdf")}>
              <FileText size={16} /> Upload a PDF
            </Button>
            <Button variant="soft" onClick={() => onAdd("note")}>
              <Pencil size={15} /> Write a note
            </Button>
            <Button variant="soft" onClick={() => onAdd("youtube")}>
              <YoutubeGlyph size={16} /> Add a YouTube link
            </Button>
          </div>
        </Empty>
      )}

      <div className="mt-4 grid grid-cols-2 gap-x-3 gap-y-5 sm:grid-cols-3 lg:grid-cols-4">
        {loading &&
          [0, 1, 2, 3].map((i) => (
            <div key={"l" + i} aria-hidden>
              <div className="shimmer aspect-[4/3] rounded-2xl" />
              <div className="shimmer mt-2 h-3.5 w-3/4 rounded-full" />
            </div>
          ))}
        {Array.from({ length: busy }).map((_, i) => (
          <div key={"b" + i}>
            <div className="shimmer aspect-[4/3] rounded-2xl" />
            <div className="shimmer mt-2 h-3.5 w-3/4 rounded-full" />
          </div>
        ))}
        {shown.map((e) => (
          <Tile key={`${e.kind}-${e.id}`} entry={e} project={project} color={col.hex} onOpen={() => open(e)} />
        ))}
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPT_ALL}
        className="hidden"
        onChange={(e) => {
          void upload(e.target.files);
          e.target.value = "";
          e.target.accept = ACCEPT_ALL;
        }}
      />
      {pane.primary && <AddSheet projectId={project.id} open={addOpen} onClose={() => setAddOpen(false)} onPick={onAdd} />}
      {pane.primary && (
        <YoutubeAddSheet
          open={youtubeOpen}
          onClose={() => setYoutubeOpen(false)}
          projectId={project.id}
          onAdded={(file) => {
            if (pane.primary) navigate(projectPath(project.id, "library", file.id));
            else pane.open({ kind: "file", id: file.id });
          }}
        />
      )}
    </div>
  );
}

const CREATE: { id: AddChoice; title: string; icon: ReactNode }[] = [
  { id: "note", title: "Note", icon: <FileText size={20} /> },
  { id: "voice", title: "Voice note", icon: <Mic size={20} /> },
  { id: "sketch", title: "Sketch", icon: <PenTool size={20} /> },
  { id: "youtube", title: "YouTube link", icon: <YoutubeGlyph size={20} /> },
];
const UPLOAD: { id: AddChoice; title: string; icon: ReactNode }[] = [
  { id: "pdf", title: "PDF", icon: <FileText size={20} /> },
  { id: "image", title: "Picture", icon: <ImageIcon size={20} /> },
  { id: "video", title: "Video", icon: <Film size={20} /> },
  { id: "audio", title: "Audio file", icon: <Music size={20} /> },
  { id: "text", title: "Text file", icon: <AlignLeft size={20} /> },
];

function AddSheet({ projectId, open, onClose, onPick }: { projectId: string; open: boolean; onClose: () => void; onPick: (c: AddChoice) => void }) {
  const [selected, setSelected] = useState<CopyChoice[]>([]);
  const [copying, setCopying] = useState(false);
  const [error, setError] = useState("");
  const lock = useRef(false);
  useEffect(() => { if (!open) { setSelected([]); setError(""); } }, [open]);
  const copy = async () => {
    if (!selected.length || lock.current) return;
    lock.current = true;
    setCopying(true);
    setError("");
    try {
      const result = await copyLibraryItems(projectId, selected);
      useApp.getState().showToast(`Added ${result.count} independent ${result.count === 1 ? "copy" : "copies"} to this project`, { tone: "success" });
      setSelected([]);
      onClose();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { lock.current = false; setCopying(false); }
  };
  const tile = (c: { id: AddChoice; title: string; icon: ReactNode }) => (
    <button
      key={c.id}
      disabled={copying}
      onClick={() => onPick(c.id)}
      className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-ink/[0.035] px-2 py-4 ring-1 ring-line transition-colors hover:bg-ink/[0.07] active:scale-[0.98]"
    >
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-card text-ink ring-1 ring-line">{c.icon}</span>
      <span className="text-[13px] font-semibold">{c.title}</span>
    </button>
  );
  return (
    <Sheet open={open} onClose={() => { if (!copying) onClose(); }} title="Add to library" footer={selected.length ? <Button size="lg" className="w-full" disabled={copying} onClick={() => void copy()}>{copying ? <Loader2 size={17} className="animate-spin" /> : <Copy size={17} />}{copying ? "Copying items..." : `Add ${selected.length} ${selected.length === 1 ? "item" : "items"}`}</Button> : undefined}>
      <h3 className="mb-2 text-[13px] font-medium text-muted">Create</h3>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{CREATE.map(tile)}</div>
      <p className="mt-2 px-1 text-[12px] leading-relaxed text-muted">A YouTube link becomes a Video item: it plays here in a clean player, and Leo reads its transcript to teach and quiz you.</p>
      <h3 className="mb-2 mt-5 text-[13px] font-medium text-muted">Upload</h3>
      <div className="grid grid-cols-3 gap-2">{UPLOAD.map(tile)}</div>
      <p className="mt-4 text-center text-[12px] text-muted">You can also drop files anywhere in the library.</p>
      {open && <PreviousProjects projectId={projectId} selected={selected} onChange={(next) => { setSelected(next); setError(""); }} disabled={copying} />}
      {error && <p role="alert" className="mt-3 text-[13px] text-danger-fg">{error}</p>}
    </Sheet>
  );
}

function KindBadge({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <span className="absolute bottom-2 left-2 inline-flex max-w-[calc(100%-16px)] items-center gap-1 truncate rounded-full bg-[#17171a]/75 px-2 py-0.5 text-[11px] font-medium text-[#fff] backdrop-blur-sm">
      {icon}
      {label}
    </span>
  );
}

function Tile({ entry, project, color, onOpen }: { entry: Entry; project: Project; color: string; onOpen: () => void }) {
  let preview: ReactNode;
  let badge: ReactNode = null;
  let meta: string;

  if (entry.kind === "note") {
    const text = snippetOf(entry.note.content, 240);
    preview = (
      <div className="flex h-full flex-col p-3.5">
        <div className="mb-2 flex items-center gap-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-ink/[0.06] px-2 py-0.5 text-[11px] font-medium text-ink">
            <FileText size={11} /> Note
          </span>
          {entry.note.author === "ai" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-ink/[0.06] px-2 py-0.5 text-[11px] font-medium text-ink">
              <AgentAvatar size={13} frozenAt={0} look={project.avatar} /> Leo
            </span>
          )}
        </div>
        <p className="line-clamp-4 text-[12.5px] leading-[1.55] text-muted" dir="auto">
          {text || "Empty note"}
        </p>
      </div>
    );
    meta = `Note · ${timeAgo(entry.at)}`;
  } else if (entry.kind === "sketch") {
    const s = entry.sketch;
    preview = <SketchThumbnail sketch={s} />;
    badge = <KindBadge icon={<PenTool size={11} />} label="Sketch" />;
    meta = `Sketch · ${timeAgo(entry.at)}`;
  } else {
    const f = entry.file;
    if (f.kind === "audio") {
      preview = (
        <div className="flex h-full flex-col justify-between p-3.5" style={{ background: `color-mix(in srgb, ${color} 10%, var(--card))` }}>
          <div className="flex items-center justify-between">
            <span className="flex h-8 w-8 items-center justify-center rounded-full" style={{ background: color, color: readableOn(color) }}>
              {f.recorded ? <Mic size={15} /> : <Music size={15} />}
            </span>
            <span className="text-[12px] font-semibold tabular-nums" style={{ color: accentText(color) }}>
              {formatDuration(f.duration)}
            </span>
          </div>
          <Waveform peaks={f.peaks} color={color} className="h-12" progress={1} />
        </div>
      );
      meta = `${f.recorded ? "Voice note" : "Audio"} · ${timeAgo(f.createdAt)}`;
    } else if (f.kind === "video") {
      preview = (
        <div className="relative h-full w-full bg-[#111]">
          {f.thumb ? <img src={f.thumb} alt="" className="h-full w-full object-cover" loading="lazy" /> : <div className="flex h-full items-center justify-center text-[#888]"><Film size={26} /></div>}
          <span className="absolute left-1/2 top-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#fff]/90 text-[#17171a] shadow-md">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </span>
          {f.youtubeId && (
            <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-full bg-[#17171a]/75 px-2 py-0.5 text-[10px] font-medium text-[#fff] backdrop-blur-sm">
              <Captions size={10} /> {f.transcript?.length ? "Transcript" : f.transcriptState === "fetching" ? "Fetching…" : "No transcript"}
            </span>
          )}
        </div>
      );
      badge = f.youtubeId ? (
        <KindBadge icon={<YoutubeGlyph size={11} />} label={f.duration ? `YouTube · ${formatDuration(f.duration)}` : "YouTube"} />
      ) : (
        <KindBadge icon={<Film size={11} />} label={f.duration ? formatDuration(f.duration) : "Video"} />
      );
      meta = `${f.youtubeId ? "YouTube" : "Video"} · ${timeAgo(f.createdAt)}`;
    } else if (f.kind === "text") {
      preview = (
        <div className="flex h-full items-center justify-center text-muted">
          <AlignLeft size={26} />
        </div>
      );
      badge = <KindBadge icon={<AlignLeft size={11} />} label="Text" />;
      meta = `Text · ${timeAgo(f.createdAt)}`;
    } else {
      preview = f.thumb ? (
        <img src={f.thumb} alt="" className={cn("h-full w-full object-cover", f.kind === "pdf" && "object-top")} loading="lazy" />
      ) : (
        <div className="flex h-full items-center justify-center text-muted">{f.kind === "pdf" ? <FileText size={26} /> : <ImageIcon size={26} />}</div>
      );
      const label = f.kind === "pdf" ? `PDF${f.pages ? ` · ${f.pages} ${f.pages === 1 ? "page" : "pages"}` : ""}` : "Picture";
      badge = <KindBadge icon={f.kind === "pdf" ? <FileText size={11} /> : <ImageIcon size={11} />} label={label} />;
      meta = `${f.kind === "pdf" ? "PDF" : "Picture"} · ${timeAgo(f.createdAt)}`;
    }
  }

  return (
    <button onClick={onOpen} className="group min-w-0 text-left">
      <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-card ring-1 ring-line transition-shadow group-hover:shadow-[0_6px_20px_rgba(0,0,0,0.08)]">
        {preview}
        {badge}
      </div>
      <div className="mt-2 truncate px-0.5 text-[14px] font-medium leading-snug" dir="auto">
        {entry.title}
      </div>
      <div className="truncate px-0.5 text-[12px] text-muted">{meta}</div>
    </button>
  );
}

/* ---------------------------------------------------------------- viewers */

function useObjectUrl(blob: Blob) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return url;
}

function FileViewer({ project, fileId }: { project: Project; fileId: string }) {
  const file = useLiveQuery(() => db.files.get(fileId), [fileId], null as LibFile | null | undefined);
  const pane = usePane();
  if (file === null) return null;
  if (!file)
    return (
      <Empty icon={<BookOpen />} title="File not found">
        <Button onClick={() => pane.close()}>{pane.primary ? "Back to library" : "Close"}</Button>
      </Empty>
    );
  if (file.kind === "pdf") return <PdfViewer file={file} bar={(controls) => <FileBar file={file} project={project} controls={controls} />} />;
  if (file.youtubeId) return <YoutubeVideoPage file={file} bar={<FileBar file={file} project={project} />} />;
  return <MediaPage file={file} project={project} />;
}

function useFileActions(file: LibFile) {
  const pane = usePane();
  return {
    remove: async () => {
      if (!(await confirmDeletion(`Delete "${file.name}"?`))) return;
      pane.close(true);
      await removeFile(file);
    },
    ask: () => useApp.getState().setChatOpen(true),
    save: () => (file.youtubeUrl ? window.open(file.youtubeUrl, "_blank", "noopener") : download(file.blob, file.name)),
    external: !!file.youtubeUrl,
  };
}

const baseName = (n: string) => n.replace(/\.[a-z0-9]{1,5}$/i, "");
const extOf = (n: string) => /\.([a-z0-9]{1,5})$/i.exec(n)?.[1]?.toUpperCase();

function EditableTitle({ file, size = "lg", className }: { file: LibFile; size?: "sm" | "lg"; className?: string }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(file.name);
  const save = async () => {
    const n = name.trim();
    if (n && n !== file.name) await db.files.update(file.id, { name: n });
    setEditing(false);
  };
  if (editing)
    return (
      <input
        autoFocus
        value={name}
        onChange={(e) => setName(e.target.value)}
        onBlur={() => void save()}
        onKeyDown={(e) => {
          if (e.key === "Enter") void save();
          if (e.key === "Escape") setEditing(false);
        }}
        aria-label="File name"
        className={cn("w-full rounded-xl bg-card px-3 py-1.5 text-[16px] outline-none ring-1 ring-line focus:ring-ink/30", className)}
      />
    );
  return (
    <button
      onClick={() => {
        setName(file.name);
        setEditing(true);
      }}
      className={cn("group flex min-w-0 max-w-full items-center gap-1.5 text-left", className)}
      title="Rename"
    >
      <span className={cn("min-w-0", size === "lg" ? "display line-clamp-2 text-[22px] leading-tight" : "truncate text-[14px] font-semibold")} dir="auto">
        {baseName(file.name)}
      </span>
      <Pencil size={size === "lg" ? 15 : 13} className="shrink-0 text-muted" />
    </button>
  );
}

/**
 * A file's bar: its title and details, the viewer's own controls (page and zoom for a PDF), then
 * its actions. It fills the pane's single top bar next to the back button, so an open document
 * never stacks a second bar under the project's.
 */
function FileBar({ file, project, controls }: { file: LibFile; project: Project; controls?: ReactNode }) {
  const { remove, ask, save, external } = useFileActions(file);
  const details = [
    file.youtubeId ? "YouTube" : file.kind === "audio" && file.recorded ? "Voice note" : KIND_WORD[file.kind],
    file.kind === "pdf" ? (file.pages ? `${file.pages} ${file.pages === 1 ? "page" : "pages"}` : null) : (extOf(file.name) ?? null),
    file.channel ?? null,
    file.duration ? formatDuration(file.duration) : null,
    file.youtubeId ? (file.transcript?.length ? transcriptLabel(file) : "No transcript yet") : null,
    file.size > 0 ? formatBytes(file.size) : null,
  ].filter(Boolean) as string[];
  return (
    <PaneBar>
      <div className="min-w-[7rem] flex-1 basis-[7rem] px-1.5 py-1">
        <EditableTitle file={file} size="sm" />
        <div className="truncate text-[12px] tabular-nums text-muted">{details.join(" · ")}</div>
      </div>
      {controls && <div className="order-last flex basis-full justify-center pb-1.5 @xl:order-none @xl:basis-auto @xl:pb-0">{controls}</div>}
      <IconBtn onClick={ask} aria-label={file.kind === "pdf" ? "Ask Leo about this PDF" : "Ask Leo about this file"}>
        <AgentAvatar size={22} frozenAt={0} look={project.avatar} />
      </IconBtn>
      <IconBtn onClick={save} aria-label={external ? "Open on YouTube" : "Download"}>
        {external ? <ExternalLink size={17} /> : <Download size={17} />}
      </IconBtn>
      <IconBtn onClick={() => void remove()} aria-label="Delete" className="hover:text-danger-fg">
        <Trash2 size={17} />
      </IconBtn>
    </PaneBar>
  );
}

const KIND_WORD: Record<FileKind, string> = { pdf: "PDF", image: "Picture", video: "Video", audio: "Audio", text: "Text file" };

/** Scrolling page for video, pictures, audio and text. Title, details and actions live in the top bar. */
function MediaPage({ file, project }: { file: LibFile; project: Project }) {
  return (
    <div className="pb-36">
      <FileBar file={file} project={project} />
      <div className="mx-auto max-w-3xl sm:px-4 sm:pt-4">
        {file.kind === "video" && <VideoStage file={file} />}
        {file.kind === "image" && <ImageStage file={file} />}
        {file.kind === "audio" && (
          <div className="px-4 pt-4 sm:px-0">
            <AudioPlayer file={file} accent={colorOf(project.color).hex} />
          </div>
        )}
        {file.kind === "text" && <TextStage file={file} />}
      </div>
      <div className="mx-auto max-w-3xl px-4 pt-4 text-[13px] leading-relaxed text-muted">
        <p className="tabular-nums">Added {new Date(file.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}</p>
        {file.kind === "video" && <p className="mt-1">Pause on any frame and ask Leo: he sees that exact frame.</p>}
        {file.kind === "image" && <p className="mt-1">Tap the picture to zoom. Ask Leo to explain what's in it.</p>}
      </div>
    </div>
  );
}

function VideoStage({ file }: { file: LibFile }) {
  const url = useObjectUrl(file.blob);
  const ref = useRef<HTMLVideoElement>(null);
  const setImage = useApp((s) => s.setImage);
  useEffect(() => {
    setImage({ fileId: file.id, name: `${file.name} (current frame)`, getDataUrl: async () => frameDataUrl(ref.current, 1280) });
    return () => setImage(null);
  }, [file.id, file.name, setImage]);
  // The frame you pause on becomes the poster in the library.
  const onPause = () => {
    const d = frameDataUrl(ref.current, 420);
    if (d) void db.files.update(file.id, { thumb: d, thumbVersion: 3 });
  };
  return (
    <div className="overflow-hidden bg-[#000] sm:rounded-2xl">
      {url ? (
        <video
          ref={ref}
          src={url}
          poster={file.thumb}
          controls
          playsInline
          preload="metadata"
          onPause={onPause}
          className="mx-auto block max-h-[70dvh] w-full bg-[#000] object-contain"
        />
      ) : (
        <div className="aspect-video" />
      )}
    </div>
  );
}

function ImageStage({ file }: { file: LibFile }) {
  const url = useObjectUrl(file.blob);
  const [zoom, setZoom] = useState(false);
  const setImage = useApp((s) => s.setImage);
  useEffect(() => {
    setImage({ fileId: file.id, name: file.name, getDataUrl: () => imageToDataUrl(file.blob, 1280) });
    return () => setImage(null);
  }, [file.id, file.name, file.blob, setImage]);
  return (
    <div className={cn("bg-document sm:rounded-2xl", zoom && "max-h-[80dvh] overflow-auto")}>
      {url && (
        <img
          src={url}
          alt={file.name}
          onClick={() => setZoom((z) => !z)}
          className={cn("mx-auto block", zoom ? "max-w-none cursor-zoom-out" : "max-h-[70dvh] w-full cursor-zoom-in object-contain sm:rounded-2xl")}
        />
      )}
    </div>
  );
}

function TextStage({ file }: { file: LibFile }) {
  const [text, setText] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    void file.blob.text().then((t) => alive && setText(t));
    return () => {
      alive = false;
    };
  }, [file.blob]);
  return (
    <div className="px-4 pt-4 sm:px-0" data-ctx-source={`file "${file.name}"`}>
      <pre className="whitespace-pre-wrap rounded-2xl bg-card p-5 font-sans text-[15px] leading-relaxed ring-1 ring-line" dir="auto">
        {text ?? "…"}
      </pre>
    </div>
  );
}

/**
 * Library filter chips. Horizontally scrollable with scroll-snap; a right-edge fade shows when
 * more chips are hidden, and the active chip is scrolled into view so none is ever cut off.
 * Chip height and type match the Progress button (h-9, 13px).
 */
function FilterTabs({
  filters,
  filter,
  onChange,
  total,
  counts,
}: {
  filters: Filter[];
  filter: Filter;
  onChange: (f: Filter) => void;
  total: number;
  counts: Partial<Record<Filter, number>>;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [fade, setFade] = useState({ left: false, right: false });

  const measure = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    const left = el.scrollLeft > 2;
    const right = el.scrollLeft + el.clientWidth < el.scrollWidth - 2;
    setFade((f) => (f.left === left && f.right === right ? f : { left, right }));
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [measure, filters.length]);

  const mounted = useRef(false);
  useEffect(() => {
    if (!mounted.current) {
      mounted.current = true;
      return;
    }
    const el = ref.current;
    const chip = el?.querySelector<HTMLElement>('[aria-selected="true"]');
    if (!el || !chip) return;
    // Scroll only the chip row (never the page) so the active chip is fully visible.
    const left = chip.offsetLeft - 16;
    const right = chip.offsetLeft + chip.offsetWidth + 40 - el.clientWidth;
    if (el.scrollLeft > left) el.scrollTo({ left, behavior: "smooth" });
    else if (el.scrollLeft < right) el.scrollTo({ left: right, behavior: "smooth" });
  }, [filter]);

  const mask =
    fade.left || fade.right
      ? `linear-gradient(to right, ${fade.left ? "transparent 0, #000 24px" : "#000 0"}, ${fade.right ? "#000 calc(100% - 40px), transparent 100%" : "#000 100%"})`
      : undefined;

  return (
    <div
      ref={ref}
      onScroll={measure}
      className="no-scrollbar -mx-4 mt-3 flex snap-x snap-mandatory scroll-px-4 gap-2 overflow-x-auto px-4 pb-1"
      style={mask ? { maskImage: mask, WebkitMaskImage: mask } : undefined}
      role="tablist"
      aria-label="Filter library"
    >
      {filters.map((f) => {
        const active = filter === f;
        return (
          <button
            key={f}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(f)}
            className={cn(
              "inline-flex h-9 shrink-0 snap-start items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 text-[13px] font-medium leading-none transition-colors",
              active ? "bg-ink text-white" : "bg-card text-ink ring-1 ring-inset ring-line hover:bg-ink/[0.04]"
            )}
          >
            {FILTER_LABEL[f]}
            <span className={cn("tabular-nums", active ? "text-white/70" : "text-muted")}>{f === "all" ? total : counts[f] ?? 0}</span>
          </button>
        );
      })}
      <span aria-hidden className="w-6 shrink-0" />
    </div>
  );
}
