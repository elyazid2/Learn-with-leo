import { Suspense, lazy, useEffect, useState } from "react";
import { Loader2, PenTool, Trash2 } from "lucide-react";
import { db, type Project, type Sketch } from "@/lib/db";
import { Button, Empty, IconBtn } from "@/components/ui";
import { confirmDeletion, useSettings } from "@/lib/settings";
import { useApp } from "@/lib/store";
import { useLive } from "@/lib/live";
import { PaneBar, usePane } from "@/components/Pane";

import { normalizeAvatarLook } from "@/lib/avatar";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

const SketchCanvas = lazy(() => import("@/components/SketchCanvas"));

export default function Sketches({ project, sketchId }: { project: Project; sketchId: string }) {
  return <SketchEditor key={sketchId} project={project} sketchId={sketchId} />;
}

/** Sketchboard: its title, save state, Leo and delete sit in the pane's one top bar; the rest is canvas. */
function SketchEditor({ project, sketchId }: { project: Project; sketchId: string }) {
  const [sketch, setSketch] = useState<Sketch | null | undefined>(null);
  const [title, setTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const setChatOpen = useApp((s) => s.setChatOpen);
  const drawing = useLive((s) => s.sketchId === sketchId);
  const pane = usePane();

  const globalLook = useSettings((s) => s.avatar);
  const look = normalizeAvatarLook(project.avatar ?? globalLook, globalLook);

  useEffect(() => {
    void db.sketches.get(sketchId).then((s) => {
      setSketch(s);
      if (s) setTitle(s.title);
    });
  }, [sketchId]);

  if (sketch === null)
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="animate-spin text-muted" />
      </div>
    );
  if (!sketch)
    return (
      <Empty icon={<PenTool />} title="Sketch not found">
        <Button onClick={() => pane.close()}>{pane.primary ? "Back to library" : "Close"}</Button>
      </Empty>
    );

  const saveTitle = () => void db.sketches.update(sketch.id, { title: title.trim() || "Sketch", updatedAt: Date.now() });
  const remove = async () => {
    if (!(await confirmDeletion("Delete this sketch?"))) return;
    pane.close(true);
    await db.sketches.delete(sketch.id);
  };

  return (
    <div className="flex h-full flex-col">
      <PaneBar>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onBlur={saveTitle}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          aria-label="Sketch title"
          dir="auto"
          className="min-w-[6rem] flex-1 basis-[6rem] truncate rounded-lg bg-transparent px-1.5 py-1 text-[16px] font-semibold outline-none focus:bg-ink/[0.05]"
        />
        <span className="flex shrink-0 items-center gap-1.5 px-1.5 text-[12px] text-muted" aria-live="polite" title={drawing ? "Leo is drawing" : saving ? "Saving" : "Saved"}>
          <span className={cn("h-1.5 w-1.5 rounded-full transition-colors", drawing || saving ? "bg-shaky" : "bg-solid")} />
          <span className="hidden sm:inline">{drawing ? "Leo is drawing" : saving ? "Saving" : "Saved"}</span>
        </span>
        <button
          onClick={() => setChatOpen(true)}
          aria-label="Ask Leo about this sketch"
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-full py-1 pl-1 pr-3 text-[14px] font-semibold transition-colors hover:bg-ink/[0.06]"
        >
          <AgentAvatar state={drawing ? "working" : "idle"} look={look} size={28} frozenAt={drawing ? undefined : 0} /> Leo
        </button>
        <IconBtn onClick={() => void remove()} aria-label="Delete sketch" className="hover:text-danger-fg">
          <Trash2 size={17} />
        </IconBtn>
      </PaneBar>
      <div className="relative min-h-0 flex-1">
        <Suspense
          fallback={
            <div className="flex h-full items-center justify-center">
              <Loader2 className="animate-spin text-muted" />
            </div>
          }
        >
          <SketchCanvas sketch={sketch} title={title} onSaving={setSaving} />
        </Suspense>
        {drawing && (
          <div className="pointer-events-none absolute inset-x-0 bottom-4 z-10 flex justify-center" role="status">
            <span className="rise flex items-center gap-2 rounded-full bg-elevated py-1.5 pl-1.5 pr-3.5 text-[13px] font-semibold shadow-[0_8px_24px_rgba(0,0,0,0.16)] ring-1 ring-line">
              <AgentAvatar state="working" look={look} size={24} /> Leo is drawing
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
