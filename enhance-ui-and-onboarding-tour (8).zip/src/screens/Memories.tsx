import { useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeft, Brain, Plus, Trash2 } from "lucide-react";
import { db, uid, type Memory, type MemoryKind } from "@/lib/db";
import { navigate } from "@/lib/router";
import { Button, Field, IconBtn, Sheet, inputCls } from "@/components/ui";
import { confirmDeletion } from "@/lib/settings";
import { timeAgo } from "@/lib/media";
import { cn } from "@/utils/cn";

const KINDS: { id: MemoryKind; label: string }[] = [
  { id: "level", label: "Level" },
  { id: "goal", label: "Goal" },
  { id: "preference", label: "Preference" },
  { id: "strength", label: "Strength" },
  { id: "weakness", label: "Weak spot" },
  { id: "fact", label: "Fact" },
];

/** One stable empty list, so memoized values don't recompute while IndexedDB answers. */
const NONE: never[] = [];

export default function Memories() {
  const memories = useLiveQuery(() => db.memories.orderBy("updatedAt").reverse().toArray(), []) ?? NONE;
  const projects = useLiveQuery(() => db.projects.toArray().then((p) => p.sort((a, b) => a.name.localeCompare(b.name))), []) ?? NONE;
  const [scope, setScope] = useState<string>("*");
  const [editing, setEditing] = useState<Memory | null>(null);
  const [draft, setDraft] = useState("");
  const [kind, setKind] = useState<MemoryKind>("fact");

  const visible = useMemo(() => memories.filter((m) => m.projectId === "*" || scope === "*" || m.projectId === scope), [memories, scope]);
  const beginEdit = (m?: Memory) => {
    setEditing(m ?? { id: "", projectId: scope, kind: "fact", text: "", createdAt: Date.now(), updatedAt: Date.now() });
    setDraft(m?.text ?? "");
    setKind(m?.kind ?? "fact");
  };
  const save = async () => {
    const text = draft.trim();
    if (!text) return;
    const now = Date.now();
    if (editing?.id) await db.memories.update(editing.id, { text, kind, updatedAt: now });
    else await db.memories.add({ id: uid(), projectId: scope, kind, text, createdAt: now, updatedAt: now });
    setEditing(null);
  };
  const remove = async (m: Memory) => {
    if (!(await confirmDeletion("Leo will no longer use it.", { title: "Forget this memory?", confirmLabel: "Forget" }))) return;
    await db.memories.delete(m.id);
  };

  return (
    <div className="mx-auto min-h-dvh max-w-2xl px-4 pb-12 pt-[max(env(safe-area-inset-top),16px)] sm:px-6">
      <header className="flex items-center gap-2 py-3">
        <IconBtn onClick={() => (history.length > 1 ? history.back() : navigate("settings"))} aria-label="Back">
          <ArrowLeft size={19} />
        </IconBtn>
        <div className="min-w-0 flex-1">
          <h1 className="display text-[24px] leading-tight">Leo's memory</h1>
          <p className="text-[13px] text-muted">Facts Leo can remember across chats. Edit or forget any of them.</p>
        </div>
        <Button size="sm" onClick={() => beginEdit()}>
          <Plus size={15} /> Add
        </Button>
      </header>

      <div className="mt-5 flex items-center gap-2">
        <label htmlFor="memory-scope" className="text-[13px] text-muted">Show</label>
        <select id="memory-scope" className={cn(inputCls, "w-auto min-w-40 py-2 text-[16px]")} value={scope} onChange={(e) => setScope(e.target.value)}>
          <option value="*">All memory</option>
          {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {visible.length === 0 ? (
        <div className="mt-8 rounded-2xl bg-card p-6 text-center ring-1 ring-line">
          <Brain size={24} className="mx-auto text-muted" />
          <h2 className="mt-3 text-[16px] font-semibold">No saved memories</h2>
          <p className="mx-auto mt-1 max-w-sm text-[13px] leading-relaxed text-muted">Leo can remember your goals, learning preferences, demonstrated strengths and weak spots. It only saves stable, useful facts.</p>
          <Button className="mt-4" onClick={() => beginEdit()}><Plus size={15} /> Add a memory</Button>
        </div>
      ) : (
        <div className="mt-4 divide-y divide-line rounded-2xl bg-card px-4 ring-1 ring-line">
          {visible.map((m) => (
            <article key={m.id} className="flex items-start gap-3 py-4">
              <span className="mt-0.5 rounded-full bg-ink/[0.06] px-2.5 py-1 text-[11px] font-medium capitalize">{m.projectId === "*" ? "You" : projects.find((p) => p.id === m.projectId)?.name ?? "Project"} · {m.kind}</span>
              <button className="min-w-0 flex-1 text-left" onClick={() => beginEdit(m)}>
                <span className="block text-[14px] leading-relaxed" dir="auto">{m.text}</span>
                <span className="mt-1 block text-[12px] text-muted">Updated {timeAgo(m.updatedAt)} · tap to edit</span>
              </button>
              <IconBtn onClick={() => void remove(m)} aria-label="Forget memory" className="text-muted hover:text-danger-fg">
                <Trash2 size={15} />
              </IconBtn>
            </article>
          ))}
        </div>
      )}

      <Sheet
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.id ? "Edit memory" : "Add a memory"}
        description="Stable facts that help Leo teach you better. Never store passwords or private details."
      >
        {editing && (
          <>
            <div className="space-y-3">
              <Field label="Scope">
                <select className={inputCls + " text-[16px]"} value={editing.projectId} onChange={(e) => setEditing({ ...editing, projectId: e.target.value })}>
                  <option value="*">All projects</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </Field>
              <Field label="Type">
                <select className={inputCls + " text-[16px]"} value={kind} onChange={(e) => setKind(e.target.value as MemoryKind)}>
                  {KINDS.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
                </select>
              </Field>
              <Field label="Memory" hint={<span className="tabular-nums">{draft.length}/500</span>}>
                <textarea
                  className={cn(inputCls, "min-h-24 resize-y text-[16px]")}
                  value={draft}
                  maxLength={500}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.metaKey || e.ctrlKey) && draft.trim()) {
                      e.preventDefault();
                      void save();
                    }
                  }}
                  placeholder="e.g. I'm preparing for the JLPT N4 in June"
                  dir="auto"
                  autoFocus
                />
              </Field>
            </div>
            <div className="mt-5 flex gap-2">
              <Button variant="soft" size="lg" className="flex-1" onClick={() => setEditing(null)}>Cancel</Button>
              <Button size="lg" className="flex-1" disabled={!draft.trim()} onClick={() => void save()}>Save memory</Button>
            </div>
          </>
        )}
      </Sheet>
    </div>
  );
}