# Provider logos

The SVG logos in this folder come from [`@lobehub/icons-static-svg`](https://github.com/lobehub/lobe-icons)
(MIT License, Copyright (c) 2023 LobeHub). They are lightly normalized: the `<title>` element is
removed and the size is set to fill the container.

Each logo is a trademark of its owner and is used here only to identify that provider.
