/**
 * A tiny in-memory stand-in for the Dexie tables the agent core touches, so tests run in Node
 * without IndexedDB. Supports get / add / put / update / delete / where(field).equals|anyOf(...).
 */
type Row = { id: string } & Record<string, unknown>;

class FakeCollection<T extends Row> {
  constructor(private rows: () => T[], private erase?: (rows: T[]) => void) {}
  toArray() {
    return Promise.resolve(this.rows().map((r) => ({ ...r })));
  }
  sortBy(field: string) {
    return Promise.resolve(
      this.rows()
        .map((r) => ({ ...r }))
        .sort((a, b) => ((a[field] as number) ?? 0) - ((b[field] as number) ?? 0))
    );
  }
  /** Dexie Collection.filter / first / count, as used by the app's queries. */
  filter(fn: (row: T) => boolean) {
    return new FakeCollection(() => this.rows().filter(fn), this.erase);
  }
  first() {
    const row = this.rows()[0];
    return Promise.resolve(row ? ({ ...row } as T) : undefined);
  }
  count() {
    return Promise.resolve(this.rows().length);
  }
  delete() {
    const rows = this.rows();
    this.erase?.(rows);
    return Promise.resolve(rows.length);
  }
}

export class FakeTable<T extends Row> {
  rows = new Map<string, T>();
  get(id: string) {
    const r = this.rows.get(id);
    return Promise.resolve(r ? ({ ...r } as T) : undefined);
  }
  add(row: T) {
    this.rows.set(row.id, { ...row });
    return Promise.resolve(row.id);
  }
  put(row: T) {
    return this.add(row);
  }
  update(id: string, patch: Partial<T>) {
    const r = this.rows.get(id);
    if (!r) return Promise.resolve(0);
    const next = { ...r, ...patch } as T;
    // Dexie removes keys explicitly set to undefined.
    for (const k of Object.keys(patch)) if ((patch as Record<string, unknown>)[k] === undefined) delete (next as Record<string, unknown>)[k];
    this.rows.set(id, next);
    return Promise.resolve(1);
  }
  delete(id: string) {
    this.rows.delete(id);
    return Promise.resolve();
  }
  bulkDelete(ids: string[]) {
    for (const id of ids) this.rows.delete(id);
    return Promise.resolve();
  }
  bulkAdd(rows: T[]) {
    for (const r of rows) this.rows.set(r.id, { ...r });
    return Promise.resolve(rows.map((r) => r.id));
  }
  count() {
    return Promise.resolve(this.rows.size);
  }
  toArray() {
    return Promise.resolve([...this.rows.values()].map((r) => ({ ...r })));
  }
  where(field: string) {
    const all = () => [...this.rows.values()];
    const erase = (rows: T[]) => { for (const row of rows) this.rows.delete(row.id); };
    return {
      equals: (v: unknown) => new FakeCollection(() => all().filter((r) => r[field] === v), erase),
      anyOf: (vs: unknown[]) => new FakeCollection(() => all().filter((r) => vs.includes(r[field])), erase),
    };
  }
  clear() {
    this.rows.clear();
  }
}

export function createFakeDb() {
  const tables = {
    projects: new FakeTable(),
    projectFolders: new FakeTable(),
    files: new FakeTable(),
    notes: new FakeTable(),
    folders: new FakeTable(),
    sketches: new FakeTable(),
    threads: new FakeTable(),
    messages: new FakeTable(),
    concepts: new FakeTable(),
    points: new FakeTable(),
    providers: new FakeTable(),
    cards: new FakeTable(),
    pdfAnnotations: new FakeTable(),
    memories: new FakeTable(),
    chunks: new FakeTable(),
    kv: new FakeTable(),
  };
  return {
    ...tables,
    /** Dexie transactions: the fake tables are synchronous, so running the callback is enough. */
    async transaction(_mode: unknown, _tables: unknown, fn: () => Promise<unknown>) {
      return fn();
    },
    reset() {
      for (const t of Object.values(tables)) t.clear();
    },
  };
}
