import { beforeEach, describe, expect, it, vi } from "vitest";

// The store remembers the active conversation in localStorage; give Node an in-memory one.
vi.hoisted(() => {
  const data = new Map<string, string>();
  (globalThis as { localStorage?: unknown }).localStorage = {
    getItem: (k: string) => data.get(k) ?? null,
    setItem: (k: string, v: string) => void data.set(k, String(v)),
    removeItem: (k: string) => void data.delete(k),
    clear: () => data.clear(),
  };
});

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db, type Thread } from "@/lib/db";
import { useApp } from "./store";
import { createThread, getOrCreateActiveThread } from "./chat";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const P = "proj";
const threads = () => db.threads.toArray() as Promise<Thread[]>;

beforeEach(() => {
  fake.reset();
  useApp.setState({ activeThread: {} });
});

/**
 * Regression: opening Leo made the chat panel look for a conversation at the same moment
 * placement (or "Teach me") created one. Both created a thread, and the empty one could end up
 * on screen while Leo answered in the other. Conversation set-up now runs one at a time per project.
 */
describe("conversation set-up is serialized per project", () => {
  it("two callers asking at the same moment share one conversation", async () => {
    const [a, b] = await Promise.all([getOrCreateActiveThread(P), getOrCreateActiveThread(P)]);
    expect(a.id).toBe(b.id);
    expect(await threads()).toHaveLength(1);
    expect(useApp.getState().activeThread[P]).toBe(a.id);
  });

  it("a burst of callers still creates exactly one conversation", async () => {
    const all = await Promise.all(Array.from({ length: 6 }, () => getOrCreateActiveThread(P)));
    expect(new Set(all.map((t) => t.id)).size).toBe(1);
    expect(await threads()).toHaveLength(1);
  });

  it("a caller that arrives after a conversation was opened shows that one, not a new one", async () => {
    const placement = await createThread(P, "placement");
    const shown = await getOrCreateActiveThread(P, "ask");
    expect(shown.id).toBe(placement.id);
    expect(shown.mode).toBe("placement");
    expect(await threads()).toHaveLength(1);
  });

  it("projects do not wait on each other and each gets its own conversation", async () => {
    const [a, b] = await Promise.all([getOrCreateActiveThread("one"), getOrCreateActiveThread("two")]);
    expect(a.projectId).toBe("one");
    expect(b.projectId).toBe("two");
    expect(await threads()).toHaveLength(2);
  });

  it("falls back to the most recent conversation when none is marked active", async () => {
    await db.threads.add({ id: "old", projectId: P, title: "Old", mode: "ask", createdAt: 1, updatedAt: 1 } as Thread);
    await db.threads.add({ id: "new", projectId: P, title: "New", mode: "ask", createdAt: 2, updatedAt: 2 } as Thread);
    const shown = await getOrCreateActiveThread(P);
    expect(shown.id).toBe("new");
    expect(await threads()).toHaveLength(2);
  });
});
