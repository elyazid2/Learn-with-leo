import { db, type CitationRef, type LibFile } from "./db";
import { parseCitations, type FoundCitation } from "./ai/actions";
import { navigate, projectPath } from "./router";

export const CITE_PREFIX = "#cite/";

export const citeHref = (c: Pick<FoundCitation, "fileId" | "page" | "t0">) =>
  `${CITE_PREFIX}${encodeURIComponent(c.fileId)}/${c.page ?? 0}/${typeof c.t0 === "number" ? Math.round(c.t0) : -1}`;

export function parseCiteHref(href: string): { fileId: string; page?: number; t0?: number } | null {
  if (!href.startsWith(CITE_PREFIX)) return null;
  const [id, page, t0] = href.slice(CITE_PREFIX.length).split("/");
  if (!id) return null;
  return { fileId: decodeURIComponent(id), page: Number(page) > 0 ? Number(page) : undefined, t0: Number(t0) >= 0 ? Number(t0) : undefined };
}

/**
 * Turn citations — "(book.pdf, p.12)", "[S2]", "[3:12]" — into markdown links the reader can tap.
 * Code fences are left alone.
 */
export function linkCitations(text: string, files: Pick<LibFile, "id" | "name" | "kind">[], labels: CitationRef[] = []): string {
  if (!files.length) return text;
  return text
    .split(/(```[\s\S]*?```)/g)
    .map((part, i) => {
      if (i % 2 === 1) return part;
      const found = parseCitations(part, files, labels);
      if (!found.length) return part;
      const seen = new Set<string>();
      let out = part;
      for (const c of found) {
        if (seen.has(c.match)) continue;
        seen.add(c.match);
        const label = c.match.replace(/([[\]])/g, "\\$1");
        // Skip matches already inside a markdown link.
        out = out.split(c.match).join(`[${label}](${citeHref(c)})`);
      }
      return out;
    })
    .join("");
}

/** Open the cited spot: the PDF at its page, or the audio/video seeked to the timestamp. */
export async function openCitation(href: string) {
  const c = parseCiteHref(href);
  if (!c) return;
  const file = await db.files.get(c.fileId);
  if (!file) return;
  if (c.page) localStorage.setItem("pdfpage." + file.id, String(c.page));
  navigate(projectPath(file.projectId, "library", file.id));
  window.dispatchEvent(new CustomEvent("harness:seek", { detail: { fileId: file.id, page: c.page, t0: c.t0 } }));
  if (typeof c.t0 === "number") {
    const t0 = c.t0;
    // The player mounts after navigation; wait for its media element, then seek.
    const started = Date.now();
    const tryseek = () => {
      const el = document.querySelector<HTMLMediaElement>("audio, video");
      if (el) {
        const go = () => {
          el.currentTime = t0;
        };
        if (el.readyState >= 1) go();
        else el.addEventListener("loadedmetadata", go, { once: true });
        return;
      }
      if (Date.now() - started < 3000) setTimeout(tryseek, 100);
    };
    setTimeout(tryseek, 50);
  }
}
