import { db, uid, type Chunk, type CitationRef, type LibFile, type Message, type Note } from "./db";

const CHUNK_CHARS = 900;
const OVERLAP = 120;

/** Split text into overlapping chunks on sentence-ish boundaries. */
export function chunkText(text: string): string[] {
  const clean = text.replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
  if (!clean) return [];
  if (clean.length <= CHUNK_CHARS) return [clean];
  const out: string[] = [];
  let i = 0;
  while (i < clean.length) {
    let end = Math.min(clean.length, i + CHUNK_CHARS);
    if (end < clean.length) {
      const window = clean.slice(i + CHUNK_CHARS * 0.6, end);
      const cut = Math.max(window.lastIndexOf(". "), window.lastIndexOf("\n"), window.lastIndexOf("? "), window.lastIndexOf("! "));
      if (cut > 0) end = i + Math.floor(CHUNK_CHARS * 0.6) + cut + 1;
    }
    out.push(clean.slice(i, end).trim());
    if (end >= clean.length) break;
    i = Math.max(end - OVERLAP, i + 1);
  }
  return out.filter(Boolean);
}

const STOP = new Set(
  "a an the and or but if then else of to in on at by for with from as is are was were be been being it its this that these those i you he she we they me him her us them my your our their what which who whom how when where why not no yes do does did done have has had having can could should would will shall may might must so than too very just about into over under again further once here there all any both each few more most other some such only own same s t don now".split(" ")
);

/**
 * Light stemming: plurals, -ing, -ed. Deliberately conservative so "cells"/"cell", "dividing"/"divide",
 * "studied"/"study" meet while short words stay intact.
 */
export function stem(t: string): string {
  if (t.length <= 3 || /\d/.test(t)) return t;
  let w = t;
  if (w.endsWith("ies") && w.length > 4) w = w.slice(0, -3) + "y";
  else if (w.endsWith("sses")) w = w.slice(0, -2);
  else if (/(xes|ches|shes|zes)$/.test(w)) w = w.slice(0, -2);
  else if (w.endsWith("s") && !/(ss|us|is)$/.test(w)) w = w.slice(0, -1);
  if (w.endsWith("ied") && w.length > 4) w = w.slice(0, -3) + "y";
  else if (w.endsWith("ing") && w.length > 5) w = w.slice(0, -3);
  else if (w.endsWith("ed") && w.length > 4) w = w.slice(0, -2);
  else return w;
  // "running" → "runn" → "run"; "divid" stays (matches "divide" → "divid" below).
  if (/([^aeiouls])\1$/.test(w)) w = w.slice(0, -1);
  return w;
}

/** Normalize a trailing silent "e" so "divide" and "dividing" share a stem. */
const fold = (t: string) => (t.length > 4 && t.endsWith("e") && !t.endsWith("ee") ? t.slice(0, -1) : t);

export function tokenize(text: string): string[] {
  return (text.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu) ?? [])
    .map((t) => t.replace(/^['’-]+|['’-]+$/g, ""))
    .filter((t) => t.length > 1 && !STOP.has(t))
    .map((t) => fold(stem(t)));
}

export interface Hit {
  chunk: Chunk;
  score: number;
}

/** Leo's own notes rank lower so it grounds in the learner's materials, not in itself. */
export const AI_WEIGHT = 0.6;
/** Hits scoring under this share of the top hit are noise and dropped. */
export const MIN_RELATIVE_SCORE = 0.4;

export interface Corpus {
  chunks: Chunk[];
  tfs: Map<string, number>[];
  lens: number[];
  df: Map<string, number>;
  avg: number;
}

export function buildCorpus(chunks: Chunk[]): Corpus {
  const tfs: Map<string, number>[] = [];
  const lens: number[] = [];
  const df = new Map<string, number>();
  for (const c of chunks) {
    const d = tokenize(c.text);
    const tf = new Map<string, number>();
    for (const t of d) tf.set(t, (tf.get(t) ?? 0) + 1);
    for (const t of tf.keys()) df.set(t, (df.get(t) ?? 0) + 1);
    tfs.push(tf);
    lens.push(d.length);
  }
  const avg = lens.reduce((s, n) => s + n, 0) / (lens.length || 1) || 1;
  return { chunks, tfs, lens, df, avg };
}

export type Scope = "all" | "files" | "notes";

/** BM25 over a prepared corpus, with Leo's notes down-weighted and weak hits dropped. */
export function rankCorpus(corpus: Corpus, query: string, limit = 6, scope: Scope = "all"): Hit[] {
  const q = Array.from(new Set(tokenize(query)));
  if (!q.length || !corpus.chunks.length) return [];
  const N = corpus.chunks.length;
  const k1 = 1.4;
  const b = 0.75;
  const hits: Hit[] = [];
  corpus.chunks.forEach((chunk, i) => {
    if (scope === "files" && chunk.sourceKind !== "file") return;
    if (scope === "notes" && chunk.sourceKind !== "note") return;
    const len = corpus.lens[i];
    if (!len) return;
    const tf = corpus.tfs[i];
    let score = 0;
    for (const t of q) {
      const f = tf.get(t);
      if (!f) continue;
      const n = corpus.df.get(t) ?? 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      score += idf * ((f * (k1 + 1)) / (f + k1 * (1 - b + (b * len) / corpus.avg)));
    }
    if (chunk.author === "ai") score *= AI_WEIGHT;
    if (score > 0) hits.push({ chunk, score });
  });
  hits.sort((a, b2) => b2.score - a.score);
  const top = hits[0]?.score ?? 0;
  return hits.filter((h) => h.score >= top * MIN_RELATIVE_SCORE).slice(0, limit);
}

/** BM25 over a list of chunks (builds a throwaway corpus). */
export function rankChunks(query: string, chunks: Chunk[], limit = 6, scope: Scope = "all"): Hit[] {
  return rankCorpus(buildCorpus(chunks), query, limit, scope);
}

// ---- per-project corpus cache -------------------------------------------------------------

const cache = new Map<string, { count: number; version: number; corpus: Corpus }>();
let indexVersion = 0;

/** Drop cached tokenized chunks (all projects, or one) after the index changed. */
export function invalidateIndex(projectId?: string) {
  indexVersion++;
  if (projectId) cache.delete(projectId);
  else cache.clear();
}

async function corpusFor(projectId: string): Promise<Corpus> {
  // The count catches writes made outside this module (file removal, backup import).
  const count = await db.chunks.where("projectId").equals(projectId).count();
  const hit = cache.get(projectId);
  if (hit && hit.count === count && hit.version === indexVersion) return hit.corpus;
  const chunks = await db.chunks.where("projectId").equals(projectId).toArray();
  const corpus = buildCorpus(chunks);
  cache.set(projectId, { count, version: indexVersion, corpus });
  return corpus;
}

export async function retrieve(projectId: string, query: string, limit = 6, scope: Scope = "all"): Promise<Hit[]> {
  return rankCorpus(await corpusFor(projectId), query, limit, scope);
}

/** The question Leo last asked (an ask/quiz action, or the last line ending in "?"). */
export function lastAssistantQuestion(content: string): string {
  const quoted = [...content.matchAll(/"question"\s*:\s*"((?:[^"\\]|\\.)*)"/g)].pop()?.[1];
  if (quoted) return quoted.replace(/\\"/g, '"').replace(/\\n/g, " ");
  const lines = content
    .replace(/```[\s\S]*?```/g, "")
    .split(/\n|(?<=[.!?])\s+/)
    .map((l) => l.trim())
    .filter((l) => l.endsWith("?"));
  return lines.pop() ?? "";
}

/**
 * What to retrieve for: the learner's last text; when it is a short reply ("yes", "the second one")
 * under 4 tokens, add the question Leo asked last so the reply has something to match.
 */
export function retrievalQuery(messages: Pick<Message, "role" | "content" | "hidden">[]): string {
  let userIdx = -1;
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role === "user" && !m.hidden) {
      userIdx = i;
      break;
    }
  }
  if (userIdx < 0) return "";
  const text = messages[userIdx].content;
  if (tokenize(text).length >= 4) return text;
  for (let i = userIdx - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role !== "assistant") continue;
    const q = lastAssistantQuestion(m.content);
    if (q) return `${text}\n${q}`;
    break;
  }
  return text;
}

// ---- formatting ---------------------------------------------------------------------------

export function clock(s: number) {
  const t = Math.max(0, Math.floor(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = t % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${m}:${String(sec).padStart(2, "0")}`;
}

/** "3:10" | "1:02:03" | "190" → seconds (NaN when unparseable). */
export function parseClock(v: string | number | undefined): number {
  if (v === undefined || v === "") return NaN;
  if (typeof v === "number") return v;
  const parts = v.trim().split(":").map(Number);
  if (!parts.length || parts.some((n) => !isFinite(n) || n < 0)) return NaN;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}

export function citation(c: Chunk) {
  if (c.sourceKind === "file" && typeof c.t0 === "number") return `${c.sourceName}, ${clock(c.t0)}`;
  return c.sourceKind === "file" && c.page > 0 ? `${c.sourceName}, p.${c.page}` : c.sourceName;
}

/** Format hits for the model with explicit, citable labels. */
export function formatSources(hits: Hit[]) {
  return hits
    .map((h, i) => `[S${i + 1}] (${citation(h.chunk)}; id=${h.chunk.sourceId})\n${h.chunk.text.slice(0, 1200)}`)
    .join("\n\n");
}

/** [S1]… → where each passage lives, stored on the reply so citations can be tapped. */
export function citationsOf(hits: Hit[]): CitationRef[] {
  return hits.map((h, i) => ({
    label: `S${i + 1}`,
    name: h.chunk.sourceName,
    ...(h.chunk.sourceKind === "file" ? { fileId: h.chunk.sourceId } : { noteId: h.chunk.sourceId }),
    ...(h.chunk.page > 0 ? { page: h.chunk.page } : {}),
    ...(typeof h.chunk.t0 === "number" ? { t0: h.chunk.t0 } : {}),
  }));
}

/** Search results for the `search` action: id, page/timestamp and source per passage. */
export function formatSearchResults(query: string, hits: Hit[]): string {
  if (!hits.length) return `## Search "${query}"\nNo matching passages. Try other words, or read a file directly by id.`;
  const lines = hits.map((h, i) => {
    const c = h.chunk;
    const where = typeof c.t0 === "number" ? `${clock(c.t0)}–${clock(c.t1 ?? c.t0)}` : c.page > 0 ? `p.${c.page}` : c.sourceKind;
    const text = c.text.replace(/\s+/g, " ").slice(0, 600);
    return `[R${i + 1}] id=${c.sourceId} · ${where} · ${c.sourceName}\n${text}`;
  });
  return `## Search "${query}" — ${hits.length} passages (read a file by id for more)\n${lines.join("\n\n")}`;
}

// ---- read pagination ----------------------------------------------------------------------

export const READ_MAX_CHARS = 12000;
export const READ_MAX_PAGES = 30;

/** "12-14" | "12" | "12-" | "3,5" → sorted page numbers within 1..numPages (capped). */
export function parsePages(spec: string | undefined, numPages: number): number[] {
  if (!numPages) return [];
  if (!spec?.trim()) return Array.from({ length: Math.min(numPages, READ_MAX_PAGES) }, (_, i) => i + 1);
  const out = new Set<number>();
  for (const part of spec.split(",")) {
    const m = /^\s*p?\.?\s*(\d+)\s*(?:(-|–)\s*(\d+)?)?\s*$/.exec(part);
    if (!m) continue;
    const a = Number(m[1]);
    const b = m[2] ? (m[3] ? Number(m[3]) : numPages) : a;
    for (let p = Math.max(1, Math.min(a, b)); p <= Math.min(numPages, Math.max(a, b)) && out.size < READ_MAX_PAGES * 4; p++) out.add(p);
  }
  return [...out].sort((x, y) => x - y);
}

export interface ReadPage {
  text: string;
  /** Pages/parts actually included. */
  included: string;
  /** Arguments for the next read, when more remains. */
  next?: Record<string, string>;
}

/** Fit PDF pages into one read, stopping at the char budget; `next` resumes at the first page left out. */
export function paginatePages(pages: { page: number; text: string }[], requestedLast: number, max = READ_MAX_CHARS): ReadPage {
  const parts: string[] = [];
  let used = 0;
  let last = 0;
  for (const p of pages) {
    const body = p.text.trim() || "(no text on this page — it is attached as an image when available)";
    const block = `--- p.${p.page} ---\n${body}`;
    if (parts.length && used + block.length > max) break;
    parts.push(block.length > max ? `${block.slice(0, max)}\n…[page clipped]` : block);
    used += Math.min(block.length, max);
    last = p.page;
  }
  const first = pages[0]?.page ?? 0;
  const remaining = pages.filter((p) => p.page > last);
  const next = remaining.length
    ? { pages: `${remaining[0].page}-${requestedLast}` }
    : undefined;
  return { text: parts.join("\n\n"), included: last ? (first === last ? `p.${first}` : `p.${first}-${last}`) : "", next };
}

/** Transcript chunks between from/to seconds, within the budget; `next` resumes after the last one. */
export function paginateTranscript(chunks: Pick<Chunk, "text" | "t0" | "t1">[], from = 0, to = Infinity, max = READ_MAX_CHARS): ReadPage {
  const inRange = chunks
    .filter((c) => typeof c.t0 === "number" && (c.t1 ?? c.t0!) > from && c.t0! < to)
    .sort((a, b) => a.t0! - b.t0!);
  const parts: string[] = [];
  let used = 0;
  let lastEnd = from;
  let n = 0;
  for (const c of inRange) {
    const block = `[${clock(c.t0!)}–${clock(c.t1 ?? c.t0!)}] ${c.text.trim()}`;
    if (parts.length && used + block.length > max) break;
    parts.push(block.slice(0, max));
    used += Math.min(block.length, max);
    lastEnd = c.t1 ?? c.t0!;
    n++;
  }
  const more = n < inRange.length;
  return {
    text: parts.join("\n"),
    included: n ? `${clock(inRange[0].t0!)}–${clock(lastEnd)}` : "",
    next: more ? { from: clock(lastEnd), ...(isFinite(to) ? { to: clock(to) } : {}) } : undefined,
  };
}

/** A character range of a text file, within the budget; `next` resumes at the following offset. */
export function paginateText(text: string, from = 0, to = Infinity, max = READ_MAX_CHARS): ReadPage {
  const start = Math.max(0, Math.min(text.length, Math.floor(from)));
  const stop = Math.min(text.length, isFinite(to) ? Math.floor(to) : text.length);
  let end = Math.min(stop, start + max);
  // Prefer to cut on a paragraph or line break near the budget.
  if (end < stop) {
    const nl = text.lastIndexOf("\n", end);
    if (nl > start + max * 0.6) end = nl + 1;
  }
  return {
    text: text.slice(start, end),
    included: `chars ${start}-${end} of ${text.length}`,
    next: end < stop ? { from: String(end), ...(isFinite(to) ? { to: String(stop) } : {}) } : undefined,
  };
}

export function nextCursor(fileId: string, next?: Record<string, string>) {
  return next ? JSON.stringify({ type: "read", kind: "file", id: fileId, ...next }) : "";
}

// ---- indexing -----------------------------------------------------------------------------

type ChunkRow = Omit<Chunk, "id" | "projectId" | "sourceId">;

async function replaceChunks(projectId: string, sourceId: string, rows: ChunkRow[]) {
  await db.transaction("rw", db.chunks, async () => {
    await db.chunks.where("sourceId").equals(sourceId).delete();
    if (rows.length) await db.chunks.bulkAdd(rows.map((r) => ({ ...r, id: uid(), projectId, sourceId })));
  });
  invalidateIndex(projectId);
}

/** Leo's notes are labelled so it can tell them from the learner's materials. */
export const noteSourceName = (note: Pick<Note, "title" | "author">) =>
  `note “${note.title || "Untitled"}”${note.author === "ai" ? " (Leo's note)" : ""}`;

export async function indexNote(note: Note) {
  const rows = chunkText(note.content).map((text) => ({
    sourceKind: "note" as const,
    sourceName: noteSourceName(note),
    page: 0,
    text,
    ...(note.author === "ai" ? { author: "ai" as const } : {}),
  }));
  await replaceChunks(note.projectId, note.id, rows);
}

export async function removeChunks(sourceId: string) {
  await db.chunks.where("sourceId").equals(sourceId).delete();
  invalidateIndex();
}

let indexing = false;
const queue: string[] = [];

/** Extract text (PDF pages, text files, media transcripts) and store chunks, one file at a time. */
export function queueIndex(fileId: string) {
  if (!queue.includes(fileId)) queue.push(fileId);
  if (!indexing) void drain();
}

async function drain() {
  indexing = true;
  try {
    while (queue.length) {
      const id = queue.shift()!;
      const file = await db.files.get(id);
      if (!file) continue;
      try {
        await indexFile(file);
      } catch (e) {
        console.warn("index failed", file.name, e);
        await db.files.update(id, { indexed: "failed", indexNote: e instanceof Error ? e.message.slice(0, 200) : String(e) });
      }
    }
  } finally {
    indexing = false;
  }
}

async function indexFile(file: LibFile) {
  if (file.kind === "text") {
    const text = await file.blob.text();
    const rows = chunkText(text).map((t) => ({ sourceKind: "file" as const, sourceName: file.name, page: 0, text: t }));
    await replaceChunks(file.projectId, file.id, rows);
    await db.files.update(file.id, { indexed: rows.length ? "done" : "none" });
    return;
  }
  if (file.kind === "audio" || file.kind === "video") {
    const { transcribeBlob, transcriptionConfigured } = await import("./transcribe");
    if (!transcriptionConfigured()) {
      await db.files.update(file.id, { indexed: "none", indexNote: "not transcribed (Settings → Transcription is off)" });
      return;
    }
    const segs = await transcribeBlob(file.blob);
    const rows: ChunkRow[] = segs.map((s) => ({ sourceKind: "file", sourceName: file.name, page: 0, text: s.text, t0: s.t0, t1: s.t1 }));
    await replaceChunks(file.projectId, file.id, rows);
    await db.files.update(file.id, { indexed: rows.length ? "done" : "none", indexNote: rows.length ? undefined : "no speech found" });
    return;
  }
  if (file.kind !== "pdf") {
    await db.files.update(file.id, { indexed: "none" });
    return;
  }
  const { openPdf, closePdf, isPdfReaderActive, waitForReaderIdle } = await import("./media");
  await waitForReaderIdle();
  let doc = await openPdf(file.blob);
  const numPages = doc.numPages;
  const rows: ChunkRow[] = [];
  const visualPages: number[] = [];
  try {
    for (let p = 1; p <= numPages; p++) {
      if (isPdfReaderActive()) {
        // Someone opened the reader: release this copy, wait, then continue where we left off.
        closePdf(doc);
        await waitForReaderIdle();
        doc = await openPdf(file.blob);
      }
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const text = tc.items
        .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
        .join("")
        .trim();
      page.cleanup();
      if (text.replace(/\s+/g, "").length < 20) visualPages.push(p);
      for (const t of chunkText(text)) rows.push({ sourceKind: "file", sourceName: file.name, page: p, text: t });
      if (rows.length > 20000) break; // hard cap: ~18 MB of text
    }
  } finally {
    closePdf(doc);
  }
  await replaceChunks(file.projectId, file.id, rows);
  await db.files.update(file.id, {
    indexed: rows.length ? "done" : visualPages.length ? "none" : "none",
    pages: numPages,
    visualPages: visualPages.length ? visualPages.slice(0, 2000) : undefined,
  });
}

/** Re-index anything left pending (e.g. after the v2 migration or an interrupted session). */
export async function resumeIndexing() {
  const pending = await db.files.where("projectId").notEqual("").filter((f) => f.indexed === "pending").primaryKeys();
  for (const id of pending) queueIndex(id as string);
}
