import { db, type Provider } from "./db";
import { useSettings } from "./settings";

/** One span of speech with its start/end in seconds from the start of the file. */
export interface Segment {
  t0: number;
  t1: number;
  text: string;
}

export const TRANSCRIBE_SAMPLE_RATE = 16000;
export const TRANSCRIBE_CHUNK_SECONDS = 600;
const GROUP_CHARS = 900;

export const transcriptionConfigured = () => !!useSettings.getState().transcriptionProviderId;

/** Merge short segments into ~900-char, non-overlapping chunks that keep their time span. */
export function groupSegments(segs: Segment[], max = GROUP_CHARS): Segment[] {
  const out: Segment[] = [];
  let cur: Segment | null = null;
  for (const s of segs) {
    const text = s.text.trim();
    if (!text) continue;
    if (cur && cur.text.length + text.length + 1 <= max) {
      cur.text += " " + text;
      cur.t1 = Math.max(cur.t1, s.t1);
    } else {
      if (cur) out.push(cur);
      cur = { t0: s.t0, t1: s.t1, text };
    }
  }
  if (cur) out.push(cur);
  return out;
}

/** "[01:05] words…" lines (Gemini's transcript format) → segments, offset by the clip start. */
export function parseTimestampedLines(text: string, offset: number, clipEnd: number): Segment[] {
  const rows: { t: number; text: string }[] = [];
  for (const line of text.split("\n")) {
    const m = /^\s*\[?\(?(\d{1,2}):(\d{2})(?::(\d{2}))?\]?\)?\s*[-–:]?\s*(.*)$/.exec(line);
    if (m) {
      const t = m[3] !== undefined ? Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) : Number(m[1]) * 60 + Number(m[2]);
      rows.push({ t, text: m[4] });
    } else if (line.trim() && rows.length) rows[rows.length - 1].text += " " + line.trim();
    else if (line.trim()) rows.push({ t: 0, text: line.trim() });
  }
  return rows.map((r, i) => ({ t0: offset + r.t, t1: i + 1 < rows.length ? offset + rows[i + 1].t : clipEnd, text: r.text }));
}

/** Plain text with no timing → evenly spread segments across the clip. */
export function spreadText(text: string, offset: number, duration: number): Segment[] {
  const sentences = text.split(/(?<=[.!?])\s+/).filter((s) => s.trim());
  const total = sentences.reduce((n, s) => n + s.length, 0) || 1;
  let t = offset;
  return sentences.map((s) => {
    const d = (s.length / total) * duration;
    const seg = { t0: t, t1: t + d, text: s };
    t += d;
    return seg;
  });
}

/** Decode any audio (or a video's audio track), resampled to 16 kHz mono, in 10-minute pieces. */
async function* decodeChunks(blob: Blob): AsyncGenerator<{ samples: Float32Array; offset: number; duration: number }> {
  const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  let buf: AudioBuffer;
  try {
    buf = await ctx.decodeAudioData(await blob.arrayBuffer());
  } catch {
    throw new Error("the audio track could not be decoded in this browser");
  } finally {
    ctx.close().catch(() => {});
  }
  for (let offset = 0; offset < buf.duration; offset += TRANSCRIBE_CHUNK_SECONDS) {
    const duration = Math.min(TRANSCRIBE_CHUNK_SECONDS, buf.duration - offset);
    if (duration < 0.5) break;
    const off = new OfflineAudioContext(1, Math.ceil(duration * TRANSCRIBE_SAMPLE_RATE), TRANSCRIBE_SAMPLE_RATE);
    const src = off.createBufferSource();
    src.buffer = buf;
    src.connect(off.destination);
    src.start(0, offset, duration);
    const rendered = await off.startRendering();
    yield { samples: rendered.getChannelData(0), offset, duration };
  }
}

const trimSlash = (s: string) => s.replace(/\/+$/, "");

async function transcribeOpenAI(p: Provider, model: string, wav: Blob, offset: number, duration: number): Promise<Segment[]> {
  const send = async (format: "verbose_json" | "json") => {
    const fd = new FormData();
    fd.append("file", wav, "audio.wav");
    fd.append("model", model || "whisper-1");
    fd.append("response_format", format);
    const headers: Record<string, string> = {};
    if (p.apiKey) headers.authorization = `Bearer ${p.apiKey}`;
    return fetch(`${trimSlash(p.baseUrl)}/audio/transcriptions`, { method: "POST", headers, body: fd });
  };
  let res = await send("verbose_json");
  // Some models (gpt-4o-transcribe) only return plain json.
  if (res.status === 400) res = await send("json");
  if (!res.ok) throw new Error(`transcription failed: ${res.status} ${(await res.text()).slice(0, 200)}`);
  const j = (await res.json()) as { text?: string; segments?: { start: number; end: number; text: string }[] };
  if (j.segments?.length) return j.segments.map((s) => ({ t0: offset + s.start, t1: offset + s.end, text: s.text }));
  return spreadText(j.text ?? "", offset, duration);
}

async function transcribeGemini(p: Provider, model: string, wav: Blob, offset: number, duration: number): Promise<Segment[]> {
  const { blobToDataUrl } = await import("./media");
  const data = (await blobToDataUrl(wav)).split(",").pop();
  const base = trimSlash(p.baseUrl || "https://generativelanguage.googleapis.com");
  const res = await fetch(`${base}/v1beta/models/${encodeURIComponent(model || p.defaultModel || "gemini-2.5-flash")}:generateContent`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-goog-api-key": p.apiKey },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [
            { inline_data: { mime_type: "audio/wav", data } },
            { text: "Transcribe this audio verbatim. Output only lines in the form [mm:ss] text, with timestamps measured from the start of this clip, starting a new line at least every 30 seconds. No commentary." },
          ],
        },
      ],
    }),
  });
  if (!res.ok) throw new Error(`transcription failed: ${res.status} ${(await res.text()).slice(0, 200)}`);
  const j = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
  const text = (j.candidates?.[0]?.content?.parts ?? []).map((x) => x.text ?? "").join("");
  return parseTimestampedLines(text, offset, offset + duration);
}

/** Transcribe a blob with the provider chosen in Settings → Transcription. */
export async function transcribeBlob(blob: Blob): Promise<Segment[]> {
  const { transcriptionProviderId, transcriptionModel } = useSettings.getState();
  const p = await db.providers.get(transcriptionProviderId);
  if (!p) throw new Error("the transcription provider was removed (Settings → Transcription)");
  if (p.type === "anthropic") throw new Error("Anthropic has no transcription API — pick an OpenAI-compatible or Gemini provider");
  const { encodeWav } = await import("./media");
  const all: Segment[] = [];
  for await (const c of decodeChunks(blob)) {
    const wav = encodeWav(c.samples, TRANSCRIBE_SAMPLE_RATE);
    const segs = p.type === "gemini" ? await transcribeGemini(p, transcriptionModel, wav, c.offset, c.duration) : await transcribeOpenAI(p, transcriptionModel, wav, c.offset, c.duration);
    all.push(...segs);
  }
  return groupSegments(all);
}
