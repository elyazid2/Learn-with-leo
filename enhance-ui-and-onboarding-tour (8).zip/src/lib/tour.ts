import { create } from "zustand";

/**
 * Leo's first-run tour.
 *
 * Two short chapters, so every step can point at something that is really on screen:
 *   "home"    — projects, and the model Leo thinks with
 *   "project" — the library, the chat and the knowledge map (plays the first time a project opens)
 *
 * Only what has been seen is persisted; the running state lives in memory.
 */
export type TourChapter = "home" | "project";

/** "interrupted" closes the tour without recording it, so it can start again later. */
export type TourEnd = "done" | "skipped" | "interrupted";

export interface TourSeen {
  home: boolean;
  project: boolean;
}

const KEY = "harness.tour";

function readSeen(): TourSeen {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "{}") as Partial<TourSeen>;
    return { home: raw.home === true, project: raw.project === true };
  } catch {
    return { home: false, project: false };
  }
}

function writeSeen(seen: TourSeen) {
  try {
    localStorage.setItem(KEY, JSON.stringify(seen));
  } catch {
    /* storage unavailable (private mode): the tour simply offers itself again next time */
  }
}

interface TourStore {
  seen: TourSeen;
  chapter: TourChapter | null;
  step: number;
  /** Set by "Take the tour" buttons; the tour starts as soon as the home screen is showing. */
  replayRequested: boolean;
  /** A new project whose placement chat is held back until Leo has shown the room. */
  deferredPlacement: string | null;
  /** Bumped when the tour asks the home screen to open the New project sheet. */
  createRequest: number;
  start: (chapter: TourChapter) => void;
  setStep: (step: number) => void;
  end: (reason: TourEnd) => void;
  markSeen: (patch: Partial<TourSeen>) => void;
  replay: () => void;
  deferPlacement: (projectId: string | null) => void;
  requestCreate: () => void;
}

export const useTour = create<TourStore>((set, get) => ({
  seen: readSeen(),
  chapter: null,
  step: 0,
  replayRequested: false,
  deferredPlacement: null,
  createRequest: 0,

  start: (chapter) => set({ chapter, step: 0, replayRequested: false }),
  setStep: (step) => set({ step: Math.max(0, step) }),
  end: (reason) => {
    const { chapter, seen } = get();
    if (!chapter) return;
    let next = seen;
    if (reason !== "interrupted") {
      // Skipping the first chapter means "no tour, thanks": the second one stays quiet too.
      next = chapter === "home" ? { home: true, project: reason === "skipped" ? true : seen.project } : { ...seen, project: true };
      writeSeen(next);
    }
    set({ chapter: null, step: 0, seen: next });
  },
  markSeen: (patch) => {
    const seen = { ...get().seen, ...patch };
    writeSeen(seen);
    set({ seen });
  },
  replay: () => {
    const seen = { ...get().seen, project: false };
    writeSeen(seen);
    set({ seen, replayRequested: true });
  },
  deferPlacement: (deferredPlacement) => set({ deferredPlacement }),
  requestCreate: () => set({ createRequest: get().createRequest + 1 }),
}));

/** True while the project chapter is still to come: a new project lets Leo show the room first. */
export function projectTourPending() {
  const { seen } = useTour.getState();
  return seen.home && !seen.project;
}
