/**
 * Data pdf.js needs beyond the PDF itself, bundled with the app so it works offline and from a
 * single file:
 *
 *  - CMaps: character maps for fonts that rely on Adobe's predefined encodings.
 *  - Standard font data: Symbol and ZapfDingbats (other standard fonts use the device's own fonts).
 *  - Image decoders (JBIG2, JPEG 2000) and colour management, which scanned books depend on.
 *
 * It also adds an Arabic fallback font to every canvas pdf.js draws text on. A PDF that does not
 * embed its Arabic font is drawn with whatever the device offers, which on many devices is nothing
 * or a mismatched face; Noto Naskh Arabic is used for those characters instead.
 */

const cmaps = import.meta.glob<string>("/node_modules/pdfjs-dist/cmaps/*.bcmap", { query: "?url", import: "default", exhaustive: true });
const fonts = import.meta.glob<string>("/node_modules/pdfjs-dist/standard_fonts/Foxit{Symbol,Dingbats}.pfb", { query: "?url", import: "default", exhaustive: true });
const wasm = import.meta.glob<string>("/node_modules/pdfjs-dist/wasm/{jbig2,openjpeg,qcms_bg}.wasm", { query: "?url", import: "default", exhaustive: true });

type Kind = "cMapUrl" | "standardFontDataUrl" | "wasmUrl";
const SOURCES: Record<Kind, Record<string, () => Promise<string>>> = { cMapUrl: cmaps, standardFontDataUrl: fonts, wasmUrl: wasm };

/** How many bundled files of each kind exist (used by tests and diagnostics). */
export const bundledCounts = () => ({ cmaps: Object.keys(cmaps).length, fonts: Object.keys(fonts).length, wasm: Object.keys(wasm).length });

async function bundled(kind: Kind, filename: string): Promise<Uint8Array> {
  const files = SOURCES[kind] ?? {};
  const key = Object.keys(files).find((k) => k.endsWith("/" + filename));
  if (!key) throw new Error(`"${filename}" is not bundled with the app`);
  const url = await files[key]();
  return new Uint8Array(await (await fetch(url)).arrayBuffer());
}

/** pdf.js `BinaryDataFactory`: answers its requests for CMaps, fonts and decoders from the bundle. */
export class BundledBinaryData {
  constructor(_options?: unknown) {
    /* pdf.js passes base URLs here; the bundle needs none */
  }

  fetch({ kind, filename }: { kind: Kind; filename: string }) {
    return bundled(kind, filename);
  }
}

export const ARABIC_FALLBACK = '"Noto Naskh Arabic"';
const GENERIC = /(,\s*)?\b(sans-serif|serif|monospace)\s*$/;

/** Put the Arabic fallback just ahead of the generic family at the end of a canvas font string. */
export function withArabicFallback(font: string) {
  if (font.includes(ARABIC_FALLBACK)) return font;
  if (!GENERIC.test(font)) return `${font}, ${ARABIC_FALLBACK}`;
  return font.replace(GENERIC, (_all, comma: string | undefined, generic: string) => `${comma ? ", " : ""}${ARABIC_FALLBACK}, ${generic}`);
}

const patched = new WeakSet<object>();

/** Make one canvas context add the Arabic fallback to every font it is given. */
export function arabicFallback<T extends CanvasRenderingContext2D>(ctx: T): T {
  if (patched.has(ctx)) return ctx;
  const desc = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(ctx), "font");
  const get = desc?.get;
  const set = desc?.set;
  if (!get || !set) return ctx;
  Object.defineProperty(ctx, "font", {
    configurable: true,
    enumerable: true,
    get() {
      return get.call(this);
    },
    set(value: string) {
      set.call(this, withArabicFallback(String(value)));
    },
  });
  patched.add(ctx);
  return ctx;
}

interface CanvasFactoryLike {
  create?: (width: number, height: number) => { context: CanvasRenderingContext2D | null };
  getNoAlphaContext?: (canvas: HTMLCanvasElement) => CanvasRenderingContext2D | null;
}

/**
 * pdf.js makes its canvases (the page itself, and scratch canvases for groups, masks and patterns)
 * through a factory. Its own factory is kept, so every behaviour pdf.js expects is there; the
 * contexts it hands out simply get the Arabic fallback as well.
 */
export function addFallbackToFactory(factory: unknown) {
  const f = factory as CanvasFactoryLike | null | undefined;
  if (!f || patched.has(f)) return;
  patched.add(f);
  if (typeof f.create === "function") {
    const create = f.create.bind(f);
    f.create = (width, height) => {
      const made = create(width, height);
      if (made.context) arabicFallback(made.context);
      return made;
    };
  }
  if (typeof f.getNoAlphaContext === "function") {
    const get = f.getNoAlphaContext.bind(f);
    f.getNoAlphaContext = (canvas) => {
      const context = get(canvas);
      return context ? arabicFallback(context) : context;
    };
  }
}

/** Canvas text never waits for a web font, so the fallback is loaded before the first page is drawn. */
export function loadPdfFallbackFonts(): Promise<void> {
  if (typeof document === "undefined" || !document.fonts) return Promise.resolve();
  const sample = "\u0628\u0633\u0645";
  return Promise.all([document.fonts.load(`400 16px ${ARABIC_FALLBACK}`, sample), document.fonts.load(`700 16px ${ARABIC_FALLBACK}`, sample)]).then(
    () => undefined,
    () => undefined
  );
}
