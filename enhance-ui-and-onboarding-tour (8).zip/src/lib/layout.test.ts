import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  const data = new Map<string, string>();
  (globalThis as { localStorage?: unknown }).localStorage = {
    getItem: (k: string) => data.get(k) ?? null,
    setItem: (k: string, v: string) => void data.set(k, String(v)),
    removeItem: (k: string) => void data.delete(k),
    clear: () => data.clear(),
  };
});

import { ARRANGEMENTS, dockOf, effectiveDock, routeTarget, sameTarget, targetPath, useLayout, type PaneTarget } from "./layout";
import { useApp } from "./store";

const P = "proj";
const pdf: PaneTarget = { kind: "file", id: "f1" };
const library: PaneTarget = { kind: "library" };
const arrangement = (id: string) => ARRANGEMENTS.find((a) => a.id === id)!;

beforeEach(() => {
  useLayout.setState({ chatDock: "float", tempDock: null, splitDir: "row", ratio: 0.5, side: null, sideProject: null, lastSide: null, focus: null, swapped: false });
  useApp.setState({ chatOpen: false });
});

describe("layout: what a route shows", () => {
  it("maps routes to pane targets and back", () => {
    expect(routeTarget({ name: "project", projectId: P, tab: "library" })).toEqual(library);
    expect(routeTarget({ name: "project", projectId: P, tab: "progress" })).toEqual(library);
    expect(routeTarget({ name: "project", projectId: P, tab: "library", itemId: "f1" })).toEqual(pdf);
    expect(routeTarget({ name: "project", projectId: P, tab: "notes", itemId: "n1" })).toEqual({ kind: "note", id: "n1" });
    expect(routeTarget({ name: "project", projectId: P, tab: "sketch", itemId: "s1" })).toEqual({ kind: "sketch", id: "s1" });
    expect(targetPath(P, { kind: "note", id: "n1" })).toBe("p/proj/notes/n1");
    expect(targetPath(P, pdf)).toBe("p/proj/library/f1");
    expect(targetPath(P, library)).toBe("p/proj/library");
  });

  it("compares targets by kind and id", () => {
    expect(sameTarget(pdf, { kind: "file", id: "f1" })).toBe(true);
    expect(sameTarget(pdf, { kind: "file", id: "f2" })).toBe(false);
    expect(sameTarget(pdf, { kind: "note", id: "f1" })).toBe(false);
    expect(sameTarget(library, null)).toBe(false);
  });
});

describe("layout: arrangements", () => {
  it("offers every combination of panes and chat placement, plus fullscreen for each", () => {
    expect(ARRANGEMENTS).toHaveLength(15);
    expect(new Set(ARRANGEMENTS.map((a) => a.id)).size).toBe(15);
  });

  it("a split opens a second pane: the library beside a document, the browser beside the library", () => {
    useLayout.getState().apply(P, arrangement("two-right"), pdf);
    expect(useLayout.getState()).toMatchObject({ side: library, sideProject: P, splitDir: "row", chatDock: "right" });
    expect(useApp.getState().chatOpen).toBe(true);

    useLayout.getState().apply(P, arrangement("one"), pdf);
    expect(useLayout.getState()).toMatchObject({ side: null, chatDock: "float" });

    useLayout.setState({ lastSide: null });
    useLayout.getState().apply(P, arrangement("stack"), library);
    expect(useLayout.getState()).toMatchObject({ side: { kind: "browser" }, splitDir: "column" });
  });

  it("re-opens the pane that was there before", () => {
    useLayout.getState().openSide(P, { kind: "note", id: "n1" });
    useLayout.getState().apply(P, arrangement("one"), pdf);
    useLayout.getState().apply(P, arrangement("two"), pdf);
    expect(useLayout.getState().side).toEqual({ kind: "note", id: "n1" });
  });

  it("fullscreen keeps the arrangement underneath", () => {
    useLayout.getState().apply(P, arrangement("two-left"), pdf);
    useLayout.getState().apply(P, arrangement("full-main"), pdf);
    expect(useLayout.getState()).toMatchObject({ focus: "main", chatDock: "left", side: library });
    useLayout.getState().setFocus(null);
    expect(useLayout.getState().side).toEqual(library);
  });

  it("fullscreen for the second pane opens one if there is none", () => {
    useLayout.getState().apply(P, arrangement("full-side"), pdf);
    expect(useLayout.getState()).toMatchObject({ focus: "side", side: library });
  });

  it("closing the second pane leaves its fullscreen", () => {
    useLayout.getState().apply(P, arrangement("full-side"), pdf);
    useLayout.getState().closeSide();
    expect(useLayout.getState()).toMatchObject({ focus: null, side: null });
  });
});

describe("layout: where the chat sits", () => {
  it("a placement Leo chose for now does not change the saved one", () => {
    useLayout.getState().setTempDock("right");
    expect(dockOf(useLayout.getState())).toBe("right");
    expect(useLayout.getState().chatDock).toBe("float");
    expect(JSON.parse(localStorage.getItem("harness.layout")!).chatDock).toBe("float");
  });

  it("choosing a position ends the temporary one", () => {
    useLayout.getState().setTempDock("right");
    useLayout.getState().setChatDock("bottom");
    expect(useLayout.getState()).toMatchObject({ chatDock: "bottom", tempDock: null });
  });

  it("on phones a side dock goes below", () => {
    expect(effectiveDock("left", true)).toBe("bottom");
    expect(effectiveDock("right", true)).toBe("bottom");
    expect(effectiveDock("right", false)).toBe("right");
    expect(effectiveDock("float", true)).toBe("float");
  });
});
