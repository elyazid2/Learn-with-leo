import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db, type Project } from "./db";
import { createProjectFolder, deleteProjectFolder, homeFolderOf, moveProject, renameProjectFolder } from "./projectFolders";
const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const project = (id: string): Project => ({ id, name: id, tag: "", color: "ink", placement: { status: "pending" }, createdAt: 1, updatedAt: 7 });
beforeEach(() => fake.reset());

describe("home project folders", () => {
  it("creates and renames a single-level container", async () => {
    const f = await createProjectFolder("  Languages  ");
    expect(f.name).toBe("Languages");
    expect(f).not.toHaveProperty("parentId");
    await renameProjectFolder(f.id, "This semester");
    expect((await db.projectFolders.get(f.id))?.name).toBe("This semester");
  });
  it("rejects empty and duplicate names, ignoring case", async () => {
    await expect(createProjectFolder("   ")).rejects.toThrow(/name/);
    const f = await createProjectFolder("Languages");
    await expect(createProjectFolder(" languages ")).rejects.toThrow(/already exists/);
    await renameProjectFolder(f.id, "LANGUAGES");
    const second = await createProjectFolder("Other");
    await expect(renameProjectFolder(second.id, "languages")).rejects.toThrow(/already exists/);
  });
  it("moves projects in and out without changing recent learning order", async () => {
    await db.projects.add(project("one"));
    const f = await createProjectFolder("Languages");
    await moveProject("one", f.id);
    expect(await db.projects.get("one")).toMatchObject({ folderId: f.id, updatedAt: 7 });
    await moveProject("one", null);
    expect((await db.projects.get("one"))?.folderId).toBeUndefined();
  });
  it("deleting a folder returns every project to home without deleting any contents", async () => {
    const f = await createProjectFolder("Languages");
    await db.projects.bulkAdd([{ ...project("one"), folderId: f.id }, { ...project("two"), folderId: f.id }, project("three")]);
    await db.notes.add({ id: "n", projectId: "one", title: "Keep me", content: "text", createdAt: 1, updatedAt: 1 });
    expect(await deleteProjectFolder(f.id)).toBe(2);
    expect(await db.projects.count()).toBe(3);
    expect((await db.projects.toArray()).every((p) => !p.folderId)).toBe(true);
    expect((await db.notes.get("n"))?.content).toBe("text");
    expect(await db.projectFolders.get(f.id)).toBeUndefined();
  });
  it("cannot move into a missing folder or move a missing project", async () => {
    await db.projects.add(project("one"));
    await expect(moveProject("one", "missing")).rejects.toThrow(/folder no longer exists/);
    await expect(moveProject("gone", null)).rejects.toThrow(/project no longer exists/);
  });
  it("shows orphaned projects at home rather than hiding them", () => {
    expect(homeFolderOf({ folderId: "gone" }, [])).toBeNull();
    expect(homeFolderOf({ folderId: "f" }, [{ id: "f" }])).toBe("f");
    expect(homeFolderOf({}, [{ id: "f" }])).toBeNull();
  });
});