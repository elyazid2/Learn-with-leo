import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db, type LibFile, type Note, type Project, type Sketch } from "./db";
import { copyLibraryItems } from "./libraryCopies";
const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const project = (id: string): Project => ({ id, name: id, tag: "", color: "ink", placement: { status: "pending" }, createdAt: 1, updatedAt: 1 });
const file = (id: string, extra: Partial<LibFile> = {}): LibFile => ({ id, projectId: "source", name: id, kind: "pdf", mime: "application/pdf", blob: new Blob(["PDF bytes"], { type: "application/pdf" }), size: 9, createdAt: 1, indexed: "done", ...extra });
beforeEach(async () => { fake.reset(); await db.projects.bulkAdd([project("source"), project("target")]); });

describe("independent library copies", () => {
  it("copies file bytes, PDF text and annotations under independent IDs", async () => {
    await db.files.add(file("f"));
    await db.chunks.add({ id: "chunk", projectId: "source", sourceId: "f", sourceKind: "file", sourceName: "f", page: 3, text: "A cell has a membrane." });
    await db.pdfAnnotations.add({ id: "mark", projectId: "source", fileId: "f", page: 3, kind: "note", text: "Study this", createdAt: 1, updatedAt: 1 });
    const result = await copyLibraryItems("target", [{ kind: "file", id: "f", projectId: "source" }]);
    const id = result.items[0].id;
    expect(id).not.toBe("f");
    expect(await db.files.get(id)).toMatchObject({ projectId: "target", indexed: "done", mime: "application/pdf" });
    expect(await (await db.files.get(id))!.blob.text()).toBe("PDF bytes");
    expect((await db.chunks.where("sourceId").equals(id).toArray())[0]).toMatchObject({ projectId: "target", page: 3, text: "A cell has a membrane." });
    const annotation = (await db.pdfAnnotations.where("fileId").equals(id).toArray())[0];
    expect(annotation.id).not.toBe("mark");
    expect(annotation).toMatchObject({ projectId: "target", text: "Study this" });
    await db.files.delete("f");
    await db.chunks.where("sourceId").equals("f").delete();
    await db.pdfAnnotations.where("fileId").equals("f").delete();
    expect(await db.files.get(id)).toBeDefined();
    expect(await db.chunks.where("sourceId").equals(id).count()).toBe(1);
    expect(await db.pdfAnnotations.where("fileId").equals(id).count()).toBe(1);
  });
  it("preserves timed video/audio transcripts without transcribing again", async () => {
    await db.files.add(file("v", { kind: "video", source: "youtube", youtubeId: "abcDEF12345", transcript: [{ t0: 12, t1: 20, text: "Cells divide." }], transcriptSource: "captions", transcriptState: "done" }));
    const { items } = await copyLibraryItems("target", [{ kind: "file", id: "v", projectId: "source" }]);
    const copied = await db.files.get(items[0].id);
    expect(copied?.transcript).toEqual([{ t0: 12, t1: 20, text: "Cells divide." }]);
    expect(copied?.transcriptState).toBe("done");
    expect((await db.chunks.where("sourceId").equals(items[0].id).toArray())[0]).toMatchObject({ t0: 12, t1: 20, text: "Cells divide." });
    copied!.transcript![0].text = "Changed copy";
    expect((await db.files.get("v"))?.transcript?.[0].text).toBe("Cells divide.");
  });
  it("copies notes and sketches, rewrites selected file links and keeps source copies independent", async () => {
    await db.files.add(file("f"));
    const note: Note = { id: "n", projectId: "source", title: "Cells", content: "See [page](#/p/source/library/f).", author: "user", folder: "Biology", sources: [{ fileId: "f", page: 2 }], createdAt: 1, updatedAt: 1 };
    const sketch: Sketch = { id: "s", projectId: "source", title: "Cell", scene: '{"elements":[]}', createdAt: 1, updatedAt: 1 };
    await db.notes.add(note); await db.sketches.add(sketch);
    const { items, count } = await copyLibraryItems("target", [{ kind: "file", id: "f", projectId: "source" }, { kind: "note", id: "n", projectId: "source" }, { kind: "sketch", id: "s", projectId: "source" }]);
    expect(count).toBe(3);
    const f = items.find((i) => i.kind === "file")!;
    const n = await db.notes.get(items.find((i) => i.kind === "note")!.id);
    expect(n?.content).toContain(`#/p/target/library/${f.id}`);
    expect(n?.sources).toEqual([{ fileId: f.id, page: 2 }]);
    expect((await db.notes.get("n"))?.content).toBe(note.content);
    expect(await db.chunks.where("sourceId").equals(n!.id).count()).toBeGreaterThan(0);
    expect((await db.sketches.get(items.find((i) => i.kind === "sketch")!.id))?.scene).toBe(sketch.scene);
    expect((await db.folders.where("projectId").equals("target").toArray())[0].path).toBe("Biology");
  });
  it("does not charge for or requeue interrupted source processing", async () => {
    await db.files.add(file("pending", { indexed: "pending", transcriptState: "fetching" }));
    const { items } = await copyLibraryItems("target", [{ kind: "file", id: "pending", projectId: "source" }]);
    expect(await db.files.get(items[0].id)).toMatchObject({ indexed: "none", transcriptState: "unavailable" });
  });
  it("deduplicates a selection, rejects the current project, and validates before writing", async () => {
    await db.files.add(file("f"));
    const choice = { kind: "file" as const, id: "f", projectId: "source" };
    expect((await copyLibraryItems("target", [choice, choice])).count).toBe(1);
    const before = await db.files.count();
    await expect(copyLibraryItems("target", [choice, { ...choice, id: "missing" }])).rejects.toThrow(/removed/);
    expect(await db.files.count()).toBe(before);
    await expect(copyLibraryItems("source", [choice])).rejects.toThrow(/another project/);
    expect(await copyLibraryItems("target", [])).toEqual({ count: 0, items: [] });
  });
});