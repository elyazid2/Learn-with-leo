import { describe, expect, it } from "vitest";
import { ARABIC_FALLBACK, bundledCounts, withArabicFallback } from "./pdfAssets";

describe("PDF rendering: bundled data", () => {
  it("bundles every CMap, the Symbol and Dingbats font data, and the image decoders", () => {
    // A build that silently drops these would bring back blank or wrong text in some PDFs.
    expect(bundledCounts()).toEqual({ cmaps: 168, fonts: 2, wasm: 3 });
  });
});

describe("PDF rendering: Arabic fallback font", () => {
  it("goes just ahead of the generic family", () => {
    expect(withArabicFallback('normal normal 16px "g_d0_f1", sans-serif')).toBe(`normal normal 16px "g_d0_f1", ${ARABIC_FALLBACK}, sans-serif`);
    expect(withArabicFallback('italic bold 12px "Arial",g_d0_s2,serif')).toBe(`italic bold 12px "Arial",g_d0_s2, ${ARABIC_FALLBACK}, serif`);
    expect(withArabicFallback("10px monospace")).toBe(`10px ${ARABIC_FALLBACK}, monospace`);
  });

  it("is appended when the font list has no generic family", () => {
    expect(withArabicFallback('16px "TraditionalArabic",g_d0_s3')).toBe(`16px "TraditionalArabic",g_d0_s3, ${ARABIC_FALLBACK}`);
    expect(withArabicFallback('16px "PT Serif"')).toBe(`16px "PT Serif", ${ARABIC_FALLBACK}`);
  });

  it("is never added twice", () => {
    const once = withArabicFallback('16px "x", sans-serif');
    expect(withArabicFallback(once)).toBe(once);
  });
});
