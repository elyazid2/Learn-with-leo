import { db, uid, type Project, type ProjectFolder } from "./db";

const nameKey = (name: string) => name.trim().toLocaleLowerCase();

async function checkedName(name: string, exceptId?: string) {
  const clean = name.trim().slice(0, 80);
  if (!clean) throw new Error("Give the folder a name.");
  const all = await db.projectFolders.toArray();
  if (all.some((f) => f.id !== exceptId && nameKey(f.name) === nameKey(clean))) throw new Error("A folder with that name already exists.");
  return clean;
}

export async function createProjectFolder(name: string): Promise<ProjectFolder> {
  return db.transaction("rw", db.projectFolders, async () => {
    const clean = await checkedName(name);
    const now = Date.now();
    const folder: ProjectFolder = { id: uid(), name: clean, createdAt: now, updatedAt: now };
    await db.projectFolders.add(folder);
    return folder;
  });
}

export async function renameProjectFolder(id: string, name: string) {
  await db.transaction("rw", db.projectFolders, async () => {
    if (!(await db.projectFolders.get(id))) throw new Error("This folder no longer exists.");
    await db.projectFolders.update(id, { name: await checkedName(name, id), updatedAt: Date.now() });
  });
}

export async function moveProject(projectId: string, folderId: string | null) {
  await db.transaction("rw", [db.projects, db.projectFolders], async () => {
    if (!(await db.projects.get(projectId))) throw new Error("This project no longer exists.");
    if (folderId && !(await db.projectFolders.get(folderId))) throw new Error("This folder no longer exists.");
    // Organizing is not a study session: keep the project's recent-learning order unchanged.
    await db.projects.update(projectId, { folderId: folderId ?? undefined });
    if (folderId) await db.projectFolders.update(folderId, { updatedAt: Date.now() });
  });
}

/** Only the container is deleted. Projects are returned to home in the same transaction. */
export async function deleteProjectFolder(id: string): Promise<number> {
  return db.transaction("rw", [db.projects, db.projectFolders], async () => {
    const projects = await db.projects.where("folderId").equals(id).toArray();
    for (const project of projects) await db.projects.update(project.id, { folderId: undefined });
    await db.projectFolders.delete(id);
    return projects.length;
  });
}

/** A missing folder in an old/imported backup must not hide its projects. */
export function homeFolderOf(project: Pick<Project, "folderId">, folders: Pick<ProjectFolder, "id">[]): string | null {
  return project.folderId && folders.some((f) => f.id === project.folderId) ? project.folderId : null;
}