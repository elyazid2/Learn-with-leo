import { db, uid, type LibFile, type TranscriptSegment } from "./db";
import { blobToDataUrl } from "./media";
import { groupSegments, parseTimestampedLines, spreadText } from "./transcribe";

/**
 * YouTube links in the library.
 *
 * The video is an ordinary library item of kind "video": it has a title, channel and thumbnail,
 * plays in the app's clean player, and carries its transcript so Leo can teach and quiz from it.
 * There is no server behind Harness, so:
 *  - metadata and thumbnails come from YouTube's public oEmbed API (which allows other pages);
 *  - captions are tried from YouTube's caption endpoint, which normally refuses other pages — when
 *    that happens the video page explains it and offers two routes that do work: paste a transcript,
 *    or upload the video/audio file once so the configured transcription provider can listen to it.
 */

export interface YouTubeRef {
  id: string;
  /** Seconds to start at, from `t=` / `start=`. */
  start: number;
  /** Shorts are portrait. */
  vertical: boolean;
}

function seconds(value: string | null): number {
  if (!value) return 0;
  if (/^\d+$/.test(value)) return Number(value);
  const m = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/.exec(value);
  return m ? Number(m[1] ?? 0) * 3600 + Number(m[2] ?? 0) * 60 + Number(m[3] ?? 0) : 0;
}

/** The video a YouTube address points at (watch, youtu.be, shorts, live, embed and music links). */
export function youtubeRef(url: string): YouTubeRef | null {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  const host = u.hostname.toLowerCase().replace(/^(www|m|music)\./, "");
  let id: string | null = null;
  let vertical = false;
  if (host === "youtu.be") id = u.pathname.split("/").filter(Boolean)[0] ?? null;
  else if (host === "youtube.com" || host === "youtube-nocookie.com") {
    if (u.pathname === "/watch") id = u.searchParams.get("v");
    else {
      const m = /^\/(embed|shorts|live|v)\/([^/?#]+)/.exec(u.pathname);
      id = m?.[2] ?? null;
      vertical = m?.[1] === "shorts";
    }
  }
  if (!id || !/^[\w-]{6,20}$/.test(id)) return null;
  return { id, start: seconds(u.searchParams.get("t") ?? u.searchParams.get("start")), vertical };
}

export const watchUrl = (id: string) => `https://www.youtube.com/watch?v=${id}`;

/** "3:12" / "1:02:03" for a transcript timestamp. */
export const stamp = (s: number) => {
  const t = Math.max(0, Math.round(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = String(t % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
};

export interface YoutubeMeta {
  id: string;
  title: string;
  channel: string;
  /** A local copy of the poster when YouTube allows fetching it, otherwise its address. */
  thumb: string;
}

const withTimeout = (ms: number) => {
  const c = new AbortController();
  const timer = setTimeout(() => c.abort(), ms);
  return { signal: c.signal, done: () => clearTimeout(timer) };
};

/** YouTube's poster, used immediately so the preview never waits on an image download. */
export const remotePoster = (id: string) => `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;

/**
 * Keep a local copy of the poster so the library tile still looks right offline. Runs after the
 * item exists; a failure simply leaves the remote address in place.
 */
async function cachePoster(fileId: string, id: string) {
  const t = withTimeout(8000);
  try {
    const res = await fetch(remotePoster(id), { signal: t.signal, mode: "cors", cache: "force-cache" });
    if (!res.ok) return;
    const blob = await res.blob();
    if (blob.size > 500_000) return;
    const src = await blobToDataUrl(blob);
    if (src) await db.files.update(fileId, { thumb: src });
  } catch {
    /* remote thumbnail stays */
  } finally {
    t.done();
  }
}

/** Title, channel and poster for a video (oEmbed; no API key needed). Null when the video is gone. */
export async function fetchYoutubeMeta(ref: YouTubeRef | string): Promise<YoutubeMeta | null> {
  const v =
    typeof ref === "string"
      ? (youtubeRef(ref) ?? (/^[\w-]{6,20}$/.test(ref) ? { id: ref, start: 0, vertical: false } : null))
      : ref;
  if (!v) return null;
  const t = withTimeout(12000);
  try {
    const res = await fetch(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(watchUrl(v.id))}`, { signal: t.signal });
    if (!res.ok) return null;
    const j = (await res.json()) as { title?: unknown; author_name?: unknown };
    const title = String(j.title ?? "").trim().slice(0, 300);
    if (!title) return null;
    return { id: v.id, title, channel: String(j.author_name ?? "").trim().slice(0, 160), thumb: remotePoster(v.id) };
  } catch {
    return null;
  } finally {
    t.done();
  }
}

/* ------------------------------------------------------------------ captions */

const decodeEntities = (s: string) =>
  s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#(?:39|x27);/g, "'")
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCodePoint(Number(n)))
    .replace(/&nbsp;/g, " ");

/** Caption tracks come as JSON (fmt=json3) or as the older XML. Both become segments. */
export function parseCaptionPayload(body: string): TranscriptSegment[] {
  const text = body.trim();
  if (!text) return [];
  const out: TranscriptSegment[] = [];
  if (text.startsWith("{")) {
    let j: { events?: { tStartMs?: number; dDurationMs?: number; segs?: { utf8?: string }[] }[] };
    try {
      j = JSON.parse(text);
    } catch {
      return [];
    }
    for (const e of j.events ?? []) {
      const body = (e.segs ?? []).map((s) => s.utf8 ?? "").join("");
      const t0 = typeof e.tStartMs === "number" ? e.tStartMs / 1000 : NaN;
      if (!body.trim() || !isFinite(t0)) continue;
      const d = typeof e.dDurationMs === "number" ? e.dDurationMs / 1000 : 2.5;
      out.push({ t0, t1: t0 + Math.max(0.4, d), text: decodeEntities(body).replace(/\s+/g, " ").trim() });
    }
  } else {
    const re = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
    for (let m = re.exec(text); m; m = re.exec(text)) {
      const start = /\bstart="([\d.]+)"/.exec(m[1])?.[1];
      const dur = /\bdur="([\d.]+)"/.exec(m[1])?.[1];
      const t0 = Number(start);
      const d = dur ? Number(dur) : 2.5;
      const body = decodeEntities(m[2].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
      if (body && start && isFinite(t0)) out.push({ t0, t1: t0 + Math.max(0.4, isFinite(d) ? d : 2.5), text: body });
    }
  }
  return out;
}

/** Some common caption tracks: the browser can ask for any of these; most requests will be refused. */
const CAPTION_ATTEMPTS: { lang: string; kind?: string }[] = [
  { lang: "en" },
  { lang: "ar" },
  { lang: "en", kind: "asr" },
  { lang: "ar", kind: "asr" },
  { lang: "" },
];

/**
 * Ask YouTube for a caption track. YouTube usually refuses requests from other pages (CORS), and
 * sometimes answers with an empty body; both are reported as "no captions", never as a crash.
 */
export async function fetchYoutubeCaptions(id: string): Promise<TranscriptSegment[] | null> {
  for (const { lang, kind } of CAPTION_ATTEMPTS) {
    const q = new URLSearchParams({ v: id, fmt: "json3", ...(lang ? { lang } : {}), ...(kind ? { kind } : {}) });
    const t = withTimeout(9000);
    try {
      const res = await fetch(`https://www.youtube.com/api/timedtext?${q.toString()}`, { signal: t.signal, mode: "cors", credentials: "omit" });
      if (!res.ok) continue;
      const segs = parseCaptionPayload(await res.text());
      if (segs.length) return segs.slice(0, 4000);
    } catch {
      /* refused or offline: try the next track, then stop */
    } finally {
      t.done();
    }
  }
  return null;
}

/** Free text (with or without timestamps) → timed segments. */
export function parseTranscriptText(text: string, duration = 0): TranscriptSegment[] {
  const clean = text.replace(/\r\n/g, "\n").trim();
  if (!clean) return [];
  const timed = /(^|\n)\s*[\[(]?\d{1,2}:\d{2}/.test(clean);
  const segs = timed
    ? parseTimestampedLines(clean, 0, duration || 0)
    : spreadText(clean, 0, duration || Math.max(30, Math.round(clean.length / 15)));
  const fixed = segs
    .map((s) => ({ ...s, text: s.text.replace(/\s+/g, " ").trim() }))
    .filter((s) => s.text)
    .map((s, i, all) => ({ ...s, t1: s.t1 > s.t0 ? s.t1 : (all[i + 1]?.t0 ?? s.t0 + 4) }));
  // Timed lines stay separate so the transcript can be read and jumped through line by line.
  return fixed.slice(0, 4000);
}

const STORED_SEGMENTS = 4000;

/**
 * Save a transcript on the item and index it for Leo (chunks with timestamps, like any other
 * audio or video). Saving twice replaces the old text rather than duplicating passages.
 */
export async function saveTranscript(fileId: string, segments: TranscriptSegment[], source: NonNullable<LibFile["transcriptSource"]>) {
  const file = await db.files.get(fileId);
  if (!file) return [];
  const timed = segments.filter((s) => s.text.trim()).slice(0, STORED_SEGMENTS);
  // Leo searches grouped passages; the learner reads the individual timed lines.
  const chunks = groupSegments(timed, 900);
  await db.files.update(fileId, {
    transcript: timed,
    transcriptSource: source,
    transcriptState: timed.length ? "done" : "unavailable",
    transcriptNote: timed.length ? undefined : "No speech was found in that transcript.",
    indexed: timed.length ? "done" : "none",
    indexNote: timed.length ? undefined : "no transcript",
    // The video's length comes from the player, never from a partial transcript.
    duration: file.duration,
  });
  const { uid: id } = await import("./db");
  await db.transaction("rw", db.chunks, async () => {
    await db.chunks.where("sourceId").equals(fileId).delete();
    if (chunks.length) {
      await db.chunks.bulkAdd(
        chunks.map((s) => ({ id: id(), projectId: file.projectId, sourceId: fileId, sourceKind: "file" as const, sourceName: file.name, page: 0, text: s.text, t0: Math.round(s.t0), t1: Math.round(s.t1) }))
      );
    }
  });
  const { invalidateIndex } = await import("./retrieval");
  invalidateIndex(file.projectId);
  await db.projects.update(file.projectId, { updatedAt: Date.now() });
  return timed;
}

const running = new Set<string>();

/** Try YouTube's captions once more; returns true when a transcript was saved. */
export async function refreshYoutubeCaptions(fileId: string): Promise<boolean> {
  if (running.has(fileId)) return false;
  const file = await db.files.get(fileId);
  if (!file?.youtubeId) return false;
  running.add(fileId);
  try {
    await db.files.update(fileId, { transcriptState: "fetching", transcriptNote: undefined });
    const segs = await fetchYoutubeCaptions(file.youtubeId);
    if (segs?.length) {
      await saveTranscript(fileId, segs, "captions");
      return true;
    }
    await db.files.update(fileId, {
      transcriptState: "unavailable",
      indexed: "none",
      indexNote: "captions are not available to the browser",
      transcriptNote: "YouTube doesn't let other apps read this video's captions from the browser. Paste the transcript, or upload the video once so its audio can be transcribed.",
    });
    return false;
  } catch (e) {
    await db.files.update(fileId, {
      transcriptState: "failed",
      transcriptNote: e instanceof Error ? e.message.slice(0, 200) : String(e),
    });
    return false;
  } finally {
    running.delete(fileId);
  }
}

export interface AddYoutubeResult {
  file: LibFile;
  existing: boolean;
}

/** Add a YouTube link to a project's library (or return the item already there for this video). */
export async function addYoutubeVideo(projectId: string, url: string): Promise<AddYoutubeResult> {
  const ref = youtubeRef(url);
  if (!ref) throw new Error("That isn't a YouTube video link.");
  const existing = await db.files.where("youtubeId").equals(ref.id).filter((f) => f.projectId === projectId).first();
  if (existing) return { file: existing, existing: true };
  const meta = await fetchYoutubeMeta(ref);
  const now = Date.now();
  const file: LibFile = {
    id: uid(),
    projectId,
    name: meta?.title ?? "YouTube video",
    kind: "video",
    mime: "video/youtube",
    size: 0,
    blob: new Blob([], { type: "video/youtube" }),
    source: "youtube",
    youtubeId: ref.id,
    youtubeUrl: watchUrl(ref.id),
    channel: meta?.channel,
    thumb: meta?.thumb,
    duration: undefined,
    indexed: "pending",
    transcriptState: "fetching",
    createdAt: now,
  };
  await db.files.add(file);
  await db.projects.update(projectId, { updatedAt: now });
  // The video page shows the transcript filling in; the add sheet need not wait for it.
  void cachePoster(file.id, ref.id);
  void refreshYoutubeCaptions(file.id);
  return { file, existing: false };
}

/** Transcript as plain text with [m:ss] markers, clipped for a chat context or a note. */
export function transcriptExcerpt(file: Pick<LibFile, "transcript">, max = 9000): string {
  const segs = file.transcript ?? [];
  if (!segs.length) return "";
  const lines = segs.map((s) => `[${stamp(s.t0)}] ${s.text}`);
  let out = "";
  for (const line of lines) {
    if (out.length + line.length + 1 > max) return `${out}\n…[transcript continues]`;
    out += (out ? "\n" : "") + line;
  }
  return out;
}

export const transcriptLabel = (file: Pick<LibFile, "transcriptSource" | "transcriptState">) => {
  if (file.transcriptState === "fetching") return "Fetching transcript…";
  if (file.transcriptState === "unavailable") return "No transcript yet";
  if (file.transcriptState === "failed") return "Transcript failed";
  if (file.transcriptSource === "captions") return "YouTube captions";
  if (file.transcriptSource === "pasted") return "Transcript added by you";
  if (file.transcriptSource === "audio") return "Transcribed from the audio";
  return "Transcript";
};

/** When the player learns the video's length, keep it on the item (once). */
export async function rememberDuration(file: Pick<LibFile, "id" | "duration">, seconds: number) {
  if (!isFinite(seconds) || seconds <= 0) return;
  if (file.duration && Math.abs(file.duration - seconds) < 2) return;
  await db.files.update(file.id, { duration: Math.round(seconds) });
}
