import { db, type Card } from "./db";
import { recordQuizResult } from "./ai/actions";

const DAY = 86_400_000;

/** Next schedule after one review: intervals grow ×2.5 on a hit (1, 3, 7, 18… days); a miss resets to today+1. */
export function scheduleCard(c: Pick<Card, "interval" | "reps" | "lapses">, correct: boolean, now = Date.now()) {
  if (!correct) return { interval: 0, nextReview: now + DAY, reps: c.reps + 1, lapses: c.lapses + 1 };
  const interval = c.interval <= 0 ? 1 : c.interval < 3 ? 3 : Math.round(c.interval * 2.5);
  return { interval, nextReview: now + interval * DAY, reps: c.reps + 1, lapses: c.lapses };
}

/** Due cards from the DB, oldest-due first — no model call involved. */
export async function dueCards(projectId: string, now = Date.now(), limit = 20): Promise<Card[]> {
  const all = await db.cards.where("projectId").equals(projectId).toArray();
  return all
    .filter((c) => c.nextReview <= now)
    .sort((a, b) => a.nextReview - b.nextReview)
    .slice(0, limit);
}

/** Grade a card locally: reschedule it and feed the outcome into the knowledge map. */
export async function answerCard(card: Card, choice: number): Promise<boolean> {
  const correct = choice === card.answer;
  await db.cards.update(card.id, { ...scheduleCard(card, correct), updatedAt: Date.now() });
  await recordQuizResult(card.projectId, card.concept, correct);
  return correct;
}
