import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  const data = new Map<string, string>();
  (globalThis as { localStorage?: unknown }).localStorage = {
    getItem: (k: string) => data.get(k) ?? null,
    setItem: (k: string, v: string) => void data.set(k, String(v)),
    removeItem: (k: string) => void data.delete(k),
    clear: () => data.clear(),
  };
});

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db } from "@/lib/db";
import { addYoutubeVideo, parseCaptionPayload, parseTranscriptText, refreshYoutubeCaptions, saveTranscript, stamp, transcriptExcerpt, transcriptLabel, youtubeRef } from "./youtube";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function until(fn: () => Promise<boolean>, ms = 2500) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    if (await fn()) return true;
    await sleep(20);
  }
  return false;
}

beforeEach(() => {
  fake.reset();
  vi.restoreAllMocks();
});

describe("YouTube captions", () => {
  it("reads YouTube's JSON caption track, with entities and timings", () => {
    const body = JSON.stringify({
      events: [
        { tStartMs: 0, dDurationMs: 4200, segs: [{ utf8: "Cells are" }, { utf8: " the unit" }] },
        { tStartMs: 4200, dDurationMs: 999999, segs: [{ utf8: "of life &amp; more" }] },
        { tStartMs: 5000, dDurationMs: 1000, segs: [{ utf8: "\n" }] },
      ],
    });
    const segs = parseCaptionPayload(body);
    expect(segs).toHaveLength(2);
    expect(segs[0]).toEqual({ t0: 0, t1: 4.2, text: "Cells are the unit" });
    expect(segs[1].text).toBe("of life & more");
    expect(segs[1].t0).toBe(4.2);
  });

  it("reads the older XML caption track", () => {
    const xml = `<transcript><text start="1.5" dur="2.5">Hello &amp;#39;there&amp;#39;</text><text start="4" dur="2">General &lt;Kenobi&gt;</text></transcript>`;
    const segs = parseCaptionPayload(xml);
    expect(segs.map((s) => s.text)).toEqual(["Hello 'there'", "General <Kenobi>"]);
    expect(segs[1]).toMatchObject({ t0: 4, t1: 6 });
  });

  it("treats an empty or broken body as no captions", () => {
    expect(parseCaptionPayload("")).toEqual([]);
    expect(parseCaptionPayload("{not json")).toEqual([]);
    expect(parseCaptionPayload("<transcript></transcript>")).toEqual([]);
  });
});

describe("Transcripts added by hand", () => {
  it("keeps timestamps when the text has them", () => {
    const segs = parseTranscriptText("0:00 Welcome back.\n0:12 Today: cells.\n1:05 Genes.", 90);
    expect(segs.length).toBeGreaterThan(0);
    expect(segs[0].t0).toBe(0);
    expect(segs).toHaveLength(3);
    expect(segs[1].t0).toBe(12);
    expect(segs[2].t0).toBe(65);
    expect(segs.map((s) => s.text).join(" ")).toMatch(/Welcome back\. Today: cells\. Genes\./);
  });

  it("spreads plain text across the video otherwise", () => {
    const segs = parseTranscriptText("First sentence. Second sentence. Third one.", 120);
    expect(segs.length).toBeGreaterThan(0);
    expect(segs[0].t0).toBe(0);
    expect(segs[segs.length - 1].t1).toBeLessThanOrEqual(121);
    expect(segs.map((s) => s.text).join(" ")).toContain("Third one.");
  });

  it("returns nothing for empty input", () => {
    expect(parseTranscriptText("   \n  ")).toEqual([]);
  });
});

describe("Saving and indexing a transcript", () => {
  it("stores the timed text on the item and indexes it for Leo", async () => {
    await db.projects.add({ id: "p", name: "Bio" } as never);
    const file = { id: "f1", projectId: "p", name: "Cells on YouTube", youtubeId: "abcDEF12345", blob: new Blob(), createdAt: 1 } as never;
    await db.files.add(file);
    const segs = await saveTranscript("f1", parseTranscriptText("0:00 Cells are the unit of life.\n0:30 Cell theory has three parts.", 60), "pasted");
    expect(segs.length).toBeGreaterThan(0);
    const row = await db.files.get("f1");
    expect(row).toMatchObject({ transcriptState: "done", transcriptSource: "pasted", indexed: "done" });
    expect(row?.transcript?.length).toBe(segs.length);
    const chunks = await db.chunks.toArray();
    expect(chunks.length).toBeGreaterThan(0);
    expect(chunks.length).toBeLessThanOrEqual(segs.length);
    expect(chunks[0]).toMatchObject({ sourceKind: "file", sourceId: "f1", sourceName: "Cells on YouTube", page: 0 });
    expect(typeof chunks[0].t0).toBe("number");
    expect(transcriptExcerpt({ transcript: row?.transcript }, 9000)).toMatch(/^\[0:00\] Cells are the unit of life\./);
  });

  it("rejects empty segments and reports the transcript as unavailable", async () => {
    await db.files.add({ id: "f2", projectId: "p", name: "Empty", youtubeId: "abcDEF12345", blob: new Blob(), createdAt: 1 } as never);
    const segs = await saveTranscript("f2", [], "pasted");
    expect(segs).toEqual([]);
    expect(await db.files.get("f2")).toMatchObject({ transcriptState: "unavailable" });
    expect(await db.chunks.count()).toBe(0);
  });

  it("labels where a transcript came from", () => {
    expect(transcriptLabel({ transcriptState: "fetching" })).toBe("Fetching transcript…");
    expect(transcriptLabel({ transcriptState: "unavailable" })).toBe("No transcript yet");
    expect(transcriptLabel({ transcriptState: "done", transcriptSource: "captions" })).toBe("YouTube captions");
    expect(transcriptLabel({ transcriptState: "done", transcriptSource: "pasted" })).toBe("Transcript added by you");
    expect(transcriptLabel({ transcriptState: "done", transcriptSource: "audio" })).toBe("Transcribed from the audio");
  });
});

describe("Adding a YouTube link to the library", () => {
  it("creates a Video item, fetches its title/channel and its captions, and indexes them", async () => {
    await db.projects.add({ id: "p", name: "Bio" } as never);
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        const url = String(input);
        if (url.includes("oembed")) return new Response(JSON.stringify({ title: "The Cell", author_name: "Biology Basics" }), { status: 200 });
        if (url.includes("timedtext"))
          return new Response(JSON.stringify({ events: [{ tStartMs: 0, dDurationMs: 3000, segs: [{ utf8: "A cell is the smallest unit." }] }, { tStartMs: 3000, dDurationMs: 2000, segs: [{ utf8: "All living things are made of cells." }] }] }), { status: 200 });
        return new Response("", { status: 404 });
      })
    );
    const { file, existing } = await addYoutubeVideo("p", "https://youtu.be/abcDEF12345?t=5");
    expect(existing).toBe(false);
    expect(file).toMatchObject({ kind: "video", source: "youtube", youtubeId: "abcDEF12345", name: "The Cell", channel: "Biology Basics", projectId: "p" });
    expect(file.transcriptState).toBe("fetching");
    expect(await until(async () => (await db.files.get(file.id))?.transcriptState === "done")).toBe(true);
    const row = await db.files.get(file.id);
    expect(row?.transcript?.length).toBeGreaterThan(0);
    expect(row?.transcriptSource).toBe("captions");
    expect(await db.chunks.count()).toBeGreaterThan(0);
  });

  it("returns the existing item instead of adding the same video twice", async () => {
    await db.projects.add({ id: "p", name: "Bio" } as never);
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => (String(input).includes("oembed") ? new Response(JSON.stringify({ title: "Cell" }), { status: 200 }) : new Response("", { status: 404 }))));
    const first = await addYoutubeVideo("p", "https://www.youtube.com/watch?v=abcDEF12345");
    const second = await addYoutubeVideo("p", "https://youtu.be/abcDEF12345");
    expect(second.existing).toBe(true);
    expect(second.file.id).toBe(first.file.id);
    expect((await db.files.toArray()).filter((f) => f.youtubeId === "abcDEF12345")).toHaveLength(1);
  });

  it("explains when captions cannot be read, and keeps the video usable", async () => {
    await db.projects.add({ id: "p", name: "Bio" } as never);
    vi.stubGlobal("fetch", vi.fn(async () => new Response("", { status: 404 })));
    const { file } = await addYoutubeVideo("p", "https://youtu.be/abcDEF12345");
    expect(await until(async () => (await db.files.get(file.id))?.transcriptState === "unavailable")).toBe(true);
    const row = await db.files.get(file.id);
    expect(row?.transcriptNote).toMatch(/Paste the transcript|upload the video/i);
    expect(await refreshYoutubeCaptions(file.id)).toBe(false);
  });

  it("refuses links that are not videos", async () => {
    await expect(addYoutubeVideo("p", "https://www.youtube.com/@BiologyBasics")).rejects.toThrow(/YouTube video link/);
  });
});

describe("YouTube addresses and labels", () => {
  it("finds the video id in every link shape", () => {
    for (const url of ["https://youtu.be/abcDEF12345", "https://www.youtube.com/watch?v=abcDEF12345", "https://m.youtube.com/shorts/abcDEF12345"]) expect(youtubeRef(url)?.id, url).toBe("abcDEF12345");
    expect(youtubeRef("https://example.com")).toBeNull();
  });

  it("formats times and clips very long transcripts", () => {
    expect(stamp(0)).toBe("0:00");
    expect(stamp(65)).toBe("1:05");
    expect(stamp(3723)).toBe("1:02:03");
    const long = Array.from({ length: 40 }, (_, i) => ({ t0: i * 4, t1: i * 4 + 4, text: "word ".repeat(40) }));
    const out = transcriptExcerpt({ transcript: long }, 500);
    expect(out.length).toBeLessThanOrEqual(540);
    expect(out).toContain("[transcript continues]");
  });
});
