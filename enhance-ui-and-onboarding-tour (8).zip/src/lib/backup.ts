import { db, SCHEMA_VERSION, type Provider } from "./db";
import { blobToDataUrl, dataUrlToBlob } from "./media";

const TABLES = ["projects", "projectFolders", "notes", "sketches", "threads", "messages", "concepts", "points", "providers", "chunks", "memories", "cards", "pdfAnnotations", "kv"] as const;
const LOCAL_KEYS = ["harness.settings", "harness.activeThread", "harness.bubble", "harness.panel"];

/**
 * Export as JSON assembled from many Blob parts. Nothing is ever concatenated into one
 * giant string, so a multi-hundred-MB library doesn't need that much contiguous memory.
 * Format: { app, version, schema, exportedAt, data: { table: [...] }, files: [...], local: {...} }
 */
export async function exportBackup(includeKeys: boolean): Promise<Blob> {
  const parts: BlobPart[] = [];
  parts.push(`{"app":"harness","version":2,"schema":${SCHEMA_VERSION},"exportedAt":${Date.now()},"data":{`);
  let firstTable = true;
  for (const t of TABLES) {
    const rows = await db.table(t).toArray();
    const out = t === "providers" && !includeKeys ? (rows as Provider[]).map((p) => ({ ...p, apiKey: "" })) : rows;
    parts.push(`${firstTable ? "" : ","}${JSON.stringify(t)}:${JSON.stringify(out)}`);
    firstTable = false;
  }
  parts.push(`},"files":[`);
  const ids = (await db.files.toCollection().primaryKeys()) as string[];
  for (let i = 0; i < ids.length; i++) {
    const f = await db.files.get(ids[i]);
    if (!f) continue;
    const { blob, ...meta } = f;
    const head = JSON.stringify(meta);
    parts.push(`${i ? "," : ""}${head.slice(0, -1)},"blob":"`);
    parts.push(await blobToDataUrl(blob));
    parts.push(`"}`);
  }
  const local: Record<string, string> = {};
  for (const k of LOCAL_KEYS) {
    const v = localStorage.getItem(k);
    if (v) local[k] = v;
  }
  parts.push(`],"local":${JSON.stringify(local)}}`);
  return new Blob(parts, { type: "application/json" });
}

export interface ImportSummary {
  tables: number;
  files: number;
  keysKept: number;
}

export async function importBackup(file: File): Promise<ImportSummary> {
  // Importing still needs the whole JSON in memory; we check size up front and say so.
  if (file.size > 1.5 * 1024 * 1024 * 1024) throw new Error("This backup is too large to import in a browser tab (limit ~1.5 GB).");
  const json = JSON.parse(await file.text());
  if (json?.app !== "harness" || !json.data) throw new Error("Not a Harness backup file");
  if (typeof json.schema === "number" && json.schema > SCHEMA_VERSION)
    throw new Error(`This backup was made by a newer Harness (schema ${json.schema}); update the app first.`);
  const data = json.data as Record<string, unknown[]>;
  const files = (Array.isArray(json.files) ? json.files : Array.isArray(data.files) ? data.files : []) as (Record<string, unknown> & { blob: string })[];

  let keysKept = 0;
  const existingProviders = new Map((await db.providers.toArray()).map((p) => [p.id, p]));
  if (Array.isArray(data.providers)) {
    data.providers = (data.providers as Provider[]).map((p) => {
      if (!p.apiKey && existingProviders.get(p.id)?.apiKey) {
        keysKept++;
        return { ...p, apiKey: existingProviders.get(p.id)!.apiKey };
      }
      return p;
    });
  }

  const tables = TABLES.filter((t) => Array.isArray(data[t]));
  await db.transaction("rw", [...TABLES.map((t) => db.table(t)), db.files], async () => {
    for (const t of tables) await db.table(t).bulkPut(data[t]);
    for (const f of files) {
      const { blob, ...meta } = f;
      await db.files.put({ ...(meta as object), blob: await dataUrlToBlob(blob) } as never);
    }
  });
  if (json.local && typeof json.local === "object") {
    for (const [k, v] of Object.entries(json.local as Record<string, string>)) {
      if (LOCAL_KEYS.includes(k) && typeof v === "string") localStorage.setItem(k, v);
    }
  }
  return { tables: tables.length, files: files.length, keysKept };
}

export function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** How handing a file to the learner ended, so the UI can say what actually happened. */
export type DeliveryResult = { how: "shared" } | { how: "download" } | { how: "cancelled" } | { how: "failed"; error: string };

/**
 * Hand a file to the learner. An <a download> link on its own silently does nothing inside sandboxed
 * iframes and on many phone browsers, so try the Web Share API with a real File first (only when the
 * browser says it can share files), then fall back to the download link. Neither is verifiable, so the
 * caller should always offer a copy/paste route as well.
 */
export async function shareOrDownload(blob: Blob, name: string): Promise<DeliveryResult> {
  const nav = navigator as Navigator & { canShare?: (data?: ShareData) => boolean; share?: (data: ShareData) => Promise<void> };
  if (nav.share && nav.canShare) {
    try {
      const file = new File([blob], name, { type: blob.type || "application/octet-stream" });
      if (nav.canShare({ files: [file] })) {
        await nav.share({ files: [file], title: name });
        return { how: "shared" };
      }
    } catch (e) {
      // Closing the share sheet is a choice, not a failure; anything else falls through to download.
      if (e instanceof DOMException && e.name === "AbortError") return { how: "cancelled" };
    }
  }
  try {
    download(blob, name);
    return { how: "download" };
  } catch (e) {
    return { how: "failed", error: e instanceof Error ? e.message : String(e) };
  }
}
