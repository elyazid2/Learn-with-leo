import { beforeEach, describe, expect, it, vi } from "vitest";

// The tour remembers what was seen in localStorage; give Node a tiny in-memory one before it loads.
const storage = vi.hoisted(() => {
  const data = new Map<string, string>();
  const api = {
    getItem: (k: string) => data.get(k) ?? null,
    setItem: (k: string, v: string) => void data.set(k, String(v)),
    removeItem: (k: string) => void data.delete(k),
    clear: () => data.clear(),
  };
  (globalThis as { localStorage?: unknown }).localStorage = api;
  return api;
});

import { projectTourPending, useTour } from "./tour";

const saved = () => JSON.parse(storage.getItem("harness.tour") ?? "null");

beforeEach(() => {
  storage.clear();
  useTour.setState({ seen: { home: false, project: false }, chapter: null, step: 0, replayRequested: false, deferredPlacement: null });
});

describe("Leo's tour: what counts as seen", () => {
  it("finishing the home chapter leaves the project chapter still to come", () => {
    useTour.getState().start("home");
    useTour.getState().end("done");
    expect(useTour.getState().seen).toEqual({ home: true, project: false });
    expect(useTour.getState().chapter).toBeNull();
    expect(projectTourPending()).toBe(true);
    expect(saved()).toEqual({ home: true, project: false });
  });

  it("skipping the home chapter means no tour at all: the project chapter stays quiet too", () => {
    useTour.getState().start("home");
    useTour.getState().end("skipped");
    expect(useTour.getState().seen).toEqual({ home: true, project: true });
    expect(projectTourPending()).toBe(false);
  });

  it("an interrupted chapter is not recorded, so it can start again later", () => {
    useTour.getState().start("home");
    useTour.getState().setStep(2);
    useTour.getState().end("interrupted");
    expect(useTour.getState().seen).toEqual({ home: false, project: false });
    expect(useTour.getState().chapter).toBeNull();
    expect(useTour.getState().step).toBe(0);
    expect(saved()).toBeNull();
  });

  it("finishing or skipping the project chapter records it", () => {
    for (const reason of ["done", "skipped"] as const) {
      useTour.setState({ seen: { home: true, project: false } });
      useTour.getState().start("project");
      useTour.getState().end(reason);
      expect(useTour.getState().seen).toEqual({ home: true, project: true });
    }
  });

  it("the project chapter never comes before the home chapter", () => {
    expect(projectTourPending()).toBe(false);
  });

  it("ending when nothing is running changes nothing", () => {
    useTour.getState().end("done");
    expect(useTour.getState().seen).toEqual({ home: false, project: false });
    expect(saved()).toBeNull();
  });
});

describe("Leo's tour: controls", () => {
  it("replay asks for the home chapter and re-arms the project chapter", () => {
    useTour.setState({ seen: { home: true, project: true } });
    useTour.getState().replay();
    expect(useTour.getState().replayRequested).toBe(true);
    expect(useTour.getState().seen).toEqual({ home: true, project: false });
    useTour.getState().start("home");
    expect(useTour.getState().replayRequested).toBe(false);
    expect(useTour.getState().step).toBe(0);
  });

  it("steps never go below the first one", () => {
    useTour.getState().start("home");
    useTour.getState().setStep(-3);
    expect(useTour.getState().step).toBe(0);
  });

  it("asking for a new project bumps the request counter each time", () => {
    const before = useTour.getState().createRequest;
    useTour.getState().requestCreate();
    useTour.getState().requestCreate();
    expect(useTour.getState().createRequest).toBe(before + 2);
  });

  it("holds and releases a deferred placement", () => {
    useTour.getState().deferPlacement("p1");
    expect(useTour.getState().deferredPlacement).toBe("p1");
    useTour.getState().deferPlacement(null);
    expect(useTour.getState().deferredPlacement).toBeNull();
  });
});
