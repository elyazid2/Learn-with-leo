import { db, uid, type Chunk, type LibFile, type Note, type Sketch, type SourceRef } from "./db";
import { chunkText, invalidateIndex, noteSourceName } from "./retrieval";

export interface CopyChoice {
  kind: "file" | "note" | "sketch";
  id: string;
  projectId: string;
}

export const copyKey = (choice: Pick<CopyChoice, "kind" | "id">) => `${choice.kind}:${choice.id}`;

export interface CopyResult {
  count: number;
  items: CopyChoice[];
}

/** New rows, blobs, annotations and search passages; no shared source IDs and no AI reprocessing. */
export async function copyLibraryItems(targetProjectId: string, choices: CopyChoice[]): Promise<CopyResult> {
  const selected = [...new Map(choices.map((c) => [copyKey(c), c])).values()];
  if (!selected.length) return { count: 0, items: [] };
  const result = await db.transaction("rw", [db.projects, db.files, db.notes, db.sketches, db.folders, db.chunks, db.pdfAnnotations], async () => {
    if (!(await db.projects.get(targetProjectId))) throw new Error("The destination project no longer exists.");
    const idMap = new Map(selected.map((c) => [copyKey(c), uid()]));
    const sourceRows: { choice: CopyChoice; row: LibFile | Note | Sketch; chunks: Chunk[] }[] = [];
    // Validate the whole selection before writing, so a deleted item never produces a partial copy.
    for (const choice of selected) {
      if (choice.projectId === targetProjectId) throw new Error("Choose items from another project.");
      const table = choice.kind === "file" ? db.files : choice.kind === "note" ? db.notes : db.sketches;
      const row = await table.get(choice.id);
      if (!row || row.projectId !== choice.projectId) throw new Error("One of the selected items was removed. Select the remaining items and try again.");
      const chunks = choice.kind === "sketch" ? [] : await db.chunks.where("sourceId").equals(choice.id).toArray();
      sourceRows.push({ choice, row, chunks });
    }
    const now = Date.now();
    const remapSources = (sources?: SourceRef[]) => sources?.flatMap((source) => {
      const fileId = idMap.get(`file:${source.fileId}`);
      return fileId ? [{ ...source, fileId }] : [];
    });
    const remapLinks = (text: string) => {
      let next = text;
      for (const c of selected) {
        const tab = c.kind === "file" ? "library" : c.kind === "note" ? "notes" : "sketch";
        next = next.split(`#/p/${c.projectId}/${tab}/${c.id}`).join(`#/p/${targetProjectId}/${tab}/${idMap.get(copyKey(c))}`);
      }
      return next;
    };
    const copied: CopyChoice[] = [];
    for (const { choice, row, chunks } of sourceRows) {
      const id = idMap.get(copyKey(choice))!;
      if (choice.kind === "file") {
        const file = structuredClone(row as LibFile);
        // Blobs are immutable; slice gives this row its own value without a lossy data-URL round trip.
        const copy: LibFile = { ...file, id, projectId: targetProjectId, blob: file.blob.slice(0, file.blob.size, file.blob.type), createdAt: now };
        if (chunks.length || copy.transcript?.length) { copy.indexed = "done"; copy.indexNote = undefined; }
        if (copy.indexed === "pending") {
          copy.indexed = chunks.length || copy.transcript?.length ? "done" : "none";
          if (copy.indexed === "none") copy.indexNote = "The original item's text was not ready when it was copied.";
        }
        if (copy.transcriptState === "fetching") copy.transcriptState = copy.transcript?.length ? "done" : "unavailable";
        await db.files.add(copy);
        const annotations = await db.pdfAnnotations.where("fileId").equals(file.id).toArray();
        if (annotations.length) await db.pdfAnnotations.bulkAdd(annotations.map((a) => ({ ...structuredClone(a), id: uid(), fileId: id, projectId: targetProjectId })));
      } else if (choice.kind === "note") {
        const note = structuredClone(row as Note);
        await db.notes.add({
          ...note, id, projectId: targetProjectId, content: remapLinks(note.content),
          sources: remapSources(note.sources), createdAt: now, updatedAt: now,
          versions: note.versions?.map((v) => ({ ...v, content: remapLinks(v.content) })),
        });
        if (note.folder) {
          const folders = await db.folders.where("projectId").equals(targetProjectId).toArray();
          if (!folders.some((f) => f.path === note.folder)) await db.folders.add({ id: uid(), projectId: targetProjectId, path: note.folder, createdAt: now });
        }
      } else {
        const sketch = structuredClone(row as Sketch);
        await db.sketches.add({ ...sketch, id, projectId: targetProjectId, createdAt: now, updatedAt: now });
      }
      let passages = chunks.map((c) => ({ ...structuredClone(c), id: uid(), projectId: targetProjectId, sourceId: id, text: remapLinks(c.text) }));
      if (!passages.length && choice.kind === "note") {
        const note = row as Note;
        passages = chunkText(remapLinks(note.content)).map((text): Chunk => ({ id: uid(), projectId: targetProjectId, sourceId: id, sourceKind: "note", sourceName: noteSourceName(note), page: 0, text, author: note.author }));
      }
      if (!passages.length && choice.kind === "file" && (row as LibFile).transcript?.length) {
        const file = row as LibFile;
        passages = file.transcript!.map((s): Chunk => ({ id: uid(), projectId: targetProjectId, sourceId: id, sourceKind: "file", sourceName: file.name, page: 0, text: s.text, t0: s.t0, t1: s.t1 }));
      }
      if (passages.length) await db.chunks.bulkAdd(passages);
      copied.push({ kind: choice.kind, id, projectId: targetProjectId });
    }
    await db.projects.update(targetProjectId, { updatedAt: now });
    return { count: copied.length, items: copied };
  });
  invalidateIndex(targetProjectId);
  return result;
}