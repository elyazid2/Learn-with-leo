import { describe, expect, it } from "vitest";
import { nextCursor, paginatePages, paginateText, paginateTranscript, parseClock, parsePages, READ_MAX_CHARS } from "./retrieval";
import { groupSegments, parseTimestampedLines } from "./transcribe";
import { scheduleCard } from "./cards";

describe("parsePages / parseClock", () => {
  it("parses ranges, open ends and lists within bounds", () => {
    expect(parsePages("12-14", 100)).toEqual([12, 13, 14]);
    expect(parsePages("98-", 100)).toEqual([98, 99, 100]);
    expect(parsePages("3,5", 10)).toEqual([3, 5]);
    expect(parsePages("8-200", 10)).toEqual([8, 9, 10]);
    expect(parsePages(undefined, 3)).toEqual([1, 2, 3]);
  });
  it("parses clocks", () => {
    expect(parseClock("3:10")).toBe(190);
    expect(parseClock("1:02:03")).toBe(3723);
    expect(parseClock("45")).toBe(45);
    expect(parseClock("x")).toBeNaN();
  });
});

describe("read pagination", () => {
  it("fits PDF pages within 12k chars and returns a next cursor", () => {
    const pages = Array.from({ length: 10 }, (_, i) => ({ page: i + 1, text: "x".repeat(5000) }));
    const r = paginatePages(pages, 10);
    expect(r.text.length).toBeLessThanOrEqual(READ_MAX_CHARS + 100);
    expect(r.included).toBe("p.1-2");
    expect(r.next).toEqual({ pages: "3-10" });
    expect(nextCursor("f1", r.next)).toBe('{"type":"read","kind":"file","id":"f1","pages":"3-10"}');
  });

  it("has no next cursor when everything fits", () => {
    const r = paginatePages([{ page: 12, text: "a" }, { page: 13, text: "b" }], 13);
    expect(r.next).toBeUndefined();
    expect(r.text).toContain("--- p.13 ---");
  });

  it("clips a single huge page instead of returning nothing", () => {
    const r = paginatePages([{ page: 1, text: "y".repeat(30000) }, { page: 2, text: "z" }], 2);
    expect(r.text).toContain("[page clipped]");
    expect(r.next).toEqual({ pages: "2-2" });
  });

  it("reads a transcript time range and resumes after the last chunk", () => {
    const chunks = Array.from({ length: 40 }, (_, i) => ({ text: "w".repeat(800), t0: i * 30, t1: i * 30 + 30 }));
    const r = paginateTranscript(chunks, 190, 900);
    expect(r.text.startsWith("[3:00–3:30]")).toBe(true);
    expect(r.next?.to).toBe("15:00");
    const resumed = paginateTranscript(chunks, parseClock(r.next!.from), parseClock(r.next!.to));
    expect(resumed.text).not.toContain(r.text.split("\n").pop()!.slice(0, 13));
    const all = paginateTranscript(chunks.slice(0, 3));
    expect(all.next).toBeUndefined();
  });

  it("pages a text file by character offsets", () => {
    const text = Array.from({ length: 400 }, (_, i) => `line ${i} ${"t".repeat(80)}`).join("\n");
    const a = paginateText(text);
    expect(a.text.length).toBeLessThanOrEqual(READ_MAX_CHARS);
    expect(a.text.endsWith("\n")).toBe(true);
    const b = paginateText(text, Number(a.next!.from));
    expect(text.slice(0, a.text.length + b.text.length)).toBe(a.text + b.text);
  });
});

describe("transcripts", () => {
  it("parses timestamped lines with the clip offset", () => {
    const segs = parseTimestampedLines("[00:00] Hello\n[00:30] world\ncontinued", 600, 660);
    expect(segs).toEqual([
      { t0: 600, t1: 630, text: "Hello" },
      { t0: 630, t1: 660, text: "world continued" },
    ]);
  });
  it("groups segments into non-overlapping chunks that keep their time span", () => {
    const g = groupSegments([
      { t0: 0, t1: 5, text: "a".repeat(500) },
      { t0: 5, t1: 9, text: "b".repeat(300) },
      { t0: 9, t1: 12, text: "c".repeat(500) },
    ]);
    expect(g.map((s) => [s.t0, s.t1])).toEqual([
      [0, 9],
      [9, 12],
    ]);
  });
});

describe("review cards", () => {
  it("grows intervals on hits and resets on misses", () => {
    const now = 0;
    let c = { interval: 0, reps: 0, lapses: 0 };
    c = { ...c, ...scheduleCard(c, true, now) };
    expect(c.interval).toBe(1);
    c = { ...c, ...scheduleCard(c, true, now) };
    expect(c.interval).toBe(3);
    c = { ...c, ...scheduleCard(c, true, now) };
    expect(c.interval).toBe(8);
    const miss = scheduleCard(c, false, now);
    expect(miss.interval).toBe(0);
    expect(miss.lapses).toBe(1);
  });
});
