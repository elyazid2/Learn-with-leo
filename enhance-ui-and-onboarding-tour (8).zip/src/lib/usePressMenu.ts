import { useEffect, useRef, type MouseEvent, type PointerEvent } from "react";

/** A held card opens its menu; movement cancels the hold so scrolling still works. */
export function usePressMenu(open: () => void) {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const origin = useRef<{ x: number; y: number } | null>(null);
  const consumed = useRef(false);
  const clickCleanup = useRef<(() => void) | null>(null);
  const cancel = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    origin.current = null;
  };
  const guardReleaseClick = () => {
    clickCleanup.current?.();
    let expiry: ReturnType<typeof setTimeout>;
    const cleanup = () => {
      clearTimeout(expiry);
      document.removeEventListener("click", swallow, true);
      document.removeEventListener("pointerdown", cleanup, true);
      document.removeEventListener("pointerup", released, true);
      clickCleanup.current = null;
    };
    const swallow = (e: Event) => { e.preventDefault(); e.stopImmediatePropagation(); cleanup(); };
    const released = () => { clearTimeout(expiry); expiry = setTimeout(cleanup, 700); };
    // A touch-release click can land on the newly opened sheet's backdrop instead of the card.
    // Suppress only that release; a new pointerdown immediately restores normal interaction.
    document.addEventListener("click", swallow, true);
    document.addEventListener("pointerdown", cleanup, true);
    document.addEventListener("pointerup", released, true);
    expiry = setTimeout(cleanup, 15000);
    clickCleanup.current = cleanup;
  };
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
    clickCleanup.current?.();
  }, []);
  return {
    onPointerDown: (e: PointerEvent) => {
      if (e.button !== 0 || !e.isPrimary) return;
      cancel();
      consumed.current = false;
      origin.current = { x: e.clientX, y: e.clientY };
      timer.current = setTimeout(() => {
        consumed.current = true;
        guardReleaseClick();
        open();
      }, 550);
    },
    onPointerMove: (e: PointerEvent) => {
      const at = origin.current;
      if (at && Math.hypot(e.clientX - at.x, e.clientY - at.y) > 10) cancel();
    },
    onPointerUp: cancel,
    onPointerCancel: cancel,
    onContextMenu: (e: MouseEvent) => { e.preventDefault(); cancel(); consumed.current = true; open(); },
    onClickCapture: (e: MouseEvent) => {
      if (!consumed.current) return;
      e.preventDefault();
      e.stopPropagation();
      consumed.current = false;
    },
  };
}