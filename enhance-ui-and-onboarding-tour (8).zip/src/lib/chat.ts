import { db, getKV, uid, type ChatMode, type ContextTag, type Message, type Provider, type Thread, type TurnMeta } from "./db";
import { useApp } from "./store";
import { streamChat, type ChatMsg, type StreamMeta } from "./ai/providers";
import { buildSystemPrompt, PLACEMENT_KICKOFF } from "./ai/prompt";
import {
  applyApprovedAction,
  executeActions,
  extractActions,
  type ExecutionReport,
  invalidActionFeedback,
  progressHint,
  recordQuizResult,
  revertQuizResult,
  stripActions,
  type Action,
} from "./ai/actions";
import { MOCK_PROVIDER, streamMockChat } from "./ai/mock";
import { useSettings } from "./settings";
import { citationsOf, formatSources, retrievalQuery, retrieve } from "./retrieval";
import type { CitationRef } from "./db";
import { resolveEnabled } from "./models";
import { earlyReveal, useLive } from "./live";

export interface ModelRef {
  providerId: string;
  model: string;
}

/** Synchronous in-flight lock. `streaming` in the store is set a few awaits later; this closes that window. */
let inFlight = false;
export const isBusy = () => inFlight || !!useApp.getState().streaming;

export async function getDefaultModel(): Promise<ModelRef | null> {
  const providers = await db.providers.toArray();
  const usable = providers.filter((p) => p.models.length > 0);
  if (!usable.length) return null;
  const saved = await getKV<ModelRef | null>("defaultModel", null);
  const savedProvider = saved ? usable.find((p) => p.id === saved.providerId) : undefined;
  // A saved default that was later disabled falls back to an enabled model, never the catalog.
  if (savedProvider) return { providerId: savedProvider.id, model: resolveEnabled(savedProvider, saved!.model) };
  const p = usable.sort((a, b) => a.createdAt - b.createdAt)[0];
  return { providerId: p.id, model: resolveEnabled(p) };
}

async function resolveProvider(thread: Thread): Promise<{ provider: Provider; model: string } | null> {
  if (thread.providerId) {
    const p = await db.providers.get(thread.providerId);
    if (p?.models.length) return { provider: p, model: resolveEnabled(p, thread.model) };
  }
  const def = await getDefaultModel();
  if (!def) return null;
  const p = await db.providers.get(def.providerId);
  return p ? { provider: p, model: resolveEnabled(p, def.model) } : null;
}

export async function createThread(projectId: string, mode: ChatMode): Promise<Thread> {
  const def = await getDefaultModel();
  const now = Date.now();
  const t: Thread = {
    id: uid(),
    projectId,
    title: mode === "placement" ? "Placement" : "New chat",
    mode,
    providerId: def?.providerId,
    model: def?.model,
    createdAt: now,
    updatedAt: now,
  };
  await db.threads.add(t);
  useApp.getState().setActiveThread(projectId, t.id);
  return t;
}

/**
 * Conversation set-up runs one at a time per project. Opening Leo makes the chat panel look for a
 * conversation to show at the same moment placement or "Teach me" creates one. Without a queue both
 * could create a thread, and the empty one could end up on screen while Leo answers in the other.
 */
const threadSetup = new Map<string, Promise<unknown>>();
function withThreadSetup<T>(projectId: string, fn: () => Promise<T>): Promise<T> {
  const previous = threadSetup.get(projectId) ?? Promise.resolve();
  const run = previous.then(fn);
  threadSetup.set(
    projectId,
    run.catch(() => undefined)
  );
  return run;
}

export function getOrCreateActiveThread(projectId: string, mode: ChatMode = "ask"): Promise<Thread> {
  return withThreadSetup(projectId, async () => {
    const id = useApp.getState().activeThread[projectId];
    if (id) {
      const t = await db.threads.get(id);
      if (t) return t;
    }
    const latest = await db.threads.where("projectId").equals(projectId).sortBy("updatedAt");
    if (latest.length) {
      const t = latest[latest.length - 1];
      useApp.getState().setActiveThread(projectId, t.id);
      return t;
    }
    return createThread(projectId, mode);
  });
}

interface SendOpts {
  threadId: string;
  text: string;
  apiContent?: string;
  hidden?: boolean;
  context?: ContextTag[];
  images?: string[];
  audios?: { data: string; mime: string; name: string }[];
}

export async function sendMessage(opts: SendOpts): Promise<boolean> {
  if (isBusy()) return false;
  inFlight = true;
  try {
    const thread = await db.threads.get(opts.threadId);
    if (!thread) return false;
    const now = Date.now();
    useApp.getState().setAgentActivity("thinking", thread.projectId);
    await db.messages.add({
      id: uid(),
      threadId: thread.id,
      projectId: thread.projectId,
      role: "user",
      content: opts.text,
      apiContent: opts.apiContent,
      hidden: opts.hidden,
      context: opts.context?.length ? opts.context : undefined,
      images: opts.images?.length ? opts.images : undefined,
      audios: opts.audios?.length ? opts.audios.map((a) => a.data) : undefined,
      createdAt: now,
    });
    const upd: Partial<Thread> = { updatedAt: now };
    if (!opts.hidden && (thread.title === "New chat" || !thread.title)) {
      upd.title = opts.text.replace(/\s+/g, " ").slice(0, 48) || "Chat";
    }
    await db.threads.update(thread.id, upd);
  } catch (e) {
    inFlight = false;
    throw e;
  }
  await runAssistant(opts.threadId, /* lockHeld */ true);
  return true;
}

const CONTEXT_NOTE = "[workspace context was attached to this message when it was sent]";

const isActionResults = (m: Message) => m.role === "user" && !!m.hidden && m.content.startsWith("<action_results>");

/**
 * An older <action_results> body, collapsed: FAILED lines stay, each `## …` item keeps only its
 * heading — except the Excalidraw guide, which stays in full for the whole chat.
 */
export function collapseActionResults(content: string): string {
  const lines = content.replace(/^<action_results>\n?/, "").replace(/\n?<\/action_results>\s*$/, "").split("\n");
  // FAILED lines are appended after every read item; keep them apart so they survive the collapse.
  let cut = lines.length;
  while (cut > 0 && lines[cut - 1].startsWith("- FAILED ")) cut--;
  const failed = lines.slice(cut);
  const body = lines.slice(0, cut).join("\n");
  const parts = body ? body.split(/\n(?=## )/) : [];
  const out = parts.map((part) => {
    if (!part.startsWith("## ")) return part;
    if (part.startsWith('## Guide "')) return part;
    const nl = part.indexOf("\n");
    const heading = nl >= 0 ? part.slice(0, nl) : part;
    return `${heading}\n[contents omitted from this older step — read it again if you need it]`;
  });
  return `<action_results>\n${[...out, ...failed].join("\n")}\n</action_results>`;
}

/** How a proposed action that needed approval ended, so the model knows on later turns. */
function pendingSummary(m: Message): string {
  if (!m.pending?.length) return "";
  const word = { pending: "awaiting the learner's approval", applied: "applied by the learner", dismissed: "dismissed by the learner", failed: "failed when applied" } as const;
  return `\n\n[Proposed changes: ${m.pending.map((p) => `${p.label} — ${word[p.status]}`).join("; ")}]`;
}

/**
 * Build the model-facing history. Only the learner's LAST visible turn carries its full apiContent
 * (note/PDF/selection text, @mentions); older turns are collapsed to their visible text so long
 * threads don't resend tens of kilobytes per request. Hidden agent-loop messages
 * (<action_results>) never take that role: otherwise every step ≥ 2 would drop the learner's context.
 * Only the latest <action_results> body is sent in full.
 */
/** The mime type inside a data URL ("data:audio/wav;base64,…" → "audio/wav"). */
export function dataUrlMime(dataUrl: string, fallback = "audio/wav"): string {
  return /^data:([^;,]+)[;,]/.exec(dataUrl)?.[1] ?? fallback;
}

export function buildHistory(all: Message[]): ChatMsg[] {
  const history = all.filter((m) => !m.error && !m.partial).slice(-40);
  // An on-demand guide stays in context for the whole chat, so Leo reads it once and never again —
  // even after the thread grows past the history window.
  const guide = [...all].reverse().find((m) => m.role === "user" && m.content.includes('## Guide "'));
  if (guide && !history.includes(guide)) {
    const at = history.map((m) => m.role).lastIndexOf("user");
    history.splice(at < 0 ? history.length : at, 0, guide);
  }
  let lastUserIdx = -1;
  let tailUserIdx = -1;
  let lastResultsIdx = -1;
  history.forEach((m, i) => {
    if (m.role !== "user") return;
    tailUserIdx = i;
    if (!m.hidden) lastUserIdx = i;
    if (isActionResults(m)) lastResultsIdx = i;
  });
  return history.map((m, i) => {
    const isLast = i === lastUserIdx;
    let content = isLast ? m.apiContent ?? m.content : m.apiContent ? `${m.content}\n${CONTEXT_NOTE}` : m.content;
    if (isActionResults(m) && i !== lastResultsIdx) content = collapseActionResults(m.content);
    if (m.role === "assistant") content += pendingSummary(m);
    if (i === tailUserIdx) {
      // Tell the model about action blocks it got wrong last turn.
      const prevAssistant = [...history.slice(0, i)].reverse().find((x) => x.role === "assistant");
      const fb = prevAssistant ? invalidActionFeedback(prevAssistant.content) : null;
      if (fb) content = `${content}\n\n${fb}`;
    }
    return {
      role: m.role,
      content,
      images: i >= history.length - 6 ? m.images : undefined,
      // Audio is heavy: it goes out only with the turn it was attached to, in its real format.
      audio: i === lastUserIdx && m.audios?.length ? m.audios.map((data, k) => ({ data, mime: dataUrlMime(data), name: `Attached audio ${k + 1}` })) : undefined,
    };
  });
}

export async function runAssistant(threadId: string, lockHeld = false) {
  if (!lockHeld) {
    if (isBusy()) return;
    inFlight = true;
  }
  const st = useApp.getState();
  let projectId: string | null = null;
  try {
    const thread = await db.threads.get(threadId);
    if (!thread) return;
    projectId = thread.projectId;
    useLive.getState().begin(thread.projectId);
    const project = await db.projects.get(thread.projectId);
    if (!project) return;

    const dev = useSettings.getState().developerMode;
    const resolved = dev ? { provider: MOCK_PROVIDER, model: MOCK_PROVIDER.defaultModel } : await resolveProvider(thread);
    if (!resolved || !resolved.model) {
      st.setAgentActivity("blocked", thread.projectId, "provider");
      await db.messages.add({
        id: uid(),
        threadId,
        projectId: thread.projectId,
        role: "assistant",
        content: resolved
          ? "This provider has no model selected. Pick a model in the chat header or in Settings."
          : "Leo needs an AI provider to think with. Open **Settings → AI providers** to add one (OpenAI, Anthropic, Gemini, OpenRouter, Ollama…). Your library stays on this device; requests go straight from your browser to the provider.",
        error: true,
        createdAt: Date.now(),
      });
      return;
    }

    if (thread.mode === "placement" && project.placement.status === "pending") {
      await db.projects.update(project.id, { placement: { ...project.placement, status: "in_progress" } });
    }

    // Agent loop: each step streams one reply, runs its actions, then — when something was read
    // or something failed — feeds the outcome back so the model can finish the turn properly.
    const MAX_STEPS = 6;
    let turnError: string | null = null;
    let turnHasText = false;

    // Auto-retrieval runs once per learner turn, not per step: it is a head start; Leo can search and
    // read the library itself with actions during the loop.
    let sources = "";
    let citations: CitationRef[] = [];
    let query = "";
    {
      const all = await db.messages.where("threadId").equals(threadId).sortBy("createdAt");
      query = retrievalQuery(all);
      try {
        const hits = query ? await retrieve(project.id, query, useSettings.getState().retrievalTopK) : [];
        if (hits.length) {
          sources = formatSources(hits);
          citations = citationsOf(hits);
        }
      } catch (e) {
        console.warn("retrieval failed", e);
      }
    }

    for (let step = 1; step <= MAX_STEPS; step++) {
      const all = await db.messages.where("threadId").equals(threadId).sortBy("createdAt");
      const history = buildHistory(all);
      const browserRow = await db.kv.get("browser.current");
      const captured = browserRow?.value as { url?: string; title?: string } | undefined;
      const browserCtx = useApp.getState().browser;
      const msgs =
        history.length && useApp.getState().browserOpen && captured?.url && browserCtx?.url === captured.url
          ? history.map((m, i) =>
              i === history.length - 1 && m.role === "user"
                ? { ...m, content: `${m.content}\n\n<workspace_context>\n## Browser page: ${browserCtx.title} (${browserCtx.url})\n${(browserCtx.selection || browserCtx.text).slice(0, 12000)}\n</workspace_context>` }
                : m
            )
          : history;
      const system = await buildSystemPrompt(project, thread.mode, sources || undefined, query);

      const ac = new AbortController();
      st.setAbort(ac);
      st.setAgentActivity("thinking", thread.projectId);
      st.setStreaming({ threadId, content: "" });
      let content = "";
      let lastFlush = 0;
      let error: string | null = null;
      let aborted = false;
      // True while an action block is mid-stream: the avatar switches to "working" and the dock shows
      // what Leo is doing ("Drawing a sketch…") instead of a generic label.
      let inAction = false;
      // Reported by the provider while the request is built and the stream closes (see streamChat).
      let streamMeta: StreamMeta = {};
      const onMeta = (m: StreamMeta) => {
        streamMeta = { ...streamMeta, ...m };
      };
      const startedAt = performance.now();
      try {
        const source = dev
          ? streamMockChat(project, thread.mode, msgs, { delay: useSettings.getState().mockDelay, behavior: useSettings.getState().mockBehavior }, ac.signal)
          : streamChat(resolved.provider, resolved.model, system, msgs, ac.signal, onMeta);
        for await (const chunk of source) {
          const hadText = content.trim().length > 0;
          content += chunk;
          if (!hadText && content.trim()) useApp.getState().setAgentActivity("idle", thread.projectId);
          const t = performance.now();
          if (t - lastFlush > 60) {
            lastFlush = t;
            useApp.getState().setStreaming({ threadId, content });
            // A note or sketch Leo is about to change comes into view while he is still writing the change.
            earlyReveal(thread.projectId, content);
            const open = progressHint(content) !== null;
            if (open !== inAction) {
              inAction = open;
              useApp.getState().setAgentActivity(open ? "working" : "idle", thread.projectId);
            }
          }
        }
      } catch (e) {
        if (ac.signal.aborted) aborted = true;
        else {
          error = e instanceof Error ? e.message : String(e);
          if (e instanceof DOMException && e.name === "TimeoutError") error = "The provider did not respond in time.";
          else if (error === "Failed to fetch" || error.includes("NetworkError") || error.includes("Load failed"))
            error += " — the provider may block browser requests (CORS), the URL may be wrong, or you're offline.";
        }
      }

      // The whole reply is on screen (finished action blocks included) while its actions run.
      if (content) useApp.getState().setStreaming({ threadId, content });
      const complete = !error && !aborted;
      const hasText = content.trim().length > 0;
      turnError = error;
      turnHasText = hasText;
      const id = uid();
      // What this turn was sent and what came back (model, cap, finish reason, size, duration) — kept
      // for the chat-log export. Provider settings other than type/base URL stay out; never the key.
      const turn: TurnMeta = {
        model: resolved.model,
        provider: resolved.provider.name,
        providerType: resolved.provider.type,
        baseUrl: resolved.provider.baseUrl,
        maxTokens: streamMeta.maxTokens ?? "not sent",
        chars: content.length,
        durationMs: Math.round(performance.now() - startedAt),
        ...(streamMeta.finishReason ? { finishReason: streamMeta.finishReason } : {}),
        ...(error ? { error } : {}),
        ...(aborted ? { error: "stopped by the learner" } : {}),
        systemPrompt: system,
      };
      let actions: Action[] = [];
      if (hasText) {
        // A truncated stream is never executed: half-emitted action blocks must not touch the workspace.
        actions = complete ? extractActions(content) : [];
        if (actions.length) st.setAgentActivity("working", thread.projectId);
        const report: ExecutionReport = actions.length ? await executeActions(thread.projectId, threadId, actions) : { results: [], read: [], pending: [] };
        const failed = report.results.filter((r) => !r.ok);
        const more = step < MAX_STEPS && (report.read.length > 0 || failed.length > 0);
        await db.messages.add({
          id,
          threadId,
          projectId: thread.projectId,
          role: "assistant",
          content,
          // The learner sees the final text; steps that only fetch material stay between us and the model.
          // A step that proposes a change needing approval stays visible so its Apply / Dismiss can be used.
          hidden: more && !actions.some((x) => x.type === "ask" || x.type === "quiz") && !report.pending.length ? true : undefined,
          partial: complete ? undefined : true,
          createdAt: Date.now(),
          actionResults: report.results.length ? report.results : undefined,
          citations: citations.length ? citations : undefined,
          pending: report.pending.length ? report.pending : undefined,
          turn,
        });
        if (more) {
          await db.messages.add({
            id: uid(),
            threadId,
            projectId: thread.projectId,
            role: "user",
            hidden: true,
            content: `<action_results>\n${[...report.read, ...failed.map((r) => `- FAILED ${r.type}: ${r.label}`)].join("\n")}\n</action_results>`,
            images: report.images?.length ? report.images : undefined,
            createdAt: Date.now() + 1,
          });
          continue;
        }
      }
      if (error || (complete && !hasText)) {
        await db.messages.add({
          id: uid(),
          threadId,
          projectId: thread.projectId,
          role: "assistant",
          content: error
            ? `**Request failed** (${resolved.provider.name} · ${resolved.model})\n\n${error}`
            : `**Empty reply** (${resolved.provider.name} · ${resolved.model}) — the model returned no text. Retry, or try another model.`,
          error: true,
          createdAt: Date.now() + 1,
          turn: { ...turn, error: error ?? "empty reply" },
        });
        turnError = error ?? "empty";
      }
      break;
    }
    await db.threads.update(threadId, { updatedAt: Date.now() });
    await db.projects.update(thread.projectId, { updatedAt: Date.now() });
    useApp.getState().setAgentActivity(turnError ? "blocked" : turnHasText ? "done" : "idle", thread.projectId, turnError ? "error" : undefined);
  } catch (e) {
    // Anything unexpected (quota, IndexedDB closed) still releases the lock and tells the user.
    console.error(e);
    if (projectId) {
      useApp.getState().setAgentActivity("blocked", projectId, "error");
      useApp.getState().showToast(`Chat error: ${e instanceof Error ? e.message : String(e)}`);
    }
  } finally {
    inFlight = false;
    useApp.getState().setStreaming(null);
    useApp.getState().setAbort(null);
  }
}

export function stopStreaming() {
  useApp.getState().abort?.abort();
}

/** Retry after a failure: remove the error banner AND any partial reply so the history ends on the user's turn. */
export async function retry(errorMessage: Message) {
  if (isBusy()) return;
  const all = await db.messages.where("threadId").equals(errorMessage.threadId).sortBy("createdAt");
  const lastUserIdx = all.map((m) => m.role).lastIndexOf("user");
  const stale = all.slice(lastUserIdx + 1).filter((m) => m.role === "assistant" && (m.error || m.partial));
  await db.messages.bulkDelete([...new Set([errorMessage.id, ...stale.map((m) => m.id)])]);
  await runAssistant(errorMessage.threadId);
}

/** Open Leo and send a message in the current conversation (starting one if needed). */
export async function askLeo(projectId: string, prompt: string, opts: { newChat?: boolean } = {}) {
  const st = useApp.getState();
  // Claim the conversation before the panel opens, so the panel shows this one (see withThreadSetup).
  const ready = isBusy()
    ? null
    : withThreadSetup(projectId, async () => {
        let thread: Thread | undefined;
        if (!opts.newChat) {
          const id = useApp.getState().activeThread[projectId];
          const t = id ? await db.threads.get(id) : undefined;
          const project = await db.projects.get(projectId);
          // Don't mix study requests into an unfinished placement conversation.
          if (t && !(t.mode === "placement" && project?.placement.status !== "done")) thread = t;
        }
        thread ??= await createThread(projectId, "ask");
        st.setActiveThread(projectId, thread.id);
        return thread;
      });
  st.setChatOpen(true);
  if (!ready) return;
  const thread = await ready;
  await sendMessage({ threadId: thread.id, text: prompt });
}

/** Start (or continue, or restart) the adaptive placement conversation with Leo. */
export async function startPlacement(projectId: string, opts: { restart?: boolean } = {}) {
  const st = useApp.getState();
  // Claim the conversation before the panel opens, so the panel shows the placement chat rather
  // than creating an empty one on top of it (see withThreadSetup).
  const ready = isBusy()
    ? null
    : withThreadSetup(projectId, async (): Promise<Thread | null> => {
        const project = await db.projects.get(projectId);
        if (!project) return null;
        if (!opts.restart && project.placement.status === "in_progress") {
          const threads = await db.threads.where("projectId").equals(projectId).sortBy("updatedAt");
          const existing = threads.reverse().find((t) => t.mode === "placement");
          if (existing) {
            st.setActiveThread(projectId, existing.id);
            return null;
          }
        }
        if (opts.restart || project.placement.status !== "pending") await db.projects.update(projectId, { placement: { status: "pending" }, updatedAt: Date.now() });
        return createThread(projectId, "placement");
      });
  st.setChatOpen(true);
  if (!ready) return;
  const thread = await ready;
  if (thread) await sendMessage({ threadId: thread.id, text: PLACEMENT_KICKOFF, hidden: true });
}

const answering = new Set<string>();

export async function answerAction(message: Message, index: number, action: Action, choice: number) {
  const key = `${message.id}:${index}`;
  if (isBusy() || answering.has(key)) return;
  answering.add(key);
  try {
    const fresh = await db.messages.get(message.id);
    if (!fresh || (fresh.answers && fresh.answers[index] !== undefined)) return;
    const previousAnswers = fresh.answers ?? {};
    await db.messages.update(message.id, { answers: { ...previousAnswers, [index]: choice } });
    let sent = false;
    const correct = action.type === "quiz" && choice === action.answer;
    try {
      if (action.type === "quiz") {
        if (action.concept) await recordQuizResult(message.projectId, action.concept, correct);
        const chosen = action.options[choice];
        const right = action.options[action.answer];
        sent = await sendMessage({
          threadId: message.threadId,
          text: chosen,
          apiContent: `Quiz answer — question: "${action.question}". I chose "${chosen}". That is ${correct ? "CORRECT" : `INCORRECT (correct answer: "${right}")`}.`,
        });
      } else if (action.type === "ask") {
        const chosen = action.options[choice];
        sent = await sendMessage({ threadId: message.threadId, text: chosen, apiContent: `(Answer to "${action.question}") ${chosen}` });
      }
    } finally {
      if (!sent) {
        // The send was refused (another request started first): undo so the learner can tap again.
        await db.messages.update(message.id, { answers: previousAnswers });
        if (action.type === "quiz" && action.concept) await revertQuizResult(message.projectId, action.concept, correct);
      }
    }
  } finally {
    answering.delete(key);
  }
}

/** The learner thinks the answer key was wrong: revert the stat and tell the model. */
export async function disputeAnswer(message: Message, index: number, action: Extract<Action, { type: "quiz" }>) {
  if (isBusy()) return;
  const fresh = await db.messages.get(message.id);
  const choice = fresh?.answers?.[index];
  if (!fresh || choice === undefined || fresh.disputed?.includes(index)) return;
  const wasCorrect = choice === action.answer;
  if (action.concept) await revertQuizResult(message.projectId, action.concept, wasCorrect);
  await db.messages.update(message.id, { disputed: [...(fresh.disputed ?? []), index] });
  await sendMessage({
    threadId: message.threadId,
    text: "I think that answer key is wrong.",
    apiContent: `I dispute the key for "${action.question}". You marked "${action.options[action.answer]}" as correct; I chose "${action.options[choice]}". Re-check carefully, explain, and if you were wrong say so plainly and use an assess action to record the corrected result for "${action.concept ?? "the concept"}". The original grade has been reverted.`,
  });
}

const resolving = new Set<string>();

/** The learner pressed Apply or Dismiss on a change Leo proposed (learner-note replace, memory delete). */
export async function resolvePending(messageId: string, pendingId: string, apply: boolean) {
  const key = `${messageId}:${pendingId}`;
  if (resolving.has(key)) return;
  resolving.add(key);
  try {
    const m = await db.messages.get(messageId);
    const p = m?.pending?.find((x) => x.id === pendingId);
    if (!m || !p || p.status !== "pending") return;
    let next: typeof p;
    if (!apply) next = { ...p, status: "dismissed" };
    else {
      const r = await applyApprovedAction(m.projectId, p.action as unknown as Action);
      next = { ...p, status: r.ok ? "applied" : "failed", result: r.label };
      useApp.getState().showToast(r.ok ? r.label : `Couldn't apply: ${r.label}`);
    }
    const fresh = await db.messages.get(messageId);
    await db.messages.update(messageId, { pending: (fresh?.pending ?? m.pending ?? []).map((x) => (x.id === pendingId ? next : x)) });
  } finally {
    resolving.delete(key);
  }
}

export const threadPreview = (m?: Message) => (m ? stripActions(m.content).slice(0, 80) : "");
