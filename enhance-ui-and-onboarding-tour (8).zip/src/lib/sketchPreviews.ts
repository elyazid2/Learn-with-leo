import { db, type Sketch } from "./db";

export type SketchTheme = "light" | "dark";
export const SKETCH_PREVIEW_VERSION = 1;
export const SKETCH_CARD_BG = { light: "#ffffff", dark: "#1a1b1e" } as const;

export function sketchFingerprint(scene: string): string {
  let hash = 2166136261;
  for (let i = 0; i < scene.length; i++) hash = Math.imul(hash ^ scene.charCodeAt(i), 16777619);
  return `${scene.length}:${(hash >>> 0).toString(36)}`;
}

export function hasSketchPreviews(sketch: Sketch) {
  return sketch.thumbVersion === SKETCH_PREVIEW_VERSION && sketch.thumbScene === sketchFingerprint(sketch.scene) && typeof sketch.thumbLight === "string" && typeof sketch.thumbDark === "string";
}

export function sketchPreview(sketch: Sketch, theme: SketchTheme): string | null {
  if (!hasSketchPreviews(sketch)) return null;
  return (theme === "dark" ? sketch.thumbDark : sketch.thumbLight) || null;
}

async function renderPreview(scene: string, theme: SketchTheme): Promise<string> {
  const parsed = JSON.parse(scene || "{}") as { elements?: { isDeleted?: boolean }[]; appState?: Record<string, unknown>; files?: Record<string, unknown> };
  const elements = parsed.elements?.filter((e) => !e.isDeleted) ?? [];
  if (!elements.length) return "";
  await import("./excalidrawFonts");
  const { exportToCanvas } = await import("@excalidraw/excalidraw");
  const drawing = await exportToCanvas({
    elements: elements as never,
    appState: { ...parsed.appState, exportBackground: false, exportWithDarkMode: theme === "dark", viewBackgroundColor: "#ffffff" },
    files: (parsed.files ?? {}) as never,
    maxWidthOrHeight: 420,
    exportPadding: 18,
  });
  // Excalidraw filters the whole export in dark mode. Composite its transparent dark-mode drawing
  // onto our card colour afterwards, so the background is exactly the surrounding surface.
  const canvas = document.createElement("canvas");
  canvas.width = drawing.width;
  canvas.height = drawing.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("A canvas could not be created for the sketch preview.");
  ctx.fillStyle = SKETCH_CARD_BG[theme];
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(drawing, 0, 0);
  const data = canvas.toDataURL("image/png");
  canvas.width = canvas.height = drawing.width = drawing.height = 0;
  return data;
}

const queue = new Set<string>();
const attempted = new Map<string, string>();
let running = false;

/** One render at a time. Both themes are cached so changing themes never flashes a white image. */
export function queueSketchPreviews(id: string) {
  queue.add(id);
  if (!running) void drain();
}

async function drain() {
  running = true;
  try {
    while (queue.size) {
      const id = queue.values().next().value as string;
      queue.delete(id);
      const sketch = await db.sketches.get(id);
      if (!sketch || hasSketchPreviews(sketch)) continue;
      const key = sketchFingerprint(sketch.scene);
      if (attempted.get(id) === key) continue;
      attempted.set(id, key);
      try {
        const light = await renderPreview(sketch.scene, "light");
        const dark = await renderPreview(sketch.scene, "dark");
        const latest = await db.sketches.get(id);
        if (!latest) continue;
        if (sketchFingerprint(latest.scene) !== key) { queue.add(id); continue; }
        // Preview maintenance must not reorder the library or change the saved drawing.
        await db.sketches.update(id, { thumb: light, thumbLight: light, thumbDark: dark, thumbScene: key, thumbVersion: SKETCH_PREVIEW_VERSION });
        attempted.delete(id);
      } catch (e) {
        console.warn("Sketch preview could not be regenerated", id, e);
      }
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  } finally { running = false; }
}