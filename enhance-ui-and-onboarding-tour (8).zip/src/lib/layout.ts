import { create } from "zustand";
import { projectPath, type Route } from "./router";
import { useApp } from "./store";

/** Where Leo's chat sits: floating over the page, docked beside or below it, or filling the screen. */
export type ChatDock = "float" | "right" | "left" | "bottom" | "full";
export type SplitDir = "row" | "column";
/** A pane shown fullscreen (the chat has its own "full" dock). */
export type Focus = "main" | "side" | null;

/** What a pane can show. The main pane follows the address; the second pane holds one of these. */
export type PaneTarget =
  | { kind: "library" }
  | { kind: "file"; id: string }
  | { kind: "note"; id: string }
  | { kind: "sketch"; id: string }
  | { kind: "browser" };

export const targetKey = (t: PaneTarget | null) => (t ? `${t.kind}:${"id" in t ? t.id : ""}` : "");
export const sameTarget = (a: PaneTarget | null, b: PaneTarget | null) => !!a && !!b && targetKey(a) === targetKey(b);

/** The item the main pane is showing for a project route. */
export function routeTarget(route: Extract<Route, { name: "project" }>): PaneTarget {
  if (route.itemId && route.tab === "library") return { kind: "file", id: route.itemId };
  if (route.itemId && route.tab === "notes") return { kind: "note", id: route.itemId };
  if (route.itemId && route.tab === "sketch") return { kind: "sketch", id: route.itemId };
  return { kind: "library" };
}

export function targetPath(projectId: string, t: PaneTarget) {
  if (t.kind === "file") return projectPath(projectId, "library", t.id);
  if (t.kind === "note") return projectPath(projectId, "notes", t.id);
  if (t.kind === "sketch") return projectPath(projectId, "sketch", t.id);
  return projectPath(projectId);
}

/** A named layout state: how many panes, how they are split, and where the chat goes. */
export interface Arrangement {
  id: string;
  label: string;
  split: "none" | SplitDir;
  chat: ChatDock;
  focus?: "main" | "side";
}

export const ARRANGEMENTS: Arrangement[] = [
  { id: "one", label: "One pane", split: "none", chat: "float" },
  { id: "one-right", label: "Leo on the right", split: "none", chat: "right" },
  { id: "one-left", label: "Leo on the left", split: "none", chat: "left" },
  { id: "one-below", label: "Leo below", split: "none", chat: "bottom" },
  { id: "two", label: "Side by side", split: "row", chat: "float" },
  { id: "two-right", label: "Side by side + Leo", split: "row", chat: "right" },
  { id: "two-left", label: "Leo + side by side", split: "row", chat: "left" },
  { id: "two-below", label: "Side by side, Leo below", split: "row", chat: "bottom" },
  { id: "stack", label: "Stacked", split: "column", chat: "float" },
  { id: "stack-right", label: "Stacked + Leo", split: "column", chat: "right" },
  { id: "stack-left", label: "Leo + stacked", split: "column", chat: "left" },
  { id: "stack-below", label: "Stacked, Leo below", split: "column", chat: "bottom" },
  { id: "full-main", label: "Fullscreen page", split: "none", chat: "float", focus: "main" },
  { id: "full-side", label: "Fullscreen second pane", split: "none", chat: "float", focus: "side" },
  { id: "full-chat", label: "Fullscreen Leo", split: "none", chat: "full" },
];

interface Saved {
  chatDock: ChatDock;
  splitDir: SplitDir;
  /** Share of the split given to the main pane. */
  ratio: number;
  /** Share of the screen given to a docked chat. */
  chatShare: number;
}

interface LayoutStore extends Saved {
  side: PaneTarget | null;
  sideProject: string | null;
  lastSide: PaneTarget | null;
  focus: Focus;
  /**
   * Where the chat sits for now, when Leo moved it aside to show his work. The saved preference
   * (chatDock) is untouched; choosing a position, or closing the chat, ends the override.
   */
  tempDock: ChatDock | null;
  /** Second pane first (left / top). */
  swapped: boolean;
  setChatDock: (dock: ChatDock) => void;
  setTempDock: (dock: ChatDock | null) => void;
  setRatio: (ratio: number) => void;
  setChatShare: (share: number) => void;
  setFocus: (focus: Focus) => void;
  swap: () => void;
  openSide: (projectId: string, target: PaneTarget) => void;
  closeSide: () => void;
  leaveProject: () => void;
  apply: (projectId: string, arrangement: Arrangement, main: PaneTarget) => void;
}

const KEY = "harness.layout";
const DEFAULTS: Saved = { chatDock: "float", splitDir: "row", ratio: 0.5, chatShare: 0.34 };
const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

function readSaved(): Saved {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "{}") as Partial<Saved>;
    return {
      chatDock: (["float", "right", "left", "bottom", "full"] as const).includes(raw.chatDock as ChatDock) ? (raw.chatDock as ChatDock) : DEFAULTS.chatDock,
      splitDir: raw.splitDir === "column" ? "column" : "row",
      ratio: typeof raw.ratio === "number" ? clamp(raw.ratio, 0.2, 0.8) : DEFAULTS.ratio,
      chatShare: typeof raw.chatShare === "number" ? clamp(raw.chatShare, 0.22, 0.6) : DEFAULTS.chatShare,
    };
  } catch {
    return DEFAULTS;
  }
}

/** The second pane's default partner: the browser next to the library, the library next to a document. */
export const defaultSide = (main: PaneTarget): PaneTarget => (main.kind === "library" ? { kind: "browser" } : { kind: "library" });

export const useLayout = create<LayoutStore>((set, get) => ({
  ...readSaved(),
  side: null,
  sideProject: null,
  lastSide: null,
  focus: null,
  tempDock: null,
  swapped: false,
  setChatDock: (chatDock) => set({ chatDock, tempDock: null }),
  setTempDock: (tempDock) => set({ tempDock }),
  setRatio: (ratio) => set({ ratio: clamp(ratio, 0.2, 0.8) }),
  setChatShare: (chatShare) => set({ chatShare: clamp(chatShare, 0.22, 0.6) }),
  setFocus: (focus) => set({ focus }),
  swap: () => set({ swapped: !get().swapped }),
  openSide: (projectId, target) => set({ side: target, sideProject: projectId, lastSide: target, focus: get().focus === "main" ? null : get().focus }),
  closeSide: () => set({ side: null, focus: get().focus === "side" ? null : get().focus }),
  leaveProject: () => set({ side: null, sideProject: null, lastSide: null, focus: null, tempDock: null }),
  apply: (projectId, a, main) => {
    const s = get();
    const side = s.sideProject === projectId ? s.side : null;
    const partner = s.lastSide && s.sideProject === projectId && !sameTarget(s.lastSide, main) ? s.lastSide : defaultSide(main);
    if (a.focus) {
      if (a.focus === "side" && !side) set({ side: partner, sideProject: projectId, lastSide: partner });
      set({ focus: a.focus });
      return;
    }
    if (a.chat === "full") {
      set({ chatDock: "full", tempDock: null, focus: null });
      useApp.getState().setChatOpen(true);
      return;
    }
    if (a.split === "none") set({ chatDock: a.chat, tempDock: null, focus: null, side: null });
    else if (side) set({ chatDock: a.chat, tempDock: null, focus: null, splitDir: a.split });
    else set({ chatDock: a.chat, tempDock: null, focus: null, splitDir: a.split, side: partner, sideProject: projectId, lastSide: partner });
    if (a.chat !== "float") useApp.getState().setChatOpen(true);
  },
}));

useLayout.subscribe((s) => {
  try {
    localStorage.setItem(KEY, JSON.stringify({ chatDock: s.chatDock, splitDir: s.splitDir, ratio: s.ratio, chatShare: s.chatShare }));
  } catch {
    /* storage unavailable: the layout simply resets next time */
  }
});

/** Where the chat is right now: Leo's temporary placement if there is one, else the saved preference. */
export const dockOf = (s: { chatDock: ChatDock; tempDock: ChatDock | null }) => s.tempDock ?? s.chatDock;

/** Phones have no room for columns: side-by-side becomes stacked, and a side-docked chat goes below. */
export const NARROW = 768;
export const effectiveDock = (dock: ChatDock, small: boolean): ChatDock => (small && (dock === "left" || dock === "right") ? "bottom" : dock);
