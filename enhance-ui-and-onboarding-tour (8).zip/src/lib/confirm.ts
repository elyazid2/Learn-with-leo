import { create } from "zustand";

export interface ConfirmOptions {
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  tone?: "danger" | "default";
}

interface ConfirmRequest extends ConfirmOptions {
  id: number;
  resolve: (ok: boolean) => void;
}

interface ConfirmStore {
  current: ConfirmRequest | null;
  queue: ConfirmRequest[];
  ask: (opts: ConfirmOptions) => Promise<boolean>;
  settle: (ok: boolean) => void;
}

let seq = 0;

/**
 * In-app replacement for window.confirm(): same yes/no semantics, but styled like the rest of
 * Harness, keyboard accessible, and stacked above sheets. Requests queue so two never collide.
 */
export const useConfirm = create<ConfirmStore>((set, get) => ({
  current: null,
  queue: [],
  ask: (opts) =>
    new Promise<boolean>((resolve) => {
      const req: ConfirmRequest = { ...opts, id: ++seq, resolve };
      if (get().current) set({ queue: [...get().queue, req] });
      else set({ current: req });
    }),
  settle: (ok) => {
    const { current, queue } = get();
    if (!current) return;
    current.resolve(ok);
    set({ current: queue[0] ?? null, queue: queue.slice(1) });
  },
}));

export function confirmDialog(opts: ConfirmOptions | string): Promise<boolean> {
  return useConfirm.getState().ask(typeof opts === "string" ? { message: opts } : opts);
}
