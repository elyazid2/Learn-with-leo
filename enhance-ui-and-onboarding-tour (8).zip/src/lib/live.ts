import { create } from "zustand";
import { db } from "./db";
import { navigate, parseHash } from "./router";
import { NARROW, routeTarget, sameTarget, targetPath, useLayout, type PaneTarget } from "./layout";
import { useApp } from "./store";
import { useSettings } from "./settings";

/**
 * The stage for Leo's tools. When Leo acts on the workspace, the work is shown where it happens:
 * the sketch opens and its shapes appear one by one, a note opens and its text is written out, and
 * the chat carries a plain-language status for every step.
 *
 * Data is always saved first. What plays on the stage is a replay of the saved result, so closing
 * the tab halfway can never leave a half-written note or sketch behind.
 */

/** No window (unit tests, server): nothing is staged and nothing waits. */
const HEADLESS = typeof window === "undefined" || typeof document === "undefined";

export const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

function motionOk() {
  if (HEADLESS) return false;
  if (useSettings.getState().reduceMotion) return false;
  return !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}

export interface LiveStep {
  id: number;
  /** The action type, used for the step's icon. */
  type: string;
  label: string;
  detail?: string;
  /** 0..1 while a long step (drawing, writing) is under way. */
  progress?: number;
  state: "running" | "done" | "failed";
}

interface LiveStore {
  projectId: string | null;
  steps: LiveStep[];
  /** Text Leo is writing into a note right now. The note editor shows this instead of its own draft. */
  note: { noteId: string; content: string } | null;
  /** The sketch Leo is drawing right now. Its canvas starts empty and does not save until he is done. */
  sketchId: string | null;
  begin: (projectId: string) => void;
  patch: (id: number, patch: Partial<LiveStep>) => void;
}

let seq = 0;

export const useLive = create<LiveStore>((set, get) => ({
  projectId: null,
  steps: [],
  note: null,
  sketchId: null,
  begin: (projectId) => set({ projectId, steps: [] }),
  patch: (id, patch) => set({ steps: get().steps.map((s) => (s.id === id ? { ...s, ...patch } : s)) }),
}));

async function waitFor<T>(probe: () => T | null | undefined | false, ms: number): Promise<T | null> {
  const t0 = Date.now();
  for (;;) {
    const value = probe();
    if (value) return value;
    if (Date.now() - t0 > ms) return null;
    await sleep(60);
  }
}

/** True when the learner is looking at this project, so there is somewhere to show the work. */
function onProject(projectId: string) {
  if (HEADLESS) return false;
  const route = parseHash(window.location.hash);
  return route.name === "project" && route.projectId === projectId;
}

async function exists(projectId: string, t: PaneTarget) {
  if (t.kind === "note") return (await db.notes.get(t.id))?.projectId === projectId;
  if (t.kind === "sketch") return (await db.sketches.get(t.id))?.projectId === projectId;
  if (t.kind === "file") return (await db.files.get(t.id))?.projectId === projectId;
  return true;
}

/**
 * Bring an item into view without throwing away what the learner has open: it replaces the library,
 * or opens beside a document on wide screens. A chat that covers the work steps aside.
 */
export async function reveal(projectId: string, target: PaneTarget): Promise<boolean> {
  if (!onProject(projectId) || !(await exists(projectId, target))) return false;
  const route = parseHash(window.location.hash);
  if (route.name !== "project") return false;
  const main = routeTarget(route);
  const layout = useLayout.getState();
  const small = window.innerWidth < NARROW;
  // A chat that floats over the work, or fills the screen, moves beside it while Leo works. This is
  // a placement for now, not a change to where the learner keeps the chat.
  const dock = layout.tempDock ?? layout.chatDock;
  if (useApp.getState().chatOpen && (dock === "full" || dock === "float")) layout.setTempDock(small ? "bottom" : "right");
  const side = layout.sideProject === projectId ? layout.side : null;
  if (sameTarget(main, target)) {
    if (layout.focus === "side") layout.setFocus(null);
    return true;
  }
  if (side && sameTarget(side, target)) {
    if (layout.focus === "main") layout.setFocus(null);
    return true;
  }
  if (layout.focus) layout.setFocus(null);
  if (main.kind === "library" || small) navigate(targetPath(projectId, target));
  else layout.openSide(projectId, target);
  return true;
}

let lastEarly = "";

/**
 * While an action is still streaming, open the note or sketch it is about to change, so the
 * learner is already looking at it when the change lands.
 */
export function earlyReveal(projectId: string, content: string) {
  if (HEADLESS) return;
  const at = content.lastIndexOf("```action");
  if (at < 0) return;
  const tail = content.slice(at + 9);
  if (/\n[ \t]*```/.test(tail)) return; // the block already closed
  const type = /"type"\s*:\s*"(edit_sketch|note)"/.exec(tail)?.[1];
  const id = /"id"\s*:\s*"([A-Za-z0-9_-]{4,40})"/.exec(tail)?.[1];
  if (!type || !id) return;
  const key = `${projectId}:${at}:${type}:${id}`;
  if (key === lastEarly) return;
  lastEarly = key;
  void reveal(projectId, { kind: type === "note" ? "note" : "sketch", id });
}

const wordCount = (s: string) => (s.trim() ? s.trim().split(/\s+/).length : 0);

/** Excalidraw elements Leo draws: a shape and the label bound to it appear together. */
interface Drawn {
  id?: string;
  containerId?: string | null;
}

function drawingUnits(elements: readonly Drawn[]): Drawn[][] {
  const bound = new Map<string, Drawn[]>();
  for (const e of elements) {
    if (!e.containerId) continue;
    const list = bound.get(e.containerId) ?? [];
    list.push(e);
    bound.set(e.containerId, list);
  }
  const units: Drawn[][] = [];
  for (const e of elements) if (!e.containerId) units.push([e, ...(bound.get(e.id ?? "") ?? [])]);
  return units;
}

const canvasFor = (sketchId: string) => {
  const api = useApp.getState().sketchApi;
  return api && api.sketchId === sketchId ? api : null;
};

export const stage = {
  start(type: string, label: string): number {
    const id = ++seq;
    useLive.setState({ steps: [...useLive.getState().steps, { id, type, label, state: "running" }] });
    return id;
  },

  finish(id: number, ok: boolean, label?: string) {
    useLive.getState().patch(id, { state: ok ? "done" : "failed", progress: undefined, detail: undefined, ...(label ? { label } : {}) });
  },

  /** A short beat between steps, so each status can be read. */
  breathe(): Promise<void> {
    return motionOk() ? sleep(220) : Promise.resolve();
  },

  /** Keep an open editor on its current text until the change is written out in front of the learner. */
  holdNote(noteId: string, content: string) {
    if (!motionOk() || !document.querySelector(`[data-note-editor="${noteId}"]`)) return;
    useLive.setState({ note: { noteId, content } });
  },

  releaseNote() {
    if (useLive.getState().note) useLive.setState({ note: null });
  },

  /** Open the note and write the new text into it, word by word. The note itself is already saved. */
  async typeNote(projectId: string, stepId: number, noteId: string, from: string, to: string) {
    const done = () => useLive.setState({ note: null });
    if (!motionOk() || !onProject(projectId) || from === to) return done();
    useLive.setState({ note: { noteId, content: from } });
    const shown = await reveal(projectId, { kind: "note", id: noteId });
    if (!shown || !(await waitFor(() => document.querySelector(`[data-note-editor="${noteId}"]`), 3000))) return done();
    let keep = 0;
    while (keep < from.length && keep < to.length && from[keep] === to[keep]) keep++;
    const rest = to.length - keep;
    const duration = Math.min(4200, Math.max(700, rest * 6));
    const total = wordCount(to);
    const t0 = performance.now();
    for (;;) {
      const k = Math.min(1, (performance.now() - t0) / duration);
      let cut = keep + Math.round(rest * k);
      while (k < 1 && cut < to.length && !/\s/.test(to[cut])) cut++;
      const text = to.slice(0, cut);
      useLive.setState({ note: { noteId, content: text } });
      useLive.getState().patch(stepId, { progress: k, detail: `${wordCount(text)} of ${total} words` });
      if (k >= 1) break;
      await sleep(40);
    }
    await sleep(300);
    done();
  },

  /** Open a freshly saved sketch on an empty canvas and add its shapes one at a time. */
  async drawSketch(projectId: string, stepId: number, sketchId: string, elements: readonly Drawn[]) {
    if (!motionOk() || !onProject(projectId) || !elements.length) return;
    useLive.setState({ sketchId });
    try {
      const shown = await reveal(projectId, { kind: "sketch", id: sketchId });
      const api = shown ? await waitFor(() => canvasFor(sketchId), 8000) : null;
      if (!api) return;
      const units = drawingUnits(elements);
      api.fit?.(elements);
      await sleep(350);
      const pace = Math.min(320, Math.max(90, 4200 / units.length));
      const visible: Drawn[] = [];
      for (let i = 0; i < units.length; i++) {
        visible.push(...units[i]);
        api.updateScene({ elements: [...visible] });
        useLive.getState().patch(stepId, { progress: (i + 1) / units.length, detail: `${i + 1} of ${units.length} ${units.length === 1 ? "shape" : "shapes"}` });
        await sleep(pace);
      }
      api.updateScene({ elements: [...elements] });
      api.fit?.(elements);
      await sleep(250);
    } finally {
      useLive.setState({ sketchId: null });
      canvasFor(sketchId)?.save?.();
    }
  },

  /** Open an existing sketch so each change to it can be painted as it is made. */
  async editSketch(projectId: string, stepId: number, sketchId: string) {
    const idle = { paint: async (_elements: readonly unknown[], _done: number, _total: number) => {}, done: () => {} };
    if (!motionOk() || !onProject(projectId)) return idle;
    const shown = await reveal(projectId, { kind: "sketch", id: sketchId });
    const api = shown ? await waitFor(() => canvasFor(sketchId), 8000) : null;
    if (!api) return idle;
    useLive.setState({ sketchId });
    return {
      paint: async (elements: readonly unknown[], done: number, total: number) => {
        api.updateScene({ elements: [...elements] });
        useLive.getState().patch(stepId, { progress: done / Math.max(1, total), detail: `${done} of ${total} ${total === 1 ? "change" : "changes"}` });
        await sleep(280);
      },
      done: () => {
        useLive.setState({ sketchId: null });
        canvasFor(sketchId)?.save?.();
      },
    };
  },

  /** Show a page in the in-app browser: beside the work on wide screens, over it on phones. */
  openBrowser(projectId: string, url: string) {
    const app = useApp.getState();
    app.setBrowserUrl(url);
    if (onProject(projectId) && window.innerWidth >= NARROW) {
      const layout = useLayout.getState();
      if (layout.focus) layout.setFocus(null);
      const dock = layout.tempDock ?? layout.chatDock;
      if (app.chatOpen && (dock === "full" || dock === "float")) layout.setTempDock("right");
      layout.openSide(projectId, { kind: "browser" });
      return;
    }
    app.setBrowserOpen(true);
    app.setChatOpen(false);
  },

  /** If the PDF Leo is reading is open, turn to the page he is on. */
  seekFile(fileId: string, pages?: string) {
    if (HEADLESS) return;
    const page = parseInt(String(pages ?? ""), 10);
    if (page > 0) window.dispatchEvent(new CustomEvent("harness:seek", { detail: { fileId, page } }));
  },
};
