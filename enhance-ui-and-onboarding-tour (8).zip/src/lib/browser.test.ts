import { describe, expect, it } from "vitest";
import { refusesEmbedding, safeUrl, youtubeRef } from "./browser";

describe("in-app browser: addresses", () => {
  it("keeps addresses and adds https to bare hosts", () => {
    expect(safeUrl("https://en.wikipedia.org/wiki/Cell")).toBe("https://en.wikipedia.org/wiki/Cell");
    expect(safeUrl("khanacademy.org")).toBe("https://khanacademy.org/");
  });

  it("turns words into a search on an engine that can be shown in a frame", () => {
    expect(safeUrl("what is photosynthesis")).toBe("https://www.bing.com/search?q=what%20is%20photosynthesis");
    expect(safeUrl("mitosis")).toBe("https://www.bing.com/search?q=mitosis");
  });

  it("rejects empty input and non-web schemes", () => {
    expect(safeUrl("   ")).toBeNull();
    expect(safeUrl("javascript://alert(1)")).toBeNull();
    expect(safeUrl("file:///etc/passwd")).toBeNull();
  });
});

describe("in-app browser: YouTube links", () => {
  it("finds the video in every common link shape", () => {
    for (const url of [
      "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
      "https://youtu.be/aqz-KE-bpKQ",
      "https://m.youtube.com/watch?v=aqz-KE-bpKQ&list=PL123",
      "https://www.youtube.com/embed/aqz-KE-bpKQ",
      "https://www.youtube.com/live/aqz-KE-bpKQ",
      "https://music.youtube.com/watch?v=aqz-KE-bpKQ",
    ])
      expect(youtubeRef(url)?.id, url).toBe("aqz-KE-bpKQ");
  });

  it("reads the start time", () => {
    expect(youtubeRef("https://youtu.be/aqz-KE-bpKQ?t=90")?.start).toBe(90);
    expect(youtubeRef("https://www.youtube.com/watch?v=aqz-KE-bpKQ&t=1m30s")?.start).toBe(90);
    expect(youtubeRef("https://www.youtube.com/watch?v=aqz-KE-bpKQ&t=1h2m3s")?.start).toBe(3723);
    expect(youtubeRef("https://www.youtube.com/watch?v=aqz-KE-bpKQ")?.start).toBe(0);
  });

  it("knows Shorts are portrait", () => {
    expect(youtubeRef("https://www.youtube.com/shorts/aqz-KE-bpKQ")).toEqual({ id: "aqz-KE-bpKQ", start: 0, vertical: true });
  });

  it("does not mistake other pages for videos", () => {
    expect(youtubeRef("https://www.youtube.com/")).toBeNull();
    expect(youtubeRef("https://www.youtube.com/@BlenderOfficial")).toBeNull();
    expect(youtubeRef("https://example.com/watch?v=aqz-KE-bpKQ")).toBeNull();
    expect(youtubeRef("https://www.youtube.com/watch?v=<script>")).toBeNull();
    expect(youtubeRef("not a url")).toBeNull();
  });
});

describe("in-app browser: sites that refuse to be framed", () => {
  it("knows the well-known ones, including subdomains and Google's country sites", () => {
    for (const host of ["github.com", "gist.github.com", "developer.mozilla.org", "www.google.com", "www.google.co.uk", "arxiv.org", "old.reddit.com"]) expect(refusesEmbedding(host), host).toBe(true);
  });

  it("lets sites that allow framing through", () => {
    for (const host of ["en.wikipedia.org", "www.khanacademy.org", "openstax.org", "docs.python.org", "notgithub.com"]) expect(refusesEmbedding(host), host).toBe(false);
  });

  it("includes sites the learner flagged", () => {
    expect(refusesEmbedding("example.org", ["example.org"])).toBe(true);
  });
});
