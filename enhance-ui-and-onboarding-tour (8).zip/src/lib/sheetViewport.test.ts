import { describe, expect, it } from "vitest";
import { sheetViewport } from "./sheetViewport";

describe("keyboard-aware bottom sheets", () => {
  it("offsets the bottom by the keyboard height when only the visual viewport shrinks", () => {
    expect(sheetViewport(844, 484, 0)).toEqual({ top: 0, bottom: 360, height: 484 });
  });
  it("follows a scrolled visual viewport on iOS", () => {
    expect(sheetViewport(844, 484, 60)).toEqual({ top: 60, bottom: 300, height: 484 });
  });
  it("does not double-count a keyboard that already resizes the layout viewport", () => {
    expect(sheetViewport(484, 484, 0)).toEqual({ top: 0, bottom: 0, height: 484 });
  });
  it("uses the whole layout viewport as a fallback", () => {
    expect(sheetViewport(844)).toEqual({ top: 0, bottom: 0, height: 844 });
    expect(sheetViewport(844, 900, -5)).toEqual({ top: 0, bottom: 0, height: 844 });
  });
});