import { db, uid, type PdfAnnotation, type PdfPoint, type PdfRect } from "./db";

/** Highlight and pen colours, chosen to stay legible on white pages in light and dark themes. */
export const HIGHLIGHT_COLORS = [
  { name: "Yellow", hex: "#ffe066" },
  { name: "Green", hex: "#b2f2bb" },
  { name: "Blue", hex: "#a5d8ff" },
  { name: "Pink", hex: "#ffc9de" },
  { name: "Orange", hex: "#ffd8a8" },
] as const;

export const PEN_COLORS = [
  { name: "Ink", hex: "#17171a" },
  { name: "Red", hex: "#e03131" },
  { name: "Blue", hex: "#1971c2" },
  { name: "Green", hex: "#2f9e44" },
  { name: "Orange", hex: "#e8590c" },
] as const;

export const PEN_WIDTHS = [
  { name: "Thin", px: 2 },
  { name: "Medium", px: 4 },
  { name: "Thick", px: 7 },
] as const;

/** A page's annotations, oldest first so a note sits under later highlights only where it should. */
export function useFileAnnotationsQuery(fileId: string) {
  return () => db.pdfAnnotations.where("fileId").equals(fileId).sortBy("createdAt");
}

export const listAnnotations = (fileId: string) => db.pdfAnnotations.where("fileId").equals(fileId).sortBy("createdAt");

const mark = (fileId: string, projectId: string, page: number): Pick<PdfAnnotation, "id" | "projectId" | "fileId" | "page" | "createdAt" | "updatedAt"> => {
  const now = Date.now();
  return { id: uid(), projectId, fileId, page, createdAt: now, updatedAt: now };
};

export async function addHighlight(projectId: string, fileId: string, page: number, color: string, rects: PdfRect[], text: string): Promise<PdfAnnotation | null> {
  if (!rects.length || !text.trim()) return null;
  const row: PdfAnnotation = { ...mark(fileId, projectId, page), kind: "highlight", color, rects, text: text.trim().slice(0, 8000) };
  await db.pdfAnnotations.add(row);
  return row;
}

export async function addInk(projectId: string, fileId: string, page: number, color: string, width: number, points: PdfPoint[]): Promise<PdfAnnotation | null> {
  if (points.length < 2) return null;
  const row: PdfAnnotation = { ...mark(fileId, projectId, page), kind: "ink", color, width, points: points.slice(0, 4000) };
  await db.pdfAnnotations.add(row);
  return row;
}

/** One note per page: saving again edits the note already there. */
export async function savePageNote(projectId: string, fileId: string, page: number, text: string): Promise<PdfAnnotation | null> {
  const clean = text.trim().slice(0, 8000);
  const existing = await db.pdfAnnotations.where("fileId").equals(fileId).filter((a) => a.kind === "note" && a.page === page).first();
  if (!clean) {
    if (existing) await db.pdfAnnotations.delete(existing.id);
    return null;
  }
  if (existing) {
    await db.pdfAnnotations.update(existing.id, { text: clean, updatedAt: Date.now() } as Partial<PdfAnnotation>);
    return { ...existing, text: clean, updatedAt: Date.now() } as PdfAnnotation;
  }
  const row: PdfAnnotation = { ...mark(fileId, projectId, page), kind: "note", text: clean };
  await db.pdfAnnotations.add(row);
  return row;
}

export async function deleteAnnotation(id: string) {
  await db.pdfAnnotations.delete(id);
}

/** Remove the most recent annotation on a file; returns what was removed (for an Undo message). */
export async function undoLast(fileId: string): Promise<PdfAnnotation | null> {
  const all = await db.pdfAnnotations.where("fileId").equals(fileId).sortBy("createdAt");
  const last = all[all.length - 1];
  if (!last) return null;
  await db.pdfAnnotations.delete(last.id);
  return last;
}

export async function clearPage(fileId: string, page: number) {
  const rows = await db.pdfAnnotations.where("fileId").equals(fileId).filter((a) => a.page === page).toArray();
  if (rows.length) await db.pdfAnnotations.bulkDelete(rows.map((r) => r.id));
  return rows.length;
}

export const annotationLabel = (a: PdfAnnotation) =>
  a.kind === "highlight" ? `Highlight on page ${a.page}` : a.kind === "ink" ? `Drawing on page ${a.page}` : `Note on page ${a.page}`;

/** What the learner marked on a page, for Leo's view of the PDF. */
export function pageMarksSummary(marks: PdfAnnotation[]): string {
  const notes = marks.filter((a) => a.kind === "note");
  const highlights = marks.filter((a) => a.kind === "highlight");
  const ink = marks.filter((a) => a.kind === "ink");
  const out: string[] = [];
  if (highlights.length) out.push(`### The learner highlighted\n${highlights.map((h) => (h.kind === "highlight" ? `- “${h.text}”` : "")).join("\n")}`);
  if (notes.length) out.push(`### The learner's note on this page\n${notes.map((n) => (n.kind === "note" ? n.text : "")).join("\n\n")}`);
  if (ink.length) out.push(`### The learner drew on this page\n${ink.length} pen stroke${ink.length === 1 ? "" : "s"} (the drawing itself isn't shown to you)`);
  return out.join("\n\n");
}

/* ---------------------------------------------------------------- geometry */

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

/** Selection rectangles → page-relative rectangles (0..1 of width/height). */
export function normalizeRects(rects: { left: number; top: number; right: number; bottom: number }[], page: { left: number; top: number; width: number; height: number }): PdfRect[] {
  if (!page.width || !page.height) return [];
  return rects
    .filter((r) => r.right > page.left && r.left < page.left + page.width && r.bottom > page.top && r.top < page.top + page.height)
    .map((r) => ({
      x: clamp01((r.left - page.left) / page.width),
      y: clamp01((r.top - page.top) / page.height),
      w: clamp01((r.right - r.left) / page.width),
      h: clamp01((r.bottom - r.top) / page.height),
    }))
    .map((r) => ({ ...r, w: Math.min(r.w, 1 - r.x), h: Math.min(r.h, 1 - r.y) }))
    .filter((r) => r.w > 0.002 && r.h > 0.002);
}

export function normalizePoint(x: number, y: number, page: { left: number; top: number; width: number; height: number }): PdfPoint {
  return { x: clamp01((x - page.left) / (page.width || 1)), y: clamp01((y - page.top) / (page.height || 1)) };
}

/** An SVG path through page-relative points, in pixels of the rendered page. */
export function strokePath(points: PdfPoint[], width: number, height: number): string {
  return points.map((p, i) => `${i ? "L" : "M"}${(p.x * width).toFixed(1)} ${(p.y * height).toFixed(1)}`).join(" ");
}

const distToSegment = (p: PdfPoint, a: PdfPoint, b: PdfPoint) => {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = dx * dx + dy * dy;
  const t = len ? Math.min(1, Math.max(0, ((p.x - a.x) * dx + (p.y - a.y) * dy) / len)) : 0;
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
};

/** The stroke under a point (for the eraser). Tolerance is in page-relative units. */
export function strokeAt(strokes: { id: string; points: PdfPoint[] }[], point: PdfPoint, tolerance = 0.012): string | null {
  for (let i = strokes.length - 1; i >= 0; i--) {
    const { id, points } = strokes[i];
    for (let j = 1; j < points.length; j++) if (distToSegment(point, points[j - 1], points[j]) <= tolerance) return id;
    if (points.length === 1 && Math.hypot(points[0].x - point.x, points[0].y - point.y) <= tolerance) return id;
  }
  return null;
}
