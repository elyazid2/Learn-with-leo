import { useEffect, useLayoutEffect, useState, type RefObject } from "react";

export interface SheetViewport { top: number; bottom: number; height: number }

/** The keyboard can shrink just the visual viewport, or the entire layout viewport. Handle both. */
export function sheetViewport(layoutHeight: number, visualHeight = layoutHeight, offsetTop = 0): SheetViewport {
  const height = Math.max(1, Math.min(layoutHeight, visualHeight));
  const top = Math.max(0, Math.min(offsetTop, layoutHeight - height));
  return { top, height, bottom: Math.max(0, layoutHeight - height - top) };
}

function readViewport(): SheetViewport {
  if (typeof window === "undefined") return { top: 0, bottom: 0, height: 800 };
  const vv = window.visualViewport;
  return sheetViewport(window.innerHeight, vv?.height, vv?.offsetTop);
}

export function useSheetViewport(open: boolean, panel: RefObject<HTMLDivElement | null>) {
  const [viewport, setViewport] = useState(readViewport);
  useEffect(() => {
    if (!open) return;
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const next = readViewport();
        setViewport((old) => old.top === next.top && old.height === next.height && old.bottom === next.bottom ? old : next);
      });
    };
    update();
    const vv = window.visualViewport;
    vv?.addEventListener("resize", update);
    vv?.addEventListener("scroll", update);
    window.addEventListener("resize", update);
    document.addEventListener("focusin", update);
    return () => {
      cancelAnimationFrame(frame);
      vv?.removeEventListener("resize", update);
      vv?.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
      document.removeEventListener("focusin", update);
    };
  }, [open]);

  useLayoutEffect(() => {
    if (!open) return;
    let frame = 0;
    let timer: ReturnType<typeof setTimeout>;
    const reveal = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const input = document.activeElement as HTMLElement | null;
        const scroll = panel.current?.querySelector<HTMLElement>("[data-sheet-scroll]");
        if (!input || !scroll?.contains(input) || !input.matches("input,textarea,select,[contenteditable=true]")) return;
        input.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "auto" });
        // Keep the field clear of the fixed header and action footer, including Safari's scroll pan.
        const box = scroll.getBoundingClientRect();
        const field = input.getBoundingClientRect();
        if (field.bottom > box.bottom - 12) scroll.scrollTop += field.bottom - box.bottom + 12;
        else if (field.top < box.top + 12) scroll.scrollTop -= box.top + 12 - field.top;
      });
    };
    const onFocus = () => {
      reveal();
      clearTimeout(timer);
      timer = setTimeout(reveal, 280);
    };
    reveal();
    document.addEventListener("focusin", onFocus);
    return () => {
      cancelAnimationFrame(frame);
      clearTimeout(timer);
      document.removeEventListener("focusin", onFocus);
    };
  }, [open, panel, viewport]);
  return viewport;
}