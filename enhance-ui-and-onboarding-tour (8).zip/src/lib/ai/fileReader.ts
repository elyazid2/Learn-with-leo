import { db } from "../db";
import {
  clock,
  nextCursor,
  paginatePages,
  paginateText,
  paginateTranscript,
  parseClock,
  parsePages,
  READ_MAX_CHARS,
} from "../retrieval";

export interface FileReadResult {
  ok: boolean;
  label: string;
  /** The `## File …` block for <action_results>. */
  text: string;
  /** Vision input: image files and text-less PDF pages, as JPEG data URLs. */
  images: string[];
}

const MAX_IMAGES = 4;

/** Execute {"type":"read","kind":"file",…}: PDF pages, a media time range or a text range, paginated. */
export async function readLibraryFile(
  projectId: string,
  a: { id: string; pages?: string; from?: string; to?: string }
): Promise<FileReadResult> {
  const file = await db.files.get(a.id);
  if (!file || file.projectId !== projectId) return { ok: false, label: `File ${a.id} not found in this project`, text: "", images: [] };
  const head = (what: string) => `## File "${file.name}" (id=${file.id}; ${file.kind}) — ${what}`;
  const tail = (next?: Record<string, string>) =>
    next ? `\n[more remains — continue with: ${nextCursor(file.id, next)}]` : "\n[end of requested range]";

  if (file.kind === "pdf") {
    const { pdfPagesText, renderPdfPageJpeg } = await import("../media");
    const total = file.pages ?? (await pdfPagesText(file.blob, [])).numPages;
    const wanted = parsePages(a.pages, total);
    if (!wanted.length) return { ok: false, label: `${file.name}: no such pages (${a.pages}); it has ${total}`, text: "", images: [] };
    // Read at most what can fit; pages beyond the budget are left for the "next" cursor.
    const { pages } = await pdfPagesText(file.blob, wanted.slice(0, 30));
    const r = paginatePages(pages, wanted[wanted.length - 1], READ_MAX_CHARS);
    const shownPages = pages.filter((p) => r.included && p.page <= Number(/(\d+)$/.exec(r.included)?.[1] ?? 0));
    const images: string[] = [];
    for (const p of shownPages) {
      if (images.length >= MAX_IMAGES) break;
      if (p.text.replace(/\s+/g, "").length < 20) {
        const img = await renderPdfPageJpeg(file.blob, p.page, 1280);
        if (img) images.push(img);
      }
    }
    const note = images.length ? `\n[${images.length} text-less page(s) attached as images to this message]` : "";
    return { ok: true, label: `Read ${file.name} · ${r.included}`, text: `${head(`${r.included} of ${total} pages`)}\n${r.text}${note}${tail(r.next)}`, images };
  }

  if (file.kind === "image") {
    const { imageToDataUrl } = await import("../media");
    const img = await imageToDataUrl(file.blob, 1280, 0.85);
    if (!img) return { ok: false, label: `${file.name} could not be decoded`, text: "", images: [] };
    return { ok: true, label: `Viewed ${file.name}`, text: `${head("image")}\n[the image is attached to this message — look at it]`, images: [img] };
  }

  if (file.kind === "audio" || file.kind === "video") {
    const chunks = await db.chunks.where("sourceId").equals(file.id).toArray();
    const timed = chunks.filter((c) => typeof c.t0 === "number");
    if (!timed.length) {
      const why =
        file.indexed === "pending"
          ? "still being transcribed — try again shortly"
          : file.youtubeId
            ? (file.transcriptNote ?? "this video has no transcript yet — the learner can add one on its page")
            : (file.indexNote ?? "not transcribed (Settings → Transcription)");
      return { ok: false, label: `${file.name}: no transcript (${why})`, text: "", images: [] };
    }
    const from = parseClock(a.from);
    const to = parseClock(a.to);
    const r = paginateTranscript(timed, isNaN(from) ? 0 : from, isNaN(to) ? Infinity : to);
    const dur = file.duration ? ` of ${clock(file.duration)}` : "";
    return { ok: true, label: `Read ${file.name} · ${r.included || "empty range"}`, text: `${head(`transcript ${r.included || "(nothing in that range)"}${dur}`)}\n${r.text}${tail(r.next)}`, images: [] };
  }

  // text
  const text = await file.blob.text();
  const from = Number(a.from);
  const to = Number(a.to);
  const r = paginateText(text, isFinite(from) ? from : 0, isFinite(to) && a.to ? to : Infinity);
  return { ok: true, label: `Read ${file.name} · ${r.included}`, text: `${head(r.included)}\n${r.text}${tail(r.next)}`, images: [] };
}
