import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});
vi.mock("@/lib/retrieval", () => ({ indexNote: vi.fn(async () => {}) }));

import { db } from "@/lib/db";
import { useLive } from "@/lib/live";
import { describeAction, executeActions, type Action } from "./actions";

const fake = db as unknown as ReturnType<typeof import("../../test/fakeDb").createFakeDb>;

beforeEach(() => {
  fake.reset();
  useLive.getState().begin("proj");
});

describe("live status: what Leo is doing, in words", () => {
  it("describes each tool", () => {
    const cases: [Action, string][] = [
      [{ type: "sketch", title: "Cell cycle", elements: [] }, "Drawing “Cell cycle”"],
      [{ type: "edit_sketch", id: "s1", ops: [{ op: "delete", ref: "s1" }] }, "Editing the sketch: 1 change"],
      [{ type: "note", title: "Verbs", content: "x" }, "Writing a note: Verbs"],
      [{ type: "note", id: "n1", title: "Verbs", content: "x", mode: "patch" }, "Editing your note"],
      [{ type: "note", id: "n1", title: "Verbs", content: "x" }, "Adding to the note"],
      [{ type: "map", concept: "Loops", status: "solid" }, "Updating your knowledge map: Loops (solid)"],
      [{ type: "set_level", level: "Novice" }, "Setting your level to Novice"],
      [{ type: "search", query: "mitosis" }, "Searching your library for “mitosis”"],
      [{ type: "read", kind: "file", id: "f1", pages: "12" }, "Reading from your library (page 12)"],
      [{ type: "browser", url: "https://www.khanacademy.org/science" }, "Opening khanacademy.org"],
      [{ type: "memory", op: "save", text: "Prefers examples" }, "Saving a memory"],
    ];
    for (const [action, label] of cases) expect(describeAction(action), action.type).toBe(label);
  });

  it("leaves questions to their cards", () => {
    expect(describeAction({ type: "ask", question: "?", options: ["a", "b"] })).toBeNull();
  });
});

describe("live status: steps recorded while actions run", () => {
  it("adds a step per tool and finishes it with the result", async () => {
    await executeActions("proj", "thread", [
      { type: "map", concept: "Loops", status: "learning" },
      { type: "point", kind: "next", text: "Practise nested loops" },
    ]);
    const steps = useLive.getState().steps;
    expect(steps.map((s) => [s.type, s.state])).toEqual([
      ["map", "done"],
      ["point", "done"],
    ]);
    expect(steps[0].label).toBe("Loops → learning");
  });

  it("marks a failed tool as failed, with the reason", async () => {
    await executeActions("proj", "thread", [{ type: "read", kind: "note", id: "missing" }]);
    const [step] = useLive.getState().steps;
    expect(step.state).toBe("failed");
    expect(step.label).toContain("not found");
  });

  it("a new turn starts with a clean list", async () => {
    await executeActions("proj", "thread", [{ type: "map", concept: "Loops" }]);
    useLive.getState().begin("proj");
    expect(useLive.getState().steps).toEqual([]);
  });
});
