import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/db")>();
  const { createFakeDb } = await import("../test/fakeDb");
  return { ...actual, db: createFakeDb() };
});

import { db } from "@/lib/db";
import {
  HIGHLIGHT_COLORS,
  PEN_COLORS,
  addHighlight,
  addInk,
  annotationLabel,
  clearPage,
  deleteAnnotation,
  listAnnotations,
  normalizePoint,
  normalizeRects,
  pageMarksSummary,
  savePageNote,
  strokeAt,
  strokePath,
  undoLast,
} from "./pdfAnnotations";

const fake = db as unknown as ReturnType<typeof import("../test/fakeDb").createFakeDb>;
const PAGE = { left: 100, top: 50, width: 600, height: 900 };
const P = "proj";
const F = "file";

beforeEach(() => fake.reset());

describe("page-relative geometry", () => {
  it("turns selection rectangles into fractions of the page and drops slivers", () => {
    const rects = normalizeRects(
      [
        { left: 160, top: 140, right: 460, bottom: 176 },
        { left: 180, top: 190, right: 181, bottom: 192 },
        { left: 10, top: 20, right: 60, bottom: 40 },
      ],
      PAGE
    );
    expect(rects).toHaveLength(1);
    expect(rects[0]).toEqual({ x: 0.1, y: 0.1, w: 0.5, h: 0.04 });
  });

  it("clamps points to the page", () => {
    expect(normalizePoint(400, 500, PAGE)).toEqual({ x: 0.5, y: 0.5 });
    expect(normalizePoint(0, 0, PAGE)).toEqual({ x: 0, y: 0 });
    expect(normalizePoint(9999, 9999, PAGE)).toEqual({ x: 1, y: 1 });
  });

  it("scales a stroke to the page and finds the stroke under the eraser", () => {
    const points = [
      { x: 0.1, y: 0.1 },
      { x: 0.5, y: 0.2 },
      { x: 0.9, y: 0.1 },
    ];
    expect(strokePath(points, 600, 900)).toBe("M60.0 90.0 L300.0 180.0 L540.0 90.0");
    expect(strokeAt([{ id: "s1", points }], { x: 0.5, y: 0.2 })).toBe("s1");
    expect(strokeAt([{ id: "s1", points }], { x: 0.5, y: 0.7 })).toBeNull();
    expect(strokeAt([{ id: "a", points }, { id: "b", points: [{ x: 0.5, y: 0.9 }, { x: 0.55, y: 0.9 }] }], { x: 0.52, y: 0.9 })).toBe("b");
  });
});

describe("annotations are saved and undoable", () => {
  it("stores a highlight with its text and colour", async () => {
    const row = await addHighlight(P, F, 3, HIGHLIGHT_COLORS[1].hex, [{ x: 0.1, y: 0.2, w: 0.4, h: 0.03 }], "  Cells are the unit  ");
    expect(row).toMatchObject({ kind: "highlight", page: 3, color: HIGHLIGHT_COLORS[1].hex, text: "Cells are the unit" });
    expect(await listAnnotations(F)).toHaveLength(1);
    expect(annotationLabel(row!)).toBe("Highlight on page 3");
  });

  it("ignores an empty selection", async () => {
    expect(await addHighlight(P, F, 1, HIGHLIGHT_COLORS[0].hex, [], "x")).toBeNull();
    expect(await addHighlight(P, F, 1, HIGHLIGHT_COLORS[0].hex, [{ x: 0, y: 0, w: 0.1, h: 0.1 }], "   ")).toBeNull();
  });

  it("stores pen strokes with a page-relative width", async () => {
    const row = await addInk(P, F, 2, PEN_COLORS[1].hex, 0.006, [{ x: 0.1, y: 0.1 }, { x: 0.2, y: 0.3 }]);
    expect(row).toMatchObject({ kind: "ink", page: 2, color: PEN_COLORS[1].hex, width: 0.006 });
    expect(await addInk(P, F, 2, PEN_COLORS[0].hex, 0.006, [{ x: 0.1, y: 0.1 }])).toBeNull();
  });

  it("keeps one page note per page: saving again edits it", async () => {
    const first = await savePageNote(P, F, 4, "Mitochondria");
    const second = await savePageNote(P, F, 4, "Mitochondria make ATP");
    expect(second?.id).toBe(first?.id);
    expect((await listAnnotations(F)).filter((a) => a.kind === "note")).toHaveLength(1);
    await savePageNote(P, F, 4, "   ");
    expect((await listAnnotations(F)).filter((a) => a.kind === "note")).toHaveLength(0);
  });

  it("undoes the newest mark, deletes one, and clears a page", async () => {
    await addHighlight(P, F, 1, HIGHLIGHT_COLORS[0].hex, [{ x: 0.1, y: 0.1, w: 0.2, h: 0.02 }], "one");
    await addInk(P, F, 1, PEN_COLORS[0].hex, 0.006, [{ x: 0.2, y: 0.2 }, { x: 0.3, y: 0.3 }]);
    await savePageNote(P, F, 2, "page two note");
    expect((await undoLast(F))?.kind).toBe("note");
    const marks = await listAnnotations(F);
    expect(marks).toHaveLength(2);
    await deleteAnnotation(marks[0].id);
    expect(await listAnnotations(F)).toHaveLength(1);
    expect(await clearPage(F, 1)).toBe(1);
    expect(await listAnnotations(F)).toHaveLength(0);
    expect(await undoLast(F)).toBeNull();
  });

  it("summarises a page for Leo: highlights, the page note and drawings", () => {
    const summary = pageMarksSummary([
      { id: "1", projectId: P, fileId: F, page: 1, kind: "highlight", color: "#ffe066", rects: [], text: "ATP is energy", createdAt: 1, updatedAt: 1 },
      { id: "2", projectId: P, fileId: F, page: 1, kind: "note", text: "Ask about the diagram", createdAt: 2, updatedAt: 2 },
      { id: "3", projectId: P, fileId: F, page: 1, kind: "ink", color: "#000", width: 0.005, points: [], createdAt: 3, updatedAt: 3 },
    ]);
    expect(summary).toContain("ATP is energy");
    expect(summary).toContain("Ask about the diagram");
    expect(summary).toContain("1 pen stroke");
    expect(pageMarksSummary([])).toBe("");
  });

  it("offers a useful palette", () => {
    expect(HIGHLIGHT_COLORS.length).toBeGreaterThanOrEqual(4);
    expect(PEN_COLORS.length).toBeGreaterThanOrEqual(4);
    expect(new Set(HIGHLIGHT_COLORS.map((c) => c.hex)).size).toBe(HIGHLIGHT_COLORS.length);
  });
});
