import { describe, expect, it } from "vitest";
import type { Chunk } from "./db";
import {
  AI_WEIGHT,
  buildCorpus,
  formatSearchResults,
  rankChunks,
  rankCorpus,
  retrievalQuery,
  stem,
  tokenize,
} from "./retrieval";
import { parseCitations } from "./ai/actions";

let n = 0;
const chunk = (text: string, over: Partial<Chunk> = {}): Chunk => ({
  id: `c${++n}`,
  projectId: "p",
  sourceId: over.sourceId ?? `f${n}`,
  sourceKind: "file",
  sourceName: "book.pdf",
  page: 1,
  text,
  ...over,
});

describe("light stemming", () => {
  it("folds plurals, -ing and -ed", () => {
    expect(stem("cells")).toBe("cell");
    expect(stem("studies")).toBe("study");
    expect(stem("studied")).toBe("study");
    expect(stem("running")).toBe("run");
    expect(tokenize("dividing")).toEqual(tokenize("divide"));
    expect(tokenize("divided")).toEqual(tokenize("divides"));
    expect(stem("class")).toBe("class");
    expect(stem("bus")).toBe("bus");
  });
});

describe("search ranking", () => {
  const corpus = [
    chunk("Mitochondria are the powerhouse of the cell and produce ATP.", { page: 3 }),
    chunk("Cells divide by mitosis. Dividing cells copy their chromosomes.", { page: 7 }),
    chunk("The French revolution began in 1789.", { page: 40 }),
    chunk("Photosynthesis happens in chloroplasts of plant cells.", { page: 9 }),
  ];

  it("matches stemmed query words and orders by relevance", () => {
    const hits = rankChunks("how do cells divided", corpus);
    expect(hits[0].chunk.page).toBe(7);
    expect(hits.some((h) => h.chunk.page === 40)).toBe(false);
  });

  it("drops hits under 40% of the top score", () => {
    const docs = [
      chunk("mitosis mitosis mitosis spindle chromosomes mitosis"),
      chunk("a long passage about many other things that mentions the cell once among lots of unrelated words here"),
    ];
    const hits = rankChunks("mitosis spindle cell", docs);
    expect(hits).toHaveLength(1);
    expect(hits[0].chunk.text).toContain("spindle");
  });

  it("down-weights Leo's own notes so learner materials win a tie", () => {
    const text = "Osmosis moves water across a membrane.";
    const docs = [
      chunk(text, { sourceKind: "note", sourceName: "note “Osmosis” (Leo's note)", author: "ai", page: 0 }),
      chunk(text, { sourceName: "bio.pdf", page: 12 }),
      chunk("unrelated filler text about rivers"),
    ];
    const hits = rankChunks("osmosis membrane", docs);
    expect(hits[0].chunk.sourceName).toBe("bio.pdf");
    expect(hits[1].score).toBeCloseTo(hits[0].score * AI_WEIGHT, 5);
  });

  it("honours scope", () => {
    const docs = [chunk("enzyme kinetics", { sourceKind: "note", page: 0 }), chunk("enzyme structure")];
    const c = buildCorpus(docs);
    expect(rankCorpus(c, "enzyme", 8, "notes").every((h) => h.chunk.sourceKind === "note")).toBe(true);
    expect(rankCorpus(c, "enzyme", 8, "files").every((h) => h.chunk.sourceKind === "file")).toBe(true);
  });

  it("formats search results with id, page or timestamp and source name", () => {
    const hits = rankChunks("entropy", [
      chunk("entropy always increases", { sourceId: "pdf1", page: 12 }),
      chunk("in this lecture entropy is defined", { sourceId: "aud1", sourceName: "lecture.mp3", page: 0, t0: 190, t1: 230 }),
    ]);
    const out = formatSearchResults("entropy", hits);
    expect(out).toContain("id=aud1 · 3:10–3:50 · lecture.mp3");
    expect(out).toContain("id=pdf1 · p.12 · book.pdf");
  });
});

describe("retrieval query", () => {
  it("adds the last assistant question when the reply is short", () => {
    const q = retrievalQuery([
      { role: "assistant", content: 'Let me check.\n```action\n{"type":"ask","question":"Which organelle makes ATP?","options":["a","b"]}\n```' },
      { role: "user", content: "the second" },
    ]);
    expect(q).toContain("Which organelle makes ATP?");
  });
  it("uses the learner's text alone when it is long enough", () => {
    const q = retrievalQuery([
      { role: "assistant", content: "What do you know about cells?" },
      { role: "user", content: "explain how mitochondria produce energy please" },
    ]);
    expect(q).toBe("explain how mitochondria produce energy please");
  });
});

describe("citations", () => {
  const files = [
    { id: "f1", name: "book.pdf", kind: "pdf" as const },
    { id: "a1", name: "lecture.mp3", kind: "audio" as const },
  ];
  it("resolves (file, p.N), [S#] and [m:ss]", () => {
    const found = parseCitations("See (`book.pdf`, p.12) and [S1], then listen at [3:12].", files, [{ label: "S1", name: "book.pdf", fileId: "f1", page: 4 }]);
    expect(found).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ fileId: "f1", page: 12 }),
        expect.objectContaining({ fileId: "f1", page: 4, match: "[S1]" }),
        expect.objectContaining({ fileId: "a1", t0: 192 }),
      ])
    );
  });
});
