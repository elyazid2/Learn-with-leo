import {
  Atom,
  BookOpen,
  Bot,
  Brain,
  Briefcase,
  Calculator,
  Camera,
  ChartLine,
  ChefHat,
  Code,
  Compass,
  Cpu,
  Dna,
  Dumbbell,
  Feather,
  Film,
  FlaskConical,
  Globe,
  GraduationCap,
  Guitar,
  Landmark,
  Languages,
  Leaf,
  Lightbulb,
  MessageCircle,
  Microscope,
  Music,
  Notebook,
  Palette,
  PenLine,
  Puzzle,
  Rocket,
  Ruler,
  Scale,
  Sigma,
  Stethoscope,
  Target,
  Telescope,
  Terminal,
  Trophy,
  type LucideIcon,
} from "lucide-react";
import type { Project, ProjectIcon } from "./db";

/**
 * Project icons are minimal line icons (Lucide), stored by name. The order is the picker's order
 * (8 per row): study, math & science, tech & world, humanities & arts, life.
 */
export const PROJECT_ICONS: Record<string, LucideIcon> = {
  "book-open": BookOpen,
  notebook: Notebook,
  "pen-line": PenLine,
  brain: Brain,
  lightbulb: Lightbulb,
  "graduation-cap": GraduationCap,
  target: Target,
  puzzle: Puzzle,

  sigma: Sigma,
  ruler: Ruler,
  calculator: Calculator,
  "chart-line": ChartLine,
  flask: FlaskConical,
  microscope: Microscope,
  dna: Dna,
  atom: Atom,

  code: Code,
  terminal: Terminal,
  cpu: Cpu,
  bot: Bot,
  globe: Globe,
  languages: Languages,
  "message-circle": MessageCircle,
  telescope: Telescope,

  landmark: Landmark,
  feather: Feather,
  scale: Scale,
  palette: Palette,
  music: Music,
  guitar: Guitar,
  camera: Camera,
  film: Film,

  stethoscope: Stethoscope,
  briefcase: Briefcase,
  leaf: Leaf,
  dumbbell: Dumbbell,
  "chef-hat": ChefHat,
  compass: Compass,
  rocket: Rocket,
  trophy: Trophy,
};

export const ICON_CHOICES = Object.keys(PROJECT_ICONS);

/** Readable names for screen readers ("chart-line" → "Chart line"). */
export const iconLabel = (name: string) => (name.charAt(0).toUpperCase() + name.slice(1)).replace(/-/g, " ");

const DEFAULT_ICON = "book-open";

/** A sensible default icon for common tags, so a new project never starts blank. */
const TAG_ICON: Record<string, string> = {
  language: "languages",
  languages: "languages",
  math: "sigma",
  maths: "sigma",
  mathematics: "sigma",
  code: "code",
  coding: "code",
  programming: "code",
  science: "flask",
  physics: "atom",
  chemistry: "flask",
  biology: "dna",
  music: "music",
  history: "landmark",
  design: "palette",
  art: "palette",
  exam: "pen-line",
  exams: "pen-line",
  medicine: "stethoscope",
  law: "scale",
  finance: "chart-line",
  business: "briefcase",
  writing: "feather",
  philosophy: "lightbulb",
  geography: "globe",
};

export function defaultIconFor(tag?: string) {
  return TAG_ICON[(tag ?? "").trim().toLowerCase()] ?? DEFAULT_ICON;
}

/**
 * Projects made before line icons stored an emoji. They are shown with the closest line icon,
 * without rewriting the saved project (backups and older data keep loading unchanged).
 */
const EMOJI_ICON: Record<string, string> = {
  "📚": "book-open", "📘": "notebook", "📝": "pen-line", "✏": "pen-line", "🧠": "brain", "💡": "lightbulb", "🎓": "graduation-cap", "🎯": "target",
  "📐": "ruler", "🧮": "calculator", "📊": "chart-line", "📈": "chart-line", "🔬": "microscope", "🧪": "flask", "🧬": "dna", "🔭": "telescope",
  "⚛": "atom", "💻": "code", "🤖": "bot", "⚙": "cpu", "🐍": "code", "🦀": "code", "🌍": "globe", "🗺": "compass",
  "🏛": "landmark", "🗣": "languages", "✍": "feather", "🦉": "lightbulb", "🎨": "palette", "🎵": "music", "🎸": "guitar", "🎹": "music",
  "🎬": "film", "📷": "camera", "🩺": "stethoscope", "⚖": "scale", "💼": "briefcase", "🌱": "leaf", "🧘": "leaf", "🏃": "dumbbell",
  "🍳": "chef-hat", "♟": "puzzle", "🧩": "puzzle", "🚀": "rocket", "⭐": "trophy", "🔥": "rocket", "🌙": "lightbulb", "☕": "notebook",
};

/** What a project shows: an uploaded image, or a line icon (chosen, mapped from an old emoji, or from its tag). */
export type ShownIcon = { kind: "icon"; name: string } | { kind: "image"; src: string };

export function iconOf(p: Pick<Project, "icon" | "tag">): ShownIcon {
  const i: ProjectIcon | undefined = p.icon;
  if (i?.kind === "image" && i.src) return i;
  if (i?.kind === "icon" && PROJECT_ICONS[i.name]) return i;
  if (i?.kind === "emoji") {
    const mapped = EMOJI_ICON[i.emoji.replace(/\uFE0F/g, "")];
    if (mapped) return { kind: "icon", name: mapped };
  }
  return { kind: "icon", name: defaultIconFor(p.tag) };
}

export const iconComponent = (name: string): LucideIcon => PROJECT_ICONS[name] ?? PROJECT_ICONS[DEFAULT_ICON];
