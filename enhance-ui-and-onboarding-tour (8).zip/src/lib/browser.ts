import { create } from "zustand";
import { getKV, setKV } from "./db";
import { useApp } from "./store";
import { youtubeRef } from "./youtube";

export { youtubeRef };
export type { YouTubeRef } from "./youtube";

/**
 * The in-app browser, without a server. Pages load straight from their own sites in a sandboxed
 * frame; YouTube links play in the app's own player. A site can refuse to be framed, and a browser
 * does not tell the embedding page when that happens, so well-known refusers are listed here and
 * the learner can flag any other site with one tap.
 */

export const hostOf = (url: string) => {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return "";
  }
};

/** Turn what was typed into an address: a URL as-is, anything else a web search. */
export function safeUrl(input: string): string | null {
  const value = input.trim();
  if (!value) return null;
  if (!/[.:/]/.test(value) || /\s/.test(value)) return `https://www.bing.com/search?q=${encodeURIComponent(value)}`;
  try {
    const u = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(value) ? value : `https://${value}`);
    if (!["https:", "http:"].includes(u.protocol)) return null;
    // A page served over https cannot show insecure pages: use the secure address instead.
    const local = /^(localhost|127\.|10\.|192\.168\.)/.test(u.hostname);
    if (u.protocol === "http:" && !local && typeof location !== "undefined" && location.protocol === "https:") u.protocol = "https:";
    return u.href;
  } catch {
    return null;
  }
}

/** Sites known to refuse being shown inside another page (X-Frame-Options / frame-ancestors). */
const REFUSES = [
  "google.com", "github.com", "developer.mozilla.org", "arxiv.org", "duckduckgo.com", "stackoverflow.com", "stackexchange.com",
  "britannica.com", "search.brave.com", "x.com", "twitter.com", "facebook.com", "instagram.com", "linkedin.com", "reddit.com",
  "medium.com", "amazon.com", "netflix.com", "nytimes.com", "openai.com", "chatgpt.com", "claude.ai", "notion.so", "discord.com",
  "tiktok.com", "quora.com", "youtube.com", "paypal.com", "dropbox.com",
];

const matches = (host: string, list: string[]) => list.some((h) => host === h || host.endsWith("." + h));

export function refusesEmbedding(host: string, learned: string[] = []) {
  return matches(host, REFUSES) || learned.includes(host) || /(^|\.)google\.[a-z.]{2,6}$/.test(host);
}

export interface BrowserPrefs {
  /** Play YouTube links in the app's own player, without YouTube's interface. */
  cleanYoutube: boolean;
  /** Open pages as plain text when the site can be read. */
  reader: boolean;
  /** Invert bright pages. */
  night: boolean;
}

export const DEFAULT_PREFS: BrowserPrefs = { cleanYoutube: true, reader: false, night: false };

interface BrowserStore {
  current: string;
  stack: string[];
  cursor: number;
  /** Bumped by Reload so the page is fetched again. */
  nonce: number;
  /** Hosts the learner flagged as not loading. */
  learned: string[];
  prefs: BrowserPrefs;
  ready: boolean;
  init: () => void;
  go: (url: string, push?: boolean) => void;
  step: (delta: number) => void;
  reload: () => void;
  learn: (host: string) => void;
  forget: (host: string) => void;
  setPrefs: (patch: Partial<BrowserPrefs>) => void;
}

export const useBrowser = create<BrowserStore>((set, get) => ({
  current: "",
  stack: [],
  cursor: -1,
  nonce: 0,
  learned: [],
  prefs: DEFAULT_PREFS,
  ready: false,
  init: () => {
    if (get().ready) return;
    set({ ready: true });
    void getKV<string[]>("browser.blocked", []).then((learned) => Array.isArray(learned) && set({ learned: learned.filter((h) => typeof h === "string").slice(0, 200) }));
    void getKV<Partial<BrowserPrefs>>("browser.prefs", {}).then((p) => set({ prefs: { cleanYoutube: p?.cleanYoutube !== false, reader: p?.reader === true, night: p?.night === true } }));
  },
  go: (url, push = true) => {
    const s = get();
    const app = useApp.getState();
    app.setBrowserUrl(url);
    app.setBrowser(null);
    if (!push) return set({ current: url, nonce: s.nonce + 1 });
    const stack = [...s.stack.slice(0, s.cursor + 1), url].slice(-50);
    set({ current: url, stack, cursor: stack.length - 1, nonce: s.nonce + 1 });
  },
  step: (delta) => {
    const s = get();
    const next = s.cursor + delta;
    if (next < 0 || next >= s.stack.length) return;
    set({ cursor: next });
    get().go(s.stack[next], false);
  },
  reload: () => set({ nonce: get().nonce + 1 }),
  learn: (host) => {
    if (!host || get().learned.includes(host)) return;
    const learned = [...get().learned, host];
    set({ learned });
    void setKV("browser.blocked", learned);
  },
  forget: (host) => {
    const learned = get().learned.filter((h) => h !== host);
    set({ learned });
    void setKV("browser.blocked", learned);
  },
  setPrefs: (patch) => {
    const prefs = { ...get().prefs, ...patch };
    set({ prefs });
    void setKV("browser.prefs", prefs);
  },
}));
