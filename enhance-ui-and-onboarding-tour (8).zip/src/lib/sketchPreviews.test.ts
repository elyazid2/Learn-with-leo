import { describe, expect, it } from "vitest";
import { SKETCH_CARD_BG, SKETCH_PREVIEW_VERSION, hasSketchPreviews, sketchFingerprint, sketchPreview } from "./sketchPreviews";
import type { Sketch } from "./db";

const base: Sketch = { id: "s", projectId: "p", title: "Cell", scene: '{"elements":[]}', createdAt: 1, updatedAt: 1 };

describe("theme-aware sketch previews", () => {
  it("requires fresh light and dark previews, not the old white thumbnail", () => {
    expect(hasSketchPreviews({ ...base, thumb: "old-white" })).toBe(false);
    expect(sketchPreview({ ...base, thumb: "old-white" }, "dark")).toBeNull();
  });
  it("switches between cached previews immediately", () => {
    const s = { ...base, thumbVersion: SKETCH_PREVIEW_VERSION, thumbScene: sketchFingerprint(base.scene), thumbLight: "light", thumbDark: "dark" };
    expect(hasSketchPreviews(s)).toBe(true);
    expect(sketchPreview(s, "light")).toBe("light");
    expect(sketchPreview(s, "dark")).toBe("dark");
    expect(sketchPreview({ ...s, scene: '{"elements":[{}]}' }, "dark")).toBeNull();
  });
  it("does not regenerate an intentionally empty preview forever", () => {
    const s = { ...base, thumbVersion: SKETCH_PREVIEW_VERSION, thumbScene: sketchFingerprint(base.scene), thumbLight: "", thumbDark: "" };
    expect(hasSketchPreviews(s)).toBe(true);
    expect(sketchPreview(s, "dark")).toBeNull();
    expect(SKETCH_CARD_BG.dark).toBe("#1a1b1e");
  });
});