import { useEffect } from "react";
import { useRoute } from "@/lib/router";
import { useApp } from "@/lib/store";
import { ConfirmHost, Toast } from "@/components/ui";
import ShortcutsSheet, { useGlobalShortcuts } from "@/components/ShortcutsSheet";
import DeveloperBadge from "@/components/DeveloperBadge";
import ErrorBoundary from "@/components/ErrorBoundary";
import { useApplyPreferences } from "@/lib/settings";
import { resumeIndexing } from "@/lib/retrieval";
import Home from "@/screens/Home";
import Settings from "@/screens/Settings";
import ProjectScreen from "@/screens/Project";
import DevAvatars from "@/screens/DevAvatars";
import Memories from "@/screens/Memories";
import BrowserPanel from "@/components/BrowserPanel";
import RecorderPill from "@/components/library/Recorder";
import Tour from "@/components/Tour";
import { useSketchPreviewRepair } from "@/components/SketchThumbnail";

const SENSITIVE_INPUT_TYPES = new Set(["password", "email", "tel", "number", "search", "url", "hidden"]);

/**
 * Track the user's latest text selection inside project content so the AI can see it.
 * Never captures from: password/sensitive inputs, anything marked data-no-capture (Settings,
 * provider editors), the chat panel itself, or screens outside a project.
 */
function useSelectionCapture(active: boolean) {
  useEffect(() => {
    if (!active) return;
    let t: number | undefined;
    const capture = () => {
      const el = document.activeElement as HTMLElement | null;
      let text = "";
      let source = "page";
      if (el && (el.tagName === "TEXTAREA" || el.tagName === "INPUT")) {
        const input = el as HTMLInputElement;
        if (input.closest("[data-chat-panel],[data-no-capture]")) return;
        if (input.tagName === "INPUT" && (SENSITIVE_INPUT_TYPES.has(input.type) || input.autocomplete === "off")) return;
        const region = input.closest("[data-ctx-source]");
        if (!region) return; // same rule as DOM selections: only explicitly shareable regions
        if (input.selectionStart == null || input.selectionEnd == null) return;
        text = input.value.slice(input.selectionStart, input.selectionEnd);
        source = region.getAttribute("data-ctx-source") || "text";
      } else {
        const sel = document.getSelection();
        if (!sel || sel.isCollapsed) return;
        const node = sel.anchorNode;
        const parent = node?.nodeType === 1 ? (node as Element) : node?.parentElement;
        if (!parent || parent.closest("[data-chat-panel],[data-no-capture]")) return;
        // Only content explicitly marked as shareable (notes, PDF text, markdown) is captured.
        if (!parent.closest("[data-ctx-source]")) return;
        text = sel.toString();
        source = parent.closest("[data-ctx-source]")?.getAttribute("data-ctx-source") || "page";
      }
      text = text.trim();
      if (text.length > 1) useApp.getState().setSelection({ text: text.slice(0, 8000), source });
    };
    const on = () => {
      window.clearTimeout(t);
      t = window.setTimeout(capture, 250);
    };
    document.addEventListener("selectionchange", on);
    document.addEventListener("select", on, true);
    return () => {
      window.clearTimeout(t);
      document.removeEventListener("selectionchange", on);
      document.removeEventListener("select", on, true);
    };
  }, [active]);
}

export default function App() {
  useApplyPreferences();
  useSketchPreviewRepair();
  const route = useRoute();
  const inProject = route.name === "project";
  useSelectionCapture(inProject);
  useGlobalShortcuts();

  const routeKey = route.name === "project" ? `${route.projectId}/${route.tab}/${route.itemId ?? ""}` : route.name === "home" ? `home/${route.folderId ?? ""}` : route.name;

  useEffect(() => {
    window.scrollTo(0, 0);
    // A selection never outlives the screen it was made on.
    useApp.getState().setSelection(null);
  }, [routeKey]);

  useEffect(() => {
    resumeIndexing().catch(() => {});
  }, []);

  // Screen-level titles for tabs, history and screen readers (projects set their own name).
  useEffect(() => {
    if (route.name === "project") return;
    const titles: Record<string, string> = { home: "Harness — Learn with Leo", settings: "Settings · Harness", memories: "Memories · Harness", "dev-avatars": "Avatars · Harness" };
    document.title = titles[route.name] ?? "Harness";
  }, [route.name]);

  return (
    <ErrorBoundary scope="screen" resetKey={routeKey}>
      {route.name === "home" && <Home folderId={route.folderId} />}
      {route.name === "settings" && <Settings />}
      {route.name === "dev-avatars" && <DevAvatars />}
      {route.name === "memories" && <Memories />}
      {route.name === "project" && <ProjectScreen key={route.projectId} route={route} />}
      <Toast />
      <ConfirmHost />
      <ShortcutsSheet />
      <BrowserPanel />
      <RecorderPill />
      <DeveloperBadge />
      <Tour route={route} />
    </ErrorBoundary>
  );
}
