export async function parseMermaidToExcalidraw() {
  throw new Error("Mermaid diagrams are not available in this build.");
}
export default { parseMermaidToExcalidraw };
