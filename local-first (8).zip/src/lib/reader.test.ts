// @vitest-environment jsdom
import { describe, expect, it } from "vitest";
import { extractReadable } from "./reader";
import { resolveEnabled } from "./models";

describe("only enabled models are ever used", () => {
  const provider = { id: "p", models: ["claude-opus-4-5", "claude-haiku-4-5"], defaultModel: "claude-haiku-4-5" };
  it("keeps an enabled request", () => {
    expect(resolveEnabled(provider, "claude-opus-4-5")).toBe("claude-opus-4-5");
  });
  it("falls back when the request was disabled or unknown", () => {
    expect(resolveEnabled(provider, "claude-sonnet-4-5")).toBe("claude-haiku-4-5");
    expect(resolveEnabled(provider)).toBe("claude-haiku-4-5");
  });
  it("never invents a model when nothing is enabled", () => {
    expect(resolveEnabled({ id: "p", models: [], defaultModel: "x" }, "x")).toBe("");
  });
});

describe("page reader extraction", () => {
  const html = `<!doctype html><html><head><title>Eigenvalues — Notes</title>
    <script>window.evil = true</script><style>.x{color:red}</style></head>
    <body><nav>Skip to content Home About</nav>
    <article><h1>Eigenvalues</h1><p>An eigenvector keeps its direction under a linear map and is only scaled by its eigenvalue.</p>
    <p>The characteristic polynomial det(A − λI) = 0 gives the eigenvalues of a square matrix.</p>
    <a href="/wiki/Determinant">Determinant</a><a href="https://example.com/x">External</a>
    <a href="javascript:alert(1)">bad</a><a href="#top">top</a></article>
    <aside>Advertisement</aside><footer>Legal</footer></body></html>`;

  it("keeps article prose and drops chrome and scripts", () => {
    const out = extractReadable(html, "https://example.org/wiki/Eigenvalues");
    expect(out.title).toBe("Eigenvalues — Notes");
    expect(out.text).toContain("eigenvector keeps its direction");
    expect(out.text).not.toContain("Skip to content");
    expect(out.text).not.toContain("Advertisement");
    expect(out.text).not.toContain("window.evil");
  });

  it("resolves links and refuses unsafe protocols", () => {
    const { links } = extractReadable(html, "https://example.org/wiki/Eigenvalues");
    const hrefs = links.map((l) => l.href);
    expect(hrefs).toContain("https://example.org/wiki/Determinant");
    expect(hrefs).toContain("https://example.com/x");
    expect(hrefs.some((h) => h.startsWith("javascript:"))).toBe(false);
  });
});
