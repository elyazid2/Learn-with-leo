import { describe, expect, it } from "vitest";
import { modelLabel } from "./models";

describe("model labels", () => {
  it("keeps family and version, and adds brain", () => {
    expect(modelLabel("claude-opus-4-5-20251001")).toBe("Opus 4.5 brain");
    expect(modelLabel("gemini-2.5-flash")).toBe("Gemini 2.5 Flash brain");
    expect(modelLabel("gpt-4.1-mini")).toBe("GPT-4.1 Mini brain");
    expect(modelLabel("meta/llama-3.3-70b-instruct")).toBe("Llama 3.3 70B brain");
    expect(modelLabel("openai/o3-mini")).toBe("O3 Mini brain");
  });
});