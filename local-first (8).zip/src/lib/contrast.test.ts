import fs from "fs";
import { describe, expect, it } from "vitest";
import { ACCENT_TEXT_SHARE, contrast, mix, readableOn } from "./color";
import { POINT_META, PROJECT_COLORS, STATUS_META } from "./db";

const css = fs.readFileSync(new URL("../index.css", import.meta.url), "utf8");

function tokens(selector: string) {
  const esc = selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const block = new RegExp(`(^|\\n)${esc}\\s*\\{([^}]*)\\}`).exec(css)?.[2] ?? "";
  const out: Record<string, string> = {};
  for (const m of block.matchAll(/--([a-z-]+):\s*(#[0-9a-f]{3,6})\b/gi)) out[m[1]] = m[2];
  return out;
}

const themes = { light: tokens(":root"), dark: tokens(".dark") };
const accents = [...Object.values(POINT_META).map((p) => p.color), STATUS_META.learning.color, STATUS_META.shaky.color, STATUS_META.solid.color];

for (const [name, t] of Object.entries(themes)) {
  describe(`${name} theme contrast (WCAG AA)`, () => {
    it("defines the tokens we test", () => {
      for (const k of ["paper", "card", "elevated", "ink", "muted", "ok-fg", "ok-bg", "danger-fg", "danger-bg", "warn-fg", "warn-bg"]) expect(t[k], k).toBeTruthy();
    });

    it("primary and secondary text are readable on every surface", () => {
      for (const surface of ["paper", "card", "elevated"]) {
        expect(contrast(t.ink, t[surface])).toBeGreaterThanOrEqual(7);
        expect(contrast(t.muted, t[surface])).toBeGreaterThanOrEqual(4.5);
      }
    });

    it("semantic messages are readable", () => {
      for (const k of ["ok", "danger", "warn"]) expect(contrast(t[`${k}-fg`], t[`${k}-bg`]), k).toBeGreaterThanOrEqual(4.5);
    });

    it("accent-derived labels are readable on their tinted chips", () => {
      for (const c of accents) {
        const text = mix(c, t.ink, ACCENT_TEXT_SHARE);
        const bg = mix(c, t.card, 0.12);
        expect(contrast(text, bg), `${c} on ${name}`).toBeGreaterThanOrEqual(4.5);
      }
    });
  });
}

describe("project colors", () => {
  it("always get text that passes AA", () => {
    for (const [k, c] of Object.entries(PROJECT_COLORS)) expect(contrast(readableOn(c.hex), c.hex), k).toBeGreaterThanOrEqual(4.5);
  });
});
