/** Human label keeps the model family + version, while avoiding vendor marketing prose. */
export function modelLabel(id: string): string {
  const raw = id.trim();
  const clean = raw.split("/").pop() ?? raw;

  let m = /^o(\d+)(?:[-_.](mini|pro))?/i.exec(clean);
  if (m) return `O${m[1]}${m[2] ? ` ${cap(m[2])}` : ""} brain`;
  m = /claude-(opus|sonnet|haiku)[-_]?(\d+)[-_.](\d+)/i.exec(clean);
  if (m) return `${cap(m[1])} ${m[2]}.${m[3]} brain`;
  m = /claude-(opus|sonnet|haiku)[-_]?(\d+)/i.exec(clean);
  if (m) return `${cap(m[1])} ${m[2]} brain`;

  m = /gpt[-_ ]?(\d+(?:\.\d+)?)(?:[-_.](mini|nano|micro|pro|turbo|o\d+))?/i.exec(clean);
  if (m) return `GPT-${m[1]}${m[2] ? ` ${cap(m[2])}` : ""} brain`;

  m = /gemini[-_ ]?(\d+(?:\.\d+)?)(?:[-_.](flash|pro|flash-lite|thinking))?/i.exec(clean);
  if (m) return `Gemini ${m[1]}${m[2] ? ` ${cap(m[2])}` : ""} brain`;

  m = /(llama)[-_ ]?(\d+(?:\.\d+)?)(?:[-_.](\d+b))?/i.exec(clean);
  if (m) return `Llama ${m[2]}${m[3] ? ` ${m[3].toUpperCase()}` : ""} brain`;
  m = /(deepseek)[-_ ]?([a-z0-9.]+)?/i.exec(clean);
  if (m) return `DeepSeek ${m[2] ?? ""} brain`.replace(/\s+brain$/, " brain").replace(/\s+/g, " ");

  const version = /(?:^|[-_])v?(\d+(?:\.\d+){0,2})(?:$|[-_])/.exec(clean)?.[1];
  const family = clean.replace(/[-_.]?(?:v?\d+(?:\.\d+){0,2}).*$/i, "").replace(/[-_]+/g, " ");
  const label = family ? capWords(family) : capWords(clean.replace(/[-_]+/g, " "));
  return `${label}${version ? ` ${version}` : ""} brain`;
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
const capWords = (s: string) => s.replace(/\b[a-z]/g, (m) => m.toUpperCase());

export const enabledModels = (p: { models?: string[] }) => p.models ?? [];

/** The model actually in use must always be one the learner enabled for that provider. */
export function resolveEnabled(
  provider: { id: string; models: string[]; defaultModel: string },
  requested?: string
): string {
  const enabled = enabledModels(provider);
  if (requested && enabled.includes(requested)) return requested;
  if (enabled.includes(provider.defaultModel)) return provider.defaultModel;
  return enabled[0] ?? "";
}