import {
  db,
  uid,
  type ActionResult,
  type Concept,
  type ConceptStatus,
  type MemoryKind,
  type PointKind,
} from "../db";
import { useApp } from "../store";
import {
  isAvatarColor,
  isAvatarExpression,
  isAvatarShape,
  normalizeAvatarLook,
  type AvatarLook,
} from "../avatar";

export type Action =
  | { type: "ask"; question: string; options: string[] }
  | {
      type: "quiz";
      question: string;
      options: string[];
      answer: number;
      explanation?: string;
      concept?: string;
    }
  | { type: "set_level"; level: string; summary?: string; startingPoint?: string }
  | { type: "map"; concept: string; status?: ConceptStatus; parent?: string; note?: string }
  | { type: "point"; kind: PointKind; text: string }
  | { type: "resolve_point"; text: string }
  | { type: "set_avatar"; shape?: AvatarLook["shape"]; color?: AvatarLook["color"]; expression?: AvatarLook["expression"] }
  /** Grade an open-ended (typed) answer so it counts toward the map and review schedule. */
  | { type: "assess"; concept: string; correct: boolean; note?: string }
  | { type: "note"; id?: string; title: string; content: string }
  | { type: "sketch"; title: string; elements: { type: "rectangle" | "ellipse" | "diamond" | "arrow" | "text"; x: number; y: number; width?: number; height?: number; text?: string }[] }
  | { type: "browser"; url: string }
  | { type: "memory"; op: "save" | "update" | "delete"; id?: string; scope?: "global" | "project"; kind?: MemoryKind; text?: string };

export type Segment =
  | { kind: "text"; text: string }
  | { kind: "action"; action: Action; index: number }
  /** A block the model emitted that we could not parse/validate. Shown to the learner and fed back to the model. */
  | { kind: "invalid"; raw: string; reason: string }
  | { kind: "pending" };

const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.length <= 8 && v.every((o) => typeof o === "string");

const BLOCK_RE = /```action[^\n]*\n([\s\S]*?)```/g;

function parseBody(body: string): { actions: Action[]; invalid: { raw: string; reason: string }[] } {
  const clean = body.trim();
  const out: unknown[] = [];
  const invalid: { raw: string; reason: string }[] = [];
  try {
    const j = JSON.parse(clean);
    if (Array.isArray(j)) out.push(...j);
    else out.push(j);
  } catch {
    for (const line of clean.split("\n")) {
      const l = line.trim().replace(/,$/, "");
      if (!l) continue;
      try {
        out.push(JSON.parse(l));
      } catch {
        invalid.push({ raw: l.slice(0, 200), reason: "not valid JSON" });
      }
    }
  }
  const actions: Action[] = [];
  for (const o of out) {
    if (isAction(o)) actions.push(o);
    else invalid.push({ raw: JSON.stringify(o).slice(0, 200), reason: `unknown or malformed action "${(o as { type?: string })?.type ?? "?"}"` });
  }
  return { actions, invalid };
}

function isAction(a: unknown): a is Action {
  if (!a || typeof a !== "object") return false;
  const o = a as Record<string, unknown>;
  switch (o.type) {
    case "ask":
      return typeof o.question === "string" && isStringArray(o.options);
    case "quiz":
      return (
        typeof o.question === "string" &&
        isStringArray(o.options) &&
        typeof o.answer === "number" &&
        Number.isInteger(o.answer) &&
        o.answer >= 0 &&
        o.answer < (o.options as string[]).length
      );
    case "assess":
      return typeof o.concept === "string" && typeof o.correct === "boolean";
    case "set_level":
      return typeof o.level === "string";
    case "map":
      return typeof o.concept === "string";
    case "point":
      return typeof o.text === "string" && ["careful", "confused", "next"].includes(o.kind as string);
    case "resolve_point":
      return typeof o.text === "string";
    case "set_avatar":
      return (
        (o.shape === undefined || isAvatarShape(o.shape)) &&
        (o.color === undefined || isAvatarColor(o.color)) &&
        (o.expression === undefined || isAvatarExpression(o.expression)) &&
        (o.shape !== undefined || o.color !== undefined || o.expression !== undefined)
      );
    case "note":
      return typeof o.content === "string" && typeof (o.title ?? "") === "string" && (o.id === undefined || typeof o.id === "string");
    case "sketch":
      return (
        typeof o.title === "string" &&
        Array.isArray(o.elements) &&
        o.elements.length > 0 &&
        o.elements.length <= 40 &&
        o.elements.every((e: unknown) => {
          if (!e || typeof e !== "object") return false;
          const v = e as Record<string, unknown>;
          return (
            ["rectangle", "ellipse", "diamond", "arrow", "text"].includes(v.type as string) &&
            typeof v.x === "number" && Number.isFinite(v.x) && Math.abs(v.x) <= 2000 &&
            typeof v.y === "number" && Number.isFinite(v.y) && Math.abs(v.y) <= 2000 &&
            (v.width === undefined || (typeof v.width === "number" && v.width >= 0 && v.width <= 1200)) &&
            (v.height === undefined || (typeof v.height === "number" && v.height >= 0 && v.height <= 900)) &&
            (v.text === undefined || (typeof v.text === "string" && v.text.length <= 300))
          );
        })
      );
    case "browser":
      return typeof o.url === "string" && o.url.length <= 2048;
    case "memory":
      return (
        ["save", "update", "delete"].includes(o.op as string) &&
        (o.scope === undefined || ["global", "project"].includes(o.scope as string)) &&
        (o.kind === undefined || ["level", "goal", "preference", "strength", "weakness", "fact"].includes(o.kind as string)) &&
        (o.text === undefined || (typeof o.text === "string" && o.text.length <= 500)) &&
        (o.id === undefined || typeof o.id === "string")
      );
    default:
      return false;
  }
}

export function parseSegments(content: string, streaming = false): Segment[] {
  const segs: Segment[] = [];
  let last = 0;
  let idx = 0;
  let m: RegExpExecArray | null;
  BLOCK_RE.lastIndex = 0;
  while ((m = BLOCK_RE.exec(content))) {
    const before = content.slice(last, m.index);
    if (before.trim()) segs.push({ kind: "text", text: before });
    const { actions, invalid } = parseBody(m[1]);
    for (const a of actions) segs.push({ kind: "action", action: a, index: idx++ });
    for (const inv of invalid) segs.push({ kind: "invalid", ...inv });
    last = m.index + m[0].length;
  }
  let rest = content.slice(last);
  const open = rest.indexOf("```action");
  if (open >= 0) {
    const before = rest.slice(0, open);
    if (before.trim()) segs.push({ kind: "text", text: before });
    if (streaming) segs.push({ kind: "pending" });
    else segs.push({ kind: "invalid", raw: rest.slice(open, open + 200), reason: "action block was cut off" });
  } else {
    if (streaming) rest = rest.replace(/`{1,3}[a-z]{0,6}$/, "");
    if (rest.trim()) segs.push({ kind: "text", text: rest });
  }
  return segs;
}

export function extractActions(content: string): Action[] {
  return parseSegments(content)
    .filter((s): s is Extract<Segment, { kind: "action" }> => s.kind === "action")
    .map((s) => s.action);
}

/** Problems the model should hear about on its next turn. */
export function invalidActionFeedback(content: string): string | null {
  const bad = parseSegments(content).filter((s): s is Extract<Segment, { kind: "invalid" }> => s.kind === "invalid");
  if (!bad.length) return null;
  return `Note: ${bad.length} of your action blocks could not be executed (${bad.map((b) => b.reason).join("; ")}). Re-emit them as valid JSON if they still matter.`;
}

/** Strip action blocks for plain-text uses (thread titles, history summaries). */
export function stripActions(content: string) {
  return content.replace(BLOCK_RE, "").trim();
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

export async function findConcept(projectId: string, name: string) {
  const all = await db.concepts.where("projectId").equals(projectId).toArray();
  return all.find((c) => norm(c.name) === norm(name));
}

export async function upsertConcept(
  projectId: string,
  name: string,
  patch: Partial<Pick<Concept, "status" | "note">> = {},
  parentName?: string
): Promise<Concept> {
  const now = Date.now();
  let parentId: string | undefined;
  if (parentName && norm(parentName) !== norm(name)) {
    const parent = await upsertConcept(projectId, parentName);
    parentId = parent.id;
  }
  const existing = await findConcept(projectId, name);
  if (existing) {
    const upd: Partial<Concept> = { updatedAt: now };
    if (patch.status) upd.status = patch.status;
    if (patch.note) upd.note = patch.note;
    if (parentId && parentId !== existing.id) upd.parentId = parentId;
    await db.concepts.update(existing.id, upd);
    return { ...existing, ...upd };
  }
  const c: Concept = {
    id: uid(),
    projectId,
    name: name.trim().slice(0, 80),
    parentId,
    status: patch.status ?? "new",
    note: patch.note,
    correct: 0,
    attempts: 0,
    createdAt: now,
    updatedAt: now,
  };
  await db.concepts.add(c);
  return c;
}

const DAY = 86_400_000;

/** Record one graded outcome: stats, recent window, status and a simple spaced-review schedule. */
export async function recordQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await upsertConcept(projectId, conceptName);
  const fresh = (await db.concepts.get(c.id))!;
  let status = fresh.status;
  if (correct && status === "new") status = "learning";
  if (!correct && status === "solid") status = "shaky";
  const recent = [...(fresh.recent ?? []), correct ? 1 : 0].slice(-10);
  // Two consecutive correct answers on a learning concept earn "solid".
  if (correct && status === "learning" && recent.length >= 2 && recent.slice(-2).every((r) => r === 1)) status = "solid";
  const prev = fresh.interval ?? 0;
  const interval = correct ? Math.min(60, prev === 0 ? 1 : Math.round(prev * 2.2 * 10) / 10) : 0.5;
  const now = Date.now();
  await db.concepts.update(c.id, {
    attempts: fresh.attempts + 1,
    correct: fresh.correct + (correct ? 1 : 0),
    recent,
    status,
    interval,
    lastReviewed: now,
    nextReview: now + interval * DAY,
    updatedAt: now,
  });
}

/** Undo one graded outcome (learner disputed the answer key). */
export async function revertQuizResult(projectId: string, conceptName: string, correct: boolean) {
  const c = await findConcept(projectId, conceptName);
  if (!c || c.attempts === 0) return;
  const recent = [...(c.recent ?? [])];
  const idx = recent.lastIndexOf(correct ? 1 : 0);
  if (idx >= 0) recent.splice(idx, 1);
  await db.concepts.update(c.id, {
    attempts: c.attempts - 1,
    correct: Math.max(0, c.correct - (correct ? 1 : 0)),
    recent,
    updatedAt: Date.now(),
  });
}

export async function addPoint(projectId: string, kind: PointKind, text: string, author: "user" | "ai") {
  const t = text.trim();
  if (!t) return false;
  const existing = await db.points.where("projectId").equals(projectId).toArray();
  if (existing.some((p) => !p.done && norm(p.text) === norm(t))) return false;
  await db.points.add({ id: uid(), projectId, kind, text: t, author, done: false, createdAt: Date.now() });
  return true;
}

export async function executeActions(
  projectId: string,
  threadId: string,
  actions: Action[]
): Promise<ActionResult[]> {
  const results: ActionResult[] = [];
  for (const a of actions) {
    try {
      switch (a.type) {
        case "set_level": {
          // Gate: placement needs evidence. Count answered ask/quiz cards in this thread.
          const project = await db.projects.get(projectId);
          if (project?.placement.status !== "done") {
            const msgs = await db.messages.where("threadId").equals(threadId).toArray();
            const answered = msgs.reduce((n, m) => n + Object.keys(m.answers ?? {}).length, 0);
            if (answered < 3) {
              results.push({ type: a.type, label: `Level not set yet — only ${answered} answered question(s); ask at least 3`, ok: false });
              break;
            }
          }
          await db.projects.update(projectId, {
            placement: {
              status: "done",
              level: a.level,
              summary: a.summary,
              startingPoint: a.startingPoint,
              at: Date.now(),
            },
            updatedAt: Date.now(),
          });
          await db.threads.update(threadId, { mode: "ask" });
          results.push({ type: a.type, label: `Level set: ${a.level}`, ok: true });
          break;
        }
        case "map": {
          const status = (["new", "learning", "shaky", "solid"] as const).includes(a.status as ConceptStatus)
            ? a.status
            : undefined;
          await upsertConcept(projectId, a.concept, { status, note: a.note }, a.parent);
          results.push({
            type: a.type,
            label: `${a.concept}${status ? ` → ${status}` : ""}`,
            ok: true,
          });
          break;
        }
        case "point": {
          const ok = await addPoint(projectId, a.kind, a.text, "ai");
          if (ok) results.push({ type: a.type, label: a.text, ok: true });
          break;
        }
        case "resolve_point": {
          const pts = await db.points.where("projectId").equals(projectId).toArray();
          const target = pts.find((p) => !p.done && norm(p.text) === norm(a.text));
          if (target) {
            await db.points.update(target.id, { done: true, resolvedBy: "ai" });
            results.push({ type: a.type, label: target.text, ok: true });
          } else {
            results.push({ type: a.type, label: `No open point matches “${a.text}” exactly`, ok: false });
          }
          break;
        }
        case "assess": {
          await recordQuizResult(projectId, a.concept, a.correct);
          if (a.note) await upsertConcept(projectId, a.concept, { note: a.note });
          results.push({ type: a.type, label: `${a.concept}: ${a.correct ? "correct" : "needs work"}`, ok: true });
          break;
        }
        case "set_avatar": {
          const project = await db.projects.get(projectId);
          if (!project) break;
          const current = normalizeAvatarLook(project.avatar);
          const look = normalizeAvatarLook({ ...current, ...a }, current);
          await db.projects.update(projectId, { avatar: look, updatedAt: Date.now() });
          results.push({ type: a.type, label: `${look.shape} · ${look.color} · ${look.expression}`, ok: true });
          break;
        }
        case "note": {
          const now = Date.now();
          if (a.id) {
            const existing = await db.notes.get(a.id);
            if (!existing || existing.projectId !== projectId) {
              results.push({ type: a.type, label: "Note not found in this project", ok: false });
              break;
            }
            await db.notes.update(a.id, { title: a.title?.trim() || existing.title, content: a.content, author: "ai", updatedAt: now });
            const updated = await db.notes.get(a.id);
            if (updated) {
              const { indexNote } = await import("../retrieval");
              await indexNote(updated);
            }
            results.push({ type: a.type, label: `Updated note · ${a.title || existing.title}`, ok: true });
          } else {
            const id = uid();
            await db.notes.add({ id, projectId, title: a.title?.trim() || "Leo's note", content: a.content, author: "ai", createdAt: now, updatedAt: now });
            const created = await db.notes.get(id);
            if (created) {
              const { indexNote } = await import("../retrieval");
              await indexNote(created);
            }
            results.push({ type: a.type, label: `Created note · ${a.title || "Leo's note"}`, ok: true });
          }
          break;
        }
        case "sketch": {
          const { convertToExcalidrawElements, serializeAsJSON } = await import("@excalidraw/excalidraw");
          const skeleton = a.elements.map((e) => {
            if (e.type === "text") return { type: "text", x: e.x, y: e.y, text: e.text || "" };
            if (e.type === "arrow") return { type: "arrow", x: e.x, y: e.y, width: e.width ?? 100, height: e.height ?? 0 };
            return {
              type: e.type,
              x: e.x,
              y: e.y,
              width: e.width ?? 140,
              height: e.height ?? 72,
              strokeColor: "#17171a",
              backgroundColor: "transparent",
              fillStyle: "solid",
              strokeWidth: 2,
              roughness: 0,
            };
          });
          const elements = convertToExcalidrawElements(skeleton as never, { regenerateIds: true });
          const scene = serializeAsJSON(elements, { viewBackgroundColor: "#ffffff", gridSize: 20 } as never, {} as never, "local");
          const now = Date.now();
          const id = uid();
          await db.sketches.add({ id, projectId, title: a.title.trim() || "Leo's sketch", scene, createdAt: now, updatedAt: now });
          results.push({ type: a.type, label: `Created sketch · ${a.title || "Untitled"}`, ok: true });
          break;
        }
        case "browser": {
          let url: URL;
          try {
            url = new URL(a.url);
          } catch {
            throw new Error("Invalid URL");
          }
          if (!["http:", "https:"].includes(url.protocol)) throw new Error("Leo can only open http and https pages");
          useApp.getState().setBrowserUrl(url.href);
          useApp.getState().setBrowserOpen(true);
          results.push({ type: a.type, label: `Opened browser · ${url.hostname}`, ok: true });
          break;
        }
        case "memory": {
          if (a.op === "delete") {
            if (!a.id) throw new Error("Memory delete needs an id");
            const existing = await db.memories.get(a.id);
            if (existing && (existing.projectId === projectId || existing.projectId === "*")) await db.memories.delete(a.id);
            results.push({ type: a.type, label: existing ? "Forgot that memory" : "Memory not found", ok: !!existing });
            break;
          }
          if (!a.text?.trim() || !a.kind) throw new Error("Memory save needs a kind and text");
          const scopeId = a.scope === "project" ? projectId : "*";
          const now = Date.now();
          if (a.op === "update" && a.id) {
            const existing = await db.memories.get(a.id);
            if (!existing || (existing.projectId !== projectId && existing.projectId !== "*")) throw new Error("Memory not found");
            await db.memories.update(a.id, { projectId: scopeId, kind: a.kind, text: a.text.trim(), updatedAt: now });
            results.push({ type: a.type, label: `Updated memory · ${a.kind}`, ok: true });
          } else {
            const all = await db.memories.where("projectId").equals(scopeId).toArray();
            const duplicate = all.find((m) => m.kind === a.kind && norm(m.text) === norm(a.text!));
            if (duplicate) {
              await db.memories.update(duplicate.id, { text: a.text.trim(), updatedAt: now });
              results.push({ type: a.type, label: `Updated memory · ${a.kind}`, ok: true });
            } else {
              await db.memories.add({ id: uid(), projectId: scopeId, kind: a.kind, text: a.text.trim(), createdAt: now, updatedAt: now });
              results.push({ type: a.type, label: `Remembered · ${a.kind}`, ok: true });
            }
          }
          break;
        }
        default:
          break;
      }
    } catch (e) {
      results.push({ type: a.type, label: String(e), ok: false });
    }
  }
  return results;
}
