import { beforeEach, describe, expect, it } from "vitest";
import { db } from "../db";
import { executeActions, extractActions, invalidActionFeedback, parseSegments, recordQuizResult, revertQuizResult, upsertConcept } from "./actions";

const block = (o: unknown) => "```action\n" + JSON.stringify(o) + "\n```";

describe("action parsing", () => {
  it("parses valid actions and keeps their order/index", () => {
    const segs = parseSegments(`Hi\n${block({ type: "map", concept: "Vectors", status: "solid" })}\n${block({ type: "quiz", question: "q", options: ["a", "b"], answer: 1 })}`);
    expect(segs.map((s) => s.kind)).toEqual(["text", "action", "action"]);
    expect(segs[2]).toMatchObject({ kind: "action", index: 1 });
  });

  it("rejects an out-of-range quiz answer instead of grading everything wrong", () => {
    const segs = parseSegments(block({ type: "quiz", question: "q", options: ["a", "b"], answer: 5 }));
    expect(segs[0].kind).toBe("invalid");
    expect(extractActions(block({ type: "quiz", question: "q", options: ["a", "b"], answer: -1 }))).toHaveLength(0);
  });

  it("rejects non-string options (would crash React when rendered)", () => {
    const segs = parseSegments(block({ type: "quiz", question: "q", options: [{ text: "a" }, "b"], answer: 0 }));
    expect(segs[0].kind).toBe("invalid");
  });

  it("marks a cut-off block as pending while streaming and invalid once final", () => {
    const partial = "Text\n```action\n{\"type\":\"map\",\"concept\":\"X";
    expect(parseSegments(partial, true).at(-1)?.kind).toBe("pending");
    expect(parseSegments(partial, false).at(-1)?.kind).toBe("invalid");
  });

  it("produces feedback for the model about malformed blocks", () => {
    expect(invalidActionFeedback("```action\n{not json}\n```")).toMatch(/could not be executed/);
    expect(invalidActionFeedback("plain")).toBeNull();
  });
});

describe("grading and spaced review", () => {
  beforeEach(async () => {
    await Promise.all(db.tables.map((t) => t.clear()));
    await db.projects.add({ id: "p1", name: "Algebra", tag: "", color: "blue", createdAt: 1, updatedAt: 1, placement: { status: "pending" } });
  });

  it("schedules a review, grows the interval on success and resets it on failure", async () => {
    await recordQuizResult("p1", "Determinants", true);
    let c = (await db.concepts.where("projectId").equals("p1").toArray())[0];
    expect(c.status).toBe("learning");
    expect(c.interval).toBe(1);
    expect(c.nextReview! - c.lastReviewed!).toBeCloseTo(86_400_000, -3);

    await recordQuizResult("p1", "Determinants", true);
    c = (await db.concepts.get(c.id))!;
    expect(c.status).toBe("solid"); // two in a row
    expect(c.interval).toBeGreaterThan(1);

    await recordQuizResult("p1", "Determinants", false);
    c = (await db.concepts.get(c.id))!;
    expect(c.status).toBe("shaky");
    expect(c.interval).toBe(0.5);
    expect(c.recent).toEqual([1, 1, 0]);
  });

  it("reverts a disputed outcome", async () => {
    await recordQuizResult("p1", "Rank", false);
    await revertQuizResult("p1", "Rank", false);
    const c = (await db.concepts.where("projectId").equals("p1").toArray())[0];
    expect(c.attempts).toBe(0);
    expect(c.recent).toEqual([]);
  });

  it("refuses set_level before three answered questions", async () => {
    await db.threads.add({ id: "t1", projectId: "p1", title: "Placement", mode: "placement", createdAt: 1, updatedAt: 1 });
    const r = await executeActions("p1", "t1", [{ type: "set_level", level: "Novice" }]);
    expect(r[0].ok).toBe(false);
    expect((await db.projects.get("p1"))!.placement.status).toBe("pending");

    for (let i = 0; i < 3; i++)
      await db.messages.add({ id: "m" + i, threadId: "t1", projectId: "p1", role: "assistant", content: "", answers: { 0: 1 }, createdAt: i });
    const ok = await executeActions("p1", "t1", [{ type: "set_level", level: "Novice" }]);
    expect(ok[0].ok).toBe(true);
    expect((await db.projects.get("p1"))!.placement.level).toBe("Novice");
  });

  it("resolves points only on exact match and records who resolved them", async () => {
    await db.points.add({ id: "pt1", projectId: "p1", kind: "next", text: "Learn eigenvalues", author: "user", done: false, createdAt: 1 });
    const miss = await executeActions("p1", "t1", [{ type: "resolve_point", text: "eigenvalues" }]);
    expect(miss[0].ok).toBe(false);
    const hit = await executeActions("p1", "t1", [{ type: "resolve_point", text: "learn eigenvalues" }]);
    expect(hit[0].ok).toBe(true);
    expect((await db.points.get("pt1"))!.resolvedBy).toBe("ai");
  });

  it("assess grades open answers into the map", async () => {
    await upsertConcept("p1", "Span", { status: "learning" });
    await executeActions("p1", "t1", [{ type: "assess", concept: "Span", correct: true }]);
    const c = (await db.concepts.where("projectId").equals("p1").toArray())[0];
    expect(c.attempts).toBe(1);
    expect(c.nextReview).toBeGreaterThan(Date.now());
  });
});

describe("memory, browser and sketch tools", () => {
  beforeEach(async () => {
    await Promise.all(db.tables.map((t) => t.clear()));
    await db.projects.add({ id: "p1", name: "Algebra", tag: "", color: "blue", createdAt: 1, updatedAt: 1, placement: { status: "pending" } });
  });

  it("saves, deduplicates, scopes, updates and forgets memories", async () => {
    const save = (text: string, extra: Record<string, unknown> = {}) =>
      executeActions("p1", "t1", [{ type: "memory", op: "save", kind: "goal", text, ...extra } as never]);
    await save("Pass the linear algebra exam");
    await save("Pass the linear algebra exam");
    let all = await db.memories.toArray();
    expect(all).toHaveLength(1);
    expect(all[0].projectId).toBe("*");

    await save("Understand eigenvalues deeply", { scope: "project" });
    all = await db.memories.toArray();
    expect(all.find((m) => m.text.startsWith("Understand"))?.projectId).toBe("p1");
    const target = all[0];
    await executeActions("p1", "t1", [{ type: "memory", op: "update", id: target.id, kind: "level", text: "Comfortable with matrices" } as never]);
    expect((await db.memories.get(target.id))?.kind).toBe("level");
    await executeActions("p1", "t1", [{ type: "memory", op: "delete", id: target.id } as never]);
    expect(await db.memories.get(target.id)).toBeUndefined();
  });

  it("rejects malformed memories and unsafe sketch/browser payloads at parse time", () => {
    expect(extractActions(block({ type: "memory", op: "save", kind: "secrets", text: "x" }))).toHaveLength(0);
    expect(extractActions(block({ type: "memory", op: "drop", kind: "goal", text: "x" }))).toHaveLength(0);
    expect(extractActions(block({ type: "sketch", title: "x", elements: [{ type: "image", x: 0, y: 0 }] }))).toHaveLength(0);
    expect(extractActions(block({ type: "browser", url: "javascript:alert(1)" }))).toHaveLength(1);
    const valid = extractActions(block({ type: "sketch", title: "Map", elements: [{ type: "text", x: 10, y: 10, text: "hello" }] }));
    expect(valid).toHaveLength(1);
  });

  it("executeActions refuses non-http browser URLs", async () => {
    const r = await executeActions("p1", "t1", [{ type: "browser", url: "file:///etc/passwd" }]);
    expect(r[0].ok).toBe(false);
  });
});
