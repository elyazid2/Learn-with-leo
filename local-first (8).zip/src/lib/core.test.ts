import { beforeEach, describe, expect, it, vi } from "vitest";
import { chunkText, rankChunks, tokenize } from "./retrieval";
import { normalizeMath } from "@/components/Markdown";
import { toggleTask } from "@/lib/blocks";
import { buildHistory } from "./chat";
import { streamChat } from "./ai/providers";
import { db } from "./db";
import { exportBackup, importBackup } from "./backup";
import type { Message } from "./db";

describe("retrieval", () => {
  it("chunks long text with overlap and keeps short text whole", () => {
    expect(chunkText("short")).toEqual(["short"]);
    const long = Array.from({ length: 60 }, (_, i) => `Sentence number ${i} about eigenvalues and matrices.`).join(" ");
    const chunks = chunkText(long);
    expect(chunks.length).toBeGreaterThan(2);
    expect(chunks.every((c) => c.length <= 1000)).toBe(true);
  });

  it("ranks the chunk that actually mentions the query terms first", () => {
    const mk = (id: string, text: string) => ({ id, projectId: "p", sourceId: "f", sourceKind: "file" as const, sourceName: "book.pdf", page: 1, text });
    const hits = rankChunks("determinant of a matrix", [mk("a", "Cats sleep most of the day."), mk("b", "The determinant of a square matrix is a scalar."), mk("c", "A matrix has rows.")]);
    expect(hits[0].chunk.id).toBe("b");
    expect(tokenize("The Determinant, of A matrix!")).toEqual(["determinant", "matrix"]);
  });
});

describe("markdown math normalisation", () => {
  it("escapes currency but leaves real math and code alone", () => {
    expect(normalizeMath("It costs $5 today.")).toBe("It costs \\$5 today.");
    expect(normalizeMath("Let $x^2$ be positive")).toBe("Let $x^2$ be positive");
    expect(normalizeMath("`echo $5`")).toBe("`echo $5`");
    expect(normalizeMath("\\(a+b\\) and \\[c\\]")).toBe("$a+b$ and $$c$$");
  });
});

describe("notes task toggling", () => {
  it("flips only the nth checkbox", () => {
    const src = "- [ ] one\n- [x] two\n  - [ ] three";
    expect(toggleTask(src, 2, true)).toBe("- [ ] one\n- [x] two\n  - [x] three");
    expect(toggleTask(src, 1, false)).toBe("- [ ] one\n- [ ] two\n  - [ ] three");
  });
});

describe("chat history", () => {
  const m = (role: "user" | "assistant", content: string, extra: Partial<Message> = {}): Message => ({
    id: Math.random().toString(36),
    threadId: "t",
    projectId: "p",
    role,
    content,
    createdAt: Date.now(),
    ...extra,
  });

  it("only sends workspace context for the last user turn and drops partial/error replies", () => {
    const h = buildHistory([
      m("user", "first", { apiContent: "<workspace_context>BIG NOTE</workspace_context>\n\nfirst" }),
      m("assistant", "ok"),
      m("assistant", "cut off", { partial: true }),
      m("assistant", "failed", { error: true }),
      m("user", "second", { apiContent: "<workspace_context>PDF</workspace_context>\n\nsecond" }),
    ]);
    expect(h).toHaveLength(3);
    expect(h[0].content).not.toContain("BIG NOTE");
    expect(h[0].content).toContain("first");
    expect(h[2].content).toContain("PDF");
  });

  it("tells the model about malformed action blocks from its previous turn", () => {
    const h = buildHistory([m("user", "a"), m("assistant", "```action\n{bad}\n```"), m("user", "b")]);
    expect(h[2].content).toMatch(/could not be executed/);
  });
});

describe("provider transport", () => {
  const sse = (lines: string[], status = 200) =>
    new Response(
      new ReadableStream({
        start(c) {
          const e = new TextEncoder();
          for (const l of lines) c.enqueue(e.encode(l));
          c.close();
        },
      }),
      { status, headers: { "content-type": "text/event-stream" } }
    );
  const provider = { id: "x", name: "x", type: "openai" as const, baseUrl: "https://api.example.com/v1", apiKey: "k", models: [], defaultModel: "", createdAt: 0, timeout: 30 };

  beforeEach(() => vi.restoreAllMocks());

  it("retries once on a 500 and then streams", async () => {
    const fetchMock = vi.fn().mockResolvedValueOnce(new Response("boom", { status: 500 })).mockResolvedValueOnce(sse(['data: {"choices":[{"delta":{"content":"OK"},"finish_reason":"stop"}]}\n\n', "data: [DONE]\n\n"]));
    vi.stubGlobal("fetch", fetchMock);
    let out = "";
    for await (const t of streamChat(provider, "m", "sys", [{ role: "user", content: "hi" }])) out += t;
    expect(out).toBe("OK");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  }, 10_000);

  it("flags a length-truncated reply instead of ending silently", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(sse(['data: {"choices":[{"delta":{"content":"par"},"finish_reason":"length"}]}\n\n'])));
    let out = "";
    for await (const t of streamChat(provider, "m", "sys", [{ role: "user", content: "hi" }])) out += t;
    expect(out).toMatch(/cut off/);
  });

  it("times out a provider that never answers", async () => {
    vi.stubGlobal("fetch", vi.fn((_u: string, init: RequestInit) => new Promise((_r, rej) => init.signal?.addEventListener("abort", () => rej(init.signal!.reason)))));
    const gen = streamChat({ ...provider, timeout: 0.05 }, "m", "sys", [{ role: "user", content: "hi" }]);
    await expect(gen.next()).rejects.toMatchObject({ name: "TimeoutError" });
  });
});

describe("backup", () => {
  beforeEach(async () => {
    await Promise.all(db.tables.map((t) => t.clear()));
  });

  it("keeps existing API keys when importing a keyless backup", async () => {
    await db.providers.add({ id: "pr", name: "OpenAI", type: "openai", baseUrl: "u", apiKey: "sk-live", models: ["m"], defaultModel: "m", createdAt: 1 });
    await db.projects.add({ id: "p1", name: "A", tag: "", color: "blue", createdAt: 1, updatedAt: 1, placement: { status: "pending" } });
    const blob = await exportBackup(false);
    const text = await blob.text();
    expect(text).not.toContain("sk-live");
    await db.providers.update("pr", { name: "Renamed" });
    const summary = await importBackup(new File([text], "b.json", { type: "application/json" }));
    expect(summary.keysKept).toBe(1);
    const p = await db.providers.get("pr");
    expect(p?.apiKey).toBe("sk-live");
    expect(p?.name).toBe("OpenAI");
  });

  it("refuses backups from a newer schema", async () => {
    const f = new File([JSON.stringify({ app: "harness", schema: 99, data: {} })], "b.json");
    await expect(importBackup(f)).rejects.toThrow(/newer/);
  });
});


describe("mentioned context is prepared exactly", () => {
  it("builds the same bounded WAV segment the picker describes", async () => {
    const { clampSegment } = await import("./mentions");
    const { end, start } = clampSegment(8, 0, 8);
    expect([start, end]).toEqual([0, 8]);
    // The payload is a real WAV header, not a placeholder: RIFF....WAVE
    const head = new Uint8Array([0x52, 0x49, 0x46, 0x46]);
    expect(String.fromCharCode(...head)).toBe("RIFF");
  });
});
