import { useEffect, useSyncExternalStore } from "react";
import { create } from "zustand";
import { normalizeAvatarLook, type AgentState, type AvatarLook } from "./avatar";

export type ForcedAgentState = "auto" | AgentState;
export type MockBehavior = "auto" | "error";
export type ThemePreference = "light" | "dark" | "system";

interface Settings {
  theme: ThemePreference;
  reduceMotion: boolean;
  avatar: AvatarLook;
  developerMode: boolean;
  forcedAgentState: ForcedAgentState;
  mockBehavior: MockBehavior;
  mockDelay: number;
  enterToSend: boolean;
  shareMediaByDefault: boolean;
  confirmDeletes: boolean;
}

interface SettingsStore extends Settings {
  setSettings: (patch: Partial<Settings>) => void;
}

const DEFAULTS: Settings = {
  theme: "system",
  reduceMotion: false,
  avatar: normalizeAvatarLook(null),
  developerMode: false,
  forcedAgentState: "auto",
  mockBehavior: "auto",
  mockDelay: 650,
  enterToSend: true,
  shareMediaByDefault: false,
  confirmDeletes: true,
};

function readSettings(): Settings {
  try {
    const saved = JSON.parse(localStorage.getItem("harness.settings") || "{}") as Partial<Settings>;
    return {
      theme: ["light", "dark", "system"].includes(saved.theme ?? "") ? (saved.theme as ThemePreference) : DEFAULTS.theme,
      reduceMotion: saved.reduceMotion === true,
      avatar: normalizeAvatarLook(saved.avatar, DEFAULTS.avatar),
      developerMode: saved.developerMode === true,
      forcedAgentState: ["auto", "idle", "listening", "thinking", "speaking", "working", "waiting", "blocked", "done"].includes(saved.forcedAgentState ?? "")
        ? (saved.forcedAgentState as ForcedAgentState)
        : DEFAULTS.forcedAgentState,
      mockBehavior: saved.mockBehavior === "error" ? "error" : "auto",
      mockDelay: typeof saved.mockDelay === "number" ? Math.max(0, Math.min(3000, saved.mockDelay)) : DEFAULTS.mockDelay,
      enterToSend: saved.enterToSend !== false,
      shareMediaByDefault: saved.shareMediaByDefault === true,
      confirmDeletes: saved.confirmDeletes !== false,
    };
  } catch {
    return DEFAULTS;
  }
}

export const useSettings = create<SettingsStore>((set) => ({
  ...readSettings(),
  setSettings: (patch) => set(patch),
}));

useSettings.subscribe((state) => {
  localStorage.setItem("harness.settings", JSON.stringify(state, (key, value) => (key === "setSettings" ? undefined : value)));
});

const darkMedia = () => window.matchMedia("(prefers-color-scheme: dark)");

export function useSystemDark() {
  return useSyncExternalStore(
    (onChange) => {
      const media = darkMedia();
      media.addEventListener("change", onChange);
      return () => media.removeEventListener("change", onChange);
    },
    () => darkMedia().matches,
    () => false
  );
}

export function useResolvedTheme(): "light" | "dark" {
  const theme = useSettings((s) => s.theme);
  const systemDark = useSystemDark();
  return theme === "system" ? (systemDark ? "dark" : "light") : theme;
}

export function useApplyPreferences() {
  const resolved = useResolvedTheme();
  const reduceMotion = useSettings((s) => s.reduceMotion);
  // Dev overrides can be written between reload and this effect; re-apply once more.
  useEffect(() => {
    const id = window.setTimeout(() => {
      const root = document.documentElement;
      root.classList.toggle("dark", resolved === "dark");
      root.style.colorScheme = resolved;
    }, 50);
    return () => window.clearTimeout(id);
  }, [resolved]);
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", resolved === "dark");
    root.classList.toggle("reduce-motion", reduceMotion);
    root.style.colorScheme = resolved;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", resolved === "dark" ? "#111214" : "#f5f4ef");
  }, [resolved, reduceMotion]);
}

export function confirmDeletion(message: string) {
  return !useSettings.getState().confirmDeletes || window.confirm(message);
}
