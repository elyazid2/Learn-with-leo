import { describe, expect, it } from "vitest";
import { LIST_RE, inFence, joinBlocks, nextMarker, snippetOf, splitBlocks } from "./blocks";
import { faceFor, gazeFor, lerpFace, normalizeAvatarLook, opennessFor, AVATAR_EXPRESSIONS, REST_GAZE } from "./avatar";

describe("note blocks", () => {
  it("splits on blank lines and round-trips", () => {
    const md = "## Title\nIntro line\n\n- a\n- b\n\n> quote";
    expect(splitBlocks(md)).toEqual(["## Title\nIntro line", "- a\n- b", "> quote"]);
    expect(joinBlocks(splitBlocks(md))).toBe(md);
  });

  it("keeps fenced code and display math intact across blank lines", () => {
    const md = "Before\n\n```js\nconst a = 1;\n\nconst b = 2;\n```\n\n$$\na^2\n\nb^2\n$$\n\nAfter";
    const blocks = splitBlocks(md);
    expect(blocks).toHaveLength(4);
    expect(blocks[1]).toContain("const b = 2;");
    expect(blocks[2]).toContain("b^2");
    expect(joinBlocks(blocks)).toBe(md);
  });

  it("treats one-line $$…$$ as a normal block", () => {
    expect(splitBlocks("$$Av = \\lambda v$$\n\nNext")).toEqual(["$$Av = \\lambda v$$", "Next"]);
  });

  it("continues list markers sensibly", () => {
    expect(nextMarker("- ")).toBe("- ");
    expect(nextMarker("- [x] ")).toBe("- [ ] ");
    expect(nextMarker("  3. ")).toBe("  4. ");
    expect(nextMarker("> ")).toBe("> ");
    expect(LIST_RE.exec("- [ ] task")?.[0]).toBe("- [ ] ");
  });

  it("knows when the caret is inside a code fence", () => {
    expect(inFence("```\ncode")).toBe(true);
    expect(inFence("```\ncode\n```\n")).toBe(false);
  });

  it("makes readable previews from markdown with math", () => {
    expect(snippetOf("## Hi\nIt has $n$ vectors and $\\lambda$ **bold**")).toBe("Hi It has n vectors and λ bold");
    expect(snippetOf("- [ ] Learn $\\mathbf{v}$")).toBe("Learn v");
  });
});

describe("avatar motion", () => {
  it("frozen frames at t=0 rest on the state's pose with eyes open", () => {
    for (const s of ["idle", "listening", "thinking", "speaking", "working", "waiting", "blocked", "done"] as const) {
      expect(gazeFor(s, 0)).toEqual(REST_GAZE[s]);
      expect(opennessFor(s, 0)).toBe(1);
    }
  });

  it("is deterministic and keeps the gaze inside the face", () => {
    for (let t = 0; t < 30; t += 0.37) {
      const [x, y] = gazeFor("idle", t, 3);
      expect(gazeFor("idle", t, 3)).toEqual([x, y]);
      expect(Math.abs(x)).toBeLessThanOrEqual(4.3);
      expect(Math.abs(y)).toBeLessThanOrEqual(4.7);
      expect(opennessFor("idle", t, 3)).toBeGreaterThan(0.05);
    }
  });

  it("blinks every few seconds while idle", () => {
    let closed = 0;
    for (let t = 0; t < 20; t += 0.02) if (opennessFor("idle", t) < 0.5) closed++;
    expect(closed).toBeGreaterThan(0);
  });

  it("interpolates between faces without overshooting", () => {
    const a = AVATAR_EXPRESSIONS.calm.face;
    const b = faceFor(normalizeAvatarLook(null), "done");
    const mid = lerpFace(a, b, 0.5);
    expect(mid[0].lid).toBeCloseTo(0.5);
    expect(mid[0].h).toBeGreaterThan(Math.min(a[0].h, b[0].h) - 1e-9);
    expect(mid[0].h).toBeLessThan(Math.max(a[0].h, b[0].h) + 1e-9);
  });

  it("falls back to a valid look for unknown saved values", () => {
    expect(normalizeAvatarLook({ shape: "bloom", color: "neon", expression: "smug" })).toEqual({ shape: "orb", color: "graphite", expression: "calm" });
  });
});
