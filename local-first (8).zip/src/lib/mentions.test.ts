import { describe, expect, it } from "vitest";
import { clampSegment, describeMention, mentionLabel } from "./mentions";
import type { LibFile } from "./db";

const file = (patch: Partial<LibFile>): LibFile => ({
  id: "f1", projectId: "p1", name: "File.pdf", kind: "pdf", mime: "application/pdf", size: 10, blob: new Blob([]), createdAt: 0, ...patch,
});

describe("@mentions attach exactly the chosen part", () => {
  it("keeps the PDF page, clamps it to the document and uses a stable key", () => {
    const pdf = file({ pages: 12, name: "Book.pdf" });
    const m = describeMention(pdf, { page: 5 });
    expect(m).toMatchObject({ kind: "pdf", page: 5, pages: 12, key: "f1:p5" });
    expect(describeMention(pdf, { page: 0 }).page).toBe(1);
    expect(describeMention(pdf, { page: 99 }).page).toBe(12);
    expect(mentionLabel(m)).toBe("Book.pdf · p.5");
  });

  it("clamps audio segments inside the recording and caps them at two minutes", () => {
    const audio = file({ kind: "audio", duration: 20, name: "Voice.wav" });
    const inside = describeMention(audio, { start: 5, length: 10 });
    expect(inside).toMatchObject({ kind: "audio", start: 5, end: 15, key: "f1:5.0-15.0" });
    expect(describeMention(audio, { start: 18, length: 30 }).end).toBe(20);
    expect(describeMention(audio, { start: -4, length: 10 }).start).toBe(0);
    expect(clampSegment(600, 30, 120)).toEqual({ start: 30, end: 150 });
    expect(mentionLabel(inside)).toBe("Voice.wav · 0:05–0:15");
  });

  it("attaches images and text whole", () => {
    expect(describeMention(file({ kind: "image", name: "Diagram.png" }))).toMatchObject({ kind: "image", key: "f1" });
    expect(describeMention(file({ kind: "text" }))).toMatchObject({ kind: "text" });
  });
});

describe("project badge survives a device with no emoji font", () => {
  it("reports renderability without throwing outside a browser", async () => {
    const { emojiRenders } = await import("./projectIcon");
    expect(typeof emojiRenders("📐")).toBe("boolean");
    expect(emojiRenders("")).toBe(false);
  });
});
