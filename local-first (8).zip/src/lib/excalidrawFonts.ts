/**
 * Excalidraw loads its fonts with `new FontFace(family, "url(<cdn>/fonts/…woff2) …")` from esm.sh.
 * Harness is a single offline file and its CSP blocks that CDN, so the hand-drawn and text fonts
 * are bundled here and those URLs are rewritten to the inline copies. The 13 MB CJK fallback
 * (Xiaolai) is not bundled; it gets a harmless stand-in so the browser falls back to system CJK
 * fonts instead of making a blocked network request.
 */
const bundled = import.meta.glob("/node_modules/@excalidraw/excalidraw/dist/prod/fonts/{Excalifont,Nunito,ComicShanns,Lilita,Virgil,Cascadia,Liberation}/*.woff2", {
  query: "?url",
  import: "default",
  eager: true,
  exhaustive: true,
}) as Record<string, string>;

const byFile = new Map<string, string>();
for (const [path, url] of Object.entries(bundled)) byFile.set(path.slice(path.lastIndexOf("/") + 1), url);
const standIn = [...byFile.entries()].find(([name]) => name.startsWith("Excalifont"))?.[1];

const URL_RE = /url\(\s*(['"]?)([^'")]+)\1\s*\)/g;

declare global {
  interface Window {
    __harnessFonts?: boolean;
  }
}

export const bundledFontCount = byFile.size;

if (typeof window !== "undefined" && typeof window.FontFace === "function" && !window.__harnessFonts && byFile.size) {
  window.__harnessFonts = true;
  const Native = window.FontFace;
  const Bundled = function (family: string, source: string | BufferSource, descriptors?: FontFaceDescriptors) {
    if (typeof source === "string" && source.includes("url(")) {
      const local: string[] = [];
      let unknown = false;
      for (const m of source.matchAll(URL_RE)) {
        const file = m[2].split(/[?#]/)[0].split("/").pop() ?? "";
        const data = byFile.get(file);
        if (data) local.push(`url("${data}") format("woff2")`);
        else unknown = true;
      }
      if (local.length) source = local.join(", ");
      else if (unknown && standIn) source = `url("${standIn}") format("woff2")`;
    }
    return new Native(family, source, descriptors);
  } as unknown as typeof FontFace;
  Bundled.prototype = Native.prototype;
  window.FontFace = Bundled;
}
