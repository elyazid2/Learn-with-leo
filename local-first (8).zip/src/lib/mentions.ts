import type { FileKind, LibFile } from "./db";

export interface Mention {
  key: string;
  kind: "pdf" | "image" | "audio" | "video" | "text";
  fileId: string;
  name: string;
  page?: number;
  pages?: number;
  start?: number;
  end?: number;
  duration?: number;
}

/** Clamp an audio segment to the file, at least 0.5s and at most 120s long. */
export function clampSegment(duration: number, start: number, length: number) {
  const dur = Number.isFinite(duration) && duration > 0 ? duration : 0;
  const from = Math.max(0, Math.min(Number.isFinite(start) ? start : 0, Math.max(0, dur - 0.5)));
  const to = Math.max(from + 0.5, Math.min(dur || from + length, from + length, from + 120));
  return { start: from, end: to };
}

/**
 * The exact thing an @mention attaches: a single PDF page, a bounded audio clip, or the whole
 * file for pictures, video and text. Keys are stable so the same part is never attached twice.
 */
export function describeMention(file: LibFile, opts: { page?: number; start?: number; length?: number } = {}): Mention {
  const kind = file.kind as FileKind;
  if (kind === "pdf") {
    const pages = Math.max(1, file.pages ?? 1);
    const page = Math.min(pages, Math.max(1, Math.round(opts.page ?? 1)));
    return { key: `${file.id}:p${page}`, kind: "pdf", fileId: file.id, name: file.name, page, pages };
  }
  if (kind === "audio") {
    const { start, end } = clampSegment(file.duration ?? 0, opts.start ?? 0, opts.length ?? 30);
    return { key: `${file.id}:${start.toFixed(1)}-${end.toFixed(1)}`, kind: "audio", fileId: file.id, name: file.name, start, end, duration: file.duration };
  }
  return { key: file.id, kind: kind as Mention["kind"], fileId: file.id, name: file.name };
}

export const mentionLabel = (m: Mention) =>
  m.kind === "pdf"
    ? `${m.name} · p.${m.page}`
    : m.kind === "audio"
      ? `${m.name} · ${fmt(m.start ?? 0)}–${fmt(m.end ?? 0)}`
      : m.name;

const fmt = (s: number) => `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, "0")}`;
