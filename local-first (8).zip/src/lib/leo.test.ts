import { beforeEach, describe, expect, it } from "vitest";
import { defaultEmojiFor, graphemes, iconOf, pickIconChar } from "./projectIcon";
import { buildSystemPrompt, PLACEMENT_KICKOFF } from "./ai/prompt";
import { streamMockChat } from "./ai/mock";
import { db, type Project } from "./db";

describe("project icons", () => {
  it("derives a default emoji from the tag", () => {
    expect(defaultEmojiFor("Math")).toBe("📐");
    expect(defaultEmojiFor(" language ")).toBe("🗣️");
    expect(defaultEmojiFor("Underwater basket weaving")).toBe("📚");
  });

  it("never falls back to a letter", () => {
    expect(iconOf({ tag: "Code" })).toEqual({ kind: "emoji", emoji: "💻" });
    expect(iconOf({ tag: "", icon: { kind: "emoji", emoji: "🦉" } })).toEqual({ kind: "emoji", emoji: "🦉" });
    expect(iconOf({ tag: "", icon: { kind: "image", src: "data:image/png;base64,AA" } }).kind).toBe("image");
    expect(iconOf({ tag: "Math", icon: { kind: "emoji", emoji: "" } })).toEqual({ kind: "emoji", emoji: "📐" });
  });

  it("keeps multi-codepoint emoji whole and prefers emoji over letters", () => {
    expect(graphemes("👩🏽‍🔬x")).toEqual(["👩🏽‍🔬", "x"]);
    expect(pickIconChar("study 🇯🇵 now")).toBe("🇯🇵");
    expect(pickIconChar("  Σ ")).toBe("Σ");
    expect(pickIconChar("")).toBe("");
  });
});

const project: Project = { id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: 1, updatedAt: 1, placement: { status: "done", level: "Novice" } };

describe("Leo prompt", () => {
  beforeEach(async () => {
    await Promise.all(db.tables.map((t) => t.clear()));
  });

  it("is Leo, with one tutor ruleset for every non-placement chat", async () => {
    for (const mode of ["ask", "teach", "test"] as const) {
      const p = await buildSystemPrompt(project, mode);
      expect(p).toMatch(/^You are Leo/);
      expect(p).toContain("MODE: TUTOR");
      expect(p).not.toContain("MODE: PLACEMENT");
    }
  });

  it("keeps the placement rules for placement chats", async () => {
    const p = await buildSystemPrompt(project, "placement");
    expect(p).toContain("MODE: PLACEMENT");
    expect(PLACEMENT_KICKOFF).toMatch(/placement/i);
  });
});

describe("mock provider infers intent from the message", () => {
  const run = async (text: string) => {
    let out = "";
    for await (const c of streamMockChat(project, "ask", [{ role: "user", content: text }], { delay: 0, behavior: "auto" })) out += c;
    return out;
  };
  it("quizzes on 'quiz me' and teaches on 'teach me' without any mode switch", async () => {
    expect(await run("Quiz me on eigenvalues")).toContain('"type":"quiz"');
    expect(await run("Teach me the next thing")).toContain("mental model");
  }, 20_000);
});

describe("harness-aware prompt", () => {
  beforeEach(async () => {
    await Promise.all(db.tables.map((t) => t.clear()));
    await db.projects.add({ ...project });
  });

  it("names its tools and prefers artifacts", async () => {
    const prompt = await buildSystemPrompt(project, "ask");
    for (const tool of ["note", "sketch", "browser", "memory", "SOURCES"]) expect(prompt).toContain(tool);
    expect(prompt).toMatch(/Prefer using a tool/);
    expect(prompt).toMatch(/Never claim to have read a file/);
  });

  it("injects relevant long-term memory and the captured browser page", async () => {
    await db.memories.add({ id: "m1", projectId: "*", kind: "goal", text: "Wants to pass the exam in June", createdAt: 1, updatedAt: 2 });
    await db.memories.add({ id: "m2", projectId: "p1", kind: "weakness", text: "Struggles with eigenvectors", createdAt: 1, updatedAt: 1 });
    await db.kv.put({ key: "browser.current", value: { url: "https://example.com/article", title: "An article" } });
    const prompt = await buildSystemPrompt(project, "ask", undefined, "eigenvectors exam");
    expect(prompt).toContain("Wants to pass the exam in June");
    expect(prompt).toContain("Struggles with eigenvectors");
    expect(prompt).toContain("https://example.com/article");
    expect(prompt).toMatch(/Long-term learner memory/);
  });
});
