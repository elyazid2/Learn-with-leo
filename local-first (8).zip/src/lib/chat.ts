import { db, getKV, uid, type ChatMode, type ContextTag, type Message, type Provider, type Thread } from "./db";
import { useApp } from "./store";
import { streamChat, type ChatMsg } from "./ai/providers";
import { buildSystemPrompt, PLACEMENT_KICKOFF } from "./ai/prompt";
import {
  executeActions,
  extractActions,
  invalidActionFeedback,
  recordQuizResult,
  revertQuizResult,
  stripActions,
  type Action,
} from "./ai/actions";
import { MOCK_PROVIDER, streamMockChat } from "./ai/mock";
import { useSettings } from "./settings";
import { formatSources, retrieve } from "./retrieval";
import { resolveEnabled } from "./models";

export interface ModelRef {
  providerId: string;
  model: string;
}

/** Synchronous in-flight lock. `streaming` in the store is set a few awaits later; this closes that window. */
let inFlight = false;
export const isBusy = () => inFlight || !!useApp.getState().streaming;

export async function getDefaultModel(): Promise<ModelRef | null> {
  const providers = await db.providers.toArray();
  const usable = providers.filter((p) => p.models.length > 0);
  if (!usable.length) return null;
  const saved = await getKV<ModelRef | null>("defaultModel", null);
  const savedProvider = saved ? usable.find((p) => p.id === saved.providerId) : undefined;
  // A saved default that was later disabled falls back to an enabled model, never the catalog.
  if (savedProvider) return { providerId: savedProvider.id, model: resolveEnabled(savedProvider, saved!.model) };
  const p = usable.sort((a, b) => a.createdAt - b.createdAt)[0];
  return { providerId: p.id, model: resolveEnabled(p) };
}

async function resolveProvider(thread: Thread): Promise<{ provider: Provider; model: string } | null> {
  if (thread.providerId) {
    const p = await db.providers.get(thread.providerId);
    if (p?.models.length) return { provider: p, model: resolveEnabled(p, thread.model) };
  }
  const def = await getDefaultModel();
  if (!def) return null;
  const p = await db.providers.get(def.providerId);
  return p ? { provider: p, model: resolveEnabled(p, def.model) } : null;
}

export async function createThread(projectId: string, mode: ChatMode): Promise<Thread> {
  const def = await getDefaultModel();
  const now = Date.now();
  const t: Thread = {
    id: uid(),
    projectId,
    title: mode === "placement" ? "Placement" : "New chat",
    mode,
    providerId: def?.providerId,
    model: def?.model,
    createdAt: now,
    updatedAt: now,
  };
  await db.threads.add(t);
  useApp.getState().setActiveThread(projectId, t.id);
  return t;
}

export async function getOrCreateActiveThread(projectId: string, mode: ChatMode = "ask") {
  const id = useApp.getState().activeThread[projectId];
  if (id) {
    const t = await db.threads.get(id);
    if (t) return t;
  }
  const latest = await db.threads.where("projectId").equals(projectId).sortBy("updatedAt");
  if (latest.length) {
    const t = latest[latest.length - 1];
    useApp.getState().setActiveThread(projectId, t.id);
    return t;
  }
  return createThread(projectId, mode);
}

interface SendOpts {
  threadId: string;
  text: string;
  apiContent?: string;
  hidden?: boolean;
  context?: ContextTag[];
  images?: string[];
  audios?: { data: string; mime: string; name: string }[];
}

export async function sendMessage(opts: SendOpts): Promise<boolean> {
  if (isBusy()) return false;
  inFlight = true;
  try {
    const thread = await db.threads.get(opts.threadId);
    if (!thread) return false;
    const now = Date.now();
    useApp.getState().setAgentActivity("thinking", thread.projectId);
    await db.messages.add({
      id: uid(),
      threadId: thread.id,
      projectId: thread.projectId,
      role: "user",
      content: opts.text,
      apiContent: opts.apiContent,
      hidden: opts.hidden,
      context: opts.context?.length ? opts.context : undefined,
      images: opts.images?.length ? opts.images : undefined,
      audios: opts.audios?.length ? opts.audios.map((a) => a.data) : undefined,
      createdAt: now,
    });
    const upd: Partial<Thread> = { updatedAt: now };
    if (!opts.hidden && (thread.title === "New chat" || !thread.title)) {
      upd.title = opts.text.replace(/\s+/g, " ").slice(0, 48) || "Chat";
    }
    await db.threads.update(thread.id, upd);
  } catch (e) {
    inFlight = false;
    throw e;
  }
  await runAssistant(opts.threadId, /* lockHeld */ true);
  return true;
}

const CONTEXT_NOTE = "[workspace context was attached to this message when it was sent]";

/**
 * Build the model-facing history. Only the LAST user turn carries its full apiContent
 * (note/PDF/selection text); older turns are collapsed to their visible text so long
 * threads don't resend tens of kilobytes per request.
 */
export function buildHistory(all: Message[]): ChatMsg[] {
  const history = all.filter((m) => !m.error && !m.partial).slice(-40);
  const lastUserIdx = history.map((m) => m.role).lastIndexOf("user");
  return history.map((m, i) => {
    const isLast = i === lastUserIdx;
    let content = isLast ? m.apiContent ?? m.content : m.apiContent ? `${m.content}\n${CONTEXT_NOTE}` : m.content;
    if (isLast && m.role === "user") {
      // Tell the model about action blocks it got wrong last turn.
      const prevAssistant = [...history.slice(0, i)].reverse().find((x) => x.role === "assistant");
      const fb = prevAssistant ? invalidActionFeedback(prevAssistant.content) : null;
      if (fb) content = `${content}\n\n${fb}`;
    }
    return {
      role: m.role,
      content,
      images: i >= history.length - 6 ? m.images : undefined,
      audio: i >= history.length - 6 && m.audios?.length ? m.audios.map((data) => ({ data, mime: "audio/webm", name: "Attached audio" })) : undefined,
    };
  });
}

export async function runAssistant(threadId: string, lockHeld = false) {
  if (!lockHeld) {
    if (isBusy()) return;
    inFlight = true;
  }
  const st = useApp.getState();
  let projectId: string | null = null;
  try {
    const thread = await db.threads.get(threadId);
    if (!thread) return;
    projectId = thread.projectId;
    const project = await db.projects.get(thread.projectId);
    if (!project) return;

    const dev = useSettings.getState().developerMode;
    const resolved = dev ? { provider: MOCK_PROVIDER, model: MOCK_PROVIDER.defaultModel } : await resolveProvider(thread);
    if (!resolved || !resolved.model) {
      st.setAgentActivity("blocked", thread.projectId, "provider");
      await db.messages.add({
        id: uid(),
        threadId,
        projectId: thread.projectId,
        role: "assistant",
        content: resolved
          ? "This provider has no model selected. Pick a model in the chat header or in Settings."
          : "Leo needs an AI provider to think with. Open **Settings → AI providers** to add one (OpenAI, Anthropic, Gemini, OpenRouter, Ollama…). Your library stays on this device; requests go straight from your browser to the provider.",
        error: true,
        createdAt: Date.now(),
      });
      return;
    }

    if (thread.mode === "placement" && project.placement.status === "pending") {
      await db.projects.update(project.id, { placement: { ...project.placement, status: "in_progress" } });
    }

    const all = await db.messages.where("threadId").equals(threadId).sortBy("createdAt");
    const history = buildHistory(all);
    const browserRow = await db.kv.get("browser.current");
    const captured = browserRow?.value as { url?: string; title?: string } | undefined;
    const browserCtx = useApp.getState().browser;
    const msgs =
      history.length && captured?.url && browserCtx?.url === captured.url
        ? history.map((m, i) =>
            i === history.length - 1 && m.role === "user"
              ? { ...m, content: `${m.content}\n\n<workspace_context>\n## Browser page: ${browserCtx.title} (${browserCtx.url})\n${(browserCtx.selection || browserCtx.text).slice(0, 12000)}\n</workspace_context>` }
              : m
          )
        : history;
    const lastUser = [...all].reverse().find((m) => m.role === "user" && !m.hidden);
    let sources = "";
    try {
      const hits = lastUser ? await retrieve(project.id, lastUser.content, 6) : [];
      if (hits.length) sources = formatSources(hits);
    } catch (e) {
      console.warn("retrieval failed", e);
    }
    const system = await buildSystemPrompt(project, thread.mode, sources || undefined, lastUser?.content);

    const ac = new AbortController();
    st.setAbort(ac);
    st.setAgentActivity("thinking", thread.projectId);
    st.setStreaming({ threadId, content: "" });
    let content = "";
    let lastFlush = 0;
    let error: string | null = null;
    let aborted = false;
    try {
      const source = dev
        ? streamMockChat(project, thread.mode, msgs, { delay: useSettings.getState().mockDelay, behavior: useSettings.getState().mockBehavior }, ac.signal)
        : streamChat(resolved.provider, resolved.model, system, msgs, ac.signal);
      for await (const chunk of source) {
        const hadText = content.trim().length > 0;
        content += chunk;
        if (!hadText && content.trim()) useApp.getState().setAgentActivity("idle", thread.projectId);
        const t = performance.now();
        if (t - lastFlush > 60) {
          lastFlush = t;
          useApp.getState().setStreaming({ threadId, content });
        }
      }
    } catch (e) {
      if (ac.signal.aborted) aborted = true;
      else {
        error = e instanceof Error ? e.message : String(e);
        if (e instanceof DOMException && e.name === "TimeoutError") error = "The provider did not respond in time.";
        else if (error === "Failed to fetch" || error.includes("NetworkError") || error.includes("Load failed"))
          error += " — the provider may block browser requests (CORS), the URL may be wrong, or you're offline.";
      }
    }

    const complete = !error && !aborted;
    const hasText = content.trim().length > 0;
    const id = uid();
    let actions: Action[] = [];
    if (hasText) {
      // A truncated stream is never executed: half-emitted action blocks must not touch the workspace.
      actions = complete ? extractActions(content) : [];
      if (actions.length) st.setAgentActivity("working", thread.projectId);
      await db.messages.add({
        id,
        threadId,
        projectId: thread.projectId,
        role: "assistant",
        content,
        partial: complete ? undefined : true,
        createdAt: Date.now(),
      });
      if (actions.length) {
        const results = await executeActions(thread.projectId, threadId, actions);
        if (results.length) await db.messages.update(id, { actionResults: results });
      }
    }
    if (error || (complete && !hasText)) {
      await db.messages.add({
        id: uid(),
        threadId,
        projectId: thread.projectId,
        role: "assistant",
        content: error
          ? `**Request failed** (${resolved.provider.name} · ${resolved.model})\n\n${error}`
          : `**Empty reply** (${resolved.provider.name} · ${resolved.model}) — the model returned no text. Retry, or try another model.`,
        error: true,
        createdAt: Date.now() + 1,
      });
      error = error ?? "empty";
    }
    await db.threads.update(threadId, { updatedAt: Date.now() });
    await db.projects.update(thread.projectId, { updatedAt: Date.now() });
    useApp.getState().setAgentActivity(error ? "blocked" : hasText ? "done" : "idle", thread.projectId, error ? "error" : undefined);
  } catch (e) {
    // Anything unexpected (quota, IndexedDB closed) still releases the lock and tells the user.
    console.error(e);
    if (projectId) {
      useApp.getState().setAgentActivity("blocked", projectId, "error");
      useApp.getState().showToast(`Chat error: ${e instanceof Error ? e.message : String(e)}`);
    }
  } finally {
    inFlight = false;
    useApp.getState().setStreaming(null);
    useApp.getState().setAbort(null);
  }
}

export function stopStreaming() {
  useApp.getState().abort?.abort();
}

/** Retry after a failure: remove the error banner AND any partial reply so the history ends on the user's turn. */
export async function retry(errorMessage: Message) {
  if (isBusy()) return;
  const all = await db.messages.where("threadId").equals(errorMessage.threadId).sortBy("createdAt");
  const lastUserIdx = all.map((m) => m.role).lastIndexOf("user");
  const stale = all.slice(lastUserIdx + 1).filter((m) => m.role === "assistant" && (m.error || m.partial));
  await db.messages.bulkDelete([...new Set([errorMessage.id, ...stale.map((m) => m.id)])]);
  await runAssistant(errorMessage.threadId);
}

/** Open Leo and send a message in the current conversation (starting one if needed). */
export async function askLeo(projectId: string, prompt: string, opts: { newChat?: boolean } = {}) {
  const st = useApp.getState();
  st.setChatOpen(true);
  if (isBusy()) return;
  let thread: Thread | undefined;
  if (!opts.newChat) {
    const id = st.activeThread[projectId];
    const t = id ? await db.threads.get(id) : undefined;
    const project = await db.projects.get(projectId);
    // Don't mix study requests into an unfinished placement conversation.
    if (t && !(t.mode === "placement" && project?.placement.status !== "done")) thread = t;
  }
  thread ??= await createThread(projectId, "ask");
  st.setActiveThread(projectId, thread.id);
  await sendMessage({ threadId: thread.id, text: prompt });
}

/** Start (or continue, or restart) the adaptive placement conversation with Leo. */
export async function startPlacement(projectId: string, opts: { restart?: boolean } = {}) {
  const st = useApp.getState();
  st.setChatOpen(true);
  if (isBusy()) return;
  const project = await db.projects.get(projectId);
  if (!project) return;
  if (!opts.restart && project.placement.status === "in_progress") {
    const threads = await db.threads.where("projectId").equals(projectId).sortBy("updatedAt");
    const existing = threads.reverse().find((t) => t.mode === "placement");
    if (existing) {
      st.setActiveThread(projectId, existing.id);
      return;
    }
  }
  if (opts.restart || project.placement.status !== "pending") await db.projects.update(projectId, { placement: { status: "pending" }, updatedAt: Date.now() });
  const thread = await createThread(projectId, "placement");
  await sendMessage({ threadId: thread.id, text: PLACEMENT_KICKOFF, hidden: true });
}

const answering = new Set<string>();

export async function answerAction(message: Message, index: number, action: Action, choice: number) {
  const key = `${message.id}:${index}`;
  if (isBusy() || answering.has(key)) return;
  answering.add(key);
  try {
    const fresh = await db.messages.get(message.id);
    if (!fresh || (fresh.answers && fresh.answers[index] !== undefined)) return;
    const previousAnswers = fresh.answers ?? {};
    await db.messages.update(message.id, { answers: { ...previousAnswers, [index]: choice } });
    let sent = false;
    const correct = action.type === "quiz" && choice === action.answer;
    try {
      if (action.type === "quiz") {
        if (action.concept) await recordQuizResult(message.projectId, action.concept, correct);
        const chosen = action.options[choice];
        const right = action.options[action.answer];
        sent = await sendMessage({
          threadId: message.threadId,
          text: chosen,
          apiContent: `Quiz answer — question: "${action.question}". I chose "${chosen}". That is ${correct ? "CORRECT" : `INCORRECT (correct answer: "${right}")`}.`,
        });
      } else if (action.type === "ask") {
        const chosen = action.options[choice];
        sent = await sendMessage({ threadId: message.threadId, text: chosen, apiContent: `(Answer to "${action.question}") ${chosen}` });
      }
    } finally {
      if (!sent) {
        // The send was refused (another request started first): undo so the learner can tap again.
        await db.messages.update(message.id, { answers: previousAnswers });
        if (action.type === "quiz" && action.concept) await revertQuizResult(message.projectId, action.concept, correct);
      }
    }
  } finally {
    answering.delete(key);
  }
}

/** The learner thinks the answer key was wrong: revert the stat and tell the model. */
export async function disputeAnswer(message: Message, index: number, action: Extract<Action, { type: "quiz" }>) {
  if (isBusy()) return;
  const fresh = await db.messages.get(message.id);
  const choice = fresh?.answers?.[index];
  if (!fresh || choice === undefined || fresh.disputed?.includes(index)) return;
  const wasCorrect = choice === action.answer;
  if (action.concept) await revertQuizResult(message.projectId, action.concept, wasCorrect);
  await db.messages.update(message.id, { disputed: [...(fresh.disputed ?? []), index] });
  await sendMessage({
    threadId: message.threadId,
    text: "I think that answer key is wrong.",
    apiContent: `I dispute the key for "${action.question}". You marked "${action.options[action.answer]}" as correct; I chose "${action.options[choice]}". Re-check carefully, explain, and if you were wrong say so plainly and use an assess action to record the corrected result for "${action.concept ?? "the concept"}". The original grade has been reverted.`,
  });
}

export const threadPreview = (m?: Message) => (m ? stripActions(m.content).slice(0, 80) : "");
