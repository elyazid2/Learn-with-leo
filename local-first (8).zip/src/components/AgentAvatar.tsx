import { useId, useMemo, useRef, useSyncExternalStore } from "react";
import { useSharedClock } from "@/lib/clock";
import {
  AGENT_STATE_META,
  AVATAR_COLORS,
  AVATAR_SHAPES,
  DEFAULT_AVATAR,
  REST_GAZE,
  faceFor,
  gazeFor,
  lerpFace,
  normalizeAvatarLook,
  opennessFor,
  type AgentState,
  type AvatarLook,
  type FaceParams,
} from "@/lib/avatar";
import { cn } from "@/utils/cn";
import { useResolvedTheme, useSettings } from "@/lib/settings";

function useSystemReducedMotion() {
  return useSyncExternalStore(
    (onChange) => {
      const media = window.matchMedia("(prefers-reduced-motion: reduce)");
      media.addEventListener("change", onChange);
      return () => media.removeEventListener("change", onChange);
    },
    () => window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    () => false
  );
}

function seedFrom(id: string) {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 997) / 7;
}

/** Exponential ease-out between faces (time constant in seconds) — never overshoots. */
const ease = (dt: number) => 1 - Math.exp(-Math.max(0, dt) / 0.16);

export default function AgentAvatar({
  state = "idle",
  look: lookProp,
  size = 40,
  frozenAt,
  reduceMotion,
  surface = "auto",
  className,
  label,
}: {
  state?: AgentState;
  look?: AvatarLook;
  size?: number;
  /** Seconds. Renders one exact, deterministic frame without starting a clock. */
  frozenAt?: number;
  reduceMotion?: boolean;
  /** The color behind the avatar when it differs from the theme (e.g. a white disc in dark mode). */
  surface?: "auto" | "light" | "dark";
  className?: string;
  label?: string;
}) {
  const systemReduced = useSystemReducedMotion();
  const preferenceReduced = useSettings((s) => s.reduceMotion);
  const customLook = useSettings((s) => s.avatar);
  const theme = useResolvedTheme();
  const look = normalizeAvatarLook(lookProp ?? customLook ?? DEFAULT_AVATAR);
  const reduced = preferenceReduced || (reduceMotion ?? systemReduced);
  const frozen = frozenAt !== undefined;
  // Tiny icons never animate: no clock subscription, no sub-pixel jitter.
  const still = frozen || reduced || size <= 20;
  const clock = useSharedClock(!still);

  const rawId = useId();
  const maskId = "av" + rawId.replace(/[^a-zA-Z0-9]/g, "");
  const seed = useMemo(() => seedFrom(rawId), [rawId]);

  const target = faceFor(look, state);
  const key = `${state}|${look.expression}`;
  const trans = useRef<{ key: string; from: FaceParams; to: FaceParams; at: number } | null>(null);
  const entry = useRef({ state, at: clock });
  if (entry.current.state !== state) entry.current = { state, at: clock };

  let face = target;
  if (!still) {
    if (!trans.current) trans.current = { key, from: target, to: target, at: clock };
    else if (trans.current.key !== key) {
      const current = lerpFace(trans.current.from, trans.current.to, ease(clock - trans.current.at));
      trans.current = { key, from: current, to: target, at: clock };
    }
    face = lerpFace(trans.current.from, trans.current.to, ease(clock - trans.current.at));
  }

  let gaze: [number, number] = REST_GAZE[state];
  let open = 1;
  const gazeRef = useRef<[number, number]>(REST_GAZE[state]);
  const lastTick = useRef(clock);
  if (frozen) {
    gaze = gazeFor(state, frozenAt ?? 0);
    open = opennessFor(state, frozenAt ?? 0);
  } else if (!still) {
    const target = gazeFor(state, clock, seed);
    // Critically-damped follow keeps eye travel smooth at any frame rate.
    const dt = Math.min(0.1, Math.max(0, clock - lastTick.current));
    const k = 1 - Math.exp(-dt / 0.075);
    gazeRef.current = [gazeRef.current[0] + (target[0] - gazeRef.current[0]) * k, gazeRef.current[1] + (target[1] - gazeRef.current[1]) * k];
    gaze = gazeRef.current;
    open = opennessFor(state, clock, seed);
  }
  lastTick.current = clock;
  const settle = !still && state === "done" ? 1 + 0.06 * Math.exp(-(clock - entry.current.at) / 0.18) : 1;
  const motionTime = still ? frozenAt ?? 0 : clock;
  const breathe = still ? 0 : state === "idle" || state === "listening" ? Math.sin(motionTime * 1.1) * 0.012 : 0;
  // Listening: a slow, calm halo. Speaking: a gentle body pulse plus three voice bars.
  const listenPulse = state === "listening" ? (still ? 0.6 : (Math.sin(motionTime * 2.4) + 1) / 2) : 0;
  const voicePulse = state === "speaking" ? 1 + 0.018 * Math.sin(motionTime * 9) : 1;
  const bodyScale = settle * voicePulse * (1 + breathe);

  const dark = surface === "dark" || (surface === "auto" && theme === "dark");
  const body = look.color === "graphite" ? (dark ? "#f1f0eb" : "#111114") : AVATAR_COLORS[look.color].hex;

  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={cn("block shrink-0", className)}
      style={{ overflow: "visible" }}
      role="img"
      aria-label={label ?? `Leo — ${AGENT_STATE_META[state].label}`}
    >
      <defs>
        <mask id={maskId} maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100">
          <rect width="100" height="100" fill="#fff" />
          <g transform={`translate(${gaze[0].toFixed(2)} ${gaze[1].toFixed(2)})`}>
            {face.map((e, i) => {
              const h = Math.max(1.6, e.h * open);
              return (
                <g key={i} transform={`rotate(${e.r.toFixed(2)} ${e.x.toFixed(2)} ${e.y.toFixed(2)})`}>
                  <rect x={e.x - e.w / 2} y={e.y - h / 2} width={e.w} height={h} rx={Math.min(e.w, h) / 2} fill="#000" />
                  {e.lid > 0.01 && <circle cx={e.x} cy={e.y + 6.5 + (1 - e.lid) * 16} r={e.w * 0.69} fill="#fff" />}
                </g>
              );
            })}
          </g>
        </mask>
      </defs>
      <path
        d={AVATAR_SHAPES[look.shape].path}
        fill={body}
        mask={`url(#${maskId})`}
        transform={bodyScale !== 1 ? `translate(50 50) scale(${bodyScale.toFixed(4)}) translate(-50 -50)` : undefined}
      />
      {state === "listening" && (
        <g fill="none" stroke={body}>
          <circle cx="50" cy="50" r={49.5 + listenPulse * 2.5} strokeOpacity={0.4 + listenPulse * 0.25} strokeWidth={1.8} />
          <circle cx="50" cy="50" r={55 + listenPulse * 4} strokeOpacity={0.18 + listenPulse * 0.16} strokeWidth={1.2} />
        </g>
      )}
      {state === "speaking" && size > 28 && (
        <g fill={body} opacity={0.8}>
          {[0, 1, 2, 3].map((i) => {
            const h = 4 + 4 * Math.abs(Math.sin(motionTime * 6 + i * 0.9));
            return <rect key={i} x={43.5 + i * 4.2} y={90 - h} width={2.6} height={h} rx={1.3} />;
          })}
        </g>
      )}
      {state === "blocked" && size >= 20 && <circle cx="83" cy="17" r="11" fill="#e5485e" stroke="var(--card)" strokeWidth="4" />}
      {state === "thinking" && still && size > 28 && (
        <g fill={body} opacity={0.45}>
          <circle cx="86" cy="16" r="3" />
          <circle cx="92" cy="10" r="2" />
        </g>
      )}
      {state === "listening" && still && size > 28 && (
        <circle cx="50" cy="50" r="55" fill="none" stroke={body} strokeOpacity={0.22} strokeWidth={1.4} />
      )}
    </svg>
  );
}
