import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { Loader2, Minus, Plus, RotateCcw } from "lucide-react";
import type { PDFDocumentProxy } from "pdfjs-dist/legacy/build/pdf.mjs";
import type { LibFile } from "@/lib/db";
import { closePdf, getPdfjs, openPdf, setPdfReaderActive } from "@/lib/media";
import { useApp } from "@/lib/store";

const TOUCH = typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches;
/** Phones: at most 2× and ~5 MP per page — sharp text, and safe for iOS's canvas memory limit. */
const MAX_DPR = TOUCH ? 2 : 3;
const MAX_CANVAS_PIXELS = TOUCH ? 5_000_000 : 16_000_000;
/** Space kept above a page when jumping to it (the floating page bar). */
const TOP_GAP = 60;
/** Pages drawn around the current one, and how far away a drawn page is kept before release. */
const AHEAD = 2;
const BEHIND = 1;
const KEEP = 3;

interface Job {
  prio: () => number;
  run: () => Promise<void>;
  cancelled: boolean;
}

/**
 * Pages render one at a time, nearest-to-current first. Drawing several pages at once (each with
 * large decoded images) is what exhausts a phone's canvas memory and leaves later pages blank.
 */
class RenderQueue {
  private busy = false;
  private jobs: Job[] = [];
  add(prio: () => number, run: () => Promise<void>) {
    const job: Job = { prio, run, cancelled: false };
    this.jobs.push(job);
    void this.pump();
    return () => {
      job.cancelled = true;
    };
  }
  private async pump() {
    if (this.busy) return;
    this.busy = true;
    try {
      for (;;) {
        this.jobs = this.jobs.filter((j) => !j.cancelled);
        if (!this.jobs.length) return;
        this.jobs.sort((a, b) => a.prio() - b.prio());
        const job = this.jobs.shift()!;
        try {
          await job.run();
        } catch {
          /* each page reports its own failure */
        }
      }
    } finally {
      this.busy = false;
    }
  }
}

/** Continuous-scroll PDF reader with a selectable text layer on every drawn page. */
export default function PdfViewer({ file, header }: { file: LibFile; header?: ReactNode }) {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [err, setErr] = useState("");
  const [ratio, setRatio] = useState(1.294);
  const [fitWidth, setFitWidth] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [current, setCurrent] = useState(1);
  const [draft, setDraft] = useState<string | null>(null);
  const [queue] = useState(() => new RenderQueue());
  const scroller = useRef<HTMLDivElement>(null);
  const pages = useRef(new Map<number, HTMLDivElement>());
  const currentRef = useRef(1);
  currentRef.current = current;
  const restored = useRef(false);
  const raf = useRef(0);
  const setPdf = useApp((s) => s.setPdf);

  // While reading, background indexing steps aside (it would load a second copy of the PDF).
  useEffect(() => {
    setPdfReaderActive(true);
    return () => setPdfReaderActive(false);
  }, []);

  useEffect(() => {
    let d: PDFDocumentProxy | null = null;
    let cancelled = false;
    restored.current = false;
    setErr("");
    openPdf(file.blob)
      .then(async (x) => {
        if (cancelled) return closePdf(x);
        d = x;
        try {
          const vp = (await x.getPage(1)).getViewport({ scale: 1 });
          if (!cancelled) setRatio(vp.height / vp.width);
        } catch {
          /* keep default ratio */
        }
        if (!cancelled) setDoc(x);
      })
      .catch((e) => !cancelled && setErr(String(e?.message || e)));
    return () => {
      cancelled = true;
      closePdf(d);
      setDoc(null);
    };
  }, [file.id, file.blob]);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setFitWidth(Math.max(0, Math.min(el.clientWidth - 24, 900))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const width = Math.max(0, Math.floor(fitWidth * zoom));

  const register = useCallback((n: number, el: HTMLDivElement | null) => {
    if (el) pages.current.set(n, el);
    else pages.current.delete(n);
  }, []);

  const scrollToPage = useCallback((n: number, smooth = false) => {
    const el = pages.current.get(n);
    const sc = scroller.current;
    if (!el || !sc) return;
    const top = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop;
    sc.scrollTo({ top: Math.max(0, top - TOP_GAP), behavior: smooth ? "smooth" : "auto" });
  }, []);

  /** Current page = the last page whose top is above 35% of the visible area. Uses viewport rects, so it works whichever element scrolls. */
  const measure = useCallback(() => {
    const sc = scroller.current;
    if (!sc) return;
    const probe = sc.getBoundingClientRect().top + sc.clientHeight * 0.35;
    let cur = 1;
    for (const [n, el] of pages.current) if (el.getBoundingClientRect().top <= probe && n > cur) cur = n;
    if (cur !== currentRef.current) setCurrent(cur);
  }, []);

  const schedule = useCallback(() => {
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0;
      measure();
    });
  }, [measure]);

  useEffect(() => {
    document.addEventListener("scroll", schedule, { capture: true, passive: true });
    window.addEventListener("resize", schedule);
    return () => {
      document.removeEventListener("scroll", schedule, { capture: true });
      window.removeEventListener("resize", schedule);
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [schedule]);

  // Reopen where you left off.
  useLayoutEffect(() => {
    if (!doc || width <= 0 || restored.current) return;
    restored.current = true;
    const saved = Math.min(doc.numPages, Math.max(1, Number(localStorage.getItem("pdfpage." + file.id)) || 1));
    if (saved > 1) {
      setCurrent(saved);
      requestAnimationFrame(() => scrollToPage(saved));
    }
  }, [doc, width, file.id, scrollToPage]);

  // Keep the current page in view when zooming or rotating.
  const prevWidth = useRef(width);
  useLayoutEffect(() => {
    if (prevWidth.current > 0 && prevWidth.current !== width) scrollToPage(currentRef.current);
    prevWidth.current = width;
  }, [width, scrollToPage]);

  useEffect(() => {
    localStorage.setItem("pdfpage." + file.id, String(current));
  }, [current, file.id]);

  // Share the page being read with Leo.
  useEffect(() => {
    if (!doc) return;
    let alive = true;
    const t = window.setTimeout(async () => {
      try {
        const tc = await (await doc.getPage(current)).getTextContent();
        const text = tc.items
          .map((i) => ("str" in i ? i.str + (i.hasEOL ? "\n" : " ") : ""))
          .join("")
          .replace(/[ \t]+/g, " ")
          .trim();
        if (alive) setPdf({ fileId: file.id, name: file.name, page: current, pages: doc.numPages, text });
      } catch {
        /* document closed while switching */
      }
    }, 200);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [doc, current, file.id, file.name, setPdf]);
  useEffect(() => () => setPdf(null), [setPdf]);

  const numPages = doc?.numPages ?? file.pages ?? 0;
  const commitDraft = () => {
    const n = parseInt(draft ?? "", 10);
    if (n >= 1 && n <= numPages) {
      setCurrent(n);
      scrollToPage(n, true);
    }
    setDraft(null);
  };
  const zoomBy = (d: number) => setZoom((z) => Math.min(3, Math.max(0.5, Math.round((z + d) * 4) / 4)));

  return (
    <div className="absolute inset-0 flex flex-col">
      {header}
      <div
        ref={scroller}
        data-pdf-scroller
        className="relative min-h-0 flex-1 overflow-auto overscroll-contain bg-document"
        data-ctx-source={`PDF "${file.name}" p.${current}`}
      >
        <div className="pointer-events-none sticky left-0 top-0 z-10 flex justify-center px-3 pb-1 pt-2.5">
          <div className="pointer-events-auto flex items-center gap-0.5 rounded-full bg-elevated/92 p-1 text-[13px] shadow-[0_4px_16px_rgba(0,0,0,0.12)] ring-1 ring-line backdrop-blur-xl">
            <button onClick={() => zoomBy(-0.25)} className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-ink/[0.06]" aria-label="Zoom out">
              <Minus size={15} />
            </button>
            <button onClick={() => setZoom(1)} className="h-8 min-w-[52px] rounded-full px-1 tabular-nums hover:bg-ink/[0.06]" aria-label="Fit to width">
              {Math.round(zoom * 100)}%
            </button>
            <button onClick={() => zoomBy(0.25)} className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-ink/[0.06]" aria-label="Zoom in">
              <Plus size={15} />
            </button>
            <span className="mx-1 h-4 w-px bg-line" aria-hidden />
            <label className="flex items-center gap-1.5 pr-2.5 tabular-nums">
              <input
                value={draft ?? String(current)}
                onChange={(e) => setDraft(e.target.value.replace(/\D/g, ""))}
                onFocus={(e) => {
                  setDraft(String(current));
                  e.currentTarget.select();
                }}
                onBlur={commitDraft}
                onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
                inputMode="numeric"
                aria-label="Go to page"
                className="h-8 w-11 rounded-full bg-ink/[0.06] text-center text-[16px] outline-none focus:bg-ink/[0.1] sm:text-[13px]"
              />
              <span className="text-muted">/ {numPages || "…"}</span>
            </label>
          </div>
        </div>
        {err ? (
          <p className="p-6 text-center text-sm text-danger-fg">Couldn't open this PDF: {err}</p>
        ) : !doc || width <= 0 ? (
          <div className="flex justify-center py-24">
            <Loader2 className="animate-spin text-muted" />
          </div>
        ) : (
          <div className="mx-auto flex w-max min-w-full flex-col items-center gap-3 px-3 pb-36 pt-1">
            {Array.from({ length: doc.numPages }, (_, i) => {
              const n = i + 1;
              return (
                <PdfPage
                  key={n}
                  doc={doc}
                  num={n}
                  width={width}
                  ratio={ratio}
                  active={n >= current - BEHIND && n <= current + AHEAD}
                  keep={Math.abs(n - current) <= KEEP}
                  distance={Math.abs(n - current)}
                  queue={queue}
                  register={register}
                />
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

type PageState = "idle" | "queued" | "rendering" | "rendered" | "error";

function PdfPage({
  doc,
  num,
  width,
  ratio,
  active,
  keep,
  distance,
  queue,
  register,
}: {
  doc: PDFDocumentProxy;
  num: number;
  width: number;
  ratio: number;
  active: boolean;
  keep: boolean;
  distance: number;
  queue: RenderQueue;
  register: (n: number, el: HTMLDivElement | null) => void;
}) {
  const box = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const [ownRatio, setOwnRatio] = useState<number | null>(null);
  const [state, setState] = useState<PageState>("idle");
  const [attempt, setAttempt] = useState(0);
  /** Width the current bitmap was drawn at (0 = nothing drawn). */
  const drawnAt = useRef(0);
  const dist = useRef(distance);
  dist.current = distance;

  useEffect(() => {
    register(num, box.current);
    return () => register(num, null);
  }, [num, register]);

  useEffect(() => {
    if (!active || width <= 0 || drawnAt.current === width) return;
    let cancelled = false;
    let task: { cancel: () => void; promise: Promise<void> } | null = null;
    let layer: { cancel: () => void } | null = null;
    setState((s) => (s === "rendered" ? s : "queued"));
    const cancelJob = queue.add(
      () => dist.current,
      async () => {
        if (cancelled) return;
        setState((s) => (s === "rendered" ? s : "rendering"));
        try {
          const page = await doc.getPage(num);
          if (cancelled) return;
          const base = page.getViewport({ scale: 1 });
          setOwnRatio(base.height / base.width);
          const scale = width / base.width;
          const vp = page.getViewport({ scale });
          const dpr = attempt > 0 ? 1 : Math.max(1, Math.min(window.devicePixelRatio || 1, MAX_DPR, Math.sqrt(MAX_CANVAS_PIXELS / (vp.width * vp.height))));
          const canvas = canvasRef.current;
          if (!canvas) return;
          canvas.width = Math.max(1, Math.floor(vp.width * dpr));
          canvas.height = Math.max(1, Math.floor(vp.height * dpr));
          canvas.style.width = `${Math.floor(vp.width)}px`;
          canvas.style.height = `${Math.floor(vp.height)}px`;
          const ctx = canvas.getContext("2d");
          if (!ctx) throw new Error("Canvas unavailable (out of memory?)");
          task = page.render({ canvasContext: ctx, canvas, viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
          await task.promise;
          task = null;
          if (cancelled) return;
          drawnAt.current = width;
          setState("rendered");
          const tc = await page.getTextContent();
          if (cancelled) return;
          const div = textRef.current;
          if (div) {
            div.replaceChildren();
            div.style.setProperty("--total-scale-factor", String(scale));
            const pdfjs = await getPdfjs();
            if (cancelled) return;
            const tl = new pdfjs.TextLayer({ textContentSource: tc, container: div, viewport: vp });
            layer = tl;
            await tl.render();
            layer = null;
          }
          page.cleanup();
        } catch (e) {
          const msg = `${(e as Error)?.name ?? ""} ${(e as Error)?.message ?? ""}`;
          if (cancelled || /cancel|abort/i.test(msg)) return;
          console.warn(`PDF page ${num} failed to render`, e);
          drawnAt.current = 0;
          // One automatic retry at 1× resolution, then show the error with a Retry button.
          if (attempt === 0) setAttempt(1);
          else setState("error");
        }
      }
    );
    return () => {
      cancelled = true;
      cancelJob();
      task?.cancel();
      layer?.cancel();
    };
  }, [active, width, doc, num, queue, attempt]);

  // Far from the viewport (or drawn at an old zoom): release the bitmap to keep memory flat.
  useEffect(() => {
    const stale = drawnAt.current !== 0 && drawnAt.current !== width;
    if (keep && (!stale || active)) return;
    const c = canvasRef.current;
    if (c) {
      c.width = 0;
      c.height = 0;
    }
    textRef.current?.replaceChildren();
    drawnAt.current = 0;
    setState("idle");
  }, [keep, width, active]);

  const height = Math.round(width * (ownRatio ?? ratio));
  return (
    <div
      ref={box}
      data-page={num}
      data-state={state}
      className="pdf-page relative shrink-0 overflow-hidden rounded-[4px] bg-[#fff] shadow-[0_1px_4px_rgba(0,0,0,0.14)]"
      style={{ width, height }}
    >
      <canvas ref={canvasRef} className="block" />
      <div ref={textRef} className="textLayer" />
      {state !== "rendered" && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 text-[13px] font-medium text-[#6e6e6e]">
          {state === "error" ? (
            <>
              <span>Couldn't show page {num}</span>
              <button
                onClick={() => {
                  drawnAt.current = 0;
                  setAttempt((a) => a + 1);
                }}
                className="pointer-events-auto inline-flex h-8 items-center gap-1.5 rounded-full bg-[#17171a] px-3.5 text-[12px] font-semibold text-[#fff]"
              >
                <RotateCcw size={13} /> Retry
              </button>
            </>
          ) : (
            <span className="tabular-nums">{num}</span>
          )}
        </div>
      )}
    </div>
  );
}
