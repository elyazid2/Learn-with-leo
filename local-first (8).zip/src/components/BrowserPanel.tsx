import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft, ArrowRight, ArrowUpRight, BookmarkPlus, Check, ExternalLink, Globe2, Loader2,
  Plus, RefreshCw, ShieldCheck, Trash2, X,
} from "lucide-react";
import { getKV, setKV, uid } from "@/lib/db";
import { useApp } from "@/lib/store";
import { readPage, type ReaderLink } from "@/lib/reader";
import { Button, Field, IconBtn, inputCls } from "@/components/ui";
import AgentAvatar from "@/components/AgentAvatar";
import { cn } from "@/utils/cn";

interface Addon {
  id: string;
  name: string;
  description: string;
  hosts: string;
  code: string;
  enabled: boolean;
  builtin?: boolean;
}

const BUILTINS: Addon[] = [
  {
    id: "youtube-focus",
    name: "YouTube Focus",
    description: "Hides Shorts, the recommendations column and end-screen shelves. In Harness, YouTube links also play in a minimal embed.",
    hosts: "youtube.com, youtu.be",
    code: `document.querySelectorAll('ytd-rich-shelf-renderer,ytd-reel-shelf-renderer,ytd-watch-next-secondary-results-renderer,#secondary,a[href^="/shorts"]').forEach(e=>e.remove());const s=document.createElement('style');s.textContent='ytd-rich-shelf-renderer,ytd-reel-shelf-renderer,ytd-watch-next-secondary-results-renderer,#secondary,a[href^="/shorts"]{display:none!important}';document.documentElement.append(s);`,
    enabled: true,
    builtin: true,
  },
  {
    id: "quiet-article",
    name: "Quiet article",
    description: "Strips sidebars, sticky banners and comments so a long reading page stays a single column.",
    hosts: "*",
    code: `document.querySelectorAll('aside,nav,footer,[role=complementary],.sidebar,.comments,.newsletter,.sticky').forEach(e=>e.remove());document.body.style.maxWidth='72ch';document.body.style.margin='0 auto';`,
    enabled: false,
    builtin: true,
  },
];

function safeUrl(input: string) {
  const value = input.trim();
  if (!value) return null;
  try {
    const u = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(value) ? value : `https://${value}`);
    return ["https:", "http:"].includes(u.protocol) ? u.href : null;
  } catch {
    return null;
  }
}

function youtubeId(url: string) {
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.split("/").filter(Boolean)[0] ?? null;
    if (u.hostname !== "www.youtube.com" && u.hostname !== "youtube.com" && !u.hostname.endsWith(".youtube.com")) return null;
    if (u.pathname === "/watch") return u.searchParams.get("v");
    return u.pathname.match(/^\/(?:embed|shorts|live)\/([^/?]+)/)?.[1] ?? null;
  } catch {
    return null;
  }
}

const hostMatches = (hosts: string, hostname: string) =>
  hosts.split(",").map((h) => h.trim().toLowerCase()).filter(Boolean)
    .some((h) => h === "*" || hostname === h || hostname.endsWith("." + h.replace(/^\*\./, "")));

/** Explicit, learner-clicked bookmarklet — Harness never injects into another origin itself. */
function makeBookmarklet(addons: Addon[], appOrigin: string) {
  const effects = addons
    .filter((a) => a.enabled && a.code.trim())
    .map((a) => `if(${JSON.stringify(a.hosts.split(",").map((h) => h.trim().toLowerCase()))}.some(h=>h==='*'||location.hostname===h||location.hostname.endsWith('.'+h.replace(/^\\*\\./,'')))){try{${a.code}}catch(e){}}`)
    .join(";");
  const send = `const s=String(window.getSelection?.()||'');const t=(s||document.body?.innerText||'').slice(0,30000);window.opener?.postMessage({type:'harness:page-capture',url:location.href,title:document.title,text:t,selection:s.slice(0,8000)},${JSON.stringify(appOrigin)});`;
  return `javascript:(()=>{${effects};${send}})()`;
}

interface PageState {
  status: "idle" | "loading" | "read" | "blocked";
  title: string;
  text: string;
  links: ReaderLink[];
  words: number;
  reason: string;
}

const EMPTY: PageState = { status: "idle", title: "", text: "", links: [], words: 0, reason: "" };

/**
 * Lightweight learning browser.
 *
 * Choice of engine: this ships as a PWA, so it cannot host Android's System WebView or GeckoView —
 * both need a native shell. The lightest thing that still supports add-ons here is the platform
 * browser plus explicit user scripts (bookmarklets), which is what this panel uses. If a native
 * wrapper is added later, System WebView + user scripts is the lightest option; GeckoView is only
 * warranted when real WebExtensions are required.
 */
export default function BrowserPanel() {
  const open = useApp((s) => s.browserOpen);
  const setOpen = useApp((s) => s.setBrowserOpen);
  const url = useApp((s) => s.browserUrl);
  const setUrl = useApp((s) => s.setBrowserUrl);
  const browser = useApp((s) => s.browser);
  const setBrowser = useApp((s) => s.setBrowser);
  const setChatOpen = useApp((s) => s.setChatOpen);

  const [address, setAddress] = useState(url);
  const [tab, setTab] = useState<"page" | "addons">("page");
  const [page, setPage] = useState<PageState>(EMPTY);
  const [stack, setStack] = useState<string[]>([]);
  const [cursor, setCursor] = useState(-1);
  const [addons, setAddons] = useState<Addon[]>(BUILTINS);
  const [formOpen, setFormOpen] = useState(false);
  const [name, setName] = useState("");
  const [hosts, setHosts] = useState("");
  const [code, setCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");
  const popup = useRef<Window | null>(null);
  const abort = useRef<AbortController | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    void getKV<Addon[]>("browser.addons", BUILTINS).then((saved) => {
      if (!saved?.length) return setAddons(BUILTINS);
      // Keep built-ins current while preserving the learner's on/off choices and custom scripts.
      const merged = BUILTINS.map((b) => ({ ...b, enabled: saved.find((s) => s.id === b.id)?.enabled ?? b.enabled }));
      setAddons([...merged, ...saved.filter((s) => !s.builtin)]);
    });
  }, [open]);

  const load = useCallback(
    async (target: string) => {
      abort.current?.abort();
      const ac = new AbortController();
      abort.current = ac;
      setAddress(target);
      setUrl(target);
      setError("");
      scroller.current?.scrollTo({ top: 0 });

      if (youtubeId(target)) {
        setPage({ ...EMPTY, status: "read", title: "YouTube", words: 0 });
        setBrowser(null);
        return;
      }
      setPage({ ...EMPTY, status: "loading" });
      const result = await readPage(target, ac.signal);
      if (ac.signal.aborted) return;
      if (result.ok) {
        setPage({ status: "read", title: result.title, text: result.text, links: result.links, words: result.words, reason: "" });
        setBrowser({ url: result.url, title: result.title, text: result.text, capturedAt: Date.now() });
        void setKV("browser.current", { url: result.url, title: result.title });
      } else {
        setPage({ ...EMPTY, status: "blocked", reason: result.reason });
      }
    },
    [setBrowser, setUrl]
  );

  const navigate = useCallback(
    (target: string) => {
      const next = [...stack.slice(0, cursor + 1), target];
      setStack(next);
      setCursor(next.length - 1);
      void load(target);
    },
    [stack, cursor, load]
  );

  // Open at whatever Leo (or a previous session) last pointed the browser at.
  useEffect(() => {
    if (!open) return;
    setAddress(url);
    if (url && stack.length === 0) {
      setStack([url]);
      setCursor(0);
      void load(url);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, url]);

  useEffect(() => () => abort.current?.abort(), []);

  // Capture sent back by the learner's explicit companion bookmarklet.
  useEffect(() => {
    if (!open) return;
    const onMessage = (e: MessageEvent) => {
      if (!popup.current || e.source !== popup.current) return;
      const d = e.data as { type?: string; url?: string; title?: string; text?: string; selection?: string };
      const pageUrl = typeof d?.url === "string" ? safeUrl(d.url) : null;
      if (d?.type !== "harness:page-capture" || !pageUrl) return;
      const captured = {
        url: pageUrl,
        title: String(d.title ?? pageUrl).slice(0, 300),
        text: String(d.text ?? "").slice(0, 30000),
        selection: String(d.selection ?? "").slice(0, 8000) || undefined,
        capturedAt: Date.now(),
      };
      setBrowser(captured);
      setUrl(pageUrl);
      setAddress(pageUrl);
      setPage({ status: "read", title: captured.title, text: captured.selection || captured.text, links: [], words: captured.text.split(/\s+/).length, reason: "" });
      void setKV("browser.current", { url: pageUrl, title: captured.title });
      useApp.getState().showToast("Page captured for Leo");
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [open, setBrowser, setUrl]);

  const go = () => {
    const target = safeUrl(address);
    if (!target) return setError("Enter a valid http or https address.");
    navigate(target);
    setTab("page");
  };

  const step = (delta: number) => {
    const next = cursor + delta;
    if (next < 0 || next >= stack.length) return;
    setCursor(next);
    void load(stack[next]);
  };

  const openExternal = () => {
    const target = safeUrl(address);
    if (!target) return setError("Enter a valid http or https address.");
    popup.current = window.open(target, "_blank");
    if (!popup.current) setError("Your browser blocked the new tab. Allow pop-ups for Harness and try again.");
  };

  const copy = async (only?: Addon) => {
    try {
      await navigator.clipboard.writeText(makeBookmarklet(only ? [only] : addons, location.origin));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
      useApp.getState().showToast("Leo companion copied — save it as a browser bookmark");
    } catch {
      setError("Clipboard permission is unavailable in this context.");
    }
  };

  const saveAddons = async (next: Addon[]) => {
    setAddons(next);
    await setKV("browser.addons", next);
  };

  const addAddon = async () => {
    if (!name.trim() || !hosts.trim() || !code.trim()) return;
    await saveAddons([
      ...addons,
      { id: uid(), name: name.trim(), hosts: hosts.trim(), code: code.trim(), description: "Your script. Runs only when you click the bookmarklet on a matching page.", enabled: true },
    ]);
    setName(""); setHosts(""); setCode(""); setFormOpen(false);
  };

  if (!open) return null;

  const yt = safeUrl(address) ? youtubeId(safeUrl(address)!) : null;
  const focusYoutube = addons.some((a) => a.id === "youtube-focus" && a.enabled);
  const embed = yt && focusYoutube ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(yt)}?rel=0&playsinline=1&modestbranding=1` : null;
  const host = (() => { try { return new URL(address).hostname; } catch { return ""; } })();

  return (
    <div className="fixed inset-0 z-[80] flex flex-col bg-paper pt-[env(safe-area-inset-top)]" role="dialog" aria-modal="true" aria-label="Learning browser">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-2 sm:px-4">
        <IconBtn onClick={() => setOpen(false)} aria-label="Close browser"><ArrowLeft size={19} /></IconBtn>
        <div className="relative min-w-0 flex-1">
          <Globe2 size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && go()}
            aria-label="Website address"
            enterKeyHint="go"
            placeholder="Enter a website or YouTube link"
            className="h-10 w-full rounded-full bg-ink/[0.05] pl-10 pr-3 text-[16px] outline-none ring-1 ring-transparent focus:ring-ink/20"
            dir="auto"
          />
        </div>
        <Button size="sm" onClick={go}><ArrowUpRight size={15} /> Go</Button>
      </header>

      <nav className="flex h-11 shrink-0 items-center gap-0.5 border-b border-line px-1.5 sm:px-3">
        <IconBtn onClick={() => step(-1)} disabled={cursor <= 0} aria-label="Back" className="h-8 w-8"><ArrowLeft size={15} /></IconBtn>
        <IconBtn onClick={() => step(1)} disabled={cursor >= stack.length - 1} aria-label="Forward" className="h-8 w-8"><ArrowRight size={15} /></IconBtn>
        <IconBtn onClick={() => stack[cursor] && void load(stack[cursor])} disabled={!stack[cursor]} aria-label="Reload" className="h-8 w-8"><RefreshCw size={15} /></IconBtn>
        <span className="mx-0.5 h-4 w-px shrink-0 bg-line" />
        <button onClick={() => setTab("page")} className={cn("h-8 shrink-0 whitespace-nowrap rounded-full px-2.5 text-[13px] font-medium", tab === "page" ? "bg-ink/[0.08]" : "text-muted")}>Page</button>
        <button onClick={() => setTab("addons")} className={cn("flex h-8 shrink-0 items-center gap-1 whitespace-nowrap rounded-full px-2.5 text-[13px] font-medium", tab === "addons" ? "bg-ink/[0.08]" : "text-muted")}>
          Add-ons
          <span className="rounded-full bg-ink/[0.08] px-1.5 text-[11px] tabular-nums">{addons.filter((a) => a.enabled).length}</span>
        </button>
        <span className="min-w-0 flex-1" />
        <button
          onClick={() => void copy()}
          aria-label="Copy Leo companion bookmarklet"
          className="flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full bg-ink/[0.06] px-2.5 text-[13px] font-medium transition-colors hover:bg-ink/[0.1]"
        >
          {copied ? <Check size={14} /> : <BookmarkPlus size={14} />}
          <span className="hidden sm:inline">Companion</span>
        </button>
      </nav>

      {error && <p className="border-b border-danger-line bg-danger-bg px-4 py-2 text-[13px] text-danger-fg">{error}</p>}

      {tab === "page" ? (
        <main ref={scroller} className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          {!address ? (
            <div className="mx-auto max-w-3xl px-5 py-10">
              <h2 className="display text-[23px]">A quiet place to read</h2>
              <p className="mt-1 text-[14px] text-muted">Open a page and Leo reads it with you. YouTube links play without the recommendations.</p>
              <div className="mt-5 flex flex-wrap gap-2">
                {[
                  ["Eigenvalues and eigenvectors", "https://en.wikipedia.org/wiki/Eigenvalues_and_eigenvectors"],
                  ["Matrix (mathematics)", "https://en.wikipedia.org/wiki/Matrix_(mathematics)"],
                  ["MDN: Array.map()", "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map"],
                ].map(([label, u]) => (
                  <button key={u} onClick={() => navigate(u)} className="max-w-full truncate rounded-full bg-card px-3.5 py-2 text-left text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.03]">
                    {label}
                  </button>
                ))}
              </div>
            </div>
          ) : embed ? (
            <div className="mx-auto max-w-4xl px-3 pt-4">
              <div className="overflow-hidden rounded-2xl bg-black ring-1 ring-line">
                <iframe src={embed} title="YouTube Focus player" className="aspect-video w-full border-0" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen />
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pb-6">
                <p className="text-[13px] text-muted">YouTube Focus · no recommendation column</p>
                <Button size="sm" variant="soft" onClick={openExternal}><ExternalLink size={14} /> Full YouTube page</Button>
              </div>
            </div>
          ) : page.status === "loading" ? (
            <div className="mx-auto max-w-3xl px-5 py-8">
              <div className="flex items-center gap-2 text-[13px] text-muted"><Loader2 size={15} className="animate-spin" /> Reading {host}…</div>
              <div className="mt-5 space-y-3">
                <div className="shimmer h-7 w-2/3 rounded-lg" />
                {[100, 96, 88, 94, 70].map((w, i) => <div key={i} className="shimmer h-4 rounded" style={{ width: `${w}%` }} />)}
              </div>
            </div>
          ) : page.status === "read" ? (
            <article className="mx-auto max-w-3xl px-5 pb-16 pt-6">
              <div className="flex flex-wrap items-center gap-2 text-[12px] text-muted">
                <span className="rounded-full bg-ink/[0.06] px-2.5 py-0.5 font-medium">{host}</span>
                {page.words > 0 && <span>{page.words.toLocaleString()} words</span>}
                <span className="inline-flex items-center gap-1 text-ok-fg"><Check size={12} /> Shared with Leo</span>
              </div>
              <h1 className="mt-3 display text-[26px] leading-tight" dir="auto">{page.title}</h1>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" onClick={() => { setOpen(false); setChatOpen(true); }}>
                  <AgentAvatar size={19} frozenAt={0} /> Ask Leo about this page
                </Button>
                <Button size="sm" variant="soft" onClick={openExternal}><ExternalLink size={14} /> Open original</Button>
              </div>
              <div className="mt-5 space-y-4 text-[15.5px] leading-[1.75]" dir="auto">
                {page.text.split(/\n\s*\n/).filter(Boolean).map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
              {page.links.length > 0 && (
                <section className="mt-8 border-t border-line pt-5">
                  <h2 className="text-[13px] font-semibold text-muted">Follow a link</h2>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {page.links.map((l) => (
                      <button key={l.href} onClick={() => navigate(l.href)} title={l.href} className="max-w-full truncate rounded-full bg-card px-3 py-1.5 text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.04]">
                        {l.text}
                      </button>
                    ))}
                  </div>
                </section>
              )}
            </article>
          ) : (
            <div className="mx-auto max-w-2xl px-5 py-12 text-center">
              <Globe2 size={30} className="mx-auto text-muted" />
              <h2 className="mt-4 display text-[22px]">This site keeps its pages private</h2>
              <p className="mx-auto mt-2 max-w-[50ch] text-[14px] leading-relaxed text-muted">{page.reason}</p>
              <Button className="mt-5" onClick={openExternal}><ExternalLink size={16} /> Open {host || "page"}</Button>
              <div className="mx-auto mt-5 max-w-md rounded-2xl bg-card p-4 text-left ring-1 ring-line">
                <div className="text-[13px] font-semibold">Read it with Leo anyway</div>
                <ol className="mt-2 list-inside list-decimal space-y-1 text-[13px] leading-relaxed text-muted">
                  <li>Tap Companion above to copy the Leo bookmarklet.</li>
                  <li>Save it once as a bookmark in your browser.</li>
                  <li>On the page, tap that bookmark — its text lands here.</li>
                </ol>
              </div>
            </div>
          )}

          {browser && page.status === "blocked" && (
            <section className="mx-auto mt-2 max-w-3xl border-t border-line px-5 py-4">
              <div className="flex items-start gap-3">
                <span className="min-w-0 flex-1">
                  <span className="block text-[14px] font-semibold">Last page Leo can see</span>
                  <span className="block truncate text-[12px] text-muted">{browser.title} · {browser.url}</span>
                </span>
                <button onClick={() => { setBrowser(null); void setKV("browser.current", null); }} className="rounded-full p-1.5 text-muted hover:bg-ink/[0.05]" aria-label="Clear captured page"><X size={15} /></button>
              </div>
            </section>
          )}
        </main>
      ) : (
        <AddonLibrary addons={addons} save={saveAddons} adding={formOpen} setAdding={setFormOpen} name={name} setName={setName} hosts={hosts} setHosts={setHosts} code={code} setCode={setCode} add={addAddon} copy={copy} host={host} />
      )}
    </div>
  );
}

function AddonLibrary({ addons, save, adding, setAdding, name, setName, hosts, setHosts, code, setCode, add, copy, host }: {
  addons: Addon[]; save: (a: Addon[]) => Promise<void>; adding: boolean; setAdding: (b: boolean) => void;
  name: string; setName: (s: string) => void; hosts: string; setHosts: (s: string) => void; code: string; setCode: (s: string) => void;
  add: () => Promise<void>; copy: (a?: Addon) => Promise<void>; host: string;
}) {
  return (
    <main className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
      <div className="mx-auto max-w-2xl">
        <div className="rounded-2xl bg-card p-4 ring-1 ring-line">
          <div className="flex items-start gap-3">
            <ShieldCheck size={20} className="mt-0.5 shrink-0 text-muted" />
            <p className="text-[13px] leading-relaxed text-muted">
              Harness ships as a web app, so it can't host Android WebView or GeckoView. Add-ons here are bookmarklets: you decide when they run, and Harness never injects into another site by itself. Pages that allow it are read in-app; the rest come back through the companion.
            </p>
          </div>
        </div>
        <div className="mt-4 space-y-3">
          {addons.map((a) => {
            const applies = !host || hostMatches(a.hosts, host);
            return (
              <article key={a.id} className="rounded-2xl bg-card p-4 ring-1 ring-line">
                <div className="flex items-start gap-3">
                  <input type="checkbox" checked={a.enabled} onChange={(e) => void save(addons.map((x) => (x.id === a.id ? { ...x, enabled: e.target.checked } : x)))} className="mt-1 h-4 w-4 accent-black" aria-label={`Enable ${a.name}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[15px] font-semibold">{a.name}</span>
                      {a.builtin && <span className="text-[11px] text-muted">Built in</span>}
                      {applies && host && <span className="rounded-full bg-ok-bg px-2 py-0.5 text-[11px] font-medium text-ok-fg">Matches this page</span>}
                    </div>
                    <p className="mt-1 text-[13px] leading-relaxed text-muted">{a.description}</p>
                    <div className="mt-1 text-[12px] text-muted">Runs on: {a.hosts}</div>
                    <Button size="sm" variant="soft" className="mt-3" onClick={() => void copy(a)}><BookmarkPlus size={14} /> Copy bookmarklet</Button>
                  </div>
                  {!a.builtin && (
                    <button onClick={() => void save(addons.filter((x) => x.id !== a.id))} aria-label={`Remove ${a.name}`} className="p-2 text-muted hover:text-danger-fg"><Trash2 size={15} /></button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
        {!adding ? (
          <Button variant="soft" className="mt-4" onClick={() => setAdding(true)}><Plus size={15} /> Add custom bookmarklet</Button>
        ) : (
          <div className="mt-4 space-y-3 rounded-2xl bg-card p-4 ring-1 ring-line">
            <Field label="Name"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="Citation helper" /></Field>
            <Field label="Hosts" hint="Comma separated, or * for every site."><input className={inputCls} value={hosts} onChange={(e) => setHosts(e.target.value)} placeholder="example.com, *.wikipedia.org" /></Field>
            <Field label="JavaScript" hint="Runs only when you click the bookmarklet on a matching page.">
              <textarea className={cn(inputCls, "min-h-28 resize-y font-mono text-[13px]")} value={code} onChange={(e) => setCode(e.target.value)} placeholder="document.body.classList.add('my-reading-mode');" />
            </Field>
            <div className="flex gap-2">
              <Button variant="soft" className="flex-1" onClick={() => setAdding(false)}>Cancel</Button>
              <Button className="flex-1" disabled={!name.trim() || !hosts.trim() || !code.trim()} onClick={() => void add()}>Add add-on</Button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
