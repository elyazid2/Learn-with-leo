import "fake-indexeddb/auto";

// Minimal browser globals the lib code touches outside React.
const store = new Map<string, string>();
(globalThis as unknown as { localStorage: Storage }).localStorage = {
  getItem: (k) => store.get(k) ?? null,
  setItem: (k, v) => void store.set(k, String(v)),
  removeItem: (k) => void store.delete(k),
  clear: () => store.clear(),
  key: (i) => Array.from(store.keys())[i] ?? null,
  get length() {
    return store.size;
  },
} as Storage;
(globalThis as unknown as { location: unknown }).location = { origin: "http://localhost", hash: "" };
(globalThis as unknown as { document: unknown }).document ??= { visibilityState: "visible", addEventListener() {}, removeEventListener() {} };
(globalThis as unknown as { window: unknown }).window ??= globalThis;
