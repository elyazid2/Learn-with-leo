import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { AlignLeft, BookOpen, Download, FileText, Film, Image as ImageIcon, Mic, Music, PenTool, Pencil, Play, Plus, Trash2, TrendingUp } from "lucide-react";
import { colorOf, db, uid, type FileKind, type LibFile, type Note, type Project, type Sketch } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { addFile, formatBytes, formatDuration, frameDataUrl, imageToDataUrl, kindOf, removeFile, timeAgo, videoInfo } from "@/lib/media";
import { useApp } from "@/lib/store";
import { download } from "@/lib/backup";
import { snippetOf } from "@/lib/blocks";
import { accentText, readableOn } from "@/lib/color";
import { confirmDeletion } from "@/lib/settings";
import { Button, Empty, IconBtn, Sheet } from "@/components/ui";
import PdfViewer from "@/components/library/PdfViewer";
import AudioPlayer, { Waveform } from "@/components/library/AudioPlayer";
import Recorder from "@/components/library/Recorder";
import AgentAvatar from "@/components/AgentAvatar";
import { LearningCard, useHasLearning } from "@/components/Progress";
import { cn } from "@/utils/cn";

type Filter = "all" | "note" | "sketch" | FileKind;
type UploadKind = "pdf" | "image" | "video" | "audio" | "text";
type AddChoice = "note" | "voice" | "sketch" | UploadKind;

type Entry =
  | { kind: "note"; id: string; title: string; at: number; note: Note }
  | { kind: "sketch"; id: string; title: string; at: number; sketch: Sketch }
  | { kind: FileKind; id: string; title: string; at: number; file: LibFile };

const FILTER_LABEL: Record<Filter, string> = {
  all: "All",
  note: "Notes",
  sketch: "Sketches",
  pdf: "PDFs",
  image: "Pictures",
  video: "Videos",
  audio: "Audio",
  text: "Text",
};
const FILTER_ORDER: Filter[] = ["note", "sketch", "pdf", "image", "video", "audio", "text"];
const ACCEPT_ALL = "application/pdf,.pdf,image/*,video/*,.mp4,.mov,.webm,.m4v,audio/*,.m4a,.mp3,.wav,.ogg,text/plain,text/markdown,.txt,.md";
const ACCEPT: Record<UploadKind, string> = {
  pdf: "application/pdf,.pdf",
  image: "image/*",
  video: "video/*,.mp4,.mov,.webm,.m4v",
  audio: "audio/*,.m4a,.mp3,.wav,.ogg,.aac,.flac",
  text: "text/plain,text/markdown,.txt,.md",
};

export default function Library({ project, fileId }: { project: Project; fileId?: string }) {
  if (fileId) return <FileViewer project={project} fileId={fileId} />;
  return <LibraryHome project={project} />;
}

async function createNote(projectId: string) {
  const now = Date.now();
  const n: Note = { id: uid(), projectId, title: "", content: "", author: "user", createdAt: now, updatedAt: now };
  await db.notes.add(n);
  await db.projects.update(projectId, { updatedAt: now });
  navigate(projectPath(projectId, "notes", n.id));
}

async function createSketch(projectId: string, count: number) {
  const now = Date.now();
  const s: Sketch = { id: uid(), projectId, title: `Sketch ${count}`, scene: "", createdAt: now, updatedAt: now };
  await db.sketches.add(s);
  await db.projects.update(projectId, { updatedAt: now });
  navigate(projectPath(projectId, "sketch", s.id));
}

function LibraryHome({ project }: { project: Project }) {
  const files = useLiveQuery(() => db.files.where("projectId").equals(project.id).toArray(), [project.id]);
  const notes = useLiveQuery(() => db.notes.where("projectId").equals(project.id).toArray(), [project.id]);
  const sketches = useLiveQuery(() => db.sketches.where("projectId").equals(project.id).toArray(), [project.id]);
  const addOpen = useApp((s) => s.addOpen);
  const setAddOpen = useApp((s) => s.setAddOpen);
  const showToast = useApp((s) => s.showToast);
  const [filter, setFilter] = useState<Filter>("all");
  const [recording, setRecording] = useState(false);
  const [busy, setBusy] = useState(0);
  const [drag, setDrag] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const col = colorOf(project.color);
  const hasLearning = useHasLearning(project);

  const items = useMemo<Entry[]>(() => {
    const out: Entry[] = [];
    for (const n of notes ?? []) out.push({ kind: "note", id: n.id, title: n.title || "Untitled note", at: n.updatedAt, note: n });
    for (const s of sketches ?? []) out.push({ kind: "sketch", id: s.id, title: s.title || "Sketch", at: s.updatedAt, sketch: s });
    for (const f of files ?? []) out.push({ kind: f.kind, id: f.id, title: f.name.replace(/\.[a-z0-9]+$/i, ""), at: f.createdAt, file: f });
    return out.sort((a, b) => b.at - a.at);
  }, [files, notes, sketches]);

  const counts = useMemo(() => {
    const c: Partial<Record<Filter, number>> = {};
    for (const it of items) c[it.kind] = (c[it.kind] ?? 0) + 1;
    return c;
  }, [items]);

  useEffect(() => {
    if (filter !== "all" && !counts[filter]) setFilter("all");
  }, [counts, filter]);

  // Older uploads may have a black or missing poster frame: rebuild it once in the background.
  useEffect(() => {
    const stale = (files ?? []).filter((f) => f.kind === "video" && (f.thumbVersion ?? 0) < 2).slice(0, 4);
    if (!stale.length) return;
    let cancelled = false;
    void (async () => {
      for (const f of stale) {
        if (cancelled) return;
        const info = await videoInfo(f.blob);
        if (cancelled) return;
        await db.files.update(f.id, { thumb: info.thumb ?? f.thumb, duration: f.duration ?? info.duration, thumbVersion: 2 });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [files]);

  const upload = async (list: FileList | File[] | null) => {
    if (!list) return;
    const arr = Array.from(list);
    let skipped = 0;
    const failed: string[] = [];
    setBusy((b) => b + arr.length);
    try {
      for (const f of arr) {
        try {
          if (!kindOf(f)) skipped++;
          else await addFile(project.id, f, f.name);
        } catch (e) {
          failed.push(`${f.name}: ${(e as Error).message}`);
        } finally {
          setBusy((b) => Math.max(0, b - 1));
        }
      }
    } finally {
      setBusy(0);
    }
    if (skipped) showToast(`${skipped} file${skipped === 1 ? "" : "s"} skipped — that type isn't supported`);
    if (failed.length) showToast(`Couldn't add ${failed.length}: ${failed[0].slice(0, 90)}`);
  };

  const pick = (kind: UploadKind) => {
    const el = inputRef.current;
    if (!el) return;
    el.accept = ACCEPT[kind];
    el.click();
  };

  const onAdd = (choice: AddChoice) => {
    setAddOpen(false);
    if (choice === "note") void createNote(project.id);
    else if (choice === "sketch") void createSketch(project.id, (sketches?.length ?? 0) + 1);
    else if (choice === "voice") setRecording(true);
    else pick(choice);
  };

  const open = (e: Entry) => {
    if (e.kind === "note") navigate(projectPath(project.id, "notes", e.id));
    else if (e.kind === "sketch") navigate(projectPath(project.id, "sketch", e.id));
    else navigate(projectPath(project.id, "library", e.id));
  };

  const loading = files === undefined || notes === undefined || sketches === undefined;
  const shown = items.filter((it) => filter === "all" || it.kind === filter);
  const filters = (["all", ...FILTER_ORDER.filter((f) => counts[f])] as Filter[]).filter((f) => f === "all" || counts[f]);

  return (
    <div
      className={cn("mx-auto min-h-full max-w-5xl px-4 pb-36 pt-4 transition-colors", drag && "bg-ink/[0.03]")}
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        void upload(e.dataTransfer.files);
      }}
    >
      {hasLearning && (
        <div className="mb-7">
          <LearningCard project={project} />
        </div>
      )}

      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-baseline gap-2">
          <h2 className="display text-[22px] leading-none">Library</h2>
          {items.length > 0 && (
            <span className="text-[13px] tabular-nums text-muted">
              {items.length} {items.length === 1 ? "item" : "items"}
            </span>
          )}
        </div>
        {!hasLearning && (
          <button
            onClick={() => navigate(projectPath(project.id, "progress"))}
            className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[13px] font-medium text-muted ring-1 ring-line transition-colors hover:bg-ink/[0.04] hover:text-ink"
          >
            <TrendingUp size={15} /> Progress
          </button>
        )}
      </div>

      {items.length > 0 && (
        <div className="no-scrollbar -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-1" role="tablist" aria-label="Filter library">
          {filters.map((f) => {
            const active = filter === f;
            return (
              <button
                key={f}
                role="tab"
                aria-selected={active}
                onClick={() => setFilter(f)}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 text-[14px] font-medium transition-colors",
                  active ? "bg-ink text-white" : "bg-card text-ink ring-1 ring-line hover:bg-ink/[0.04]"
                )}
              >
                {FILTER_LABEL[f]}
                <span className={cn("tabular-nums", active ? "text-white/70" : "text-muted")}>{f === "all" ? items.length : counts[f]}</span>
              </button>
            );
          })}
        </div>
      )}

      {!loading && items.length === 0 && busy === 0 && (
        <Empty
          icon={<BookOpen size={24} />}
          title="Everything for this topic lives here"
          text="Notes, voice notes, sketches, PDFs, pictures and videos. Tap Add, or drop files anywhere on this page."
        >
          <Button size="lg" onClick={() => setAddOpen(true)}>
            <Plus size={17} /> Add to library
          </Button>
        </Empty>
      )}

      <div className="mt-4 grid grid-cols-2 gap-x-3 gap-y-5 sm:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: busy }).map((_, i) => (
          <div key={"b" + i}>
            <div className="shimmer aspect-[4/3] rounded-2xl" />
            <div className="shimmer mt-2 h-3.5 w-3/4 rounded-full" />
          </div>
        ))}
        {shown.map((e) => (
          <Tile key={`${e.kind}-${e.id}`} entry={e} project={project} color={col.hex} onOpen={() => open(e)} />
        ))}
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPT_ALL}
        className="hidden"
        onChange={(e) => {
          void upload(e.target.files);
          e.target.value = "";
          e.target.accept = ACCEPT_ALL;
        }}
      />
      <AddSheet open={addOpen} onClose={() => setAddOpen(false)} onPick={onAdd} />
      <Recorder projectId={project.id} open={recording} onClose={() => setRecording(false)} />
    </div>
  );
}

const CREATE: { id: AddChoice; title: string; icon: ReactNode }[] = [
  { id: "note", title: "Note", icon: <FileText size={20} /> },
  { id: "voice", title: "Voice note", icon: <Mic size={20} /> },
  { id: "sketch", title: "Sketch", icon: <PenTool size={20} /> },
];
const UPLOAD: { id: AddChoice; title: string; icon: ReactNode }[] = [
  { id: "pdf", title: "PDF", icon: <FileText size={20} /> },
  { id: "image", title: "Picture", icon: <ImageIcon size={20} /> },
  { id: "video", title: "Video", icon: <Film size={20} /> },
  { id: "audio", title: "Audio file", icon: <Music size={20} /> },
  { id: "text", title: "Text file", icon: <AlignLeft size={20} /> },
];

function AddSheet({ open, onClose, onPick }: { open: boolean; onClose: () => void; onPick: (c: AddChoice) => void }) {
  const tile = (c: { id: AddChoice; title: string; icon: ReactNode }) => (
    <button
      key={c.id}
      onClick={() => onPick(c.id)}
      className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-ink/[0.035] px-2 py-4 ring-1 ring-line transition-colors hover:bg-ink/[0.07] active:scale-[0.98]"
    >
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-card text-ink ring-1 ring-line">{c.icon}</span>
      <span className="text-[13px] font-semibold">{c.title}</span>
    </button>
  );
  return (
    <Sheet open={open} onClose={onClose} title="Add to library">
      <h3 className="mb-2 text-[13px] font-medium text-muted">Create</h3>
      <div className="grid grid-cols-3 gap-2">{CREATE.map(tile)}</div>
      <h3 className="mb-2 mt-5 text-[13px] font-medium text-muted">Upload</h3>
      <div className="grid grid-cols-3 gap-2">{UPLOAD.map(tile)}</div>
      <p className="mt-4 text-center text-[12px] text-muted">You can also drop files anywhere in the library.</p>
    </Sheet>
  );
}

function KindBadge({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <span className="absolute bottom-2 left-2 inline-flex max-w-[calc(100%-16px)] items-center gap-1 truncate rounded-full bg-[#17171a]/75 px-2 py-0.5 text-[11px] font-medium text-[#fff] backdrop-blur-sm">
      {icon}
      {label}
    </span>
  );
}

function Tile({ entry, project, color, onOpen }: { entry: Entry; project: Project; color: string; onOpen: () => void }) {
  let preview: ReactNode;
  let badge: ReactNode = null;
  let meta: string;

  if (entry.kind === "note") {
    const text = snippetOf(entry.note.content, 240);
    preview = (
      <div className="flex h-full flex-col p-3.5">
        <div className="mb-2 flex items-center gap-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-ink/[0.06] px-2 py-0.5 text-[11px] font-medium text-ink">
            <FileText size={11} /> Note
          </span>
          {entry.note.author === "ai" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-ink/[0.06] px-2 py-0.5 text-[11px] font-medium text-ink">
              <AgentAvatar size={13} frozenAt={0} look={project.avatar} /> Leo
            </span>
          )}
        </div>
        <p className="line-clamp-4 text-[12.5px] leading-[1.55] text-muted" dir="auto">
          {text || "Empty note"}
        </p>
      </div>
    );
    meta = `Note · ${timeAgo(entry.at)}`;
  } else if (entry.kind === "sketch") {
    const s = entry.sketch;
    preview = s.thumb ? (
      <img src={s.thumb} alt="" className="h-full w-full object-contain p-2" loading="lazy" />
    ) : (
      <div
        className="flex h-full items-center justify-center text-muted"
        style={{ backgroundImage: "radial-gradient(color-mix(in srgb, var(--ink) 14%, transparent) 1px, transparent 1px)", backgroundSize: "14px 14px" }}
      >
        <PenTool size={22} />
      </div>
    );
    badge = <KindBadge icon={<PenTool size={11} />} label="Sketch" />;
    meta = `Sketch · ${timeAgo(entry.at)}`;
  } else {
    const f = entry.file;
    if (f.kind === "audio") {
      preview = (
        <div className="flex h-full flex-col justify-between p-3.5" style={{ background: `color-mix(in srgb, ${color} 10%, var(--card))` }}>
          <div className="flex items-center justify-between">
            <span className="flex h-8 w-8 items-center justify-center rounded-full" style={{ background: color, color: readableOn(color) }}>
              {f.recorded ? <Mic size={15} /> : <Music size={15} />}
            </span>
            <span className="text-[12px] font-semibold tabular-nums" style={{ color: accentText(color) }}>
              {formatDuration(f.duration)}
            </span>
          </div>
          <Waveform peaks={f.peaks} color={color} className="h-12" progress={1} />
        </div>
      );
      meta = `${f.recorded ? "Voice note" : "Audio"} · ${timeAgo(f.createdAt)}`;
    } else if (f.kind === "video") {
      preview = (
        <div className="relative h-full w-full bg-[#111]">
          {f.thumb ? <img src={f.thumb} alt="" className="h-full w-full object-cover" loading="lazy" /> : <div className="flex h-full items-center justify-center text-[#888]"><Film size={26} /></div>}
          <span className="absolute left-1/2 top-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#fff]/90 text-[#17171a] shadow-md">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </span>
        </div>
      );
      badge = <KindBadge icon={<Film size={11} />} label={f.duration ? formatDuration(f.duration) : "Video"} />;
      meta = `Video · ${timeAgo(f.createdAt)}`;
    } else if (f.kind === "text") {
      preview = (
        <div className="flex h-full items-center justify-center text-muted">
          <AlignLeft size={26} />
        </div>
      );
      badge = <KindBadge icon={<AlignLeft size={11} />} label="Text" />;
      meta = `Text · ${timeAgo(f.createdAt)}`;
    } else {
      preview = f.thumb ? (
        <img src={f.thumb} alt="" className={cn("h-full w-full object-cover", f.kind === "pdf" && "object-top")} loading="lazy" />
      ) : (
        <div className="flex h-full items-center justify-center text-muted">{f.kind === "pdf" ? <FileText size={26} /> : <ImageIcon size={26} />}</div>
      );
      const label = f.kind === "pdf" ? `PDF${f.pages ? ` · ${f.pages} ${f.pages === 1 ? "page" : "pages"}` : ""}` : "Picture";
      badge = <KindBadge icon={f.kind === "pdf" ? <FileText size={11} /> : <ImageIcon size={11} />} label={label} />;
      meta = `${f.kind === "pdf" ? "PDF" : "Picture"} · ${timeAgo(f.createdAt)}`;
    }
  }

  return (
    <button onClick={onOpen} className="group min-w-0 text-left">
      <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-card ring-1 ring-line transition-shadow group-hover:shadow-[0_6px_20px_rgba(0,0,0,0.08)]">
        {preview}
        {badge}
      </div>
      <div className="mt-2 truncate px-0.5 text-[14px] font-medium leading-snug" dir="auto">
        {entry.title}
      </div>
      <div className="truncate px-0.5 text-[12px] text-muted">{meta}</div>
    </button>
  );
}

/* ---------------------------------------------------------------- viewers */

function useObjectUrl(blob: Blob) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return url;
}

function FileViewer({ project, fileId }: { project: Project; fileId: string }) {
  const file = useLiveQuery(() => db.files.get(fileId), [fileId], null as LibFile | null | undefined);
  if (file === null) return null;
  if (!file)
    return (
      <Empty icon={<BookOpen />} title="File not found">
        <Button onClick={() => navigate(projectPath(project.id))}>Back to library</Button>
      </Empty>
    );
  if (file.kind === "pdf") return <PdfViewer file={file} header={<FileBar file={file} project={project} />} />;
  return <MediaPage file={file} project={project} />;
}

function useFileActions(file: LibFile, project: Project) {
  return {
    remove: async () => {
      if (!confirmDeletion(`Delete "${file.name}"?`)) return;
      navigate(projectPath(project.id), true);
      await removeFile(file);
    },
    ask: () => useApp.getState().setChatOpen(true),
    save: () => download(file.blob, file.name),
  };
}

const baseName = (n: string) => n.replace(/\.[a-z0-9]{1,5}$/i, "");
const extOf = (n: string) => /\.([a-z0-9]{1,5})$/i.exec(n)?.[1]?.toUpperCase();

function EditableTitle({ file, size = "lg", className }: { file: LibFile; size?: "sm" | "lg"; className?: string }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(file.name);
  const save = async () => {
    const n = name.trim();
    if (n && n !== file.name) await db.files.update(file.id, { name: n });
    setEditing(false);
  };
  if (editing)
    return (
      <input
        autoFocus
        value={name}
        onChange={(e) => setName(e.target.value)}
        onBlur={() => void save()}
        onKeyDown={(e) => {
          if (e.key === "Enter") void save();
          if (e.key === "Escape") setEditing(false);
        }}
        aria-label="File name"
        className={cn("w-full rounded-xl bg-card px-3 py-1.5 text-[16px] outline-none ring-1 ring-line focus:ring-ink/30", className)}
      />
    );
  return (
    <button
      onClick={() => {
        setName(file.name);
        setEditing(true);
      }}
      className={cn("group flex min-w-0 max-w-full items-center gap-1.5 text-left", className)}
      title="Rename"
    >
      <span className={cn("min-w-0", size === "lg" ? "display line-clamp-2 text-[22px] leading-tight" : "truncate text-[14px] font-semibold")} dir="auto">
        {baseName(file.name)}
      </span>
      <Pencil size={size === "lg" ? 15 : 13} className="shrink-0 text-muted" />
    </button>
  );
}

/** Compact header for full-height viewers (PDF). */
function FileBar({ file, project }: { file: LibFile; project: Project }) {
  const { remove, ask, save } = useFileActions(file, project);
  return (
    <div className="flex shrink-0 items-center gap-1 border-b border-line bg-paper px-2 py-1.5 sm:px-4">
      <div className="min-w-0 flex-1 px-1.5">
        <EditableTitle file={file} size="sm" />
        <div className="truncate text-[12px] text-muted">
          PDF{file.pages ? ` · ${file.pages} pages` : ""} · {formatBytes(file.size)}
        </div>
      </div>
      <IconBtn onClick={ask} aria-label="Ask Leo about this PDF">
        <AgentAvatar size={22} frozenAt={0} look={project.avatar} />
      </IconBtn>
      <IconBtn onClick={save} aria-label="Download">
        <Download size={17} />
      </IconBtn>
      <IconBtn onClick={() => void remove()} aria-label="Delete" className="hover:text-danger-fg">
        <Trash2 size={17} />
      </IconBtn>
    </div>
  );
}

const KIND_WORD: Record<FileKind, string> = { pdf: "PDF", image: "Picture", video: "Video", audio: "Audio", text: "Text file" };

/** Scrolling page for video, pictures, audio and text: media first, then title, details and actions. */
function MediaPage({ file, project }: { file: LibFile; project: Project }) {
  const { remove, ask, save } = useFileActions(file, project);
  const details = [
    file.kind === "audio" && file.recorded ? "Voice note" : KIND_WORD[file.kind],
    extOf(file.name) ?? null,
    file.duration ? formatDuration(file.duration) : null,
    formatBytes(file.size),
    `Added ${new Date(file.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`,
  ].filter(Boolean) as string[];
  return (
    <div className="pb-36">
      <div className="mx-auto max-w-3xl sm:px-4 sm:pt-4">
        {file.kind === "video" && <VideoStage file={file} />}
        {file.kind === "image" && <ImageStage file={file} />}
        {file.kind === "audio" && (
          <div className="px-4 pt-4 sm:px-0">
            <AudioPlayer file={file} accent={colorOf(project.color).hex} />
          </div>
        )}
        {file.kind === "text" && <TextStage file={file} />}
      </div>
      <div className="mx-auto max-w-3xl px-4 pt-5">
        <EditableTitle file={file} />
        <div className="mt-1.5 flex flex-wrap gap-x-2 gap-y-1 text-[13px] tabular-nums text-muted">
          {details.map((d, i) => (
            <span key={i}>
              {i > 0 && (
                <span aria-hidden className="mr-2">
                  ·
                </span>
              )}
              {d}
            </span>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="soft" onClick={ask}>
            <AgentAvatar size={20} frozenAt={0} look={project.avatar} /> Ask Leo
          </Button>
          <Button variant="soft" onClick={save}>
            <Download size={16} /> Download
          </Button>
          <Button variant="danger" onClick={() => void remove()}>
            <Trash2 size={16} /> Delete
          </Button>
        </div>
        {file.kind === "video" && <p className="mt-4 text-[13px] leading-relaxed text-muted">Pause on any frame and tap Ask Leo — Leo sees that exact frame.</p>}
        {file.kind === "image" && <p className="mt-4 text-[13px] leading-relaxed text-muted">Tap the picture to zoom. Ask Leo to explain what's in it.</p>}
      </div>
    </div>
  );
}

function VideoStage({ file }: { file: LibFile }) {
  const url = useObjectUrl(file.blob);
  const ref = useRef<HTMLVideoElement>(null);
  const setImage = useApp((s) => s.setImage);
  useEffect(() => {
    setImage({ fileId: file.id, name: `${file.name} (current frame)`, getDataUrl: async () => frameDataUrl(ref.current, 1280) });
    return () => setImage(null);
  }, [file.id, file.name, setImage]);
  // The frame you pause on becomes the poster in the library.
  const onPause = () => {
    const d = frameDataUrl(ref.current, 420);
    if (d) void db.files.update(file.id, { thumb: d, thumbVersion: 3 });
  };
  return (
    <div className="overflow-hidden bg-[#000] sm:rounded-2xl">
      {url ? (
        <video
          ref={ref}
          src={url}
          poster={file.thumb}
          controls
          playsInline
          preload="metadata"
          onPause={onPause}
          className="mx-auto block max-h-[70dvh] w-full bg-[#000] object-contain"
        />
      ) : (
        <div className="aspect-video" />
      )}
    </div>
  );
}

function ImageStage({ file }: { file: LibFile }) {
  const url = useObjectUrl(file.blob);
  const [zoom, setZoom] = useState(false);
  const setImage = useApp((s) => s.setImage);
  useEffect(() => {
    setImage({ fileId: file.id, name: file.name, getDataUrl: () => imageToDataUrl(file.blob, 1280) });
    return () => setImage(null);
  }, [file.id, file.name, file.blob, setImage]);
  return (
    <div className={cn("bg-document sm:rounded-2xl", zoom && "max-h-[80dvh] overflow-auto")}>
      {url && (
        <img
          src={url}
          alt={file.name}
          onClick={() => setZoom((z) => !z)}
          className={cn("mx-auto block", zoom ? "max-w-none cursor-zoom-out" : "max-h-[70dvh] w-full cursor-zoom-in object-contain sm:rounded-2xl")}
        />
      )}
    </div>
  );
}

function TextStage({ file }: { file: LibFile }) {
  const [text, setText] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    void file.blob.text().then((t) => alive && setText(t));
    return () => {
      alive = false;
    };
  }, [file.blob]);
  return (
    <div className="px-4 pt-4 sm:px-0" data-ctx-source={`file "${file.name}"`}>
      <pre className="whitespace-pre-wrap rounded-2xl bg-card p-5 font-sans text-[15px] leading-relaxed ring-1 ring-line" dir="auto">
        {text ?? "…"}
      </pre>
    </div>
  );
}
