import {
  useCallback,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent as RKeyboardEvent,
  type MouseEvent as RMouseEvent,
  type ReactNode,
  type Ref,
} from "react";
import { Bold, Code, FileText, Heading, Italic, List, ListChecks, ListOrdered, Quote, Sigma, Trash2 } from "lucide-react";
import AgentAvatar from "@/components/AgentAvatar";
import { confirmDeletion } from "@/lib/settings";
import { indexNote, removeChunks } from "@/lib/retrieval";
import { db, type Note, type Project } from "@/lib/db";
import { navigate, projectPath } from "@/lib/router";
import { timeAgo } from "@/lib/media";
import { useApp } from "@/lib/store";
import { Markdown } from "@/components/Markdown";
import { Button, Empty } from "@/components/ui";
import { LIST_RE, inFence, joinBlocks, nextMarker, splitBlocks, toggleTask } from "@/lib/blocks";
import { cn } from "@/utils/cn";

export { toggleTask };

export default function Notes({ project, noteId }: { project: Project; noteId: string }) {
  return <NoteEditor key={noteId} project={project} noteId={noteId} />;
}

function NoteEditor({ project, noteId }: { project: Project; noteId: string }) {
  const [note, setNoteState] = useState<Note | null | undefined>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [saved, setSaved] = useState(true);
  const [editedAt, setEditedAt] = useState(0);
  const editor = useRef<BlockEditorApi>(null);
  const titleRef = useRef<HTMLTextAreaElement>(null);
  const setNoteCtx = useApp((s) => s.setNote);
  const loaded = useRef(false);

  useEffect(() => {
    void db.notes.get(noteId).then((n) => {
      setNoteState(n);
      if (n) {
        setTitle(n.title);
        setContent(n.content);
        setEditedAt(n.updatedAt);
      }
      loaded.current = true;
    });
  }, [noteId]);

  // Autosave only real changes; flush on leave so a quick back-navigation never drops typing.
  const dirty = useRef(false);
  const latest = useRef({ title, content });
  latest.current = { title, content };
  const persist = useCallback(async () => {
    if (!dirty.current) return;
    dirty.current = false;
    const { title: t, content: c } = latest.current;
    const now = Date.now();
    await db.notes.update(noteId, { title: t, content: c, updatedAt: now });
    await db.projects.update(project.id, { updatedAt: now });
    const fresh = await db.notes.get(noteId);
    if (fresh) await indexNote(fresh);
    setEditedAt(now);
    setSaved(true);
  }, [noteId, project.id]);

  useEffect(() => {
    if (!loaded.current || !note) return;
    if (title === note.title && content === note.content && !dirty.current) return;
    dirty.current = true;
    setSaved(false);
    const t = setTimeout(() => void persist(), 500);
    return () => clearTimeout(t);
  }, [title, content, note, persist]);

  useEffect(() => {
    const flush = () => void persist();
    window.addEventListener("pagehide", flush);
    return () => {
      window.removeEventListener("pagehide", flush);
      flush();
    };
  }, [persist]);

  useEffect(() => {
    if (!note) return;
    setNoteCtx({ id: noteId, title: title || "Untitled", content });
  }, [title, content, noteId, note, setNoteCtx]);
  useEffect(() => () => setNoteCtx(null), [setNoteCtx]);

  useEffect(() => {
    if (note && !note.title && !note.content) titleRef.current?.focus();
  }, [note]);

  useLayoutEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
  }, [title, note]);

  if (note === null) return null;
  if (!note)
    return (
      <Empty icon={<FileText />} title="Note not found">
        <Button onClick={() => navigate(projectPath(project.id))}>Back to library</Button>
      </Empty>
    );

  const remove = async () => {
    if (!confirmDeletion("Delete this note?")) return;
    dirty.current = false;
    navigate(projectPath(project.id), true);
    await db.notes.delete(noteId);
    await removeChunks(noteId);
  };

  const words = content.trim() ? content.trim().split(/\s+/).length : 0;

  return (
    <div className="pb-40">
      <div className="sticky top-0 z-20 border-b border-line/70 bg-paper/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[760px] items-center px-2 py-1 sm:px-8">
          <div className="no-scrollbar flex min-w-0 flex-1 items-center justify-between overflow-x-auto sm:justify-start sm:gap-1" role="toolbar" aria-label="Formatting">
            <ToolBtn label="Heading" onClick={() => editor.current?.prefix("## ")}>
              <Heading size={18} />
            </ToolBtn>
            <ToolBtn label="Bold" onClick={() => editor.current?.wrap("**")}>
              <Bold size={18} />
            </ToolBtn>
            <ToolBtn label="Italic" onClick={() => editor.current?.wrap("*")}>
              <Italic size={18} />
            </ToolBtn>
            <Sep />
            <ToolBtn label="Bulleted list" onClick={() => editor.current?.prefix("- ")}>
              <List size={18} />
            </ToolBtn>
            <ToolBtn label="Numbered list" onClick={() => editor.current?.prefix("1. ")}>
              <ListOrdered size={18} />
            </ToolBtn>
            <ToolBtn label="Checklist" onClick={() => editor.current?.prefix("- [ ] ")}>
              <ListChecks size={18} />
            </ToolBtn>
            <ToolBtn label="Quote" onClick={() => editor.current?.prefix("> ")}>
              <Quote size={18} />
            </ToolBtn>
            <Sep />
            <ToolBtn label="Code" onClick={() => editor.current?.wrap("`")}>
              <Code size={18} />
            </ToolBtn>
            <ToolBtn label="Math" onClick={() => editor.current?.wrap("$", "$", "x^2")}>
              <Sigma size={18} />
            </ToolBtn>
          </div>
        </div>
      </div>

      <article className="mx-auto max-w-[760px] px-5 pt-7 sm:px-10">
        <textarea
          ref={titleRef}
          rows={1}
          value={title}
          onChange={(e) => setTitle(e.target.value.replace(/\n/g, " "))}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              editor.current?.focusStart();
            }
          }}
          placeholder="Untitled"
          dir="auto"
          aria-label="Note title"
          className="block w-full resize-none overflow-hidden bg-transparent display text-[30px] leading-[1.15] outline-none placeholder:text-muted/60 sm:text-[34px]"
        />
        <div className="mt-2 flex items-start gap-2">
          <div className="flex min-w-0 flex-1 flex-wrap items-center gap-x-2 gap-y-1 pt-2 text-[13px] tabular-nums text-muted">
          {note.author === "ai" && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-ink/[0.06] px-2 py-0.5 text-[12px] font-medium text-ink">
              <AgentAvatar size={14} frozenAt={0} look={project.avatar} /> Written by Leo
            </span>
          )}
          <span>
            {words} {words === 1 ? "word" : "words"}
          </span>
          <span aria-hidden>·</span>
          <span>Edited {timeAgo(editedAt || note.updatedAt)}</span>
          <span className="ml-1 inline-flex items-center gap-1.5" aria-live="polite">
            <span className={cn("h-1.5 w-1.5 rounded-full transition-colors", saved ? "bg-solid" : "bg-shaky")} />
            {saved ? "Saved" : "Saving"}
          </span>
          </div>
          <button
            onClick={() => void remove()}
            aria-label="Delete note"
            className="inline-flex shrink-0 h-9 w-9 items-center justify-center rounded-full text-muted transition-colors hover:bg-danger-bg hover:text-danger-fg"
          >
            <Trash2 size={16} />
          </button>
        </div>
        <div className="mt-6" data-ctx-source={`note "${title || "Untitled"}"`}>
          <BlockEditor apiRef={editor} value={content} onChange={setContent} />
        </div>
      </article>
    </div>
  );
}

function Sep() {
  return <span className="mx-1 h-5 w-px shrink-0 bg-line" aria-hidden />;
}

function ToolBtn({ onClick, label, children }: { onClick: () => void; label: string; children: ReactNode }) {
  return (
    <button
      type="button"
      onPointerDown={(e) => e.preventDefault()}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      aria-label={label}
      title={label}
      className="inline-flex h-10 w-[38px] shrink-0 items-center justify-center rounded-xl text-ink/80 transition-colors hover:bg-ink/[0.06] hover:text-ink active:scale-95"
    >
      {children}
    </button>
  );
}

/* ------------------------------------------------------------ block editor */

export interface BlockEditorApi {
  wrap: (before: string, after?: string, placeholder?: string) => void;
  prefix: (p: string) => void;
  focusStart: () => void;
}

interface Editing {
  before: string[];
  after: string[];
  draft: string;
}

/** Map a click in rendered markdown to an offset in the block's source. */
function estimateCaret(e: RMouseEvent<HTMLElement>, el: HTMLElement, raw: string) {
  const d = document as Document & {
    caretPositionFromPoint?: (x: number, y: number) => { offsetNode: Node; offset: number } | null;
    caretRangeFromPoint?: (x: number, y: number) => Range | null;
  };
  let node: Node | null = null;
  let offset = 0;
  if (d.caretPositionFromPoint) {
    const p = d.caretPositionFromPoint(e.clientX, e.clientY);
    if (p) ({ offsetNode: node, offset } = p);
  } else if (d.caretRangeFromPoint) {
    const r = d.caretRangeFromPoint(e.clientX, e.clientY);
    if (r) {
      node = r.startContainer;
      offset = r.startOffset;
    }
  }
  if (!node || !el.contains(node)) return raw.length;
  const range = document.createRange();
  range.setStart(el, 0);
  try {
    range.setEnd(node, offset);
  } catch {
    return raw.length;
  }
  const prefix = range.toString();
  if (!prefix) return 0;
  const total = el.textContent?.length || 1;
  const est = Math.round((prefix.length / total) * raw.length);
  const tail = prefix.slice(-12);
  let best = -1;
  let bestDist = Infinity;
  for (let i = raw.indexOf(tail); i >= 0; i = raw.indexOf(tail, i + 1)) {
    const dist = Math.abs(i + tail.length - est);
    if (dist < bestDist) {
      best = i;
      bestDist = dist;
    }
  }
  return best >= 0 ? best + tail.length : Math.min(raw.length, est);
}

/**
 * Live-preview editor: every block renders as formatted markdown; tapping a block turns just
 * that block into its source for editing. Enter on an empty line starts a new block, lists
 * continue themselves, Backspace at the start merges upward, arrows move between blocks.
 */
function BlockEditor({ value, onChange, apiRef }: { value: string; onChange: (v: string) => void; apiRef: Ref<BlockEditorApi> }) {
  const blocks = useMemo(() => splitBlocks(value), [value]);
  const [editing, setEditing] = useState<Editing | null>(() => (value.trim() ? null : { before: [], after: [], draft: "" }));
  const ta = useRef<HTMLTextAreaElement>(null);
  const pendingSel = useRef<[number, number] | null>(null);
  const blurTimer = useRef<number | undefined>(undefined);

  const emit = (before: string[], draft: string, after: string[]) => onChange(joinBlocks([...before, draft, ...after]));
  const allOf = (e: Editing) => [...e.before, ...splitBlocks(e.draft), ...e.after];

  const begin = (all: string[], i: number, sel: number | [number, number]) => {
    window.clearTimeout(blurTimer.current);
    pendingSel.current = typeof sel === "number" ? [sel, sel] : sel;
    setEditing({ before: all.slice(0, i), after: all.slice(i + 1), draft: all[i] ?? "" });
  };

  const setDraft = (draft: string, sel?: [number, number]) => {
    if (!editing) return;
    if (sel) pendingSel.current = sel;
    setEditing({ ...editing, draft });
    emit(editing.before, draft, editing.after);
  };

  const splitInto = (head: string, tail: string) => {
    if (!editing) return;
    const before = [...editing.before, ...splitBlocks(head)];
    pendingSel.current = [0, 0];
    setEditing({ before, after: editing.after, draft: tail });
    emit(before, tail, editing.after);
  };

  useLayoutEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
    if (pendingSel.current) {
      const [a, b] = pendingSel.current;
      pendingSel.current = null;
      el.focus({ preventScroll: true });
      el.setSelectionRange(a, b);
      el.scrollIntoView({ block: "nearest" });
    }
  }, [editing]);

  useImperativeHandle(apiRef, () => ({
    wrap(before, after = before, placeholder = "text") {
      if (!editing) {
        const draft = before + placeholder + after;
        begin([...blocks, draft], blocks.length, [before.length, before.length + placeholder.length]);
        onChange(joinBlocks([...blocks, draft]));
        return;
      }
      const el = ta.current;
      const v = editing.draft;
      const s = el?.selectionStart ?? v.length;
      const en = el?.selectionEnd ?? v.length;
      const sel = v.slice(s, en) || placeholder;
      setDraft(v.slice(0, s) + before + sel + after + v.slice(en), [s + before.length, s + before.length + sel.length]);
    },
    prefix(p) {
      if (!editing) {
        begin([...blocks, p], blocks.length, p.length);
        onChange(joinBlocks([...blocks, p]));
        return;
      }
      const el = ta.current;
      const v = editing.draft;
      const s = el?.selectionStart ?? v.length;
      const en = el?.selectionEnd ?? v.length;
      const lineStart = v.lastIndexOf("\n", s - 1) + 1;
      const lines = v.slice(lineStart, en).split("\n");
      const allHave = lines.every((l) => l.startsWith(p));
      const replaced = lines.map((l) => (allHave ? l.slice(p.length) : p + l.replace(LIST_RE, "").replace(/^#{1,6}\s+/, ""))).join("\n");
      const caret = lineStart + replaced.length;
      setDraft(v.slice(0, lineStart) + replaced + v.slice(en), [caret, caret]);
    },
    focusStart() {
      if (!editing) begin(blocks, 0, 0);
      else ta.current?.focus();
    },
  }));

  const onKeyDown = (e: RKeyboardEvent<HTMLTextAreaElement>) => {
    if (!editing) return;
    const el = e.currentTarget;
    const v = el.value;
    const s = el.selectionStart;
    const en = el.selectionEnd;
    if (e.key === "Escape") {
      e.preventDefault();
      setEditing(null);
      el.blur();
      return;
    }
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && s === en) {
      if (inFence(v.slice(0, s))) return;
      const lineStart = v.lastIndexOf("\n", s - 1) + 1;
      const line = v.slice(lineStart, s);
      const m = LIST_RE.exec(line);
      if (m) {
        e.preventDefault();
        const marker = m[0];
        if (line.trim() === marker.trim() && v.slice(s).split("\n")[0].trim() === "") {
          // Enter on an empty item ends the list and starts a fresh block.
          splitInto(v.slice(0, lineStart).replace(/\n+$/, ""), v.slice(s).replace(/^\n/, ""));
        } else {
          const next = nextMarker(marker);
          setDraft(v.slice(0, s) + "\n" + next + v.slice(en), [s + 1 + next.length, s + 1 + next.length]);
        }
        return;
      }
      if (s === v.length && (v === "" || v.endsWith("\n"))) {
        e.preventDefault();
        if (v.trim()) splitInto(v.replace(/\n+$/, ""), "");
        return;
      }
      return;
    }
    if (e.key === "Backspace" && s === 0 && en === 0 && editing.before.length) {
      e.preventDefault();
      const prev = editing.before[editing.before.length - 1];
      const before = editing.before.slice(0, -1);
      const merged = v.trim() ? `${prev}\n${v}` : prev;
      pendingSel.current = [prev.length, prev.length];
      setEditing({ before, after: editing.after, draft: merged });
      emit(before, merged, editing.after);
      return;
    }
    if (e.key === "ArrowUp" && s === 0 && en === 0 && editing.before.length) {
      e.preventDefault();
      const all = allOf(editing);
      const i = editing.before.length - 1;
      begin(all, i, all[i].length);
      return;
    }
    if (e.key === "ArrowDown" && s === v.length && en === v.length && editing.after.length) {
      e.preventDefault();
      begin(allOf(editing), editing.before.length + splitBlocks(v).length, 0);
    }
  };

  const onBlur = () => {
    window.clearTimeout(blurTimer.current);
    blurTimer.current = window.setTimeout(() => {
      if (document.activeElement !== ta.current) setEditing(null);
    }, 160);
  };
  useEffect(() => () => window.clearTimeout(blurTimer.current), []);

  const onBlockClick = (e: RMouseEvent<HTMLDivElement>, all: string[], i: number) => {
    if ((e.target as HTMLElement).closest("a,input,button,label")) return;
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && e.currentTarget.contains(sel.anchorNode)) return; // selecting text to ask the AI
    begin(all, i, estimateCaret(e, e.currentTarget, all[i]));
  };

  const replaceAt = (all: string[], i: number, next: string) => {
    const copy = [...all];
    copy[i] = next;
    if (editing) {
      const bLen = editing.before.length;
      const dLen = splitBlocks(editing.draft).length;
      const before = copy.slice(0, bLen);
      const after = copy.slice(bLen + dLen);
      setEditing({ ...editing, before, after });
      emit(before, editing.draft, after);
    } else onChange(joinBlocks(copy));
  };

  const block = (raw: string, all: string[], i: number) => (
    <div
      key={`b${i}`}
      className="-mx-3 cursor-text rounded-xl px-3 py-1.5 transition-colors hover:bg-ink/[0.03]"
      onClick={(e) => onBlockClick(e, all, i)}
    >
      <Markdown className="note-body" onToggleTask={(nth, checked) => replaceAt(all, i, toggleTask(raw, nth, checked))}>
        {raw}
      </Markdown>
    </div>
  );

  if (!editing) {
    return (
      <div className="flex flex-col gap-0.5">
        {blocks.map((b, i) => block(b, blocks, i))}
        <div
          role="button"
          tabIndex={0}
          aria-label="Add a paragraph"
          onClick={() => begin(blocks, blocks.length, 0)}
          onKeyDown={(e) => e.key === "Enter" && begin(blocks, blocks.length, 0)}
          className="min-h-[120px] cursor-text pt-1.5 text-[17px] text-muted/80"
        >
          {blocks.length ? "" : "Start writing…"}
        </div>
      </div>
    );
  }

  const all = allOf(editing);
  const draftCount = splitBlocks(editing.draft).length;
  return (
    <div className="flex flex-col gap-0.5">
      {editing.before.map((b, j) => block(b, all, j))}
      <div key="active" className="-mx-3 rounded-xl bg-ink/[0.035] px-3 py-1.5 ring-1 ring-line">
        <textarea
          ref={ta}
          value={editing.draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={onKeyDown}
          onBlur={onBlur}
          rows={1}
          dir="auto"
          spellCheck
          aria-label="Edit paragraph"
          placeholder="Write… Markdown, checklists and $math$ work"
          className="block w-full resize-none overflow-hidden bg-transparent text-[17px] leading-[1.75] outline-none placeholder:text-muted/70"
        />
      </div>
      {editing.after.map((b, k) => block(b, all, editing.before.length + draftCount + k))}
      <div
        aria-hidden
        onClick={() => {
          const a = allOf(editing);
          begin(a, a.length, 0);
        }}
        className="min-h-[120px] cursor-text"
      />
    </div>
  );
}
