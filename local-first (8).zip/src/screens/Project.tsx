import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeft, ChevronRight, Globe2, LayoutGrid, MoreHorizontal, Search, Trash2, TrendingUp } from "lucide-react";
import { PROJECT_COLORS, db, deleteProject, type Project, type ProjectIcon } from "@/lib/db";
import { navigate, projectPath, type Route } from "@/lib/router";
import { useApp } from "@/lib/store";
import { confirmDeletion } from "@/lib/settings";
import { Button, Empty, Field, IconBtn, Sheet, inputCls } from "@/components/ui";
import { cn } from "@/utils/cn";
import Library from "./project/Library";
import Notes from "./project/Notes";
import Sketches from "./project/Sketches";
import ChatPanel from "@/components/chat/ChatPanel";
import ProjectAvatar from "@/components/ProjectAvatar";
import ProjectIconPicker from "@/components/ProjectIconPicker";
import SearchSheet from "@/components/SearchSheet";
import Dock from "@/components/Dock";
import { ProgressSheet } from "@/components/Progress";

export default function ProjectScreen({ route }: { route: Extract<Route, { name: "project" }> }) {
  const project = useLiveQuery(() => db.projects.get(route.projectId), [route.projectId], null as Project | null | undefined);
  const [editing, setEditing] = useState(false);
  const [searching, setSearching] = useState(false);
  const chatOpen = useApp((s) => s.chatOpen);
  const mainRef = useRef<HTMLElement>(null);
  const libraryScroll = useRef(0);
  const lastView = useRef("");

  const atLibrary = route.tab === "progress" || (route.tab === "library" && !route.itemId);
  const view = atLibrary ? "library" : `${route.tab}/${route.itemId ?? ""}`;

  useEffect(() => {
    return () => {
      const s = useApp.getState();
      s.setSelection(null);
      s.setNote(null);
      s.setPdf(null);
      s.setImage(null);
      s.setSketch(null);
      s.setChatOpen(false);
      s.setAddOpen(false);
    };
  }, []);

  // Starting a chat from the Progress sheet closes it, so the chat panel is never hidden behind it.
  useEffect(() => {
    if (chatOpen && route.tab === "progress") navigate(projectPath(route.projectId), true);
  }, [chatOpen, route.tab, route.projectId]);

  // Items open at the top; coming back to the library restores where you were.
  useLayoutEffect(() => {
    const el = mainRef.current;
    if (!el || lastView.current === view) return;
    el.scrollTop = view === "library" ? libraryScroll.current : 0;
    lastView.current = view;
  }, [view, project]);

  if (project === null) return null;
  if (!project)
    return (
      <Empty icon={<LayoutGrid />} title="Project not found" text="It may have been deleted.">
        <Button onClick={() => navigate("")}>Go home</Button>
      </Empty>
    );

  // Sketching gets the whole screen: no project header, no dock — one slim bar inside the editor.
  const immersive = route.tab === "sketch" && !!route.itemId;

  return (
    <div className="flex h-dvh flex-col">
      {!immersive && (
        <header className="z-20 shrink-0 border-b border-line/70 bg-paper/85 pt-[env(safe-area-inset-top)] backdrop-blur-xl">
          <div className="mx-auto flex h-14 max-w-5xl items-center gap-1 px-2 sm:px-3">
            <IconBtn onClick={() => navigate(atLibrary ? "" : projectPath(project.id))} aria-label={atLibrary ? "All projects" : "Back to library"}>
              <ArrowLeft size={19} />
            </IconBtn>
            <button onClick={() => navigate(projectPath(project.id))} className="flex min-w-0 flex-1 items-center gap-2.5 rounded-xl px-1 py-1 text-left">
              <ProjectAvatar project={project} size={34} />
              <div className="min-w-0">
                <div className="truncate display text-[18px] leading-tight">{project.name}</div>
                {project.tag && <div className="truncate text-[12px] text-muted">{project.tag}</div>}
              </div>
            </button>
            <IconBtn onClick={() => useApp.getState().setBrowserOpen(true)} aria-label="Open learning browser">
              <Globe2 size={18} />
            </IconBtn>
            <IconBtn onClick={() => setSearching(true)} aria-label="Search this project">
              <Search size={18} />
            </IconBtn>
            <IconBtn onClick={() => setEditing(true)} aria-label="Project settings">
              <MoreHorizontal size={19} />
            </IconBtn>
          </div>
        </header>
      )}

      <main
        ref={mainRef}
        onScroll={(e) => {
          if (atLibrary) libraryScroll.current = e.currentTarget.scrollTop;
        }}
        className={cn("relative min-h-0 flex-1", immersive ? "overflow-hidden pt-[env(safe-area-inset-top)]" : "overflow-y-auto")}
      >
        {route.tab === "notes" && route.itemId ? (
          <Notes project={project} noteId={route.itemId} />
        ) : route.tab === "sketch" && route.itemId ? (
          <Sketches project={project} sketchId={route.itemId} />
        ) : (
          <Library project={project} fileId={route.tab === "library" ? route.itemId : undefined} />
        )}
      </main>

      {!immersive && <Dock project={project} route={route} />}
      <ChatPanel project={project} docked />
      <ProgressSheet project={project} open={route.tab === "progress"} onClose={() => navigate(projectPath(project.id), true)} />
      <EditProjectSheet project={project} open={editing} onClose={() => setEditing(false)} />
      <SearchSheet project={project} open={searching} onClose={() => setSearching(false)} />
    </div>
  );
}

function EditProjectSheet({ project, open, onClose }: { project: Project; open: boolean; onClose: () => void }) {
  const [name, setName] = useState(project.name);
  const [tag, setTag] = useState(project.tag);
  const [color, setColor] = useState(project.color);
  const [icon, setIcon] = useState<ProjectIcon | undefined>(project.icon);
  const wasOpen = useRef(false);
  // Reset the form only when the sheet opens, so live project updates never clobber unsaved edits.
  useEffect(() => {
    if (open && !wasOpen.current) {
      setName(project.name);
      setTag(project.tag);
      setColor(project.color);
      setIcon(project.icon);
    }
    wasOpen.current = open;
  }, [open, project]);

  const save = async () => {
    await db.projects.update(project.id, { name: name.trim() || project.name, tag: tag.trim(), color, icon, updatedAt: Date.now() });
    onClose();
  };
  const remove = async () => {
    if (!confirmDeletion(`Delete "${project.name}" and everything in it? This cannot be undone.`)) return;
    navigate("", true);
    await deleteProject(project.id);
  };
  return (
    <Sheet open={open} onClose={onClose} title="Project">
      <div className="space-y-5">
        <button
          onClick={() => {
            onClose();
            navigate(projectPath(project.id, "progress"));
          }}
          className="flex w-full items-center gap-3 rounded-2xl bg-ink/[0.035] p-3.5 text-left ring-1 ring-line transition-colors hover:bg-ink/[0.06]"
        >
          <TrendingUp size={18} className="text-muted" />
          <span className="flex-1 text-[14px] font-medium">Progress and knowledge map</span>
          <ChevronRight size={16} className="text-muted" />
        </button>
        <div>
          <span className="mb-1.5 block text-[12px] font-medium text-muted">Icon</span>
          <ProjectIconPicker value={icon} onChange={setIcon} color={color} tag={tag} />
        </div>
        <Field label="Topic">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Tag">
          <input className={inputCls} value={tag} onChange={(e) => setTag(e.target.value)} />
        </Field>
        <div>
          <span className="mb-1.5 block text-[12px] font-medium text-muted">Color</span>
          <div className="flex flex-wrap gap-2">
            {Object.entries(PROJECT_COLORS).map(([k, c]) => (
              <button
                key={k}
                type="button"
                onClick={() => setColor(k)}
                aria-label={c.name}
                aria-pressed={color === k}
                className={cn("h-9 w-9 rounded-full transition-transform", color === k ? "ring-2 ring-ink ring-offset-2 ring-offset-card" : "hover:scale-110")}
                style={{ background: c.hex }}
              />
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="lg" className="flex-1" onClick={() => void save()}>
            Save
          </Button>
          <Button size="lg" variant="danger" onClick={() => void remove()}>
            <Trash2 size={16} /> Delete
          </Button>
        </div>
      </div>
    </Sheet>
  );
}
