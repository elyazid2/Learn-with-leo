# Visual QA

`shoot.mjs` seeds a realistic project (notes, an AI note, concepts, points, and generated
PNG / PDF / WAV / WebM files uploaded through the real UI), screenshots every key screen in
light and dark at phone size, and writes contact sheets to `qa/out/` (git-ignored).

```bash
npm run build
npx vite preview --port 4173 &
node qa/shoot.mjs <prefix>      # e.g. node qa/shoot.mjs before
```

Needs a Chromium binary and `playwright-core`:

- `CHROME` — path to Chromium (default `/usr/bin/chromium`)
- `PW_CORE` — path to `playwright-core/index.mjs` (default `/tmp/pw/node_modules/playwright-core/index.mjs`)
- `QA_BASE` — app URL (default `http://localhost:4173/`)

Each navigation is a full reload, so settings changes (theme, developer mode) take effect.
The in-app avatar board lives at `#/dev/avatars` (Settings → Developer mode → Open avatar sheet).

## PDF reader probes

- `node qa/probe.mjs` — prints a realistic 12-page PDF (6 text pages + 6 high-res "scans") with
  Chromium, uploads it at phone size, scrolls through the reader and prints each page's state
  (`R` rendered, `q` queued, `-` released, `E` error). `ENGINE=webkit` needs a persistent profile
  for file storage, so for WebKit use the next script.
- `node qa/webkit-pdf.mjs` — same check in WebKit (Safari's engine) with a persistent profile.
  Install once with `node /tmp/pw/node_modules/playwright-core/cli.js install webkit`
  (and `sudo … install-deps webkit`).
