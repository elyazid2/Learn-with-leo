// Visual QA harness: seeds a realistic project, screenshots key screens (light + dark),
// and writes contact sheets. Not part of the app build.
//   npm run build && npx vite preview --port 4173 &
//   node qa/shoot.mjs <prefix>        (PW_CORE / CHROME env vars override defaults)
const { chromium } = await import(process.env.PW_CORE || "/tmp/pw/node_modules/playwright-core/index.mjs");
import fs from "fs";

const PREFIX = process.argv[2] || "shot";
const OUT = process.env.QA_OUT || new URL("./out", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const BASE = process.env.QA_BASE || "http://localhost:4173/";
const shots = {};
const log = (...a) => console.log("[qa]", ...a);

const browser = await chromium.launch({
  executablePath: process.env.CHROME || "/usr/bin/chromium",
  args: ["--no-sandbox", "--disable-gpu", "--autoplay-policy=no-user-gesture-required"],
});
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
await ctx.addInitScript(() => {
  if (!localStorage.getItem("harness.settings"))
    localStorage.setItem("harness.settings", JSON.stringify({ theme: "light", developerMode: false, mockDelay: 250, confirmDeletes: false }));
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push("PAGEERROR " + e.message));
page.on("console", (m) => m.type() === "error" && errors.push("CONSOLE " + m.text().slice(0, 200)));

let navCount = 0;
async function go(hash, wait = 900) {
  // Full reload each time (a hash-only goto would not re-read settings).
  await page.goto(`${BASE}?n=${++navCount}${hash}`, { waitUntil: "load" });
  await page.waitForTimeout(wait);
}
async function snap(name) {
  try {
    shots[name] = await page.screenshot({ type: "png" });
    log("shot", name);
  } catch (e) {
    log("shot failed", name, e.message);
  }
}
async function setSettings(patch) {
  await page.evaluate((p) => {
    const s = JSON.parse(localStorage.getItem("harness.settings") || "{}");
    localStorage.setItem("harness.settings", JSON.stringify({ ...s, ...p }));
  }, patch);
}

// ---------- seed ----------
await go("", 1200);
await page.evaluate(async () => {
  const now = Date.now();
  const day = 86400000;
  const put = (store, rows) =>
    new Promise((res, rej) => {
      const req = indexedDB.open("harness");
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction(store, "readwrite");
        rows.forEach((r) => tx.objectStore(store).put(r));
        tx.oncomplete = () => (db.close(), res());
        tx.onerror = () => rej(tx.error);
      };
      req.onerror = () => rej(req.error);
    });
  await put("providers", [{ id: "prov1", name: "OpenAI", type: "openai", baseUrl: "https://api.openai.com/v1", apiKey: "sk-test", models: ["gpt-4.1-mini"], defaultModel: "gpt-4.1-mini", createdAt: now }]);
  await put("projects", [
    { id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: now - 9 * day, updatedAt: now, placement: { status: "done", level: "Intermediate", summary: "Comfortable with matrix arithmetic and systems; shaky on eigenvectors and change of basis.", startingPoint: "Eigenvalues and diagonalization, building on solid matrix arithmetic.", at: now - 8 * day } },
    { id: "p2", name: "Japanese", tag: "Language", color: "rose", icon: { kind: "emoji", emoji: "🗾" }, createdAt: now - 20 * day, updatedAt: now - 2 * day, placement: { status: "pending" } },
    { id: "p3", name: "Rust", tag: "Code", color: "amber", icon: { kind: "image", src: (() => { const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d"); g.fillStyle = "#b7410e"; g.beginPath(); g.arc(128, 128, 104, 0, 7); g.fill(); g.fillStyle = "#fff"; g.font = "bold 132px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText("R", 128, 138); return c.toDataURL("image/png"); })() }, createdAt: now - 30 * day, updatedAt: now - 5 * day, placement: { status: "done", level: "Novice" } },
  ]);
  await put("notes", [
    { id: "n1", projectId: "p1", title: "Eigenvectors — the intuition", author: "user", createdAt: now - 3 * day, updatedAt: now - 3600000,
      content: "## Core idea\nAn eigenvector keeps its direction when a matrix acts on it — it only gets **scaled** by $\\lambda$.\n\n$$A\\mathbf{v} = \\lambda \\mathbf{v}$$\n\n- Find $\\lambda$ from $\\det(A - \\lambda I) = 0$\n- Plug each $\\lambda$ back in and solve for $\\mathbf{v}$\n\n### To practise\n- [x] 2×2 examples by hand\n- [ ] A 3×3 with a repeated eigenvalue\n- [ ] Explain why rotation matrices have complex eigenvalues\n\n> Geometric picture first, algebra second." },
    { id: "n2", projectId: "p1", title: "Diagonalization cheat sheet", author: "ai", createdAt: now - 2 * day, updatedAt: now - 2 * day,
      content: "A matrix is **diagonalizable** when it has $n$ linearly independent eigenvectors.\n\n| Step | What you do |\n|---|---|\n| 1 | Solve $\\det(A-\\lambda I)=0$ |\n| 2 | Find a basis of each eigenspace |\n| 3 | Build $P$ from eigenvectors, $D$ from eigenvalues |\n\nThen $A = PDP^{-1}$, so $A^k = PD^kP^{-1}$ — powers become cheap." },
  ]);
  await put("sketches", [{ id: "s1", projectId: "p1", title: "Shear vs. eigen-directions", scene: "", createdAt: now - 4 * day, updatedAt: now - 4 * day }]);
  const c = (id, name, status, parentId, extra = {}) => ({ id, projectId: "p1", name, parentId, status, correct: 0, attempts: 0, recent: [], interval: 0, createdAt: now, updatedAt: now, ...extra });
  await put("concepts", [
    c("c1", "Matrices", "solid"),
    c("c2", "Eigen-things", "learning"),
    c("c3", "Vector spaces", "learning"),
    c("c4", "Matrix multiplication", "solid", "c1", { attempts: 4, correct: 4, recent: [1, 1, 1, 1], nextReview: now - day, lastReviewed: now - 6 * day, interval: 4 }),
    c("c5", "Determinants", "solid", "c1", { attempts: 3, correct: 3, recent: [1, 1, 1], nextReview: now + 3 * day }),
    c("c6", "Inverse matrices", "shaky", "c1", { attempts: 3, correct: 1, recent: [0, 1, 0], nextReview: now - 3600000 }),
    c("c7", "Eigenvalues", "learning", "c2", { attempts: 2, correct: 1, recent: [1, 0] }),
    c("c8", "Eigenvectors", "shaky", "c2", { attempts: 2, correct: 0, recent: [0, 0] }),
    c("c9", "Diagonalization", "new", "c2"),
    c("c10", "Span", "solid", "c3", { attempts: 2, correct: 2, recent: [1, 1] }),
    c("c11", "Basis", "learning", "c3"),
    c("c12", "Change of basis", "new", "c3"),
  ]);
  const pt = (id, kind, text, author) => ({ id, projectId: "p1", kind, text, author, done: false, createdAt: now });
  await put("points", [
    pt("pt1", "careful", "Don't forget the minus sign in det(A − λI)", "ai"),
    pt("pt2", "confused", "Why does a repeated eigenvalue not always give two eigenvectors?", "user"),
    pt("pt3", "next", "Diagonalize a 3×3 matrix end to end", "ai"),
    pt("pt4", "next", "Connect eigenvectors to Markov chains", "user"),
  ]);
});

// ---------- upload generated files through the real UI ----------
await go("#/p/p1/library", 1200);
const uploaded = await page.evaluate(async () => {
  const files = [];
  const c = document.createElement("canvas");
  c.width = 640; c.height = 420;
  const g = c.getContext("2d");
  const grd = g.createLinearGradient(0, 0, 640, 420);
  grd.addColorStop(0, "#e9eefc"); grd.addColorStop(1, "#cfdcfb");
  g.fillStyle = grd; g.fillRect(0, 0, 640, 420);
  g.strokeStyle = "#3b74f0"; g.lineWidth = 6;
  g.beginPath(); g.moveTo(320, 380); g.lineTo(320, 40); g.moveTo(40, 210); g.lineTo(600, 210); g.stroke();
  g.strokeStyle = "#e2445c"; g.beginPath(); g.moveTo(320, 210); g.lineTo(520, 90); g.stroke();
  g.fillStyle = "#17171a"; g.font = "bold 28px sans-serif"; g.fillText("v -> Av = lv", 360, 330);
  files.push(new File([await new Promise((r) => c.toBlob(r, "image/png"))], "Eigen diagram.png", { type: "image/png" }));
  const pages = [
    ["Chapter 5: Eigenvalues", "", "Let A be an n x n matrix. A nonzero vector v is an", "eigenvector of A if Av = lambda v for some scalar lambda.", "", "The scalar lambda is called an eigenvalue of A."],
    ["5.2 The characteristic equation", "", "lambda is an eigenvalue of A if and only if", "det(A - lambda I) = 0.", "", "This polynomial equation is the characteristic equation."],
    ["5.3 Diagonalization", "", "A = P D P^-1 where D is diagonal.", "An n x n matrix is diagonalizable iff it has", "n linearly independent eigenvectors."],
  ];
  const objs = [];
  const kids = [];
  objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
  let n = 4;
  for (const lines of pages) {
    const stream = "BT /F1 22 Tf 72 720 Td " + lines.map((l, i) => (i ? "0 -30 Td " : "") + "(" + l.replace(/[()\\]/g, "\\$&") + ") Tj").join(" ") + " ET";
    objs[n] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
    objs[n + 1] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents ${n} 0 R /Resources << /Font << /F1 3 0 R >> >> >>`;
    kids.push(`${n + 1} 0 R`);
    n += 2;
  }
  objs[2] = `<< /Type /Pages /Kids [${kids.join(" ")}] /Count ${kids.length} >>`;
  let pdf = "%PDF-1.4\n";
  const offs = [];
  for (let i = 1; i < objs.length; i++) {
    offs[i] = pdf.length;
    pdf += `${i} 0 obj\n${objs[i]}\nendobj\n`;
  }
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length}\n0000000000 65535 f \n` + offs.slice(1).map((o) => String(o).padStart(10, "0") + " 00000 n \n").join("");
  pdf += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  files.push(new File([pdf], "Linear Algebra - Ch5 Eigenvalues.pdf", { type: "application/pdf" }));
  const sr = 8000, secs = 2.4, N = sr * secs;
  const buf = new ArrayBuffer(44 + N * 2);
  const dv = new DataView(buf);
  const w = (o, s) => [...s].forEach((ch, i) => dv.setUint8(o + i, ch.charCodeAt(0)));
  w(0, "RIFF"); dv.setUint32(4, 36 + N * 2, true); w(8, "WAVE"); w(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
  dv.setUint32(24, sr, true); dv.setUint32(28, sr * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, "data"); dv.setUint32(40, N * 2, true);
  for (let i = 0; i < N; i++) { const env = Math.abs(Math.sin((i / N) * Math.PI * 7)); dv.setInt16(44 + i * 2, Math.sin(i * 0.09) * 12000 * env, true); }
  files.push(new File([buf], "Recording - lecture recap.wav", { type: "audio/wav" }));
  try {
    const vc = document.createElement("canvas");
    vc.width = 480; vc.height = 270;
    const vg = vc.getContext("2d");
    const stream = vc.captureStream(30);
    const rec = new MediaRecorder(stream, { mimeType: "video/webm;codecs=vp8" });
    const chunks = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    let t = 0;
    const timer = setInterval(() => {
      t++;
      vg.fillStyle = "#101828"; vg.fillRect(0, 0, 480, 270);
      vg.strokeStyle = "#334155"; vg.lineWidth = 1;
      for (let x = 0; x < 480; x += 30) { vg.beginPath(); vg.moveTo(x, 0); vg.lineTo(x, 270); vg.stroke(); }
      vg.fillStyle = "#60a5fa"; vg.beginPath(); vg.arc(240 + Math.cos(t / 8) * 120, 135 + Math.sin(t / 8) * 70, 18, 0, 7); vg.fill();
      vg.fillStyle = "#fff"; vg.font = "bold 22px sans-serif"; vg.fillText("Lecture 7 - Rotations", 20, 40);
    }, 33);
    rec.start(100);
    await new Promise((r) => setTimeout(r, 1800));
    rec.stop();
    await new Promise((r) => (rec.onstop = r));
    clearInterval(timer);
    files.push(new File([new Blob(chunks, { type: "video/webm" })], "Lecture 7 - rotations.webm", { type: "video/webm" }));
  } catch (e) {
    console.error("video gen failed", e);
  }
  const input = document.querySelector('input[type="file"]');
  if (!input) return "no input";
  const dt = new DataTransfer();
  files.forEach((f) => dt.items.add(f));
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return files.map((f) => `${f.name} ${f.size}`).join(" | ");
});
log("uploaded:", uploaded);
const ids = await page.evaluate(async () => {
  const all = () =>
    new Promise((res) => {
      const req = indexedDB.open("harness");
      req.onsuccess = () => {
        const db = req.result;
        const r = db.transaction("files").objectStore("files").getAll();
        r.onsuccess = () => (db.close(), res(r.result.map((f) => ({ id: f.id, kind: f.kind, thumb: !!f.thumb, dur: f.duration }))));
      };
    });
  for (let i = 0; i < 40; i++) {
    const f = await all();
    if (f.length >= 4) return f;
    await new Promise((r) => setTimeout(r, 500));
  }
  return all();
});
log("files:", JSON.stringify(ids));
const fileId = (k) => ids.find((f) => f.kind === k)?.id;

// ---------- screens ----------
await go("", 900); await snap("home");
await go("#/p/p1/library", 1400); await snap("library");
try {
  await page.getByRole("button", { name: /^\+?\s*add( to library)?$/i }).first().click({ timeout: 3000 });
  await page.waitForTimeout(500);
  await snap("add-sheet");
  await page.keyboard.press("Escape");
} catch (e) { log("add sheet failed", e.message); }
await go("#/p/p2/library", 1200); await snap("library-unplaced");
await go("#/p/p1/library", 1000);
try {
  await page.locator('button[aria-label="Search this project"]').click({ timeout: 3000 });
  await page.waitForTimeout(600); await snap("search-empty");
  await page.keyboard.type("eigen");
  await page.waitForTimeout(900); await snap("search-results");
  await page.keyboard.press("Escape");
} catch (e) { log("search failed", e.message); }
await go("#/p/p1/sketch/s1", 3800); await snap("sketch");
await go("", 900);
try {
  await page.getByRole("button", { name: /new project/i }).first().click({ timeout: 3000 });
  await page.waitForTimeout(500);
  await page.getByPlaceholder(/Linear algebra/i).fill("Organic chemistry");
  await page.getByRole("button", { name: "Science", exact: true }).click();
  await page.evaluate(() => { const el = [...document.querySelectorAll('[role="dialog"] *')].find((e) => e.scrollHeight > e.clientHeight + 20 && getComputedStyle(e).overflowY === "auto"); el?.scrollBy(0, 260); });
  await page.waitForTimeout(400); await snap("new-project");
  await page.keyboard.press("Escape");
} catch (e) { log("new project failed", e.message); }
await go("#/p/p1/notes/n1", 1200); await snap("note-edit");
await go("#/p/p1/notes/n2", 1400); await snap("note-read");
if (fileId("video")) { await go(`#/p/p1/library/${fileId("video")}`, 1600); await snap("video"); }
if (fileId("pdf")) {
  await go(`#/p/p1/library/${fileId("pdf")}`, 2200); await snap("pdf");
  await page.evaluate(() => {
    const els = [...document.querySelectorAll("main *")].filter((e) => e.scrollHeight > e.clientHeight + 40 && getComputedStyle(e).overflowY !== "visible");
    (els[els.length - 1] || document.querySelector("main"))?.scrollBy(0, 700);
  });
  await page.waitForTimeout(1200); await snap("pdf-scrolled");
}
if (fileId("audio")) { await go(`#/p/p1/library/${fileId("audio")}`, 1200); await snap("audio"); }
await go("#/p/p1/progress", 1400); await snap("progress");

await go("#/dev/avatars", 1400); await snap("avatars");
await go("#/settings", 1000); await snap("settings");
await page.evaluate(() => [...document.querySelectorAll("h2")].find((h) => /Agent avatar/.test(h.textContent || ""))?.scrollIntoView());
await page.waitForTimeout(500); await snap("settings-avatar");

await setSettings({ developerMode: true });
await go("#/p/p1/library", 1200);
try {
  await page.locator('button[aria-label^="Open Leo"]').first().click({ timeout: 3000 });
  await page.waitForTimeout(500);
  const ta = page.locator("[data-chat-panel] textarea").first();
  await ta.fill("Test me on eigenvalues");
  await ta.press("Enter");
  await page.waitForSelector("text=Quiz", { timeout: 12000 });
  await page.waitForTimeout(800);
  await snap("chat");
} catch (e) { log("chat failed", e.message); await snap("chat"); }
await setSettings({ developerMode: false });

await setSettings({ theme: "dark" });
await go("#/p/p1/library", 1400); await snap("dark-library");
await go("#/p/p1/notes/n1", 1200); await snap("dark-note-edit");
await go("#/p/p1/notes/n2", 1200); await snap("dark-note-read");
await go("#/p/p1/progress", 1400); await snap("dark-progress");
if (fileId("pdf")) { await go(`#/p/p1/library/${fileId("pdf")}`, 2000); await snap("dark-pdf"); }
if (fileId("audio")) {
  await go(`#/p/p1/library/${fileId("audio")}`, 1200);
  try { await page.locator('button[aria-label="Play"]').click({ timeout: 3000 }); await page.waitForTimeout(1300); } catch (e) { log("play failed", e.message); }
  await snap("dark-audio-playing");
}
await go("#/p/p1/sketch/s1", 3800); await snap("dark-sketch");
await setSettings({ theme: "light" });

async function sheet(name, keys) {
  const tiles = keys.filter((k) => shots[k]).map((k) => `<figure><img src="data:image/png;base64,${shots[k].toString("base64")}"><figcaption>${k}</figcaption></figure>`);
  if (!tiles.length) return;
  const p = await ctx.newPage();
  await p.setViewportSize({ width: 1240, height: 900 });
  await p.setContent(`<style>body{margin:0;padding:12px;background:#888;font:600 15px system-ui;display:grid;grid-template-columns:repeat(3,390px);gap:12px}figure{margin:0}img{width:390px;display:block;border-radius:6px}figcaption{padding:4px 2px;color:#fff}</style>${tiles.join("")}`);
  await p.waitForTimeout(300);
  await p.screenshot({ path: `${OUT}/${PREFIX}-${name}.png`, fullPage: true, scale: "css" });
  await p.close();
  log("sheet", `${OUT}/${PREFIX}-${name}.png`);
}
await sheet("1-core", ["home", "library", "library-unplaced", "chat", "search-empty", "search-results"]);
await sheet("2-media", ["sketch", "new-project", "pdf", "pdf-scrolled", "audio", "progress"]);
await sheet("3-dark", ["dark-library", "dark-audio-playing", "dark-sketch", "dark-note-read", "dark-pdf", "note-edit"]);
await sheet("4-settings", ["settings", "settings-avatar", "avatars"]);
for (const [k, v] of Object.entries(shots)) fs.writeFileSync(`${OUT}/${PREFIX}-tile-${k}.png`, v);
log("errors:", errors.length ? errors.slice(0, 12).join("\n") : "none");
await browser.close();
