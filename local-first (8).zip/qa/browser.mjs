const { chromium } = await import("/tmp/pw/node_modules/playwright-core/index.mjs");
import fs from "fs";
const OUT = new URL("./out", import.meta.url).pathname;
const shots = {}; const errors = [];
const b = await chromium.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox", "--disable-gpu"] });
const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
await ctx.addInitScript(() => { if (!localStorage.getItem("harness.settings")) localStorage.setItem("harness.settings", JSON.stringify({ theme: "light", confirmDeletes: false })); });
const p = await ctx.newPage();
p.on("pageerror", (e) => errors.push("PAGEERROR " + e.message));
p.on("console", (m) => m.type() === "error" && errors.push("CONSOLE " + m.text().slice(0, 140)));

const ARTICLE = `<!doctype html><html><head><title>Eigenvalues and eigenvectors</title></head><body>
<nav>Home About Contact</nav><article><h1>Eigenvalues and eigenvectors</h1>
<p>In linear algebra, an eigenvector of a linear transformation is a nonzero vector that changes at most by a scalar factor when that transformation is applied to it. The corresponding eigenvalue is the factor by which the eigenvector is scaled.</p>
<p>Geometrically, an eigenvector points in a direction in which it is stretched by the transformation, and the eigenvalue is the factor by which it is stretched. If the eigenvalue is negative, the direction is reversed.</p>
<p>The characteristic polynomial det(A − λI) = 0 gives the eigenvalues. Eigenvalues and eigenvectors give a great deal of information about a linear transformation, and studying them is the essence of linear algebra.</p>
<p>Applications include stability analysis, vibration analysis, atomic orbitals, facial recognition and matrix diagonalization.</p>
<a href="https://study.test/wiki/Determinant">Determinant</a> <a href="https://study.test/wiki/Matrix">Matrix</a>
</article><aside>Buy now</aside></body></html>`;

await p.route("https://study.test/**", (r) => r.fulfill({ status: 200, contentType: "text/html; charset=utf-8", headers: { "access-control-allow-origin": "*" }, body: ARTICLE }));
await p.route("https://blocked.test/**", (r) => r.abort("failed"));

let n = 0;
const go = async (h, w = 1200) => { await p.goto(`http://localhost:4173/?b=${++n}${h}`, { waitUntil: "load" }); await p.waitForTimeout(w); };
const snap = async (k) => { shots[k] = await p.screenshot({ type: "png" }); console.log("[b]", k); };

await go("", 1200);
await p.evaluate(() => new Promise((res) => {
  const r = indexedDB.open("harness");
  r.onsuccess = () => {
    const tx = r.result.transaction(["projects", "providers"], "readwrite");
    tx.objectStore("projects").put({ id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: 1, updatedAt: 2, placement: { status: "done", level: "Intermediate" } });
    tx.objectStore("providers").put({ id: "pr", name: "Anthropic", type: "anthropic", baseUrl: "https://api.anthropic.com", apiKey: "k", catalogModels: ["claude-opus-4-5", "claude-sonnet-4-5", "claude-haiku-4-5"], models: ["claude-opus-4-5"], defaultModel: "claude-opus-4-5", createdAt: 1 });
    tx.oncomplete = () => { r.result.close(); res(); };
  };
}));

await go("#/p/p1/library", 1200);
await p.getByRole("button", { name: /open learning browser/i }).click({ force: true });
await p.waitForTimeout(400);
await snap("browser-empty");
await p.getByLabel("Website address").fill("https://study.test/wiki/Eigenvalues");
await p.getByRole("button", { name: /^Go$/ }).click();
await p.waitForTimeout(1500);
await snap("browser-reader");
const readOk = await p.getByText("eigenvector of a linear transformation").isVisible().catch(() => false);
const sharedOk = await p.getByText("Shared with Leo").isVisible().catch(() => false);
console.log("[check] reader text:", readOk, "shared:", sharedOk);
await p.getByRole("button", { name: "Determinant", exact: true }).click({ force: true });
await p.waitForTimeout(1200);
await snap("browser-link");
await p.getByRole("button", { name: "Back", exact: true }).click({ force: true });
await p.waitForTimeout(1200);
await snap("browser-back");
await p.getByLabel("Website address").fill("https://blocked.test/page");
await p.getByRole("button", { name: /^Go$/ }).click();
await p.waitForTimeout(1500);
await snap("browser-blocked");
await p.getByRole("button", { name: /Add-ons/ }).click();
await p.waitForTimeout(400);
await snap("browser-addons");
await p.getByRole("button", { name: /Close browser/i }).click({ force: true });
await p.waitForTimeout(500);

// Leo can see the captured page as chat context
await p.locator('button[aria-label^="Open Leo"]').first().click({ force: true });
await p.waitForTimeout(900);
await snap("chat-browser-chip");

// Settings default-model sheet
await go("#/settings", 1400);
await p.evaluate(() => window.scrollTo(0, 900));
await p.waitForTimeout(300);
await p.getByRole("button", { name: /Opus 4.5 brain|Choose a model/ }).first().click({ force: true });
await p.waitForTimeout(500);
await snap("settings-default-sheet");

async function sheet(name, keys) {
  const tiles = keys.filter((k) => shots[k]).map((k) => `<figure><img src="data:image/png;base64,${shots[k].toString("base64")}"><figcaption>${k}</figcaption></figure>`);
  const q = await ctx.newPage();
  await q.setViewportSize({ width: 1240, height: 900 });
  await q.setContent(`<style>body{margin:0;padding:12px;background:#888;font:600 14px system-ui;display:grid;grid-template-columns:repeat(3,390px);gap:12px}figure{margin:0}img{width:390px;display:block;border-radius:6px}figcaption{padding:4px;color:#fff}</style>${tiles.join("")}`);
  await q.waitForTimeout(250);
  await q.screenshot({ path: `${OUT}/${name}.png`, fullPage: true });
  await q.close(); console.log("[sheet]", name);
}
await sheet("browser-sheet-1", ["browser-empty", "browser-reader", "browser-link", "browser-back", "browser-blocked", "browser-addons"]);
await sheet("browser-sheet-2", ["chat-browser-chip", "settings-default-sheet"]);
console.log("[errors]", errors.length ? errors.slice(0, 8).join("\n") : "none");
await b.close();
