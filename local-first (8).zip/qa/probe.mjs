// Probe: realistic multi-page PDF (printed by Chromium, with large "scanned" JPEG pages) in the
// PDF reader at phone size, plus the sketch screen. Not part of the app build.
const pw = await import(process.env.PW_CORE || "/tmp/pw/node_modules/playwright-core/index.mjs");
const { chromium } = pw;
const ENGINE = process.env.ENGINE || "chromium";
import fs from "fs";

const OUT = new URL("./out", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const BASE = process.env.QA_BASE || "http://localhost:4173/";
const browser = await chromium.launch({ executablePath: process.env.CHROME || "/usr/bin/chromium", args: ["--no-sandbox", "--disable-gpu"] });

// 1) Build a realistic PDF: 6 text pages + 6 full-page high-res "scans" (Chromium can print; reuse if present).
let pdfBuffer;
if (fs.existsSync(`${OUT}/probe.pdf`)) pdfBuffer = fs.readFileSync(`${OUT}/probe.pdf`);
else {
const maker = await browser.newPage();
await maker.setContent(`<html><body style="margin:0;font:15px Georgia,serif;color:#222"></body></html>`);
await maker.evaluate(() => {
  const body = document.body;
  for (let i = 1; i <= 12; i++) {
    const sec = document.createElement("section");
    sec.style.cssText = "page-break-after:always;padding:48px 56px;height:1000px;box-sizing:border-box";
    if (i <= 6) {
      sec.innerHTML = `<h1 style="font:700 28px system-ui">Chapter ${i}: Eigen-ideas, part ${i}</h1>` +
        Array.from({ length: 9 }, (_, k) => `<p>Paragraph ${k + 1} of chapter ${i}. A nonzero vector v is an eigenvector of A when Av = λv. The characteristic polynomial det(A − λI) = 0 gives the eigenvalues; each eigenspace is the null space of A − λI. Diagonalization writes A = PDP⁻¹.</p>`).join("");
    } else {
      const c = document.createElement("canvas");
      c.width = 2480; c.height = 3300;
      const g = c.getContext("2d");
      g.fillStyle = "#f4f1e8"; g.fillRect(0, 0, c.width, c.height);
      for (let n = 0; n < 9000; n++) { g.fillStyle = `rgba(0,0,0,${Math.random() * 0.06})`; g.fillRect(Math.random() * c.width, Math.random() * c.height, 3, 3); }
      g.fillStyle = "#1d1d1d"; g.font = "bold 120px serif"; g.fillText(`Scanned page ${i}`, 160, 320);
      g.font = "64px serif";
      for (let l = 0; l < 30; l++) g.fillText(`Handwritten-ish line ${l + 1}: λ₁ = 3, λ₂ = −1, v = (1, 2)ᵀ ...`, 160, 520 + l * 92);
      const img = document.createElement("img");
      img.src = c.toDataURL("image/jpeg", 0.92);
      img.style.cssText = "width:100%;display:block";
      sec.style.padding = "0";
      sec.appendChild(img);
    }
    body.appendChild(sec);
  }
});
await maker.waitForTimeout(500);
pdfBuffer = await maker.pdf({ format: "A4", printBackground: true });
fs.writeFileSync(`${OUT}/probe.pdf`, pdfBuffer);
await maker.close();
}
console.log("[probe] engine", ENGINE, "pdf bytes", pdfBuffer.length);
const appBrowser = ENGINE === "webkit" ? await pw.webkit.launch() : browser;

// 2) Phone context
const ctx = await appBrowser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 3,
  isMobile: true,
  hasTouch: true,
  userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
});
await ctx.addInitScript(() => localStorage.setItem("harness.settings", JSON.stringify({ theme: "light", confirmDeletes: false })));
const page = await ctx.newPage();
const logs = [];
page.on("console", (m) => (m.type() === "error" || m.type() === "warning") && logs.push(`${m.type()}: ${m.text().slice(0, 160)}`));
page.on("pageerror", (e) => logs.push("PAGEERROR " + e.message));
let n = 0;
const go = async (hash, wait = 1000) => {
  await page.goto(`${BASE}?p=${++n}${hash}`, { waitUntil: "load" });
  await page.waitForTimeout(wait);
};

await go("", 1200);
await page.evaluate(async () => {
  const put = (store, rows) =>
    new Promise((res, rej) => {
      const req = indexedDB.open("harness");
      req.onsuccess = () => {
        const tx = req.result.transaction(store, "readwrite");
        rows.forEach((r) => tx.objectStore(store).put(r));
        tx.oncomplete = () => (req.result.close(), res());
        tx.onerror = () => rej(tx.error);
      };
    });
  const now = Date.now();
  await put("projects", [{ id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: now, updatedAt: now, placement: { status: "pending" } }]);
  await put("sketches", [{ id: "s1", projectId: "p1", title: "Shear vs eigen-directions", scene: "", createdAt: now, updatedAt: now }]);
});
await go("#/p/p1/library", 1500);
await page.screenshot({ path: `${OUT}/probe-${ENGINE}-library.png` });
await page.setInputFiles('input[type="file"]', { name: "Textbook - Chapter 5.pdf", mimeType: "application/pdf", buffer: pdfBuffer });
let fileId = null;
for (let i = 0; i < 60 && !fileId; i++) {
  await page.waitForTimeout(500);
  fileId = await page.evaluate(
    () =>
      new Promise((res) => {
        const req = indexedDB.open("harness");
        req.onsuccess = () => {
          const r = req.result.transaction("files").objectStore("files").getAll();
          r.onsuccess = () => (req.result.close(), res(r.result.find((f) => f.kind === "pdf")?.id ?? null));
        };
      })
  );
}
console.log("[probe] file", fileId);

const report = async (label) => {
  const r = await page.evaluate(() =>
    [...document.querySelectorAll("[data-page]")].map((el) => {
      const c = el.querySelector("canvas");
      const st = el.getAttribute("data-state") || "";
      return `${el.getAttribute("data-page")}:${st === "rendered" ? "R" : st === "error" ? "E" : st === "idle" ? "-" : "q"}`;
    }).join(" ")
  );
  console.log(`[probe] ${label}: ${r}`);
};
await go(`#/p/p1/library/${fileId}`, 3000);
await report("t=3s top");
await page.screenshot({ path: `${OUT}/probe-${ENGINE}-pdf-0.png` });
for (let step = 1; step <= 8; step++) {
  await page.evaluate(() => {
    const sc = document.querySelector("[data-pdf-scroller]") || [...document.querySelectorAll("main *")].find((e) => e.scrollHeight > e.clientHeight + 40 && /auto|scroll/.test(getComputedStyle(e).overflowY));
    sc?.scrollBy(0, 1300);
  });
  await page.waitForTimeout(1600);
  await report(`after scroll ${step}`);
  if (step === 1 || step === 3) await page.screenshot({ path: `${OUT}/probe-${ENGINE}-pdf-${step}.png` });
}

await go("#/p/p1/sketch/s1", 3500);
await page.screenshot({ path: `${OUT}/probe-${ENGINE}-sketch.png` });
console.log("[probe] console:\n" + (logs.filter((l) => !l.includes("esm.sh")).slice(0, 25).join("\n") || "none"));
if (appBrowser !== browser) await appBrowser.close();
await browser.close();
