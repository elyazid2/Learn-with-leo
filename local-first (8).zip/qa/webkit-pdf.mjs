const pw = await import("/tmp/pw/node_modules/playwright-core/index.mjs");
import fs from "fs";
const OUT = new URL("./out", import.meta.url).pathname;
import os from "os";
const dir = fs.mkdtempSync(os.tmpdir() + "/wkprofile-");
const ctx = await pw.webkit.launchPersistentContext(dir, { viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
const b = { close: () => ctx.close() };
const page = await ctx.newPage();
page.on("console", (m) => console.log(`[${m.type()}] ${m.text().slice(0, 300)}`));
page.on("pageerror", (e) => console.log("[pageerror]", e.message, e.stack?.slice(0, 400)));
await page.goto("http://localhost:4173/?wk=1", { waitUntil: "load" });
await page.waitForTimeout(1500);
const seeded = await page.evaluate(() => new Promise((res) => {
  const req = indexedDB.open("harness");
  req.onsuccess = () => { const db = req.result; res({ v: db.version, stores: [...db.objectStoreNames] }); db.close(); };
  req.onerror = () => res({ err: String(req.error) });
}));
console.log("[db]", JSON.stringify(seeded));
await page.evaluate(() => new Promise((res) => {
  const req = indexedDB.open("harness");
  req.onsuccess = () => { const tx = req.result.transaction("projects", "readwrite"); tx.objectStore("projects").put({ id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: Date.now(), updatedAt: Date.now(), placement: { status: "pending" } }); tx.oncomplete = () => { req.result.close(); res(); }; };
}));
await page.goto("http://localhost:4173/?wk=2#/p/p1/library", { waitUntil: "load" });
await page.waitForTimeout(1500);
const buf = fs.readFileSync(`${OUT}/probe.pdf`);
await page.setInputFiles('input[type="file"]', { name: "Textbook.pdf", mimeType: "application/pdf", buffer: buf });
await page.waitForTimeout(900);
await page.screenshot({ path: `${OUT}/wk-upload-1s.png` });
await page.waitForTimeout(11000);
await page.screenshot({ path: `${OUT}/wk-after-upload.png` });
const files = await page.evaluate(() => new Promise((res) => {
  const req = indexedDB.open("harness");
  req.onsuccess = () => { const r = req.result.transaction("files").objectStore("files").getAll(); r.onsuccess = () => { res(r.result.map((f) => ({ kind: f.kind, thumb: !!f.thumb, pages: f.pages, indexed: f.indexed }))); req.result.close(); }; };
}));
console.log("[files]", JSON.stringify(files));
const id = await page.evaluate(() => new Promise((res) => { const req = indexedDB.open("harness"); req.onsuccess = () => { const r = req.result.transaction("files").objectStore("files").getAll(); r.onsuccess = () => { res(r.result[0]?.id); req.result.close(); }; }; }));
if (id) {
  await page.goto(`http://localhost:4173/?wk=3#/p/p1/library/${id}`, { waitUntil: "load" });
  const rep = async (label) => console.log("[pdf]", label, await page.evaluate(() => [...document.querySelectorAll("[data-page]")].map((el) => { const st = el.getAttribute("data-state") || ""; return el.getAttribute("data-page") + ":" + (st === "rendered" ? "R" : st === "error" ? "E" : st === "idle" ? "-" : "q"); }).join(" ")));
  await page.waitForTimeout(4000); await rep("top");
  await page.screenshot({ path: `${OUT}/wk-pdf-top.png` });
  for (let i = 1; i <= 4; i++) {
    await page.evaluate(() => { const sc = [...document.querySelectorAll("main *")].find((e) => e.scrollHeight > e.clientHeight + 40 && /auto|scroll/.test(getComputedStyle(e).overflowY)); sc?.scrollBy(0, 1300); });
    await page.waitForTimeout(2500); await rep("scroll " + i);
    if (i === 1) await page.screenshot({ path: `${OUT}/wk-pdf-scroll1.png` });
  }
}
await b.close();
