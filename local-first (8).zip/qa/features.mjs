// Focused visual QA for: model label/picker, @mentions, memory, browser/add-ons, new orb states.
const { chromium } = await import(process.env.PW_CORE || "/tmp/pw/node_modules/playwright-core/index.mjs");
import fs from "fs";
const OUT = new URL("./out", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const BASE = "http://localhost:4173/";
const shots = {};
const errors = [];
const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox", "--disable-gpu", "--autoplay-policy=no-user-gesture-required"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
await ctx.addInitScript(() => {
  if (!localStorage.getItem("harness.settings"))
    localStorage.setItem("harness.settings", JSON.stringify({ theme: "light", confirmDeletes: false, developerMode: false }));
});
const page = await ctx.newPage();
page.on("pageerror", (e) => errors.push("PAGEERROR " + e.message));
page.on("console", (m) => m.type() === "error" && errors.push("CONSOLE " + m.text().slice(0, 160)));
let n = 0;
const go = async (hash, w = 1200) => { await page.goto(`${BASE}?f=${++n}${hash}`, { waitUntil: "load" }); await page.waitForTimeout(w); };
const snap = async (name) => { shots[name] = await page.screenshot({ type: "png" }); console.log("[f]", name); };

await go("", 1200);
await page.evaluate(async () => {
  const put = (store, rows) => new Promise((res, rej) => {
    const req = indexedDB.open("harness");
    req.onsuccess = () => { const tx = req.result.transaction(store, "readwrite"); rows.forEach((r) => tx.objectStore(store).put(r)); tx.oncomplete = () => { req.result.close(); res(); }; tx.onerror = () => rej(tx.error); };
  });
  const now = Date.now();
  await put("providers", [
    { id: "pr-an", name: "Anthropic", type: "anthropic", baseUrl: "https://api.anthropic.com", apiKey: "sk-ant-test", catalogModels: ["claude-opus-4-5-20251001", "claude-sonnet-4-5-20250929", "claude-haiku-4-5"], models: ["claude-opus-4-5-20251001", "claude-haiku-4-5"], defaultModel: "claude-opus-4-5-20251001", createdAt: now },
    { id: "pr-gm", name: "Google Gemini", type: "gemini", baseUrl: "https://generativelanguage.googleapis.com", apiKey: "AIza-test", catalogModels: ["gemini-2.5-pro", "gemini-2.5-flash"], models: ["gemini-2.5-flash"], defaultModel: "gemini-2.5-flash", createdAt: now + 1 },
  ]);
  await put("projects", [{ id: "p1", name: "Linear Algebra", tag: "Math", color: "blue", createdAt: now, updatedAt: now, placement: { status: "done", level: "Intermediate" } }]);
  await put("notes", [{ id: "n1", projectId: "p1", title: "Eigenvectors", content: "An eigenvector keeps direction. $Av = \\lambda v$.", author: "user", createdAt: now, updatedAt: now }]);
  await put("memories", [
    { id: "m1", projectId: "*", kind: "goal", text: "Wants to pass the linear algebra exam in June", createdAt: now, updatedAt: now },
    { id: "m2", projectId: "*", kind: "preference", text: "Prefers worked examples before formal proofs", createdAt: now - 1000, updatedAt: now - 1000 },
    { id: "m3", projectId: "p1", kind: "weakness", text: "Loses track of the minus sign in det(A − λI)", createdAt: now - 2000, updatedAt: now - 2000 },
  ]);
  await put("kv", [{ key: "browser.current", value: { url: "https://en.wikipedia.org/wiki/Eigenvalues_and_eigenvectors", title: "Eigenvalues and eigenvectors" } }]);
});
await go("#/p/p1/library", 1200);
await page.evaluate(async () => {
  const c = document.createElement("canvas"); c.width = 640; c.height = 420; const g = c.getContext("2d");
  g.fillStyle = "#eef2ff"; g.fillRect(0, 0, 640, 420); g.strokeStyle = "#2f66e0"; g.lineWidth = 5;
  g.beginPath(); g.moveTo(320, 380); g.lineTo(320, 40); g.moveTo(40, 210); g.lineTo(600, 210); g.stroke();
  g.fillStyle = "#17171a"; g.font = "bold 28px sans-serif"; g.fillText("v -> Av = λv", 350, 340);
  const png = await new Promise((r) => c.toBlob(r, "image/png"));
  const pages = [["Chapter 5 Eigenvalues"], ["5.2 Characteristic equation"], ["5.3 Diagonalization"]];
  const objs = [], kids = []; objs[1] = "<< /Type /Catalog /Pages 2 0 R >>"; objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
  let i = 4;
  for (const [title] of pages) {
    const stream = `BT /F1 24 Tf 72 720 Td (${title}) Tj 0 -36 Td (Av = lambda v for eigenvectors.) Tj ET`;
    objs[i] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
    objs[i + 1] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents ${i} 0 R /Resources << /Font << /F1 3 0 R >> >> >>`;
    kids.push(`${i + 1} 0 R`); i += 2;
  }
  objs[2] = `<< /Type /Pages /Kids [${kids.join(" ")}] /Count ${kids.length} >>`;
  let pdf = "%PDF-1.4\n"; const offs = [];
  for (let k = 1; k < objs.length; k++) { offs[k] = pdf.length; pdf += `${k} 0 obj\n${objs[k]}\nendobj\n`; }
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length}\n0000000000 65535 f \n` + offs.slice(1).map((o) => String(o).padStart(10, "0") + " 00000 n \n").join("");
  pdf += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  // 8s WAV voice note
  const sr = 8000, N = sr * 8, buf = new ArrayBuffer(44 + N * 2), dv = new DataView(buf);
  const w = (o, s) => [...s].forEach((ch, j) => dv.setUint8(o + j, ch.charCodeAt(0)));
  w(0, "RIFF"); dv.setUint32(4, 36 + N * 2, true); w(8, "WAVE"); w(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true); dv.setUint32(24, sr, true); dv.setUint32(28, sr * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, "data"); dv.setUint32(40, N * 2, true);
  for (let j = 0; j < N; j++) dv.setInt16(44 + j * 2, Math.sin(j * 0.09) * 12000 * Math.abs(Math.sin((j / N) * Math.PI * 5)), true);
  const files = [
    new File([pdf], "Linear Algebra - Ch5.pdf", { type: "application/pdf" }),
    new File([png], "Eigen diagram.png", { type: "image/png" }),
    new File([buf], "Lecture recap.wav", { type: "audio/wav" }),
  ];
  const input = document.querySelector('input[type="file"]');
  const dt = new DataTransfer(); files.forEach((f) => dt.items.add(f)); input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
});
await page.waitForTimeout(6000);
await go("#/p/p1/library", 1400);
await snap("library");

// Chat + model label + picker
await go("#/p/p1/library", 1000);
await page.locator('button[aria-label^="Open Leo"]').first().click();
await page.waitForTimeout(800);
await snap("chat-header");
await page.getByRole("button", { name: /choose model/i }).click({ force: true }).catch((e) => console.log("model click", e.message.slice(0,80)));
await page.waitForTimeout(500);
await snap("model-picker");
await page.locator('[role="dialog"]').getByRole("button", { name: /Haiku 4\.5 brain/ }).click({ force: true });
await page.waitForTimeout(900);
await snap("model-changed");
await page.getByRole("button", { name: /choose model/i }).click({ force: true });
await page.waitForTimeout(400);
await page.locator('[role="dialog"]').getByRole("button", { name: /Opus 4\.5 brain/ }).first().click({ force: true });
await page.waitForTimeout(900);
await snap("chat-after-model");

// Mentions: PDF page then a precise audio segment (scoped to the picker dialog)
const ta = page.locator("[data-chat-panel] textarea").first();
const picker = page.getByRole("dialog", { name: "Mention a library file" });
await ta.fill("Explain @");
await picker.waitFor();
await snap("mention-list");
await picker.getByRole("button", { name: /Linear Algebra - Ch5/ }).click();
await picker.getByText("Only this page is sent").waitFor();
await picker.getByLabel("Page", { exact: false }).fill("2").catch(() => {});
await snap("mention-page");
await picker.getByRole("button", { name: /Attach page/i }).click();
await page.waitForTimeout(500);
await snap("mention-page-attached");
await ta.fill("Quiz me on @");
await picker.waitFor();
await picker.getByRole("button", { name: /Lecture recap/ }).click();
await picker.getByText("Choose the exact segment").waitFor();
await page.waitForTimeout(300);
await snap("mention-audio");
await picker.getByRole("button", { name: /^Attach \d/i }).click();
await page.waitForTimeout(500);
await snap("mention-audio-attached");

// Memory screen
await go("#/memories", 1200);
await snap("memories");
await page.getByRole("button", { name: /^Add$/ }).first().click({ force: true }).catch(() => {});
await page.waitForTimeout(500);
await snap("memory-editor");

// Browser + add-ons
await go("#/p/p1/library", 1000);
await page.getByRole("button", { name: /open learning browser/i }).click();
await page.waitForTimeout(700);
await snap("browser");
await page.getByRole("button", { name: /Add-ons/ }).click({ force: true }).catch((e) => console.log("addons click", e.message.slice(0,80)));
await page.waitForTimeout(400);
await snap("browser-addons");

// Avatar states
await go("#/dev/avatars", 1400);
await snap("avatars");

// Dark model label/picker and memory
await page.evaluate(() => { const s = JSON.parse(localStorage.getItem("harness.settings") || "{}"); localStorage.setItem("harness.settings", JSON.stringify({ ...s, theme: "dark" })); });
await go("#/p/p1/library", 1200);
if (!(await page.evaluate(() => document.documentElement.classList.contains("dark")))) console.log("[warn] dark class missing");
await snap("dark-library");
await page.locator('button[aria-label^="Open Leo"]').first().click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /choose model/i }).click({ force: true }).catch((e) => console.log("model click", e.message.slice(0,80)));
await page.waitForTimeout(500);
await snap("dark-model-picker");
await page.keyboard.press("Escape");
await go("#/memories", 1000);
await snap("dark-memories");

async function sheet(name, keys) {
  const tiles = keys.filter((k) => shots[k]).map((k) => `<figure><img src="data:image/png;base64,${shots[k].toString("base64")}"><figcaption>${k}</figcaption></figure>`);
  const p = await ctx.newPage();
  await p.setViewportSize({ width: 1240, height: 900 });
  await p.setContent(`<style>body{margin:0;padding:12px;background:#888;font:600 14px system-ui;display:grid;grid-template-columns:repeat(3,390px);gap:12px}figure{margin:0}img{width:390px;display:block;border-radius:6px}figcaption{padding:4px;color:#fff}</style>${tiles.join("")}`);
  await p.waitForTimeout(250);
  await p.screenshot({ path: `${OUT}/${name}.png`, fullPage: true });
  await p.close();
  console.log("[sheet]", name);
}
await sheet("feature-sheet-1", ["chat-header", "model-picker", "model-changed", "mention-list", "mention-page", "mention-audio"]);
await sheet("feature-sheet-2", ["mention-page-attached", "mention-audio-attached", "memories", "memory-editor", "browser-addons", "avatars"]);
console.log("[errors]", errors.length ? errors.slice(0, 10).join("\n") : "none");
await browser.close();
