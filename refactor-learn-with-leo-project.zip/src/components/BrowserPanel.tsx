import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft, ArrowRight, ArrowUpRight, BookmarkPlus, ExternalLink, Globe2, Loader2,
  Plus, Puzzle, RefreshCw, Sparkles, Trash2, X,
} from "lucide-react";
import { db, getKV, setKV, uid } from "@/lib/db";
import { useApp } from "@/lib/store";
import { Button, Field, IconBtn, inputCls } from "@/components/ui";
import { cn } from "@/utils/cn";

/**
 * Engine choice: Harness is a web app, so the lightest engine that supports extensions is the one
 * already running it — a system WebView/browser frame. Pages are fetched by the Harness server and
 * rendered in a sandboxed iframe (opaque origin, no access to your keys or library), and add-ons are
 * injected as content scripts/CSS, the same model as WebView user-script injection. No Chromium
 * bundle, no GeckoView — real WebExtensions aren't needed for learning-focused tweaks.
 */

export interface Addon {
  id: string;
  name: string;
  description: string;
  hosts: string;
  css: string;
  code: string;
  enabled: boolean;
  builtin?: boolean;
}

const BUILTINS: Addon[] = [
  {
    id: "youtube-focus",
    name: "YouTube Focus",
    description: "Hides Shorts, recommendations, comments and end screens. Video links play in a clean, distraction-free player.",
    hosts: "youtube.com, youtu.be",
    css: "ytd-rich-shelf-renderer,ytd-reel-shelf-renderer,ytd-watch-next-secondary-results-renderer,#secondary,#related,#comments,ytm-reel-shelf-renderer,ytm-item-section-renderer[section-identifier=related-items],a[href^='/shorts'],.ytp-endscreen-content,ytd-browse[page-subtype=home] #contents{display:none!important}",
    code: "",
    enabled: true,
    builtin: true,
  },
  {
    id: "quiet-article",
    name: "Quiet article",
    description: "Removes sidebars, sticky banners, cookie bars and comments; narrows text to a comfortable reading width.",
    hosts: "*",
    css: "aside,[role=complementary],.sidebar,.comments,#comments,.newsletter,[class*=cookie],[id*=cookie],[class*=banner]{display:none!important}body{max-width:74ch!important;margin:0 auto!important;line-height:1.65!important}",
    code: "",
    enabled: false,
    builtin: true,
  },
  {
    id: "dark-reader-lite",
    name: "Night reading",
    description: "Inverts bright pages for late-night study (images keep their colours).",
    hosts: "*",
    css: "html{filter:invert(.9) hue-rotate(180deg)!important;background:#111!important}img,video,picture,svg,iframe{filter:invert(1) hue-rotate(180deg)!important}",
    code: "",
    enabled: false,
    builtin: true,
  },
];

export function safeUrl(input: string) {
  const value = input.trim();
  if (!value) return null;
  if (!/[.:/]/.test(value) || /\s/.test(value)) return `https://duckduckgo.com/html/?q=${encodeURIComponent(value)}`;
  try {
    const u = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(value) ? value : `https://${value}`);
    return ["https:", "http:"].includes(u.protocol) ? u.href : null;
  } catch {
    return null;
  }
}

function youtubeId(url: string) {
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.split("/").filter(Boolean)[0] ?? null;
    if (!/(^|\.)youtube\.com$/.test(u.hostname)) return null;
    if (u.pathname === "/watch") return u.searchParams.get("v");
    return u.pathname.match(/^\/(?:embed|shorts|live)\/([^/?]+)/)?.[1] ?? null;
  } catch {
    return null;
  }
}

const hostMatches = (hosts: string, hostname: string) =>
  hosts.split(",").map((h) => h.trim().toLowerCase().replace(/^\*\./, "")).filter(Boolean)
    .some((h) => h === "*" || hostname === h || hostname.endsWith("." + h));

const hostOf = (u: string) => { try { return new URL(u).hostname; } catch { return ""; } };

export default function BrowserPanel() {
  const open = useApp((s) => s.browserOpen);
  const setOpen = useApp((s) => s.setBrowserOpen);
  const storeUrl = useApp((s) => s.browserUrl);
  const setStoreUrl = useApp((s) => s.setBrowserUrl);
  const setBrowser = useApp((s) => s.setBrowser);
  const page = useApp((s) => s.browser);

  const [address, setAddress] = useState("");
  const [current, setCurrent] = useState("");
  const [stack, setStack] = useState<string[]>([]);
  const [cursor, setCursor] = useState(-1);
  const [loading, setLoading] = useState(false);
  const [frameKey, setFrameKey] = useState(0);
  const [panel, setPanel] = useState<"none" | "addons">("none");
  const [addons, setAddons] = useState<Addon[]>(BUILTINS);
  const [form, setForm] = useState({ open: false, name: "", hosts: "", css: "", code: "" });
  const frame = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    void getKV<Addon[]>("browser.addons", BUILTINS).then((saved) => {
      if (!saved?.length) return;
      const merged = BUILTINS.map((b) => ({ ...b, enabled: saved.find((s) => s.id === b.id)?.enabled ?? b.enabled }));
      setAddons([...merged, ...saved.filter((s) => !s.builtin).map((s) => ({ ...s, css: s.css ?? "" }))]);
    });
  }, []);

  const go = useCallback((target: string, push = true) => {
    setCurrent(target);
    setAddress(target);
    setStoreUrl(target);
    setLoading(!youtubeId(target));
    setBrowser(null);
    setFrameKey((k) => k + 1);
    if (push) {
      setStack((s) => {
        const next = [...s.slice(0, cursorRef.current + 1), target];
        cursorRef.current = next.length - 1;
        setCursor(next.length - 1);
        return next;
      });
    }
  }, [setStoreUrl, setBrowser]);
  const cursorRef = useRef(-1);

  // Leo (or any other part of the app) points the browser somewhere by setting browserUrl.
  useEffect(() => {
    if (open && storeUrl && storeUrl !== current) go(storeUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, storeUrl]);

  const activeAddons = useCallback(
    (url: string) => addons.filter((a) => a.enabled && hostMatches(a.hosts, hostOf(url))).map((a) => ({ name: a.name, css: a.css, code: a.code })),
    [addons]
  );

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (!frame.current || e.source !== frame.current.contentWindow) return;
      const d = e.data as { __harness?: number; type?: string; url?: string; title?: string; text?: string; selection?: string; name?: string };
      if (!d?.__harness) return;
      if (d.type === "ready") {
        setLoading(false);
        frame.current.contentWindow?.postMessage({ __harnessShell: 1, type: "addons", addons: activeAddons(current) }, "*");
      } else if (d.type === "navigate" && d.url) {
        const u = safeUrl(d.url);
        if (u) go(u);
      } else if (d.type === "page" && d.url) {
        setLoading(false);
        const ctx = {
          url: String(d.url),
          title: String(d.title ?? d.url).slice(0, 300),
          text: String(d.text ?? "").slice(0, 40000),
          selection: String(d.selection ?? "").slice(0, 8000) || undefined,
          capturedAt: Date.now(),
        };
        setBrowser(ctx);
        setAddress((a) => (document.activeElement?.tagName === "INPUT" ? a : ctx.url));
        void setKV("browser.current", { url: ctx.url, title: ctx.title });
      } else if (d.type === "addon-error") {
        useApp.getState().showToast(`Add-on "${d.name}" failed on this page`);
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [activeAddons, current, go, setBrowser]);

  const step = (delta: number) => {
    const next = cursor + delta;
    if (next < 0 || next >= stack.length) return;
    cursorRef.current = next;
    setCursor(next);
    go(stack[next], false);
  };

  const submit = () => {
    const u = safeUrl(address);
    if (u) go(u);
  };

  const saveAddons = async (next: Addon[]) => {
    setAddons(next);
    await setKV("browser.addons", next);
    if (current) setFrameKey((k) => k + 1);
  };

  const saveToLibrary = async () => {
    const projectId = location.hash.match(/#\/p\/([^/]+)/)?.[1];
    if (!projectId || !page) return useApp.getState().showToast("Open a project to save pages into it");
    const now = Date.now();
    const excerpt = page.text.slice(0, 1800);
    await db.notes.add({
      id: uid(), projectId, title: page.title.slice(0, 120) || "Web page",
      content: `Source: [${page.title}](${page.url})\n\n> ${excerpt.replace(/\n+/g, "\n> ")}${page.text.length > 1800 ? "\n>\n> …" : ""}`,
      createdAt: now, updatedAt: now,
    } as never);
    useApp.getState().showToast("Saved to library as a note");
  };

  if (!open) return null;

  const yt = current ? youtubeId(current) : null;
  const focusYoutube = addons.some((a) => a.id === "youtube-focus" && a.enabled);
  const embed = yt && focusYoutube ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(yt)}?rel=0&playsinline=1&modestbranding=1` : null;
  const enabledCount = addons.filter((a) => a.enabled).length;

  return (
    <div className="fixed inset-0 z-[45] flex flex-col bg-paper pt-[env(safe-area-inset-top)]" role="dialog" aria-modal="true" aria-label="Learning browser">
      <header className="flex h-14 shrink-0 items-center gap-1.5 border-b border-line px-2 sm:px-3">
        <IconBtn onClick={() => setOpen(false)} aria-label="Close browser"><X size={19} /></IconBtn>
        <IconBtn onClick={() => step(-1)} disabled={cursor <= 0} aria-label="Back" className="hidden sm:flex"><ArrowLeft size={17} /></IconBtn>
        <IconBtn onClick={() => step(1)} disabled={cursor >= stack.length - 1} aria-label="Forward" className="hidden sm:flex"><ArrowRight size={17} /></IconBtn>
        <form className="relative min-w-0 flex-1" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          {loading ? (
            <Loader2 size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 animate-spin text-muted" />
          ) : (
            <Globe2 size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          )}
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onFocus={(e) => e.currentTarget.select()}
            onBlur={(e) => { e.currentTarget.scrollLeft = 0; }}
            aria-label="Search or enter address"
            enterKeyHint="go"
            placeholder="Search or enter a website"
            className="h-10 w-full rounded-full bg-ink/[0.05] pl-10 pr-3 text-[16px] outline-none ring-1 ring-transparent focus:ring-ink/20"
          />
        </form>
        <IconBtn onClick={() => current && setFrameKey((k) => k + 1)} disabled={!current} aria-label="Reload"><RefreshCw size={16} /></IconBtn>
        <IconBtn onClick={() => setPanel(panel === "addons" ? "none" : "addons")} aria-label="Add-ons" className="relative">
          <Puzzle size={17} />
          {enabledCount > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-solid" />}
        </IconBtn>
      </header>

      <div className="relative min-h-0 flex-1">
        {!current ? (
          <div className="mx-auto max-w-2xl px-5 py-10">
            <h2 className="display text-[23px]">Browse with Leo</h2>
            <p className="mt-1 text-[14px] text-muted">
              Leo reads the page you're on, so you can ask about it, get quizzed on it or save it to your library. Add-ons strip the distractions.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {[
                ["Wikipedia", "https://en.m.wikipedia.org/wiki/Special:Random"],
                ["MDN Web Docs", "https://developer.mozilla.org/en-US/docs/Learn"],
                ["Khan Academy", "https://www.khanacademy.org/"],
                ["arXiv", "https://arxiv.org/"],
              ].map(([label, u]) => (
                <button key={u} onClick={() => go(u)} className="rounded-full bg-card px-3.5 py-2 text-[13px] ring-1 ring-line transition-colors hover:bg-ink/[0.03]">
                  {label}
                </button>
              ))}
            </div>
          </div>
        ) : embed ? (
          <div className="h-full overflow-y-auto">
            <div className="mx-auto max-w-4xl px-3 pt-4">
              <div className="aspect-video overflow-hidden rounded-2xl bg-black ring-1 ring-line">
                <iframe key={frameKey} src={embed} title="YouTube video" className="h-full w-full" allow="encrypted-media; picture-in-picture; fullscreen" allowFullScreen />
              </div>
              <p className="mt-3 text-[13px] text-muted">YouTube Focus is on: no recommendations, no Shorts, no comments. Just the video.</p>
            </div>
          </div>
        ) : (
          <iframe
            key={frameKey}
            ref={frame}
            src={`/api/browse?url=${encodeURIComponent(current)}`}
            title="Web page"
            sandbox="allow-scripts allow-forms"
            className="h-full w-full border-0 bg-white"
          />
        )}

        {panel === "addons" && (
          <aside className="absolute inset-y-0 right-0 z-10 w-full max-w-md overflow-y-auto border-l border-line bg-paper p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="display text-[20px]">Add-ons</h3>
              <IconBtn onClick={() => setPanel("none")} aria-label="Close add-ons"><X size={17} /></IconBtn>
            </div>
            <p className="mb-3 text-[13px] text-muted">Content scripts injected into matching pages. Pages run sandboxed, so add-ons can reshape them but never touch your library.</p>
            <div className="space-y-2">
              {addons.map((a) => (
                <div key={a.id} className="rounded-2xl bg-card p-3 ring-1 ring-line">
                  <div className="flex items-start gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="text-[14px] font-semibold">{a.name}</div>
                      <div className="text-[12px] text-muted">{a.hosts}</div>
                      <p className="mt-1 text-[13px] text-muted">{a.description}</p>
                    </div>
                    <button
                      role="switch"
                      aria-checked={a.enabled}
                      aria-label={`Toggle ${a.name}`}
                      onClick={() => void saveAddons(addons.map((x) => (x.id === a.id ? { ...x, enabled: !x.enabled } : x)))}
                      className={cn("relative h-6 w-10 shrink-0 rounded-full transition-colors", a.enabled ? "bg-ink" : "bg-ink/15")}
                    >
                      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-card shadow transition-transform", a.enabled ? "translate-x-[18px]" : "translate-x-0.5")} />
                    </button>
                  </div>
                  {!a.builtin && (
                    <button onClick={() => void saveAddons(addons.filter((x) => x.id !== a.id))} className="mt-2 flex items-center gap-1 text-[12px] text-danger-fg">
                      <Trash2 size={12} /> Remove
                    </button>
                  )}
                </div>
              ))}
            </div>
            {form.open ? (
              <div className="mt-4 space-y-3 rounded-2xl bg-card p-3 ring-1 ring-line">
                <Field label="Name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                <Field label="Sites (comma separated, * for all)"><input className={inputCls} value={form.hosts} placeholder="example.com" onChange={(e) => setForm({ ...form, hosts: e.target.value })} /></Field>
                <Field label="CSS"><textarea className={cn(inputCls, "h-20 font-mono text-[12px]")} value={form.css} placeholder=".sidebar{display:none}" onChange={(e) => setForm({ ...form, css: e.target.value })} /></Field>
                <Field label="Script (optional)"><textarea className={cn(inputCls, "h-20 font-mono text-[12px]")} value={form.code} placeholder="document.querySelector('.popup')?.remove()" onChange={(e) => setForm({ ...form, code: e.target.value })} /></Field>
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      if (!form.name.trim() || !form.hosts.trim() || !(form.css.trim() || form.code.trim())) return;
                      void saveAddons([...addons, { id: uid(), name: form.name.trim(), hosts: form.hosts.trim(), css: form.css, code: form.code, description: "Your add-on.", enabled: true }]);
                      setForm({ open: false, name: "", hosts: "", css: "", code: "" });
                    }}
                  >
                    Save add-on
                  </Button>
                  <Button variant="ghost" onClick={() => setForm({ ...form, open: false })}>Cancel</Button>
                </div>
              </div>
            ) : (
              <Button className="mt-4" variant="ghost" onClick={() => setForm({ ...form, open: true })}><Plus size={15} /> New add-on</Button>
            )}
          </aside>
        )}
      </div>

      {current && (
        <footer className="flex shrink-0 items-center gap-2 border-t border-line bg-paper/95 px-3 py-2 pb-[max(8px,env(safe-area-inset-bottom))]">
          <div className="flex sm:hidden">
            <IconBtn onClick={() => step(-1)} disabled={cursor <= 0} aria-label="Back"><ArrowLeft size={17} /></IconBtn>
            <IconBtn onClick={() => step(1)} disabled={cursor >= stack.length - 1} aria-label="Forward"><ArrowRight size={17} /></IconBtn>
          </div>
          <span className="min-w-0 flex-1 truncate text-[12px] text-muted">
            {page && !yt ? `Leo can read this page · ${page.text.split(/\s+/).length.toLocaleString()} words` : yt ? "Video" : "Loading…"}
          </span>
          <IconBtn onClick={() => window.open(current, "_blank", "noopener")} aria-label="Open in system browser"><ExternalLink size={16} /></IconBtn>
          <IconBtn onClick={() => void saveToLibrary()} disabled={!page} aria-label="Save page to library"><BookmarkPlus size={17} /></IconBtn>
          <Button size="sm" onClick={() => useApp.getState().setChatOpen(true)}>
            <Sparkles size={14} /> Ask Leo
          </Button>
          <ArrowUpRight size={0} className="hidden" />
        </footer>
      )}
    </div>
  );
}
