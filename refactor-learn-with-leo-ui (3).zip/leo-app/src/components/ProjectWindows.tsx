import { useCallback, useEffect, useRef, useState, type TouchEvent as RTouchEvent } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { History, Pin, StickyNote, Trash2 } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { confirmDeletion } from "@/lib/settings";
import { scratchWinId, useWindows, type FloatWin } from "@/lib/windows";
import { trashItem } from "@/lib/trash";
import { setPinned } from "@/lib/pins";
import ItemHistorySheet from "@/components/library/ItemHistorySheet";
import { FloatingWindow, WinBtn } from "@/components/FloatingWindow";
import { ToolBody, TOOL_ICON, TOOL_SIZE } from "@/components/tools/Tools";
import { cn } from "@/utils/cn";

const canHover = typeof window !== "undefined" && !!window.matchMedia?.("(hover: hover) and (pointer: fine)").matches;

/** Every floating window of a project — its open tools and its scratchpad — plus the edge that opens the scratchpad. */
export default function ProjectWindows({ project, edgeHidden }: { project: Project; edgeHidden?: boolean }) {
  const wins = useWindows((s) => s.wins);
  const tools = useLiveQuery(() => db.tools.where("projectId").equals(project.id).toArray(), [project.id]);
  const [historyToolId, setHistoryToolId] = useState<string | null>(null);
  const mine = wins.filter((w) => w.projectId === project.id);
  const order = mine.map((w) => w.id);

  // A tool removed from the library takes its window with it.
  useEffect(() => {
    if (!tools) return;
    for (const w of wins) if (w.projectId === project.id && w.kind === "tool" && !tools.some((t) => t.id === w.toolId && !t.deletedAt)) useWindows.getState().close(w.id);
  }, [tools, wins, project.id]);

  const focus = (id: string) => useWindows.getState().focus(id);
  const close = (id: string) => useWindows.getState().close(id);
  // Rendered in a stable order so focusing a window never remounts or moves another; stacking comes from z.
  const stable = [...mine].sort((a, b) => a.id.localeCompare(b.id));
  const scratchOpen = order.includes(scratchWinId(project.id));

  return (
    <>
      {stable.map((w: FloatWin) => {
        const z = 41 + Math.min(order.indexOf(w.id), 8);
        if (w.kind === "scratch") return <ScratchpadWindow key={w.id} project={project} z={z} onFocus={() => focus(w.id)} onClose={() => close(w.id)} />;
        const tool = tools?.find((t) => t.id === w.toolId);
        if (!tool || tool.deletedAt) return null;
        const remove = async () => {
          if (!(await confirmDeletion(`“${tool.title}” and what it saved will go to the Trash.`, { title: "Remove tool?", confirmLabel: "Remove" }))) return;
          close(w.id);
          await trashItem("tool", tool.id);
        };
        return (
          <FloatingWindow
            key={w.id}
            storageKey={`tool:${tool.id}`}
            label={tool.title}
            title={tool.title}
            icon={TOOL_ICON[tool.kind](15)}
            size={TOOL_SIZE[tool.kind]}
            minSize={{ w: 260, h: 220 }}
            index={order.indexOf(w.id)}
            z={z}
            onFocus={() => focus(w.id)}
            onClose={() => close(w.id)}
            actions={
              <>
                <WinBtn onClick={() => void setPinned("tool", tool.id, !tool.pinned)} label={tool.pinned ? "Unpin from Leo's context" : "Pin for Leo"} className={tool.pinned ? "bg-ink text-on-ink hover:bg-ink/90" : ""}>
                  <Pin size={13} fill={tool.pinned ? "currentColor" : "none"} />
                </WinBtn>
                <WinBtn onClick={() => setHistoryToolId(tool.id)} label="Version history">
                  <History size={14} />
                </WinBtn>
                <WinBtn onClick={() => void remove()} label="Remove tool" className="hover:bg-danger-bg hover:text-danger-fg">
                  <Trash2 size={14} />
                </WinBtn>
              </>
            }
          >
            <ToolBody tool={tool} />
          </FloatingWindow>
        );
      })}
      {historyToolId && <ItemHistorySheet kind="tool" id={historyToolId} open={!!historyToolId} onClose={() => setHistoryToolId(null)} />}
      {!scratchOpen && !edgeHidden && <ScratchpadEdge onOpen={() => useWindows.getState().open({ id: scratchWinId(project.id), kind: "scratch", projectId: project.id })} />}
    </>
  );
}

/* ---------------------------------------------------------------- scratchpad */

function ScratchpadWindow({ project, z, onFocus, onClose }: { project: Project; z: number; onFocus: () => void; onClose: () => void }) {
  const [text, setText] = useState(project.scratchpad ?? "");
  const [status, setStatus] = useState<"idle" | "saving" | "saved">("idle");
  const timer = useRef<number | undefined>(undefined);
  const pending = useRef<string | null>(null);
  const ta = useRef<HTMLTextAreaElement>(null);

  const flush = useCallback(async () => {
    window.clearTimeout(timer.current);
    const v = pending.current;
    if (v === null) return;
    pending.current = null;
    await db.projects.update(project.id, { scratchpad: v });
    setStatus("saved");
  }, [project.id]);

  // Whatever is still unsaved is written when the window closes or the project is left.
  useEffect(
    () => () => {
      window.clearTimeout(timer.current);
      if (pending.current !== null) void db.projects.update(project.id, { scratchpad: pending.current });
    },
    [project.id]
  );

  useEffect(() => {
    if (canHover) ta.current?.focus({ preventScroll: true });
  }, []);

  const onChange = (v: string) => {
    setText(v);
    pending.current = v;
    setStatus("saving");
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void flush(), 600);
  };

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;

  return (
    <FloatingWindow
      storageKey="scratchpad"
      label={`Scratchpad for ${project.name}`}
      variant="minimal"
      size={{ w: 360, h: 420 }}
      minSize={{ w: 240, h: 180 }}
      z={z}
      onFocus={onFocus}
      onClose={() => {
        void flush();
        onClose();
      }}
      title={
        <span className="flex items-center gap-2">
          <span className="text-[13px] font-semibold">Scratchpad</span>
          <span className="flex items-center gap-1 text-[11px] font-normal text-muted" aria-live="polite">
            <span className={cn("h-1.5 w-1.5 rounded-full transition-colors", status === "saving" ? "animate-pulse bg-warn-fg/70" : status === "saved" ? "bg-solid" : "bg-ink/15")} />
            {status === "saving" ? "Saving" : status === "saved" ? "Saved" : words ? `${words} ${words === 1 ? "word" : "words"}` : ""}
          </span>
        </span>
      }
      bodyClass="overflow-hidden"
    >
      <textarea
        ref={ta}
        value={text}
        onChange={(e) => onChange(e.target.value)}
        onBlur={() => void flush()}
        dir="auto"
        spellCheck
        placeholder="Jot something down…"
        aria-label="Scratchpad"
        className="block h-full w-full resize-none bg-transparent px-4 pb-6 pt-0.5 text-[15px] leading-[1.7] text-ink/90 outline-none placeholder:text-muted/50"
      />
    </FloatingWindow>
  );
}

/**
 * Opens the scratchpad from the screen edge. With a mouse it is a dock-style hotspot on the left
 * edge that swells as the pointer nears and opens after a short hover; touch screens have no
 * hover, so they get a small handle on the right edge to tap or swipe in.
 */
function ScratchpadEdge({ onOpen }: { onOpen: () => void }) {
  return canHover ? <HoverHotspot onOpen={onOpen} /> : <TouchHandle onOpen={onOpen} />;
}

function HoverHotspot({ onOpen }: { onOpen: () => void }) {
  const [near, setNear] = useState(false);
  const timer = useRef<number | undefined>(undefined);
  useEffect(() => () => window.clearTimeout(timer.current), []);
  return (
    <div
      className="fixed left-0 top-1/2 z-[39] flex h-48 w-2.5 -translate-y-1/2 items-center"
      onMouseEnter={() => {
        setNear(true);
        timer.current = window.setTimeout(onOpen, 280);
      }}
      onMouseLeave={() => {
        setNear(false);
        window.clearTimeout(timer.current);
      }}
      data-no-capture
    >
      <button
        type="button"
        onClick={onOpen}
        onFocus={() => setNear(true)}
        onBlur={() => setNear(false)}
        aria-label="Open scratchpad"
        title="Scratchpad"
        className={cn(
          "absolute left-0 flex items-center justify-center overflow-hidden rounded-r-2xl transition-[width,height,background-color,box-shadow,color] duration-200 ease-[var(--ease-spring)]",
          near ? "h-24 w-10 bg-card text-ink shadow-[0_8px_26px_rgba(0,0,0,0.14)] ring-1 ring-line" : "h-14 w-[5px] bg-ink/20 text-transparent"
        )}
      >
        <StickyNote size={17} />
      </button>
    </div>
  );
}

function TouchHandle({ onOpen }: { onOpen: () => void }) {
  const startX = useRef<number | null>(null);
  const onStart = (e: RTouchEvent) => {
    startX.current = e.touches[0]?.clientX ?? null;
  };
  const onMove = (e: RTouchEvent) => {
    const x = e.touches[0]?.clientX;
    if (startX.current !== null && x !== undefined && startX.current - x > 24) {
      startX.current = null;
      onOpen();
    }
  };
  return (
    <button
      type="button"
      onClick={onOpen}
      onTouchStart={onStart}
      onTouchMove={onMove}
      aria-label="Open scratchpad"
      className="fixed right-0 top-[36%] z-[39] flex h-16 w-7 touch-none items-center justify-end pr-1"
      data-no-capture
    >
      <span className="flex h-12 w-4 items-center justify-center rounded-l-xl bg-card/90 shadow-[0_4px_14px_rgba(0,0,0,0.12)] ring-1 ring-line backdrop-blur">
        <span className="h-6 w-[3px] rounded-full bg-ink/25" />
      </span>
    </button>
  );
}
