import { useEffect, useRef, useState, type CSSProperties, type PointerEvent as RPointerEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { ChevronUp, Minus, X } from "lucide-react";
import { cn } from "@/utils/cn";

/**
 * The one floating-window frame in the app. Leo's floating chat, every library tool and the
 * project scratchpad are built on it: draggable by the header, resizable from the corner,
 * minimizable to the header, and remembered (position, size, minimized) per window.
 */

/** Below this width the window becomes a compact, full-width floating panel. */
export const FLOAT_SMALL = 640;
/** Room kept free at the bottom for the floating Leo pill. */
export const DOCK_CLEARANCE = 96;
const MARGIN = 8;

export interface Viewport {
  w: number;
  h: number;
  top: number;
}

export function useViewport(): Viewport {
  const get = () => ({
    w: window.innerWidth,
    h: Math.round(window.visualViewport?.height ?? window.innerHeight),
    top: Math.round(window.visualViewport?.offsetTop ?? 0),
  });
  const [vp, setVp] = useState(get);
  useEffect(() => {
    const on = () => setVp(get());
    window.addEventListener("resize", on);
    window.visualViewport?.addEventListener("resize", on);
    window.visualViewport?.addEventListener("scroll", on);
    return () => {
      window.removeEventListener("resize", on);
      window.visualViewport?.removeEventListener("resize", on);
      window.visualViewport?.removeEventListener("scroll", on);
    };
  }, []);
  return vp;
}

export interface Frame {
  x: number;
  y: number;
  w: number;
  h: number;
  min?: boolean;
}

const readFrame = (key: string): Partial<Frame> | null => {
  try {
    const v = JSON.parse(localStorage.getItem(key) || "null");
    return v && typeof v === "object" ? (v as Partial<Frame>) : null;
  } catch {
    return null;
  }
};
const writeFrame = (key: string, f: Frame) => {
  try {
    localStorage.setItem(key, JSON.stringify(f));
  } catch {
    /* storage full or unavailable: the window just opens at its default spot next time */
  }
};
const clamp = (v: number, lo: number, hi: number) => Math.min(Math.max(v, lo), Math.max(lo, hi));
const num = (v: unknown, fallback: number) => (typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : fallback);

/** Where a window opens the first time: bottom-right on a computer, a compact panel above the dock on a phone. */
export function defaultFrame(vp: Viewport, size: { w: number; h: number }, index = 0): Frame {
  if (vp.w < FLOAT_SMALL) {
    const h = Math.min(size.h, Math.round(vp.h * 0.55));
    return { x: MARGIN, y: Math.max(MARGIN, vp.h - h - DOCK_CLEARANCE - index * 20), w: vp.w - MARGIN * 2, h };
  }
  const off = (index % 6) * 28;
  return { x: vp.w - size.w - 24 - off, y: Math.max(16, vp.h - size.h - DOCK_CLEARANCE - off), w: size.w, h: size.h };
}

export interface FloatFrame {
  style: CSSProperties;
  small: boolean;
  minimized: boolean;
  toggleMin: () => void;
  moveHandlers: {
    onPointerDown: (e: RPointerEvent) => void;
    onPointerMove: (e: RPointerEvent) => void;
    onPointerUp: () => void;
    onPointerCancel: () => void;
  };
  resizeHandlers: {
    onPointerDown: (e: RPointerEvent) => void;
    onPointerMove: (e: RPointerEvent) => void;
    onPointerUp: () => void;
    onPointerCancel: () => void;
  };
}

/** Position, size and minimized state of one floating window, clamped to the screen and saved under `storageKey`. */
export function useFloatFrame(
  storageKey: string,
  opts: { vp: Viewport; initial: (vp: Viewport) => Frame; minW?: number; minH?: number; headerH?: number; enabled?: boolean }
): FloatFrame {
  const { vp, minW = 260, minH = 180, headerH = 44, enabled = true } = opts;
  const [frame, setFrame] = useState<Frame>(() => {
    const base = opts.initial(vp);
    const saved = readFrame(storageKey);
    return saved
      ? { x: num(saved.x, base.x), y: num(saved.y, base.y), w: num(saved.w, base.w) || base.w, h: num(saved.h, base.h) || base.h, min: !!saved.min }
      : base;
  });

  const small = vp.w < FLOAT_SMALL;
  const w = small ? vp.w - MARGIN * 2 : clamp(frame.w, Math.min(minW, vp.w - MARGIN * 2), vp.w - MARGIN * 2);
  const h = clamp(frame.h, Math.min(minH, vp.h - MARGIN * 2), vp.h - MARGIN * 2);
  const shownH = frame.min ? headerH : h;
  const x = small ? MARGIN : clamp(frame.x, MARGIN, vp.w - w - MARGIN);
  const y = clamp(frame.y, MARGIN, vp.h - shownH - MARGIN);

  const latest = useRef<Frame>({ x, y, w: frame.w, h, min: frame.min });
  latest.current = { x, y, w: small ? frame.w : w, h, min: frame.min };

  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number; ow: number; oh: number; moved: boolean; mode: "move" | "resize" } | null>(null);

  const start = (mode: "move" | "resize") => (e: RPointerEvent) => {
    if (!enabled) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    if (mode === "move" && (e.target as HTMLElement).closest("button,select,input,textarea,label,a,[data-no-drag]")) return;
    drag.current = { sx: e.clientX, sy: e.clientY, ox: x, oy: y, ow: w, oh: h, moved: false, mode };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    if (mode === "resize") {
      e.preventDefault();
      e.stopPropagation();
    }
  };
  const move = (e: RPointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;
    if (!d.moved && Math.hypot(dx, dy) < 4) return;
    d.moved = true;
    if (d.mode === "move") setFrame((f) => ({ ...f, x: d.ox + dx, y: d.oy + dy }));
    else setFrame((f) => ({ ...f, x: d.ox, y: d.oy, w: Math.max(minW, d.ow + dx), h: Math.max(minH, d.oh + dy), min: false }));
  };
  const end = () => {
    const d = drag.current;
    drag.current = null;
    if (d?.moved) writeFrame(storageKey, latest.current);
  };

  const toggleMin = () => {
    const next = { ...latest.current, min: !latest.current.min };
    setFrame((f) => ({ ...f, min: next.min }));
    writeFrame(storageKey, next);
  };

  const handlers = (mode: "move" | "resize") => ({ onPointerDown: start(mode), onPointerMove: move, onPointerUp: end, onPointerCancel: end });

  return {
    style: { left: x, top: y + vp.top, width: w, height: shownH },
    small,
    minimized: !!frame.min,
    toggleMin,
    moveHandlers: handlers("move"),
    resizeHandlers: handlers("resize"),
  };
}

/** The corner grip that resizes a floating window. */
export function ResizeGrip({ handlers, className }: { handlers: FloatFrame["resizeHandlers"]; className?: string }) {
  return (
    <div
      {...handlers}
      role="separator"
      aria-label="Resize window"
      title="Drag to resize"
      className={cn("absolute bottom-0 right-0 z-30 flex h-[18px] w-[18px] cursor-nwse-resize touch-none items-end justify-end p-[3px] text-ink/30 hover:text-ink/60 [@media(pointer:coarse)]:h-6 [@media(pointer:coarse)]:w-6", className)}
    >
      <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden>
        <path d="M9 1 1 9M9 5 5 9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none" />
      </svg>
    </div>
  );
}

export function WinBtn({ onClick, label, children, className }: { onClick: () => void; label: string; children: ReactNode; className?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-ink/55 transition-colors hover:bg-ink/[0.06] hover:text-ink", className)}
    >
      {children}
    </button>
  );
}

export function FloatingWindow({
  storageKey,
  title,
  label,
  icon,
  actions,
  onClose,
  onFocus,
  z = 45,
  size,
  minSize,
  index = 0,
  variant = "default",
  bodyClass,
  children,
}: {
  storageKey: string;
  title: ReactNode;
  /** Accessible name of the window. */
  label: string;
  icon?: ReactNode;
  /** Extra header buttons, before minimize and close. */
  actions?: ReactNode;
  onClose: () => void;
  onFocus?: () => void;
  z?: number;
  size: { w: number; h: number };
  minSize?: { w: number; h: number };
  /** Cascades the first-time position of several windows. */
  index?: number;
  /** "minimal" drops the header rule and tint for a calmer surface (the scratchpad). */
  variant?: "default" | "minimal";
  bodyClass?: string;
  children: ReactNode;
}) {
  const vp = useViewport();
  const headerH = variant === "minimal" ? 40 : 44;
  const f = useFloatFrame(`harness.win.${storageKey}`, { vp, initial: (v) => defaultFrame(v, size, index), minW: minSize?.w ?? 240, minH: minSize?.h ?? 160, headerH });
  return createPortal(
    <div
      role="dialog"
      aria-label={label}
      data-float-window
      onPointerDownCapture={onFocus}
      className={cn(
        "panel-in fixed flex flex-col overflow-hidden rounded-2xl ring-1",
        variant === "minimal" ? "bg-card shadow-[0_18px_50px_rgba(0,0,0,0.13)] ring-black/[0.07]" : "bg-paper shadow-[0_20px_60px_rgba(0,0,0,0.20)] ring-black/10"
      )}
      style={{ ...f.style, zIndex: z }}
    >
      <header
        {...f.moveHandlers}
        onDoubleClick={(e) => {
          if (!(e.target as HTMLElement).closest("button,input,textarea,select")) f.toggleMin();
        }}
        className={cn(
          "flex shrink-0 cursor-grab touch-none select-none items-center gap-1 pl-3 pr-1 active:cursor-grabbing",
          variant === "minimal" ? "h-10" : "h-11 border-b border-line/80 bg-card/85 backdrop-blur",
          f.minimized && "border-b-0"
        )}
      >
        {icon && <span className="mr-0.5 flex shrink-0 text-muted">{icon}</span>}
        <div className="min-w-0 flex-1 truncate text-[13px] font-semibold">{title}</div>
        {actions}
        <WinBtn onClick={f.toggleMin} label={f.minimized ? "Restore" : "Minimize"}>
          {f.minimized ? <ChevronUp size={15} /> : <Minus size={15} />}
        </WinBtn>
        <WinBtn onClick={onClose} label="Close">
          <X size={15} />
        </WinBtn>
      </header>
      <div className={cn("@container relative min-h-0 flex-1 overflow-y-auto overscroll-contain", f.minimized && "hidden", bodyClass)}>{children}</div>
      {!f.minimized && <ResizeGrip handlers={f.resizeHandlers} />}
    </div>,
    document.body
  );
}
