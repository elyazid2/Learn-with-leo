import { Check, Server } from "lucide-react";
import { db, type ProviderType } from "@/lib/db";
import { cn } from "@/utils/cn";
import openai from "@/assets/providers/openai.svg?raw";
import anthropic from "@/assets/providers/anthropic.svg?raw";
import gemini from "@/assets/providers/gemini.svg?raw";
import openrouter from "@/assets/providers/openrouter.svg?raw";
import nvidia from "@/assets/providers/nvidia.svg?raw";
import groq from "@/assets/providers/groq.svg?raw";
import ollama from "@/assets/providers/ollama.svg?raw";
import lmstudio from "@/assets/providers/lmstudio.svg?raw";

/** Bundled, trusted SVG markup (see src/assets/providers/LICENSE.md). Mono logos follow the text color. */
const LOGOS = { openai, anthropic, gemini, openrouter, nvidia, groq, ollama, lmstudio } as const;
export type LogoKey = keyof typeof LOGOS;

/** Normalize a legacy display typo without changing the learner's saved connection. */
export const providerDisplayName = (name?: string) => (name || "Provider").replace(/\bOpenAIh\b/gi, "OpenAI");

const isLogo = (k: string | undefined): k is LogoKey => !!k && k in LOGOS;

/** Recognize a provider by its endpoint first (most reliable), then by name, then by API type. */
const BY_HOST: [RegExp, LogoKey][] = [
  [/api\.openai\.com/i, "openai"],
  [/anthropic\.com/i, "anthropic"],
  [/generativelanguage\.googleapis\.com|googleapis\.com/i, "gemini"],
  [/openrouter\.ai/i, "openrouter"],
  [/nvidia\.com|^\/api\/nim/i, "nvidia"],
  [/groq\.com/i, "groq"],
  [/:11434\b/, "ollama"],
  [/:1234\b/, "lmstudio"],
];
const BY_NAME: [RegExp, LogoKey][] = [
  [/openrouter/i, "openrouter"],
  // "OpenAI-compatible" describes the API shape, not the company.
  [/openai(?![-\s]*compatible)/i, "openai"],
  [/anthropic|claude/i, "anthropic"],
  [/gemini|google/i, "gemini"],
  [/nvidia|\bnim\b/i, "nvidia"],
  [/groq/i, "groq"],
  [/ollama/i, "ollama"],
  [/lm ?studio/i, "lmstudio"],
];

export function logoKeyFor(p: { key?: string; type: ProviderType; name?: string; baseUrl?: string }): LogoKey | null {
  if (isLogo(p.key)) return p.key;
  if (p.key === "custom") return null;
  const url = p.baseUrl ?? "";
  for (const [re, key] of BY_HOST) if (re.test(url)) return key;
  const name = providerDisplayName(p.name ?? "");
  for (const [re, key] of BY_NAME) if (re.test(name)) return key;
  if (p.type === "anthropic") return "anthropic";
  if (p.type === "gemini") return "gemini";
  return null;
}

/** Fix any saved provider whose name had the "OpenAIh" typo. */
export async function repairProviderNames() {
  const all = await db.providers.toArray();
  for (const p of all) {
    const fixed = providerDisplayName(p.name);
    if (fixed !== p.name) await db.providers.update(p.id, { name: fixed });
  }
}

/** A provider's real logo on a neutral tile; unknown OpenAI-compatible endpoints get a server glyph. */
export default function ProviderLogo({
  provider,
  size = 36,
  selected = false,
  className,
}: {
  provider: { key?: string; type: ProviderType; name?: string; baseUrl?: string };
  size?: number;
  selected?: boolean;
  className?: string;
}) {
  const key = logoKeyFor(provider);
  const glyph = Math.round(size * 0.56);
  return (
    <span
      role="img"
      aria-label={`${providerDisplayName(provider.name)} logo`}
      className={cn(
        "relative flex shrink-0 items-center justify-center rounded-xl bg-card text-ink ring-1",
        selected ? "ring-ink/35" : "ring-line",
        className
      )}
      style={{ width: size, height: size }}
    >
      {key ? (
        <span aria-hidden className="block" style={{ width: glyph, height: glyph }} dangerouslySetInnerHTML={{ __html: LOGOS[key] }} />
      ) : (
        <Server aria-hidden size={Math.round(size * 0.5)} strokeWidth={1.75} className="text-muted" />
      )}
      {selected && (
        <span
          aria-hidden
          className=" absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-ink text-white ring-2 ring-card"
        >
          <Check size={10} strokeWidth={3} />
        </span>
      )}
    </span>
  );
}
