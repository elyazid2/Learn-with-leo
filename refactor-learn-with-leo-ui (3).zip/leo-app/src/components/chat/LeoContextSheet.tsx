import { useLiveQuery } from "dexie-react-hooks";
import { useShallow } from "zustand/react/shallow";
import { BookOpen, Eye, FileText, Film, Globe2, Image as ImageIcon, MessageCircle, PenTool, Pin, Quote, Wrench, X } from "lucide-react";
import { db, type Project } from "@/lib/db";
import { pinnedItems, setPinned, type PinnedItem } from "@/lib/pins";
import { buildSystemPrompt } from "@/lib/ai/prompt";
import { stripActions } from "@/lib/ai/actions";
import { useApp } from "@/lib/store";
import { navigate, projectPath } from "@/lib/router";
import { openToolWindow } from "@/lib/windows";
import { Sheet } from "@/components/ui";
import { cn } from "@/utils/cn";

/** Rough token estimate (~4 characters per token) against a 32k-token working context budget. */
const CONTEXT_BUDGET_TOKENS = 32_000;
const estTokens = (chars: number) => Math.max(1, Math.round(chars / 4));
const fmtTokens = (tokens: number) => (tokens >= 1000 ? `~${(tokens / 1000).toFixed(1)}k tok` : `~${tokens} tok`);

export default function LeoContextSheet({
  project,
  open,
  onClose,
}: {
  project: Project;
  open: boolean;
  onClose: () => void;
}) {
  const { note, pdf, image, sketch, video, browser, selection } = useApp(
    useShallow((s) => ({
      note: s.note,
      pdf: s.pdf,
      image: s.image,
      sketch: s.sketch,
      video: s.video,
      browser: s.browser,
      selection: s.selection,
    }))
  );
  const activeThreadId = useApp((s) => s.activeThread[project.id]);

  const data = useLiveQuery(async () => {
    const [pinned, thread, allMsgs, sysPrompt] = await Promise.all([
      pinnedItems(project.id),
      activeThreadId ? db.threads.get(activeThreadId) : undefined,
      activeThreadId ? db.messages.where("threadId").equals(activeThreadId).sortBy("createdAt") : Promise.resolve([]),
      buildSystemPrompt(project, "ask"),
    ]);
    const recentMsgs = allMsgs.filter((m) => !m.error && !m.partial && !m.hidden).slice(-40);
    const chatChars = recentMsgs.reduce((sum, m) => sum + m.content.length, 0);
    const pinnedChars = pinned.reduce((sum, p) => sum + p.chars + p.title.length + 24, 0);
    const baseSystemChars = Math.max(0, sysPrompt.length - pinnedChars);
    return { pinned, thread, recentMsgs, chatChars, pinnedChars, baseSystemChars };
  }, [project.id, activeThreadId, open]);

  const openItems: { key: string; title: string; detail: string; chars: number; icon: React.ReactNode }[] = [];
  if (pdf) {
    openItems.push({
      key: "pdf",
      title: pdf.name,
      detail: `Open PDF · page ${pdf.page} of ${pdf.pages}`,
      chars: Math.min(pdf.text.length, 8000),
      icon: <FileText size={15} />,
    });
  }
  if (note) {
    openItems.push({
      key: "note",
      title: note.title || "Untitled note",
      detail: "Open note",
      chars: Math.min(note.content.length, 12000),
      icon: <FileText size={15} />,
    });
  }
  if (sketch) {
    openItems.push({
      key: "sketch",
      title: sketch.title || "Sketch",
      detail: "Open sketchboard (attached as image)",
      chars: 1200,
      icon: <PenTool size={15} />,
    });
  }
  if (image) {
    openItems.push({
      key: "image",
      title: image.name,
      detail: "Open picture / video frame (attached as image)",
      chars: 1200,
      icon: <ImageIcon size={15} />,
    });
  }
  if (video) {
    openItems.push({
      key: "video",
      title: video.title,
      detail: video.text ? "Watching video · transcript shared" : "Watching video · no transcript yet",
      chars: Math.min(video.text.length, 9000),
      icon: <Film size={15} />,
    });
  }
  if (browser) {
    openItems.push({
      key: "browser",
      title: browser.title || browser.url,
      detail: "Open browser page",
      chars: Math.min((browser.selection || browser.text).length, 12000),
      icon: <Globe2 size={15} />,
    });
  }
  if (selection) {
    openItems.push({
      key: "selection",
      title: `“${selection.text.slice(0, 60)}${selection.text.length > 60 ? "…" : ""}”`,
      detail: `Selected text from ${selection.source}`,
      chars: Math.min(selection.text.length, 6000),
      icon: <Quote size={15} />,
    });
  }

  const openChars = openItems.reduce((sum, item) => sum + item.chars, 0);
  const pinnedChars = data?.pinnedChars ?? 0;
  const chatChars = data?.chatChars ?? 0;
  const baseChars = data?.baseSystemChars ?? 3200;
  const totalTokens = estTokens(baseChars + pinnedChars + openChars + chatChars);
  const pct = Math.min(100, Math.max(1, Math.round((totalTokens / CONTEXT_BUDGET_TOKENS) * 100)));

  const jumpToPinned = (p: PinnedItem) => {
    onClose();
    if (p.kind === "note") navigate(projectPath(project.id, "notes", p.id));
    else if (p.kind === "sketch") navigate(projectPath(project.id, "sketch", p.id));
    else if (p.kind === "file") navigate(projectPath(project.id, "library", p.id));
    else openToolWindow(project.id, p.id);
  };

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Leo's context"
      description={`What Leo currently sees in ${project.name}. Pins belong to this project only.`}
      wide
    >
      <div className="space-y-5">
        {/* Context fullness meter */}
        <section className="rounded-2xl bg-ink/[0.035] p-3.5 ring-1 ring-line" aria-label="Context fullness">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-[13px] font-semibold">Context fullness</span>
            <span className="text-[12px] font-medium tabular-nums text-muted">
              {pct}% full · {fmtTokens(totalTokens)} of {fmtTokens(CONTEXT_BUDGET_TOKENS)}
            </span>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink/10">
            <div
              className={cn("h-full rounded-full transition-[width]", pct > 85 ? "bg-danger-fg" : pct > 60 ? "bg-warn-fg" : "bg-ink")}
              style={{ width: `${pct}%` }}
            />
          </div>
          <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1 text-[11.5px] text-muted tabular-nums">
            <span>Pinned: {fmtTokens(estTokens(pinnedChars))}</span>
            <span>Open view: {fmtTokens(estTokens(openChars))}</span>
            <span>Recent chat: {fmtTokens(estTokens(chatChars))}</span>
            <span>Map & index: {fmtTokens(estTokens(baseChars))}</span>
          </div>
        </section>

        {/* Pinned items */}
        <section aria-label="Pinned items">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-[13px] font-semibold">
              <Pin size={13} /> Pinned for Leo in {project.name}
            </h3>
            <span className="text-[12px] tabular-nums text-muted">{data?.pinned.length ?? 0}</span>
          </div>
          {!data?.pinned.length ? (
            <p className="rounded-2xl bg-card px-3.5 py-3 text-[13px] text-muted ring-1 ring-line">
              Nothing pinned in this project. Pin any note, file, sketch or tool so it is always in Leo&apos;s context here.
            </p>
          ) : (
            <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-card ring-1 ring-line">
              {data.pinned.map((p) => (
                <li key={`${p.kind}-${p.id}`} className="flex items-center gap-2.5 px-3.5 py-2.5">
                  <button
                    type="button"
                    onClick={() => jumpToPinned(p)}
                    className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-muted">
                      {p.kind === "note" ? <FileText size={15} /> : p.kind === "sketch" ? <PenTool size={15} /> : p.kind === "tool" ? <Wrench size={15} /> : <BookOpen size={15} />}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14px] font-medium" dir="auto">{p.title}</span>
                      <span className="block truncate text-[11.5px] text-muted">
                        {p.subtitle} · {fmtTokens(estTokens(p.chars))}
                      </span>
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void setPinned(p.kind, p.id, false)}
                    aria-label={`Unpin ${p.title}`}
                    title="Unpin"
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-muted hover:bg-ink/[0.06] hover:text-ink"
                  >
                    <X size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Open PDF page or item */}
        <section aria-label="Open item in workspace">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-[13px] font-semibold">
              <Eye size={14} /> Open PDF page or item
            </h3>
            <span className="text-[12px] tabular-nums text-muted">{openItems.length}</span>
          </div>
          {openItems.length === 0 ? (
            <p className="rounded-2xl bg-card px-3.5 py-3 text-[13px] text-muted ring-1 ring-line">
              No PDF page, note, sketch or selection is currently open. When you open one, Leo sees that active view automatically.
            </p>
          ) : (
            <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-card ring-1 ring-line">
              {openItems.map((it) => (
                <li key={it.key} className="flex items-center gap-2.5 px-3.5 py-2.5">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-ink/[0.05] text-muted">
                    {it.icon}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium" dir="auto">{it.title}</span>
                    <span className="block truncate text-[11.5px] text-muted">
                      {it.detail} · {fmtTokens(estTokens(it.chars))}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Recent chat */}
        <section aria-label="Recent chat in context">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-[13px] font-semibold">
              <MessageCircle size={14} /> Recent chat
            </h3>
            <span className="text-[12px] tabular-nums text-muted">
              {data?.recentMsgs.length ?? 0} {(data?.recentMsgs.length ?? 0) === 1 ? "message" : "messages"} · {fmtTokens(estTokens(chatChars))}
            </span>
          </div>
          {!data?.recentMsgs.length ? (
            <p className="rounded-2xl bg-card px-3.5 py-3 text-[13px] text-muted ring-1 ring-line">
              No messages in the current chat yet. Up to the last 40 messages of the active chat are sent with each turn.
            </p>
          ) : (
            <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-line">
              <div className="border-b border-line bg-ink/[0.025] px-3.5 py-2 text-[12px] font-medium text-muted">
                {data.thread?.title || "Current chat"} · last {data.recentMsgs.length} of 40 message window
              </div>
              <ul className="max-h-44 divide-y divide-line overflow-y-auto">
                {data.recentMsgs.slice(-6).reverse().map((m) => (
                  <li key={m.id} className="px-3.5 py-2 text-[12.5px]">
                    <span className="font-semibold text-ink">{m.role === "assistant" ? "Leo: " : "You: "}</span>
                    <span className="text-muted" dir="auto">
                      {stripActions(m.content).slice(0, 140) || "(action)"}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      </div>
    </Sheet>
  );
}
